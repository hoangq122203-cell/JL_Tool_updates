@echo off
chcp 65001 >nul
cd /d "C:\Tool quản lý kênh"
title JL Tool - He Thong Quan Ly TikTok

:: Giải phóng bất kỳ tiến trình Tool cũ nào đang treo ngầm
taskkill /f /im pythonw.exe >nul 2>&1
powershell -Command "Get-CimInstance Win32_Process -Filter \"CommandLine like '%%main.py%%' and Name like 'python%%'\" | ForEach-Object { Stop-Process -Id $_.ProcessId -Force }" >nul 2>&1
ping 127.0.0.1 -n 2 >nul

set "PY_EXE=%LOCALAPPDATA%\Programs\Python\Python311\pythonw.exe"
if exist "%PY_EXE%" (
    start "" "%PY_EXE%" "C:\Tool quản lý kênh\main.py"
    exit /b 0
)

start "" pythonw "C:\Tool quản lý kênh\main.py"
exit /b 0
