@echo off
chcp 65001 >nul
cd /d "C:\Tool quản lý kênh"
title JL Tool - He Thong Quan Ly TikTok

taskkill /f /im pythonw.exe >nul 2>&1
ping 127.0.0.1 -n 2 >nul

set "PY_EXE=%LOCALAPPDATA%\Programs\Python\Python311\pythonw.exe"
if exist "%PY_EXE%" (
    start "" "%PY_EXE%" "C:\Tool quản lý kênh\main.py"
    exit /b
)

start "" pythonw "C:\Tool quản lý kênh\main.py"
exit /b
