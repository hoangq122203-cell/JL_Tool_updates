import sys
import builtins
# Đảm bảo sys luôn luôn có mặt ở mọi scope, mọi thread và mọi dynamic module
builtins.sys = sys
import os
import time
from pathlib import Path

# Đảm bảo thư mục làm việc luôn luôn trỏ đúng về thư mục gốc của Tool
BASE_DIR = Path(__file__).resolve().parent
os.chdir(str(BASE_DIR))
if str(BASE_DIR) not in sys.path:
    sys.path.insert(0, str(BASE_DIR))

# Đảm bảo console Windows hỗ trợ UTF-8 mượt mà
if sys.platform == "win32":
    try:
        if hasattr(sys.stdout, "reconfigure") and sys.stdout:
            sys.stdout.reconfigure(encoding="utf-8")
        if hasattr(sys.stderr, "reconfigure") and sys.stderr:
            sys.stderr.reconfigure(encoding="utf-8")
    except Exception:
        pass

def global_excepthook(exc_type, exc_value, exc_traceback):
    """Ghi lại lỗi chi tiết vào file crash.log và hiển thị thông báo rõ ràng kèm nguồn phát sinh"""
    import traceback
    err_text = "".join(traceback.format_exception(exc_type, exc_value, exc_traceback))
    try:
        with open("crash.log", "a", encoding="utf-8") as f:
            f.write(f"\n[{time.strftime('%Y-%m-%d %H:%M:%S')}] LỖI HỆ THỐNG:\n{err_text}\n")
            f.flush()
    except Exception:
        pass
    try:
        from PySide6.QtWidgets import QMessageBox
        tb_last = traceback.extract_tb(exc_traceback)[-1] if exc_traceback else None
        loc_info = f"\n\nVị trí: {os.path.basename(tb_last.filename)} (dòng {tb_last.lineno})" if tb_last else ""
        QMessageBox.critical(None, "Lỗi Chạy JL Tool", f"Đã xảy ra lỗi:\n\n{exc_value}{loc_info}\n\nChi tiết xem tại file crash.log")
    except Exception:
        pass

sys.excepthook = global_excepthook

# Kiểm tra sớm các thư viện bắt buộc khi chuyển sang máy tính mới
try:
    import PySide6
    import playwright
    import requests
    import PIL
    import yt_dlp
except ImportError as err:
    if sys.platform == "win32":
        try:
            import ctypes
            missing_msg = (
                f"Phần mềm JL Tool phát hiện máy tính của bạn chưa được cài đặt đủ thư viện hoạt động:\n\n"
                f"Chi tiết: {err}\n\n"
                f"👉 Vui lòng nhấp đúp chuột vào file 'Cai_Dat_JL_Tool.bat' trong thư mục để tự động cài đặt 1-Click!"
            )
            ctypes.windll.user32.MessageBoxW(0, missing_msg, "JL Tool - Cần Cài Đặt Môi Trường", 0x30)
        except Exception:
            pass
    sys.exit(1)

import time
from PySide6.QtWidgets import QApplication
from PySide6.QtGui import QIcon, QFont
from PySide6.QtCore import Qt, QTimer
from ui.main_window import MainWindow
from ui.styles import DARK_THEME_QSS
from ui.splash_screen import JLSplashScreen
import config

def main():
    if sys.platform == "win32":
        try:
            import ctypes
            ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("JLTool.Desktop.App")
        except Exception:
            pass

    os.environ["QT_AUTO_SCREEN_SCALE_FACTOR"] = "1"
    
    app = QApplication(sys.argv)
    app.setStyle("Fusion")
    # Đảm bảo khi tắt cửa sổ chính, Tool không bị tắt mà tiếp tục chạy ngầm trên khay hệ thống
    app.setQuitOnLastWindowClosed(False)

    # ----------------- KIỂM TRA DUY NHẤT 1 PHIÊN BẢN (SINGLE INSTANCE WINDOWS MUTEX) -----------------
    import ctypes
    import ctypes.wintypes
    ERROR_ALREADY_EXISTS = 183
    _kernel32 = ctypes.windll.kernel32
    _user32 = ctypes.windll.user32

    # Mutex cấp Kernel Windows: Tuyệt đối chính xác, tự giải phóng khi app đóng hoặc crash
    app_mutex = _kernel32.CreateMutexW(None, False, "Global\\JL_TOOL_SINGLE_INSTANCE_MUTEX_V2")
    if _kernel32.GetLastError() == ERROR_ALREADY_EXISTS:
        # Đã có một phiên bản JL Tool đang chạy! Tìm và đưa cửa sổ đang chạy lên màn hình chính
        def enum_windows_callback(h, lparam):
            length = _user32.GetWindowTextLengthW(h)
            if length > 0:
                buff = ctypes.create_unicode_buffer(length + 1)
                _user32.GetWindowTextW(h, buff, length + 1)
                if "JL Tool" in buff.value:
                    _user32.ShowWindow(h, 9)  # SW_RESTORE
                    _user32.SetForegroundWindow(h)
                    return False
            return True
        try:
            WNDENUMPROC = ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.wintypes.HWND, ctypes.wintypes.LPARAM)
            _user32.EnumWindows(WNDENUMPROC(enum_windows_callback), 0)
        except Exception:
            pass
        sys.exit(0)

    from PySide6.QtNetwork import QLocalSocket, QLocalServer

    SERVER_NAME = "JLTool_SingleInstance_App_Server_v3"
    is_minimized_boot = "--minimized" in sys.argv

    # TIẾN TRÌNH DUY NHẤT (CHÍNH)
    QLocalServer.removeServer(SERVER_NAME)
    local_server = QLocalServer()
    local_server.listen(SERVER_NAME)

    main_win = None
    splash_ref = None

    def handle_client_connection():
        client = local_server.nextPendingConnection()
        if not client:
            return

        def on_ready_read():
            try:
                data = bytes(client.readAll())
                if b"RESTORE" in data:
                    if main_win:
                        main_win.restore_window()
                        client.write(b"ACK\n")
                        client.flush()
                        client.waitForBytesWritten(300)
                    elif splash_ref:
                        splash_ref.startup_finished.emit()
                        client.write(b"ACK\n")
                        client.flush()
                        client.waitForBytesWritten(300)
            except Exception:
                pass

        if client.bytesAvailable() > 0:
            on_ready_read()
        else:
            client.readyRead.connect(on_ready_read)

    local_server.newConnection.connect(handle_client_connection)

    def cleanup_single_instance():
        try:
            local_server.close()
            QLocalServer.removeServer(SERVER_NAME)
        except Exception:
            pass

    app.aboutToQuit.connect(cleanup_single_instance)

    # Đảm bảo đăng ký tự khởi động cùng Windows khi người dùng mở máy tính
    try:
        from core.startup_manager import enable_windows_startup, is_windows_startup_enabled, keep_system_awake
        if not is_windows_startup_enabled():
            enable_windows_startup(True)
        keep_system_awake(True)
    except Exception:
        pass

    # Cấu hình phông chữ hệ thống hiện đại, sắc nét và chuyên nghiệp
    sys_font = QFont("Segoe UI", 10)
    sys_font.setStyleHint(QFont.SansSerif)
    sys_font.setWeight(QFont.Medium)
    app.setFont(sys_font)

    # Cấu hình bảng màu chuẩn: Chỉ chuột vào tooltip luôn hiển thị chữ trắng tinh trên nền tối viền xanh
    from PySide6.QtGui import QPalette, QColor
    palette = app.palette()
    palette.setColor(QPalette.ToolTipBase, QColor("#1E293B"))
    palette.setColor(QPalette.ToolTipText, QColor("#FFFFFF"))
    app.setPalette(palette)

    app.setStyleSheet(DARK_THEME_QSS)

    # Đặt icon ứng dụng cho toàn hệ thống
    icon_path = str(config.BASE_DIR / "assets" / "icon.png")
    if not os.path.exists(icon_path):
        icon_path = str(config.BASE_DIR / "assets" / "icon.ico")
    if os.path.exists(icon_path):
        app_icon = QIcon(icon_path)
        app.setWindowIcon(app_icon)

    # ----------------- BẢO VỆ BẢN QUYỀN MÁY TÍNH (HWID LICENSE) -----------------
    from core.license_manager import license_mgr
    from ui.components.license_dialog import LicenseDialog

    is_licensed, lic_msg, lic_info = license_mgr.check_current_license()
    if not is_licensed:
        lic_dlg = LicenseDialog(is_mandatory=True)
        if lic_dlg.exec() != LicenseDialog.Accepted:
            cleanup_single_instance()
            sys.exit(0)
        is_licensed, lic_msg, lic_info = license_mgr.check_current_license()

    # Khởi động chế độ chạy ngầm nếu được gọi từ Windows Startup (--minimized)
    if is_minimized_boot:
        main_win = MainWindow()
        if os.path.exists(icon_path):
            main_win.setWindowIcon(QIcon(icon_path))
        main_win.hide()
        from core.scheduler_service import scheduler_service
        if not scheduler_service.is_running:
            scheduler_service.start()
        sys.exit(app.exec())

    # Khởi động màn hình chào mừng (Startup Splash Screen) chuyên nghiệp
    splash = JLSplashScreen()
    splash_ref = splash
    if os.path.exists(icon_path):
        splash.setWindowIcon(QIcon(icon_path))

    def on_startup_finished():
        nonlocal main_win
        main_win = MainWindow()
        if os.path.exists(icon_path):
            main_win.setWindowIcon(QIcon(icon_path))
        main_win.show()
        main_win.showNormal()
        main_win.raise_()
        main_win.activateWindow()
        if sys.platform == "win32":
            try:
                import ctypes
                hwnd = int(main_win.winId())
                ctypes.windll.user32.ShowWindow(hwnd, 9)  # 9 = SW_RESTORE
                HWND_TOPMOST = -1
                HWND_NOTOPMOST = -2
                SWP_NOSIZE = 0x0001
                SWP_NOMOVE = 0x0002
                SWP_SHOWWINDOW = 0x0040
                ctypes.windll.user32.SetWindowPos(hwnd, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_SHOWWINDOW)
                ctypes.windll.user32.SetWindowPos(hwnd, HWND_NOTOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_SHOWWINDOW)
                ctypes.windll.user32.SetForegroundWindow(hwnd)
                try:
                    ctypes.windll.user32.SwitchToThisWindow(hwnd, True)
                except Exception:
                    pass
            except Exception:
                pass

        # Cập nhật nhãn bản quyền & nhắc gia hạn nếu còn <= 3 ngày
        main_win.update_license_badge()
        if is_licensed and not lic_info.get("is_lifetime") and lic_info.get("days_left", 999) <= 3:
            rem_days = lic_info.get("days_left", 0)
            exp_date_str = lic_info.get("exp_date_str", "")
            from PySide6.QtWidgets import QMessageBox
            QTimer.singleShot(2500, lambda: QMessageBox.warning(
                main_win,
                "🔔 Nhắc Nhở Gia Hạn Bản Quyền",
                f"Bản quyền phần mềm của bạn còn {rem_days} ngày (Hết hạn ngày {exp_date_str}).\n\n"
                f"Vui lòng liên hệ Admin sớm để gia hạn bản quyền, đảm bảo lịch đăng không bị gián đoạn!"
            ))

    splash.startup_finished.connect(on_startup_finished)
    splash.start_loading()

    sys.exit(app.exec())

if __name__ == "__main__":
    main()
