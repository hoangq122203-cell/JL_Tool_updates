import sys
import sqlite3
import os
from datetime import datetime, date, timedelta
from pathlib import Path
from typing import List, Dict, Any, Optional
import config

class DatabaseManager:
    def __init__(self, db_path: str = str(config.DB_PATH)):
        self.db_path = db_path
        self._init_db()

    def _get_connection(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path, timeout=60.0)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA busy_timeout = 60000;")
        conn.execute("PRAGMA cache_size = -32000;")  # 32MB bộ nhớ đệm RAM siêu tốc
        conn.execute("PRAGMA synchronous = NORMAL;")
        return conn

    def _init_db(self):
        """Khởi tạo cấu trúc các bảng dữ liệu nếu chưa tồn tại"""
        with self._get_connection() as conn:
            conn.execute("PRAGMA journal_mode = WAL;")
            conn.execute("PRAGMA synchronous = NORMAL;")
            cursor = conn.cursor()

            # Bảng Cài đặt
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS settings (
                    key TEXT PRIMARY KEY,
                    value TEXT
                )
            """)

            # Bảng Kênh TikTok
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS channels (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT NOT NULL,
                    username TEXT,
                    avatar TEXT,
                    profile_dir TEXT UNIQUE NOT NULL,
                    video_folder TEXT,
                    status TEXT DEFAULT 'active',
                    is_logged_in INTEGER DEFAULT 0,
                    posted_count INTEGER DEFAULT 0,
                    note TEXT,
                    network_type TEXT DEFAULT 'direct', -- direct, proxy, hma, pia
                    proxy_string TEXT DEFAULT '',
                    vpn_region TEXT DEFAULT '',
                    last_ip TEXT DEFAULT '',
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    last_login_check TIMESTAMP
                )
            """)

            # Tự động nâng cấp cột nếu database cũ chưa có
            columns_to_add = [
                ("network_type", "TEXT DEFAULT 'vpn'"),
                ("proxy_string", "TEXT DEFAULT ''"),
                ("vpn_region", "TEXT DEFAULT ''"),
                ("last_ip", "TEXT DEFAULT ''"),
                ("pia_username", "TEXT DEFAULT ''"),
                ("pia_password", "TEXT DEFAULT ''"),
                ("use_vpn", "INTEGER DEFAULT 1"),
                ("ai_autopilot", "INTEGER DEFAULT 1"),
                ("youtube_source_url", "TEXT DEFAULT ''"),
                ("youtube_channel_name", "TEXT DEFAULT ''"),
                ("crop_frame", "TEXT DEFAULT 'original'"),
                ("followers_count", "INTEGER DEFAULT 0"),
                ("views_count", "INTEGER DEFAULT 0"),
                ("auto_series_config", "TEXT DEFAULT ''")
            ]
            for col_name, col_type in columns_to_add:
                try:
                    cursor.execute(f"ALTER TABLE channels ADD COLUMN {col_name} {col_type}")
                except sqlite3.OperationalError:
                    pass

            # Bảng Video thư viện
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS videos (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    channel_id INTEGER,
                    title TEXT NOT NULL,
                    file_path TEXT NOT NULL,
                    duration REAL DEFAULT 0,
                    file_size INTEGER DEFAULT 0,
                    caption TEXT,
                    hashtags TEXT,
                    cover_path TEXT,
                    is_posted INTEGER DEFAULT 0,
                    posted_at TIMESTAMP,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (channel_id) REFERENCES channels (id) ON DELETE SET NULL
                )
            """)

            for col_name, col_type in [
                ("duration", "REAL DEFAULT 0"),
                ("file_size", "INTEGER DEFAULT 0"),
                ("caption", "TEXT DEFAULT ''"),
                ("hashtags", "TEXT DEFAULT ''"),
                ("cover_path", "TEXT DEFAULT ''"),
                ("is_posted", "INTEGER DEFAULT 0"),
                ("posted_at", "TIMESTAMP")
            ]:
                try:
                    cursor.execute(f"ALTER TABLE videos ADD COLUMN {col_name} {col_type}")
                except sqlite3.OperationalError:
                    pass

            # Bảng Lịch đăng
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS schedules (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    channel_id INTEGER NOT NULL,
                    video_id INTEGER NOT NULL,
                    scheduled_time TIMESTAMP NOT NULL,
                    caption TEXT,
                    hashtags TEXT,
                    status TEXT DEFAULT 'pending', -- pending, processing, success, failed, cancelled
                    error_message TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    vpn_region TEXT DEFAULT '',
                    target_country TEXT DEFAULT '',
                    upload_mode TEXT DEFAULT 'local',
                    retry_count INTEGER DEFAULT 0,
                    last_attempt TIMESTAMP,
                    crop_frame TEXT DEFAULT 'original',
                    FOREIGN KEY (channel_id) REFERENCES channels (id) ON DELETE CASCADE,
                    FOREIGN KEY (video_id) REFERENCES videos (id) ON DELETE CASCADE
                )
            """)

            schedules_cols_to_add = [
                ("vpn_region", "TEXT DEFAULT ''"),
                ("target_country", "TEXT DEFAULT ''"),
                ("upload_mode", "TEXT DEFAULT 'local'"),
                ("retry_count", "INTEGER DEFAULT 0"),
                ("last_attempt", "TIMESTAMP"),
                ("crop_frame", "TEXT DEFAULT 'original'")
            ]
            for col_name, col_type in schedules_cols_to_add:
                try:
                    cursor.execute(f"ALTER TABLE schedules ADD COLUMN {col_name} {col_type}")
                except sqlite3.OperationalError:
                    pass

            # Bảng Lịch sử đăng
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS history (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    channel_id INTEGER,
                    channel_name TEXT,
                    video_title TEXT,
                    video_path TEXT,
                    status TEXT NOT NULL, -- success, failed
                    error_message TEXT,
                    post_url TEXT,
                    posted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)

            # Bảng Phân tích Sức khỏe & Đề xuất AI cho từng Kênh
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS channel_analytics (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    channel_id INTEGER UNIQUE NOT NULL,
                    followers_count INTEGER DEFAULT 0,
                    likes_count INTEGER DEFAULT 0,
                    videos_count INTEGER DEFAULT 0,
                    avg_views INTEGER DEFAULT 0,
                    zero_view_count INTEGER DEFAULT 0,
                    viral_count INTEGER DEFAULT 0,
                    health_status TEXT DEFAULT 'unknown', -- healthy, warning, shadowban, new
                    health_score INTEGER DEFAULT 100,
                    ai_recommendation TEXT DEFAULT '',
                    last_analyzed TIMESTAMP,
                    FOREIGN KEY (channel_id) REFERENCES channels (id) ON DELETE CASCADE
                )
            """)

            # Bảng Lưu Lịch Sử Video YouTube Đã Xử Lý (Chống lấy trùng video 100%)
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS youtube_processed_videos (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    channel_id INTEGER NOT NULL,
                    youtube_video_id TEXT NOT NULL,
                    title TEXT DEFAULT '',
                    view_count INTEGER DEFAULT 0,
                    duration INTEGER DEFAULT 0,
                    parts_created INTEGER DEFAULT 0,
                    source_url TEXT DEFAULT '',
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    UNIQUE(channel_id, youtube_video_id),
                    FOREIGN KEY (channel_id) REFERENCES channels (id) ON DELETE CASCADE
                )
            """)

            # Tối ưu hóa chỉ mục (Indexes) cho hàng nghìn video và kênh không giới hạn
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_schedules_perf ON schedules(status, scheduled_time)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_channels_perf ON channels(id, status)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_videos_perf ON videos(id, is_posted)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_analytics_cid ON channel_analytics(channel_id)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_yt_proc ON youtube_processed_videos(channel_id, youtube_video_id)")

            # Thiết lập cài đặt mặc định nếu chưa có
            cursor.execute("SELECT value FROM settings WHERE key = 'chrome_path'")
            if not cursor.fetchone():
                cursor.execute(
                    "INSERT INTO settings (key, value) VALUES (?, ?)",
                    ('chrome_path', config.DEFAULT_CHROME_PATH)
                )

            cursor.execute("SELECT value FROM settings WHERE key = 'profiles_dir'")
            if not cursor.fetchone():
                cursor.execute(
                    "INSERT INTO settings (key, value) VALUES (?, ?)",
                    ('profiles_dir', str(config.PROFILES_DIR))
                )

            cursor.execute("SELECT value FROM settings WHERE key = 'max_concurrent_tasks'")
            if not cursor.fetchone():
                cursor.execute(
                    "INSERT INTO settings (key, value) VALUES (?, ?)",
                    ('max_concurrent_tasks', '2')
                )

            # Đồng bộ toàn bộ lịch sử cũ sang chuẩn Giờ Việt Nam (UTC+7)
            cursor.execute("SELECT value FROM settings WHERE key = 'history_tz_migrated_vn'")
            row_mig = cursor.fetchone()
            if not row_mig or row_mig["value"] != "1":
                try:
                    cursor.execute("UPDATE history SET posted_at = datetime(posted_at, '+7 hours') WHERE posted_at IS NOT NULL")
                    cursor.execute("INSERT OR REPLACE INTO settings (key, value) VALUES ('history_tz_migrated_vn', '1')")
                except Exception:
                    pass

            conn.commit()

    # --- CÀI ĐẶT ---
    def get_setting(self, key: str, default: str = "") -> str:
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT value FROM settings WHERE key = ?", (key,))
            row = cursor.fetchone()
            return row["value"] if row else default

    def set_setting(self, key: str, value: str):
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO settings (key, value) VALUES (?, ?)
                ON CONFLICT(key) DO UPDATE SET value = excluded.value
            """, (key, value))
            conn.commit()

    # --- KÊNH TIKTOK ---
    def get_all_channels(self) -> List[Dict[str, Any]]:
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                SELECT c.id, c.name, c.username, c.avatar, c.profile_dir, c.video_folder,
                       c.status, c.is_logged_in, c.posted_count, c.note, c.created_at,
                       c.last_login_check, c.network_type, c.proxy_string, c.vpn_region,
                       c.last_ip, c.pia_username, c.pia_password, c.use_vpn, c.ai_autopilot,
                       c.youtube_source_url, c.youtube_channel_name, c.crop_frame, c.auto_series_config,
                       COALESCE(NULLIF(c.followers_count, 0), ca.followers_count, 0) as followers_count,
                       COALESCE(NULLIF(c.views_count, 0), ca.avg_views, 0) as views_count,
                       COALESCE(ca.likes_count, 0) as likes_count
                FROM channels c
                LEFT JOIN channel_analytics ca ON c.id = ca.channel_id
                ORDER BY c.id DESC
            """)
            return [dict(row) for row in cursor.fetchall()]

    def get_channel(self, channel_id: int) -> Optional[Dict[str, Any]]:
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                SELECT c.id, c.name, c.username, c.avatar, c.profile_dir, c.video_folder,
                       c.status, c.is_logged_in, c.posted_count, c.note, c.created_at,
                       c.last_login_check, c.network_type, c.proxy_string, c.vpn_region,
                       c.last_ip, c.pia_username, c.pia_password, c.use_vpn, c.ai_autopilot,
                       c.youtube_source_url, c.youtube_channel_name, c.crop_frame, c.auto_series_config,
                       COALESCE(NULLIF(c.followers_count, 0), ca.followers_count, 0) as followers_count,
                       COALESCE(NULLIF(c.views_count, 0), ca.avg_views, 0) as views_count,
                       COALESCE(ca.likes_count, 0) as likes_count
                FROM channels c
                LEFT JOIN channel_analytics ca ON c.id = ca.channel_id
                WHERE c.id = ?
            """, (channel_id,))
            row = cursor.fetchone()
            return dict(row) if row else None

    def save_channel_auto_series_config(self, channel_id: int, config_dict: dict):
        import json
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cfg_json = json.dumps(config_dict, ensure_ascii=False)
            cursor.execute("UPDATE channels SET auto_series_config = ? WHERE id = ?", (cfg_json, channel_id))
            conn.commit()

    def clear_channel_youtube_source(self, channel_id: int):
        """Xóa link nguồn YouTube và tắt hoàn toàn tính năng tự động hóa series cho kênh"""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                UPDATE channels 
                SET youtube_source_url = '', 
                    youtube_channel_name = '', 
                    auto_series_config = '' 
                WHERE id = ?
            """, (channel_id,))
            conn.commit()

    def get_channel_auto_series_config(self, channel_id: int) -> dict:
        import json
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT auto_series_config FROM channels WHERE id = ?", (channel_id,))
            row = cursor.fetchone()
            if row and row[0]:
                try:
                    return json.loads(row[0])
                except Exception:
                    pass
        return {}

    def get_channel_by_id(self, channel_id: int) -> Optional[Dict[str, Any]]:
        return self.get_channel(channel_id)

    def update_channel_stats(self, channel_id: int, followers_count: int = 0, views_count: int = 0):
        """Cập nhật số Follower (Flow) và Lượt Xem (View) cho từng kênh chuẩn xác"""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                UPDATE channels
                SET followers_count = ?, views_count = ?
                WHERE id = ?
            """, (int(followers_count or 0), int(views_count or 0), channel_id))
            cursor.execute("""
                INSERT INTO channel_analytics (channel_id, followers_count, avg_views, last_analyzed)
                VALUES (?, ?, ?, CURRENT_TIMESTAMP)
                ON CONFLICT(channel_id) DO UPDATE SET
                    followers_count = excluded.followers_count,
                    avg_views = excluded.avg_views,
                    last_analyzed = excluded.last_analyzed
            """, (channel_id, int(followers_count or 0), int(views_count or 0)))
            conn.commit()

    def add_channel(self, name: str, username: str = "", profile_dir: str = "",
                    video_folder: str = "", note: str = "",
                    network_type: str = "direct", proxy_string: str = "", vpn_region: str = "",
                    pia_username: str = "", pia_password: str = "",
                    crop_frame: str = "original") -> int:
        with self._get_connection() as conn:
            cursor = conn.cursor()
            # Tự động đồng nhất username sau chữ @ theo tên kênh
            if not username:
                clean = name.strip()
                username = clean if clean.startswith("@") else f"@{clean}"
            elif not username.startswith("@"):
                username = f"@{username.strip()}"

            if not profile_dir:
                import time
                unique_suffix = int(time.time() * 1000)
                profile_dir = str(Path(config.PROFILES_DIR) / f"channel_{unique_suffix}")
                Path(profile_dir).mkdir(parents=True, exist_ok=True)

            cursor.execute("""
                INSERT INTO channels (name, username, profile_dir, video_folder, note, network_type, proxy_string, vpn_region, pia_username, pia_password, crop_frame)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (name, username, profile_dir, video_folder, note, network_type, proxy_string, vpn_region, pia_username, pia_password, crop_frame))
            conn.commit()
            return cursor.lastrowid

    def update_channel(self, channel_id: int, name: str, username: str,
                       video_folder: str, status: str, note: str,
                       network_type: str = "direct", proxy_string: str = "", vpn_region: str = "",
                       pia_username: str = "", pia_password: str = "",
                       crop_frame: str = "original"):
        with self._get_connection() as conn:
            cursor = conn.cursor()
            # Tự động đồng nhất username sau chữ @ theo tên kênh
            if not username:
                clean = name.strip()
                username = clean if clean.startswith("@") else f"@{clean}"
            elif not username.startswith("@"):
                username = f"@{username.strip()}"

            cursor.execute("""
                UPDATE channels
                SET name = ?, username = ?, video_folder = ?, status = ?, note = ?,
                    network_type = ?, proxy_string = ?, vpn_region = ?,
                    pia_username = ?, pia_password = ?, crop_frame = ?
                WHERE id = ?
            """, (name, username, video_folder, status, note, network_type, proxy_string, vpn_region, pia_username, pia_password, crop_frame, channel_id))
            conn.commit()

    def update_channel_crop_frame(self, channel_id: int, crop_frame: str):
        """Cập nhật khung hình tự cắt cho kênh"""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("UPDATE channels SET crop_frame = ? WHERE id = ?", (crop_frame, channel_id))
            conn.commit()

    def update_channel_ip(self, channel_id: int, ip_text: str):
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("UPDATE channels SET last_ip = ? WHERE id = ?", (ip_text, channel_id))
            conn.commit()

    def set_channel_vpn_status(self, channel_id: int, use_vpn: bool):
        with self._get_connection() as conn:
            cursor = conn.cursor()
            val = 1 if use_vpn else 0
            # Nếu kênh đang được gắn Proxy tĩnh -> Proxy luôn được ưu tiên số 1, không bị VPN ghi đè
            cursor.execute("SELECT proxy_string FROM channels WHERE id = ?", (channel_id,))
            row = cursor.fetchone()
            has_proxy = bool(row and str(row["proxy_string"] or "").strip())
            net_type = 'proxy' if has_proxy else ('vpn' if use_vpn else 'direct')
            cursor.execute("UPDATE channels SET use_vpn = ?, network_type = ? WHERE id = ?", (val, net_type, channel_id))
            conn.commit()

    def set_multiple_channels_vpn(self, channel_ids: List[int], use_vpn: bool):
        with self._get_connection() as conn:
            cursor = conn.cursor()
            val = 1 if use_vpn else 0
            for cid in channel_ids:
                cursor.execute("SELECT proxy_string FROM channels WHERE id = ?", (cid,))
                row = cursor.fetchone()
                has_proxy = bool(row and str(row["proxy_string"] or "").strip())
                net_type = 'proxy' if has_proxy else ('vpn' if use_vpn else 'direct')
                cursor.execute("UPDATE channels SET use_vpn = ?, network_type = ? WHERE id = ?", (val, net_type, cid))
            conn.commit()

    def update_channel_login_status(self, channel_id: int, is_logged_in: bool):
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                UPDATE channels
                SET is_logged_in = ?, last_login_check = ?
                WHERE id = ?
            """, (1 if is_logged_in else 0, datetime.now().strftime("%Y-%m-%d %H:%M:%S"), channel_id))
            conn.commit()

    def update_channel_youtube_source(self, channel_id: int, source_url: str, channel_name: str = ""):
        """Cập nhật thông tin kênh nguồn YouTube mà kênh TikTok này đang lấy video (Tự động nhận diện tên thật)"""
        source_url = (source_url or "").strip()
        channel_name = (channel_name or "").strip()

        # Tự động nhận diện TÊN THẬT của kênh YouTube từ đường link (Ví dụ: Cong TV, Wowowin...)
        # Tuyệt đối không để tên thô dạng đường link hoặc mã kênh 'UC...'
        if source_url and (not channel_name or channel_name.startswith("UC") or channel_name.startswith("http")):
            try:
                from core.youtube_pipeline import resolve_youtube_channel_title
                resolved = resolve_youtube_channel_title(source_url)
                if resolved and not resolved.startswith("UC"):
                    channel_name = resolved
            except Exception:
                pass

        # Nếu chưa có channel_name và link dạng @handle
        if not channel_name and source_url:
            import re
            m = re.search(r"@([a-zA-Z0-9_\-\.]+)", source_url)
            if m:
                channel_name = m.group(1)

        with self._get_connection() as conn:
            cursor = conn.cursor()
            # Nếu vẫn chưa có channel_name và source_url không đổi, giữ lại tên cũ nếu tên cũ hợp lệ
            if not channel_name and source_url:
                row = cursor.execute("SELECT youtube_channel_name FROM channels WHERE id = ?", (channel_id,)).fetchone()
                if row and row[0] and not row[0].startswith("UC") and not row[0].startswith("http"):
                    channel_name = row[0]

            cursor.execute("""
                UPDATE channels
                SET youtube_source_url = ?, youtube_channel_name = ?
                WHERE id = ?
            """, (source_url, channel_name, channel_id))
            conn.commit()

    def get_channel_latest_schedule_time(self, channel_id: int) -> Optional[datetime]:
        """Lấy mốc thời gian của video cuối cùng đang có trong lịch hẹn của kênh"""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            row = cursor.execute("""
                SELECT MAX(scheduled_time) FROM schedules
                WHERE channel_id = ? AND status IN ('pending', 'processing', 'cloud_scheduled')
            """, (channel_id,)).fetchone()
            if row and row[0]:
                for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M"):
                    try:
                        return datetime.strptime(str(row[0]).strip(), fmt)
                    except Exception:
                        pass
            return None

    def get_channel_schedule_summary(self, channel_id: int) -> Dict[str, Any]:
        """Thống kê chi tiết lịch hẹn hiện tại của kênh: tổng video, số video hôm nay, ngày kết thúc"""
        now = datetime.now()
        today_str = now.strftime("%Y-%m-%d")
        with self._get_connection() as conn:
            cursor = conn.cursor()
            row_total = cursor.execute("""
                SELECT COUNT(id), MAX(scheduled_time) FROM schedules
                WHERE channel_id = ? AND status IN ('pending', 'processing', 'cloud_scheduled')
            """, (channel_id,)).fetchone()
            
            row_today = cursor.execute("""
                SELECT COUNT(id) FROM schedules
                WHERE channel_id = ? AND status IN ('pending', 'processing', 'cloud_scheduled')
                  AND scheduled_time LIKE ?
            """, (channel_id, f"{today_str}%")).fetchone()

            total_pending = int(row_total[0] or 0) if row_total else 0
            max_time_str = str(row_total[1] or "") if row_total else ""
            today_count = int(row_today[0] or 0) if row_today else 0

            end_date_str = ""
            if max_time_str:
                try:
                    dt = datetime.strptime(max_time_str[:10], "%Y-%m-%d")
                    end_date_str = dt.strftime("%d/%m/%Y")
                except Exception:
                    end_date_str = max_time_str[:10]

            return {
                "total_pending": total_pending,
                "today_count": today_count,
                "end_date_str": end_date_str,
                "max_time_str": max_time_str
            }

    def get_channel_analytics(self, channel_id: int) -> Optional[Dict[str, Any]]:
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM channel_analytics WHERE channel_id = ?", (channel_id,))
            row = cursor.fetchone()
            return dict(row) if row else None

    def save_channel_analytics(self, channel_id: int, data: Dict[str, Any]):
        now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO channel_analytics (
                    channel_id, followers_count, likes_count, videos_count,
                    avg_views, zero_view_count, viral_count, health_status,
                    health_score, ai_recommendation, last_analyzed
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(channel_id) DO UPDATE SET
                    followers_count = excluded.followers_count,
                    likes_count = excluded.likes_count,
                    videos_count = excluded.videos_count,
                    avg_views = excluded.avg_views,
                    zero_view_count = excluded.zero_view_count,
                    viral_count = excluded.viral_count,
                    health_status = excluded.health_status,
                    health_score = excluded.health_score,
                    ai_recommendation = excluded.ai_recommendation,
                    last_analyzed = excluded.last_analyzed
            """, (
                channel_id,
                data.get("followers_count", 0),
                data.get("likes_count", 0),
                data.get("videos_count", 0),
                data.get("avg_views", 0),
                data.get("zero_view_count", 0),
                data.get("viral_count", 0),
                data.get("health_status", "healthy"),
                data.get("health_score", 100),
                data.get("ai_recommendation", ""),
                now_str
            ))
            conn.commit()

    def set_channel_autopilot(self, channel_id: int, enabled: bool):
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("UPDATE channels SET ai_autopilot = ? WHERE id = ?", (1 if enabled else 0, channel_id))
            conn.commit()

    def is_channel_autopilot(self, channel_id: int) -> bool:
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT ai_autopilot FROM channels WHERE id = ?", (channel_id,))
            row = cursor.fetchone()
            if not row:
                return True
            val = row["ai_autopilot"]
            return True if val is None else bool(val == 1)

    # ==================== YOUTUBE AUTO PIPELINE TRACKING ====================
    def is_youtube_video_processed(self, channel_id: int, youtube_video_id: str) -> bool:
        """Kiểm tra video YouTube đã từng được tải và cắt cho kênh này hay chưa (Chống trùng 100%)"""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                "SELECT id FROM youtube_processed_videos WHERE channel_id = ? AND youtube_video_id = ?",
                (channel_id, youtube_video_id)
            )
            return cursor.fetchone() is not None

    def save_youtube_processed_video(self, channel_id: int, youtube_video_id: str, title: str,
                                     view_count: int = 0, duration: int = 0, parts_created: int = 0, source_url: str = ""):
        """Lưu vết video YouTube đã xử lý thành công để không bao giờ lấy lại"""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT OR REPLACE INTO youtube_processed_videos (
                    channel_id, youtube_video_id, title, view_count, duration, parts_created, source_url
                ) VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (channel_id, youtube_video_id, title, view_count, duration, parts_created, source_url))
            conn.commit()

    def add_processed_youtube_id(self, channel_id: int, youtube_video_id: str, title: str = ""):
        """Đánh dấu video YouTube đã được xử lý hoặc bỏ qua để không quét lại (Hỗ trợ đa hàm tương thích)"""
        self.save_youtube_processed_video(channel_id, youtube_video_id, title or "processed_or_skipped")

    def get_processed_youtube_ids(self, channel_id: int) -> set:
        """Lấy tập hợp các ID video YouTube đã xử lý của kênh (chỉ tính các video đã cắt thành công parts_created > 0)"""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                SELECT youtube_video_id FROM youtube_processed_videos 
                WHERE channel_id = ? AND parts_created > 0
            """, (channel_id,))
            return {row["youtube_video_id"] for row in cursor.fetchall()}

    def increment_posted_count(self, channel_id: int):
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                UPDATE channels
                SET posted_count = posted_count + 1
                WHERE id = ?
            """, (channel_id,))
            conn.commit()

    def delete_channel(self, channel_id: int):
        with self._get_connection() as conn:
            cursor = conn.cursor()
            # 1. Thu thập danh sách file video trong kho của các lịch trình thuộc kênh này
            cursor.execute("""
                SELECT v.file_path, s.id as schedule_id 
                FROM schedules s
                JOIN videos v ON s.video_id = v.id
                WHERE s.channel_id = ?
            """, (channel_id,))
            schedule_videos = [dict(r) for r in cursor.fetchall()]

            # 2. Xóa toàn bộ lịch trình liên quan đến kênh này
            cursor.execute("DELETE FROM schedules WHERE channel_id = ?", (channel_id,))

            # 3. Xóa các video liên kết với kênh này
            cursor.execute("DELETE FROM videos WHERE channel_id = ?", (channel_id,))

            # 4. Xóa kênh khỏi bảng channels
            cursor.execute("DELETE FROM channels WHERE id = ?", (channel_id,))
            conn.commit()

            # 5. Dọn dẹp kho video an toàn nếu không còn lịch nào khác cần file
            for row in schedule_videos:
                v_path = row.get("file_path")
                s_id = row.get("schedule_id")
                if v_path:
                    try:
                        from core.video_vault import video_vault
                        video_vault.cleanup_vault_video(v_path, schedule_id=s_id)
                    except Exception:
                        pass

    # --- THỐNG KÊ DASHBOARD ---
    def get_dashboard_stats(self) -> Dict[str, Any]:
        with self._get_connection() as conn:
            cursor = conn.cursor()

            # Tổng số kênh
            cursor.execute("SELECT COUNT(*) as count FROM channels")
            total_channels = cursor.fetchone()["count"]

            # Số kênh đang đăng nhập
            cursor.execute("SELECT COUNT(*) as count FROM channels WHERE is_logged_in = 1")
            logged_in_channels = cursor.fetchone()["count"]

            # Tổng video đã đăng
            cursor.execute("SELECT COUNT(*) as count FROM history WHERE status = 'success'")
            total_posted = cursor.fetchone()["count"]

            # Video đang chờ đăng (trong bảng schedules)
            cursor.execute("SELECT COUNT(*) as count FROM schedules WHERE status = 'pending'")
            pending_videos = cursor.fetchone()["count"]

            # Video đăng lỗi
            cursor.execute("SELECT COUNT(*) as count FROM history WHERE status = 'failed'")
            failed_videos = cursor.fetchone()["count"]

            # Số video đăng hôm nay
            today_str = datetime.now().strftime("%Y-%m-%d")
            cursor.execute("""
                SELECT COUNT(*) as count FROM history
                WHERE status = 'success' AND posted_at LIKE ?
            """, (f"{today_str}%",))
            today_posted = cursor.fetchone()["count"]

            return {
                "total_channels": total_channels,
                "logged_in_channels": logged_in_channels,
                "total_posted": total_posted,
                "pending_videos": pending_videos,
                "failed_videos": failed_videos,
                "today_posted": today_posted
            }

    # --- LỊCH TRÌNH ĐĂNG & VIDEO ---
    def add_video(self, title: str, file_path: str, file_size: int = 0, channel_id: Optional[int] = None, description: str = "", **kwargs) -> int:
        with self._get_connection() as conn:
            cursor = conn.cursor()
            if not file_size and file_path and os.path.exists(file_path):
                try:
                    file_size = os.path.getsize(file_path)
                except Exception:
                    pass
            cursor.execute("""
                INSERT INTO videos (title, file_path, file_size, channel_id)
                VALUES (?, ?, ?, ?)
            """, (title, file_path, file_size, channel_id))
            conn.commit()
            return cursor.lastrowid

    def update_video_posted(self, video_id: int):
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                UPDATE videos 
                SET is_posted = 1, posted_at = CURRENT_TIMESTAMP
                WHERE id = ?
            """, (video_id,))
            conn.commit()

    def add_schedule(self, channel_id: int, video_id: int, scheduled_time: str, caption: str = "", hashtags: str = "", vpn_region: str = "", target_country: str = "", upload_mode: str = "local", crop_frame: str = "original") -> int:
        with self._get_connection() as conn:
            cursor = conn.cursor()
            try:
                cursor.execute("""
                    INSERT INTO schedules (channel_id, video_id, scheduled_time, caption, hashtags, vpn_region, target_country, upload_mode, status, crop_frame)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'pending', ?)
                """, (channel_id, video_id, scheduled_time, caption, hashtags, vpn_region, target_country, upload_mode, crop_frame))
            except sqlite3.OperationalError as e:
                # Tự động khắc phục tại chỗ (Self-Healing) nếu database cũ của khách hàng thiếu cột
                if "no column named" in str(e).lower():
                    for col_name, col_type in [
                        ("vpn_region", "TEXT DEFAULT ''"),
                        ("target_country", "TEXT DEFAULT ''"),
                        ("upload_mode", "TEXT DEFAULT 'local'"),
                        ("retry_count", "INTEGER DEFAULT 0"),
                        ("last_attempt", "TIMESTAMP"),
                        ("crop_frame", "TEXT DEFAULT 'original'")
                    ]:
                        try:
                            cursor.execute(f"ALTER TABLE schedules ADD COLUMN {col_name} {col_type}")
                        except sqlite3.OperationalError:
                            pass
                    cursor.execute("""
                        INSERT INTO schedules (channel_id, video_id, scheduled_time, caption, hashtags, vpn_region, target_country, upload_mode, status, crop_frame)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'pending', ?)
                    """, (channel_id, video_id, scheduled_time, caption, hashtags, vpn_region, target_country, upload_mode, crop_frame))
                else:
                    raise
            conn.commit()
            return cursor.lastrowid

    def get_all_schedules(self, status_filter: str = "all") -> List[Dict[str, Any]]:
        with self._get_connection() as conn:
            cursor = conn.cursor()
            sql = """
                SELECT s.*, c.name as channel_name, c.profile_dir, v.title as video_title, v.file_path as video_path
                FROM schedules s
                JOIN channels c ON s.channel_id = c.id
                JOIN videos v ON s.video_id = v.id
            """
            if status_filter != "all":
                sql += " WHERE s.status = ? ORDER BY s.scheduled_time ASC"
                cursor.execute(sql, (status_filter,))
            else:
                sql += " ORDER BY s.scheduled_time ASC"
                cursor.execute(sql)
            return [dict(row) for row in cursor.fetchall()]

    def reset_stuck_processing_schedules(self):
        """Khôi phục các lịch hẹn bị kẹt ở trạng thái processing sang pending"""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("UPDATE schedules SET status = 'pending' WHERE status = 'processing'")
            conn.commit()

    def set_all_pending_schedules_due_now(self, include_future: bool = True) -> int:
        """
        Đưa toàn bộ hoặc các video đang chờ sang thời gian hiện tại để đăng hàng loạt ngay lập tức
        """
        now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        with self._get_connection() as conn:
            cursor = conn.cursor()
            if include_future:
                cursor.execute("""
                    UPDATE schedules
                    SET scheduled_time = ?,
                        status = 'pending',
                        error_message = ''
                    WHERE status IN ('pending', 'failed')
                """, (now_str,))
            else:
                cursor.execute("""
                    UPDATE schedules
                    SET status = 'pending',
                        error_message = ''
                    WHERE status = 'failed' AND scheduled_time <= ?
                """, (now_str,))
            count = cursor.rowcount
            conn.commit()
            return count

    def get_unique_pending_channels_count(self) -> int:
        """Đếm số lượng kênh độc nhất đang có lịch chờ đăng (bao gồm cả lịch đã lưu sẵn trên Đám Mây TikTok)"""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT COUNT(DISTINCT channel_id) FROM schedules WHERE status IN ('pending', 'processing', 'cloud_scheduled')")
            row = cursor.fetchone()
            return row[0] if row else 0

    def get_channel_remaining_schedules_count(self, channel_id: int) -> int:
        """Đếm chính xác số video còn lại đang chờ đăng của một kênh TikTok (bao gồm cả các video đang tự động thử lại)"""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            row = cursor.execute("""
                SELECT COUNT(id) FROM schedules
                WHERE channel_id = ? AND status IN ('pending', 'processing', 'failed', 'cloud_scheduled')
            """, (channel_id,)).fetchone()
            return int(row[0]) if row else 0

    def get_channels_video_schedule_status(self) -> Dict[int, Dict[str, Any]]:
        """
        Thống kê chính xác tình trạng lịch đăng video của từng kênh TikTok:
        - 🟢 Còn video (Hạn kéo dài qua ngày mai)
        - 🟠 Sắp hết: Mai là ngày cuối (Lượt đăng cuối cùng của lịch hẹn rơi vào ngày mai)
        - 🟠 Sắp hết: Hôm nay lượt cuối (Lượt đăng cuối cùng của lịch hẹn rơi vào hôm nay)
        - 🔴 Hết video (Kênh không còn video nào trong lịch hẹn)
        """
        now = datetime.now()
        today = now.date()
        tomorrow = today + timedelta(days=1)

        result = {}
        with self._get_connection() as conn:
            cursor = conn.cursor()
            rows = cursor.execute("""
                SELECT 
                    channel_id,
                    COUNT(id) as pending_count,
                    MIN(scheduled_time) as min_time,
                    MAX(scheduled_time) as max_time
                FROM schedules
                WHERE status IN ('pending', 'processing', 'cloud_scheduled')
                GROUP BY channel_id
            """).fetchall()

            for r in rows:
                cid = r["channel_id"]
                count = int(r["pending_count"] or 0)
                max_time_str = str(r["max_time"] or "").strip()
                min_time_str = str(r["min_time"] or "").strip()

                last_date = None
                if max_time_str:
                    try:
                        last_date = datetime.strptime(max_time_str[:10], "%Y-%m-%d").date()
                    except Exception:
                        pass

                if count == 0 or not last_date:
                    status_type = "empty"
                    label = "🔴 Hết video"
                    badge_short = "🔴 Hết video"
                    detail = "0 video chờ đăng"
                    tooltip = "Kênh này hiện không còn video nào trong lịch hẹn đăng."
                    color = "#EF4444"
                    bg_color = "#2D1519"
                    border_color = "#7F1D1D"
                elif last_date < today:
                    status_type = "empty"
                    label = "🔴 Hết video (Lịch quá hạn)"
                    badge_short = "🔴 Hết video"
                    detail = f"{count} lịch quá hạn"
                    tooltip = f"Kênh đã hết video hợp lệ ({count} lịch hẹn đã quá thời gian đăng). Cần lên lịch mới!"
                    color = "#EF4444"
                    bg_color = "#2D1519"
                    border_color = "#7F1D1D"
                elif last_date == today:
                    status_type = "ending_today"
                    label = f"🟠 Sắp hết ({count} vid • Hôm nay)"
                    badge_short = f"🟠 Sắp hết ({count} vid)"
                    detail = f"Còn {count} video (hết hôm nay)"
                    tooltip = f"⚠️ Kênh sắp hết video! Hôm nay là ngày đăng lượt cuối cùng của lịch hẹn (còn {count} video). Cần nạp thêm video mới!"
                    color = "#F59E0B"
                    bg_color = "#2D1F10"
                    border_color = "#78350F"
                elif last_date == tomorrow:
                    status_type = "ending_tomorrow"
                    label = f"🟠 Sắp hết ({count} vid • Đến mai)"
                    badge_short = f"🟠 Sắp hết ({count} vid)"
                    detail = f"Còn {count} video (hết vào ngày mai)"
                    tooltip = f"⚠️ Kênh sắp hết video! Ngày mai ({last_date.strftime('%d/%m')}) là ngày đăng lượt cuối cùng của lịch hẹn (còn {count} video). Cần nạp thêm video mới!"
                    color = "#F59E0B"
                    bg_color = "#2D1F10"
                    border_color = "#78350F"
                else:
                    status_type = "active"
                    days_left = (last_date - today).days
                    d_str = last_date.strftime("%d/%m")
                    label = f"🟢 Còn {count} video (Đến {d_str})"
                    badge_short = f"🟢 Còn {count} video"
                    detail = f"Còn {count} video (đến {last_date.strftime('%d/%m/%Y')})"
                    tooltip = f"✅ Kênh còn {count} video trong lịch hẹn tự động. Lịch đăng kéo dài đến ngày {last_date.strftime('%d/%m/%Y')} (còn {days_left} ngày)."
                    color = "#10B981"
                    bg_color = "#0E281F"
                    border_color = "#065F46"

                result[cid] = {
                    "status_type": status_type,
                    "count": count,
                    "last_date": last_date.strftime("%d/%m/%Y") if last_date else "",
                    "label": label,
                    "badge_short": badge_short,
                    "detail": detail,
                    "tooltip": tooltip,
                    "color": color,
                    "bg_color": bg_color,
                    "border_color": border_color,
                    "max_time": max_time_str,
                    "min_time": min_time_str
                }

        return result

    def get_due_schedules(self, current_time_str: str) -> List[Dict[str, Any]]:
        """Lấy các lịch đăng đã đến hoặc quá hạn giờ đăng"""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                SELECT s.*, c.name as channel_name, c.profile_dir, c.network_type, c.use_vpn, c.proxy_string,
                       COALESCE(NULLIF(s.vpn_region, ''), c.vpn_region) as vpn_region,
                       s.target_country, s.upload_mode,
                       c.pia_username, c.pia_password,
                       v.title as video_title, v.file_path as video_path
                FROM schedules s
                JOIN channels c ON s.channel_id = c.id
                JOIN videos v ON s.video_id = v.id
                WHERE s.status = 'pending' AND s.scheduled_time <= ?
                ORDER BY s.scheduled_time ASC
            """, (current_time_str,))
            return [dict(row) for row in cursor.fetchall()]

    def get_future_cloud_schedulable_items(self, min_future_str: str, max_future_str: str) -> List[Dict[str, Any]]:
        """
        Lấy danh sách các lịch hẹn trong tương lai (cách hiện tại từ 22 phút đến 10 ngày)
        để tự động nạp trước lên Máy Chủ Đám Mây TikTok Studio (giúp tắt máy tính hoàn toàn vẫn tự đăng đúng giờ!).
        """
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                SELECT s.*, c.name as channel_name, c.profile_dir, c.network_type, c.use_vpn, c.proxy_string,
                       COALESCE(NULLIF(s.vpn_region, ''), c.vpn_region) as vpn_region,
                       s.target_country, s.upload_mode,
                       c.pia_username, c.pia_password,
                       v.title as video_title, v.file_path as video_path
                FROM schedules s
                JOIN channels c ON s.channel_id = c.id
                JOIN videos v ON s.video_id = v.id
                WHERE s.status = 'pending'
                  AND s.scheduled_time >= ?
                  AND s.scheduled_time <= ?
                ORDER BY s.scheduled_time ASC
            """, (min_future_str, max_future_str))
            return [dict(row) for row in cursor.fetchall()]

    def complete_due_cloud_scheduled_items(self, current_time_str: str) -> int:
        """
        Tự động hoàn tất và dọn dẹp các lịch đã đẩy lên Đám Mây TikTok khi thời gian hẹn đã điểm.
        """
        with self._get_connection() as conn:
            cursor = conn.cursor()
            rows = cursor.execute("""
                SELECT s.id, s.channel_id, s.video_id, v.file_path as video_path
                FROM schedules s
                LEFT JOIN videos v ON s.video_id = v.id
                WHERE s.status = 'cloud_scheduled' AND s.scheduled_time <= ?
            """, (current_time_str,)).fetchall()
            if not rows:
                return 0
            count = 0
            for r in rows:
                sid = r["id"]
                vid = r["video_id"]
                vpath = r["video_path"]
                if vid:
                    cursor.execute("UPDATE videos SET status = 'posted', uploaded_at = ? WHERE id = ?", (current_time_str, vid))
                cursor.execute("DELETE FROM schedules WHERE id = ?", (sid,))
                count += 1
                if vpath:
                    try:
                        from core.video_vault import video_vault
                        video_vault.cleanup_vault_video(vpath, schedule_id=sid)
                    except Exception:
                        pass
            conn.commit()
            return count

    def update_schedule_status(self, schedule_id: int, status: str, error_message: str = "", increment_retry: bool = False):
        now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        with self._get_connection() as conn:
            cursor = conn.cursor()
            if status == "success":
                cursor.execute("""
                    UPDATE schedules
                    SET status = ?, error_message = '', retry_count = 0, last_attempt = ?
                    WHERE id = ?
                """, (status, now_str, schedule_id))
            elif increment_retry:
                cursor.execute("""
                    UPDATE schedules
                    SET status = ?, error_message = ?, retry_count = COALESCE(retry_count, 0) + 1, last_attempt = ?
                    WHERE id = ?
                """, (status, error_message, now_str, schedule_id))
            else:
                cursor.execute("""
                    UPDATE schedules
                    SET status = ?, error_message = ?, last_attempt = ?
                    WHERE id = ?
                """, (status, error_message, now_str, schedule_id))
            conn.commit()

    def recover_overdue_failed_schedules(self, cooldown_seconds: int = 30, max_retries: int = 0) -> int:
        """
        Tự động khôi phục toàn bộ các video bị lỗi quá hạn giờ đăng sang trạng thái pending để tự động đăng lại liên tục đến khi thành công thì thôi.
        - max_retries = 0 (mặc định): Thử lại không giới hạn lần đến khi đăng thành công 100%.
        - cooldown_seconds: Thời gian nghỉ giữa các lần thử lại.
        """
        now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        with self._get_connection() as conn:
            cursor = conn.cursor()
            if max_retries > 0:
                cursor.execute("""
                    UPDATE schedules
                    SET status = 'pending',
                        error_message = 'Tự động kích hoạt đăng lại...'
                    WHERE status = 'failed'
                      AND scheduled_time <= ?
                      AND (error_message IS NULL OR error_message NOT LIKE '%File video không tồn tại%')
                      AND COALESCE(retry_count, 0) < ?
                      AND (last_attempt IS NULL OR (strftime('%s', ?) - strftime('%s', last_attempt)) >= ?)
                """, (now_str, max_retries, now_str, cooldown_seconds))
            else:
                cursor.execute("""
                    UPDATE schedules
                    SET status = 'pending',
                        error_message = 'Tự động kích hoạt đăng lại (chạy lại liên tục đến khi thành công)...'
                    WHERE status = 'failed'
                      AND scheduled_time <= ?
                      AND (error_message IS NULL OR error_message NOT LIKE '%File video không tồn tại%')
                      AND (last_attempt IS NULL OR (strftime('%s', ?) - strftime('%s', last_attempt)) >= ?)
                """, (now_str, now_str, cooldown_seconds))
            count = cursor.rowcount
            conn.commit()
            return count

    def auto_retry_failed_schedules(self, max_retries: int = 0, cooldown_seconds: int = 30) -> int:
        """Tự động chuyển các lịch trình bị lỗi đủ điều kiện về trạng thái pending để tự động đăng lại"""
        return self.recover_overdue_failed_schedules(cooldown_seconds=cooldown_seconds, max_retries=max_retries)

    def retry_all_failed_schedules(self, reset_time_to_now: bool = True) -> int:
        """
        Hàng loạt khôi phục TOÀN BỘ video bị lỗi sang trạng thái chờ đăng (pending) ngay lập tức:
        - Reset retry_count về 0
        - Đặt thời gian hẹn về hiện tại (nếu reset_time_to_now=True) để worker quét và đăng ngay
        - Xóa sạch lỗi cũ
        """
        now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        with self._get_connection() as conn:
            cursor = conn.cursor()
            if reset_time_to_now:
                cursor.execute("""
                    UPDATE schedules
                    SET status = 'pending',
                        retry_count = 0,
                        scheduled_time = ?,
                        error_message = NULL,
                        last_attempt = NULL
                    WHERE status = 'failed'
                """, (now_str,))
            else:
                cursor.execute("""
                    UPDATE schedules
                    SET status = 'pending',
                        retry_count = 0,
                        error_message = NULL,
                        last_attempt = NULL
                    WHERE status = 'failed'
                """)
            count = cursor.rowcount
            conn.commit()
            return count

    def retry_single_schedule(self, schedule_id: int) -> bool:
        """Khôi phục một lịch hẹn lỗi cụ thể sang pending và đặt giờ đăng về ngay lập tức"""
        now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                UPDATE schedules
                SET status = 'pending',
                    retry_count = 0,
                    scheduled_time = ?,
                    error_message = NULL,
                    last_attempt = NULL
                WHERE id = ?
            """, (now_str, schedule_id))
            conn.commit()
            return cursor.rowcount > 0

    def update_schedule_video_path(self, schedule_id: int, new_video_path: str) -> bool:
        """Cập nhật lại đường dẫn tệp video mới cho lịch hẹn và đưa trạng thái về pending"""
        now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        with self._get_connection() as conn:
            cursor = conn.cursor()
            sch = cursor.execute("SELECT video_id FROM schedules WHERE id = ?", (schedule_id,)).fetchone()
            if sch and sch["video_id"]:
                cursor.execute("UPDATE videos SET file_path = ? WHERE id = ?", (new_video_path, sch["video_id"]))
            cursor.execute("""
                UPDATE schedules
                SET status = 'pending',
                    retry_count = 0,
                    scheduled_time = ?,
                    error_message = NULL,
                    last_attempt = NULL
                WHERE id = ?
            """, (now_str, schedule_id))
            conn.commit()
            return True

    def clean_orphan_schedules(self) -> int:
        """Dọn dẹp các lịch trình bị mồ côi (không có video tương ứng trong bảng videos)"""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM schedules WHERE video_id NOT IN (SELECT id FROM videos)")
            count = cursor.rowcount
            conn.commit()
            return count

    def delete_schedule(self, schedule_id: int):
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                SELECT v.file_path FROM schedules s
                JOIN videos v ON s.video_id = v.id
                WHERE s.id = ?
            """, (schedule_id,))
            row = cursor.fetchone()
            video_path = row[0] if row else None

            cursor.execute("DELETE FROM schedules WHERE id = ?", (schedule_id,))
            conn.commit()

            if video_path:
                try:
                    from core.video_vault import video_vault
                    video_vault.cleanup_vault_video(video_path, schedule_id=schedule_id)
                except Exception:
                    pass

    def delete_successful_schedules(self) -> int:
        """
        Tự động xóa toàn bộ các lịch trình video đã hoàn thành/đăng thành công khỏi bảng lịch trình,
        chỉ giữ lại các video chưa đăng và đang chờ đăng (pending).
        """
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM schedules WHERE status = 'success'")
            count = cursor.rowcount
            conn.commit()
            return count

    def clear_channel_pending_schedules(self, channel_id: int) -> int:
        """Xóa toàn bộ lịch trình đang chờ đăng của 1 kênh (đảm bảo chỉ 1 video duy nhất hoạt động, không trộn lẫn)"""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                DELETE FROM schedules 
                WHERE channel_id = ? AND status IN ('pending', 'failed', 'processing', 'cloud_scheduled')
            """, (channel_id,))
            cnt = cursor.rowcount
            conn.commit()
            return cnt

    def clear_all_schedules(self):
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT file_path FROM videos")
            paths = [row[0] for row in cursor.fetchall() if row[0]]
            cursor.execute("DELETE FROM schedules")
            cursor.execute("DELETE FROM videos")
            conn.commit()
            try:
                from core.video_vault import video_vault
                for p in paths:
                    if video_vault.is_in_vault(p) and os.path.isfile(p):
                        try:
                            os.remove(p)
                        except Exception:
                            pass
            except Exception:
                pass

    def is_video_already_posted(self, channel_id: int, video_title: str, video_path: str = "", current_schedule_id: int = 0) -> bool:
        """
        Kiểm tra xem kênh này đã từng đăng thành công video có tiêu đề hoặc file này chưa.
        Đảm bảo nguyên tắc: 1 video 1 tiêu đề chỉ đăng 1 lần thành công trên mỗi kênh.
        """
        if not channel_id:
            return False
        clean_title = (video_title or "").strip().lower()
        clean_path = (video_path or "").strip().lower()
        clean_filename = os.path.splitext(os.path.basename(video_path))[0].strip().lower() if video_path else ""

        match_titles = list({clean_title, clean_filename} - {""})
        if not match_titles and not clean_path:
            return False

        with self._get_connection() as conn:
            cursor = conn.cursor()

            # 1. Kiểm tra trong bảng lịch sử đăng thành công (history)
            for t in match_titles:
                cursor.execute("""
                    SELECT id FROM history 
                    WHERE channel_id = ? AND status = 'success' AND LOWER(TRIM(video_title)) = ?
                    LIMIT 1
                """, (channel_id, t))
                if cursor.fetchone():
                    return True
            if clean_path:
                cursor.execute("""
                    SELECT id FROM history 
                    WHERE channel_id = ? AND status = 'success' AND LOWER(TRIM(video_path)) = ?
                    LIMIT 1
                """, (channel_id, clean_path))
                if cursor.fetchone():
                    return True

            # 2. Kiểm tra trong bảng lịch trình đã đăng thành công (schedules)
            for t in match_titles:
                cursor.execute("""
                    SELECT s.id FROM schedules s
                    LEFT JOIN videos v ON s.video_id = v.id
                    WHERE s.channel_id = ? AND s.status = 'success' AND s.id != ?
                      AND (LOWER(TRIM(s.caption)) = ? OR LOWER(TRIM(v.title)) = ?)
                    LIMIT 1
                """, (channel_id, current_schedule_id, t, t))
                if cursor.fetchone():
                    return True
            if clean_path:
                cursor.execute("""
                    SELECT s.id FROM schedules s
                    LEFT JOIN videos v ON s.video_id = v.id
                    WHERE s.channel_id = ? AND s.status = 'success' AND s.id != ?
                      AND LOWER(TRIM(v.file_path)) = ?
                    LIMIT 1
                """, (channel_id, current_schedule_id, clean_path))
                if cursor.fetchone():
                    return True

            # 3. Kiểm tra cờ is_posted trong bảng videos
            for t in match_titles:
                cursor.execute("""
                    SELECT id FROM videos 
                    WHERE channel_id = ? AND is_posted = 1 AND LOWER(TRIM(title)) = ?
                    LIMIT 1
                """, (channel_id, t))
                if cursor.fetchone():
                    return True
            if clean_path:
                cursor.execute("""
                    SELECT id FROM videos 
                    WHERE channel_id = ? AND is_posted = 1 AND LOWER(TRIM(file_path)) = ?
                    LIMIT 1
                """, (channel_id, clean_path))
                if cursor.fetchone():
                    return True

        return False

    def clean_duplicate_pending_schedules(self, target_channel_id: Optional[int] = None) -> int:
        """
        Tự động quét qua toàn bộ kho lịch trình đăng bài (pending, failed, processing, cloud_scheduled):
        1. Xóa triệt để các video bị cắt 2 lần (ví dụ: vừa có tập Part 2, Part 3 lại có thêm bản cắt Short của cùng video đó).
        2. Xóa các bản ghi trùng lặp nội bộ (cùng kênh, cùng video/tiêu đề hoặc cùng số tập Part X).
        3. Xóa các lịch trùng lặp với video đã đăng thành công trước đó (kiểm tra bảng history chống spam).
        """
        import re
        from pathlib import Path

        def _extract_root_title(title_str: str, path_str: str) -> str:
            text = (title_str or "").strip()
            if not text and path_str:
                text = Path(path_str).stem
            if "|" in text:
                text = text.split("|")[0].strip()
            text = re.sub(r'#\w+', '', text)
            text = re.sub(r'-\s*(?:Part|Tập|Ep|Episode)\s*\d+.*$', '', text, flags=re.I)
            text = re.sub(r'_(?:Part_\d+|Short|Tap_\d+)$', '', text, flags=re.I)
            text = re.sub(r'[\s\-–—:|]+$', '', text).strip()
            if not text and path_str:
                base = Path(path_str).stem
                base = re.sub(r'_(?:Part_\d+|Short|Tap_\d+)$', '', base, flags=re.I)
                text = base.strip()
            return re.sub(r'\s+', ' ', text).strip().lower()

        def _extract_part_number(title_str: str, path_str: str) -> Optional[int]:
            if "|" in (title_str or ""):
                after_pipe = title_str.split("|", 1)[1]
                m = re.search(r'(?:part|tập)\s*(\d+)', after_pipe, re.I)
                if m:
                    return int(m.group(1))
            if path_str:
                m = re.search(r'_(?:Part|Tap)_(\d+)', path_str, re.I)
                if m:
                    return int(m.group(1))
            m = re.search(r'-\s*(?:part|tập)\s*(\d+)', (title_str or ""), re.I)
            if m:
                return int(m.group(1))
            return None

        query = """
            SELECT s.id, s.channel_id, s.caption, s.status, s.scheduled_time, s.video_id, v.title AS video_title, v.file_path AS video_path
            FROM schedules s
            LEFT JOIN videos v ON s.video_id = v.id
            WHERE s.status IN ('pending', 'processing', 'failed', 'cloud_scheduled')
        """
        params = []
        if target_channel_id is not None:
            query += " AND s.channel_id = ?"
            params.append(target_channel_id)
        query += " ORDER BY s.channel_id ASC, s.scheduled_time ASC, s.id ASC"

        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(query, params)
            pending_rows = [dict(r) for r in cursor.fetchall()]

        skipped_count = 0
        by_channel = {}
        for r in pending_rows:
            cid = r["channel_id"]
            by_channel.setdefault(cid, []).append(r)

        for cid, items in by_channel.items():
            # 1. Chống trùng lặp chính xác (Cùng video_id hoặc cùng file và cùng giờ đăng)
            seen_exact = set()
            non_duplicate_items = []
            for it in items:
                s_id = it["id"]
                vid_id = it.get("video_id")
                sched_time = it.get("scheduled_time") or ""
                f_path = (it.get("video_path") or "").lower()
                exact_key = (vid_id, sched_time) if vid_id else (f_path, sched_time)

                if exact_key in seen_exact:
                    self.delete_schedule(s_id)
                    skipped_count += 1
                else:
                    seen_exact.add(exact_key)
                    non_duplicate_items.append(it)

            # 2. Xử lý trùng lặp nội bộ trong cùng 1 video gốc (trùng số tập Part X, short cắt thừa của cùng video)
            # TUYỆT ĐỐI BẢO VỆ 100% các file khác nhau mà khách hàng tải lên từ máy tính
            by_root = {}
            for it in non_duplicate_items:
                root = _extract_root_title(it.get("caption") or it.get("video_title") or "", it.get("video_path") or "")
                by_root.setdefault(root, []).append(it)

            for root, root_items in by_root.items():
                if len(root_items) > 1:
                    has_parts = any(_extract_part_number(x.get("caption") or x.get("video_title") or "", x.get("video_path") or "") is not None for x in root_items)
                    seen_parts = set()
                    for it in root_items:
                        s_id = it["id"]
                        t = it.get("caption") or it.get("video_title") or ""
                        f = it.get("video_path") or ""
                        p_num = _extract_part_number(t, f)

                        # TH1: Video đã có series nhiều tập mà lại có thêm bản cắt Short thừa của cùng video đó
                        if has_parts and p_num is None:
                            self.delete_schedule(s_id)
                            skipped_count += 1
                            continue
                        # TH2: Trùng số tập (ví dụ có 2 tập Part 2 của cùng video)
                        elif p_num is not None:
                            if p_num in seen_parts:
                                self.delete_schedule(s_id)
                                skipped_count += 1
                                continue
                            else:
                                seen_parts.add(p_num)

            # 3. Kiểm tra nếu video này đã từng đăng thành công trước đó trong history
            for it in non_duplicate_items:
                s_id = it["id"]
                t = it.get("caption") or it.get("video_title") or ""
                f = it.get("video_path") or ""
                if self.is_video_already_posted(channel_id=cid, video_title=t, video_path=f, current_schedule_id=s_id):
                    self.delete_schedule(s_id)
                    skipped_count += 1

        return skipped_count

    def reschedule_channel_pending_schedules(self, channel_id: int, config_data: Dict[str, Any]) -> int:
        """
        Tự động tính toán và cập nhật lại toàn bộ thời gian hẹn giờ (scheduled_time)
        cho các video chưa được đăng (pending) của kênh theo đúng cài đặt chuẩn xác 100%:
        - Video 1 (Part 1) LUÔN LUÔN bắt đầu đúng Slot 0 (start_time_str)
        - Toàn bộ các tập được sắp xếp theo đúng thứ tự Part 1 -> Part 2 -> Part 3...
        - Khoảng cách các video cách nhau chuẩn xác từng phút (00 giây, KHÔNG BỊ LỆCH)
        - Đủ số lượng videos_per_day mỗi ngày
        - Nếu Slot 0 của ngày hôm nay đã qua giờ hoặc cách hiện tại dưới 15 phút,
          bắt đầu từ ngày mai để đảm bảo Video 1 xuất phát đúng từ Slot 0 chuẩn giờ!
        """
        import datetime
        import re
        from core.youtube_pipeline import compute_daily_schedule_slots

        videos_per_day = int(config_data.get("videos_per_day", 2))
        schedule_mode = config_data.get("schedule_mode", "golden")
        interval_minutes = int(config_data.get("interval_minutes", 180))
        start_time_str = config_data.get("start_time_str", "11:00")
        golden_hours = config_data.get("golden_hours")

        daily_slots = compute_daily_schedule_slots(
            videos_per_day=videos_per_day,
            schedule_mode=schedule_mode,
            interval_minutes=interval_minutes,
            start_time_str=start_time_str,
            custom_hours_list=golden_hours
        )
        if not daily_slots:
            daily_slots = ["11:30", "19:30"]

        # Lấy danh sách video pending của kênh
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                SELECT s.id, s.scheduled_time, s.caption, v.title AS video_title
                FROM schedules s
                LEFT JOIN videos v ON s.video_id = v.id
                WHERE s.channel_id = ? AND s.status IN ('pending', 'processing', 'cloud_scheduled')
                ORDER BY s.id ASC
            """, (channel_id,))
            rows = [dict(r) for r in cursor.fetchall()]

        if not rows:
            return 0

        # Sắp xếp các video chuẩn xác theo số tập Part 1 -> Part 2 -> Part 3...
        def _get_sort_key(item):
            text = f"{item.get('caption') or ''} {item.get('video_title') or ''}"
            m = re.search(r'(?:part|tập|ep|p)\s*(\d+)', text, re.IGNORECASE)
            p_num = int(m.group(1)) if m else None
            if p_num is not None:
                return (0, p_num, item.get("id", 0))
            return (1, str(item.get("scheduled_time") or ""), item.get("id", 0))

        rows.sort(key=_get_sort_key)

        now = datetime.datetime.now()
        current_day = datetime.date.today()

        # Slot 0 luôn là giờ bắt đầu của Video 1 (ví dụ 17:00)
        first_slot_str = daily_slots[0]
        tp0 = [int(x) for x in first_slot_str.split(':')]
        first_today_dt = datetime.datetime(current_day.year, current_day.month, current_day.day, tp0[0], tp0[1], 0)

        # Nếu Slot đầu tiên hôm nay đã qua giờ hoặc còn dưới 15 phút,
        # BẮT BUỘC bắt đầu từ ngày mai để Video 1 luôn được bắt đầu chuẩn từ Slot 0, KHÔNG BỊ LỆCH!
        if first_today_dt <= now + datetime.timedelta(minutes=15):
            current_day += datetime.timedelta(days=1)

        slot_idx = 0
        updated_count = 0
        with self._get_connection() as conn:
            cursor = conn.cursor()
            for r in rows:
                sid = r["id"]
                hour_str = daily_slots[slot_idx % len(daily_slots)]
                tp = [int(x) for x in hour_str.split(':')]
                target_dt = datetime.datetime(current_day.year, current_day.month, current_day.day, tp[0], tp[1], 0)

                # Tuyệt đối chuẩn giờ (00 giây, không lệch jitter)
                new_sched_str = target_dt.strftime("%Y-%m-%d %H:%M:00")
                cursor.execute("UPDATE schedules SET scheduled_time = ? WHERE id = ?", (new_sched_str, sid))
                updated_count += 1

                slot_idx += 1
                if slot_idx >= videos_per_day or slot_idx >= len(daily_slots):
                    current_day += datetime.timedelta(days=1)
                    slot_idx = 0

            conn.commit()

        return updated_count

    def reschedule_all_channels_pending_schedules(self) -> int:
        """Đồng bộ và tính toán lại lịch hẹn cho TẤT CẢ các kênh theo đúng cấu hình đã lưu của từng kênh"""
        channels = self.get_all_channels()
        total_updated = 0
        for c in channels:
            cid = c["id"]
            cfg = self.get_channel_auto_series_config(cid)
            if cfg:
                total_updated += self.reschedule_channel_pending_schedules(cid, cfg)
        return total_updated

    def add_history(self, channel_id: Optional[int], channel_name: str,
                    video_title: str, video_path: str, status: str,
                    error_message: str = "", post_url: str = "",
                    posted_at: Optional[str] = None):
        import datetime
        now_vn = posted_at or datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO history (channel_id, channel_name, video_title, video_path, status, error_message, post_url, posted_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, (channel_id, channel_name, video_title, video_path, status, error_message, post_url, now_vn))
            conn.commit()

    def get_recent_history(self, limit: int = 20) -> List[Dict[str, Any]]:
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM history ORDER BY id DESC LIMIT ?", (limit,))
            return [dict(row) for row in cursor.fetchall()]

    def get_channel_today_posted_count(self, channel_id: int) -> int:
        """Đếm số video đã đăng thành công của kênh trong ngày hôm nay"""
        import datetime
        today_str = datetime.datetime.now().strftime("%Y-%m-%d")
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                SELECT COUNT(id) FROM history 
                WHERE channel_id = ? 
                  AND status = 'success' 
                  AND (date(posted_at) = ? OR substr(posted_at, 1, 10) = ?)
            """, (channel_id, today_str, today_str))
            row = cursor.fetchone()
            return int(row[0]) if row and row[0] is not None else 0

    def get_channel_max_daily_posts(self, channel_id: int, default: int = 3) -> int:
        """Lấy giới hạn số video tối đa được phép đăng trong ngày của kênh (mặc định 3 video/ngày)"""
        try:
            cfg = self.get_channel_auto_series_config(channel_id)
            if cfg and "videos_per_day" in cfg:
                val = int(cfg["videos_per_day"])
                if val > 0:
                    return val
        except Exception:
            pass
        try:
            setting_val = int(self.get_setting("max_videos_per_day", str(default)))
            if setting_val > 0:
                return setting_val
        except Exception:
            pass
        return default


    # ==================== PHÂN BỔ PROXY TĨNH HÀNG LOẠT (1 - 1000 KÊNH) ====================
    def batch_assign_proxies(self, proxy_list: List[str], ratio: int = 5,
                             channel_ids: Optional[List[int]] = None,
                             sort_order: str = "id_asc",
                             loop_proxies: bool = True) -> Dict[str, Any]:
        """
        Gán danh sách proxy tĩnh hàng loạt cho các kênh:
        - proxy_list: Danh sách proxy dạng chuỗi (hỗ trợ ip:port, ip:port:user:pass, http://...)
        - ratio: Số lượng kênh dùng chung 1 proxy (mặc định 5 kênh / 1 proxy)
        - channel_ids: Danh sách ID kênh (nếu None thì lấy toàn bộ kênh)
        - sort_order: 'id_asc' (theo thứ tự tạo STT 1->1000), 'id_desc' hoặc giữ nguyên thứ tự truyền vào
        - loop_proxies: Tự động xoay vòng proxy nếu số lượng kênh nhiều hơn số proxy
        """
        clean_proxies = []
        for p in proxy_list:
            raw = str(p or "").strip()
            if raw and not raw.startswith("#"):
                clean_proxies.append(raw)

        if not clean_proxies:
            return {
                "success": False,
                "message": "Danh sách proxy rỗng hoặc không có proxy nào hợp lệ!",
                "assigned_count": 0
            }

        ratio = max(1, int(ratio))

        with self._get_connection() as conn:
            cursor = conn.cursor()
            if channel_ids and len(channel_ids) > 0:
                if sort_order == "id_asc":
                    placeholders = ",".join("?" for _ in channel_ids)
                    cursor.execute(f"SELECT id, name, username FROM channels WHERE id IN ({placeholders}) ORDER BY id ASC", channel_ids)
                    channels = [dict(r) for r in cursor.fetchall()]
                else:
                    # Giữ nguyên thứ tự của channel_ids truyền vào
                    channels = []
                    for cid in channel_ids:
                        cursor.execute("SELECT id, name, username FROM channels WHERE id = ?", (cid,))
                        row = cursor.fetchone()
                        if row:
                            channels.append(dict(row))
            else:
                order_sql = "ORDER BY id ASC" if sort_order == "id_asc" else "ORDER BY id DESC"
                cursor.execute(f"SELECT id, name, username FROM channels {order_sql}")
                channels = [dict(r) for r in cursor.fetchall()]

            if not channels:
                return {
                    "success": False,
                    "message": "Không tìm thấy kênh nào trong hệ thống để gán proxy!",
                    "assigned_count": 0
                }

            assigned = []
            total_proxies = len(clean_proxies)

            for i, ch in enumerate(channels):
                p_idx = i // ratio
                if p_idx < total_proxies:
                    target_proxy = clean_proxies[p_idx]
                elif loop_proxies:
                    target_proxy = clean_proxies[p_idx % total_proxies]
                else:
                    break  # Đã gán hết proxy có sẵn và không xoay vòng

                cursor.execute("""
                    UPDATE channels
                    SET network_type = 'proxy',
                        proxy_string = ?,
                        use_vpn = 1
                    WHERE id = ?
                """, (target_proxy, ch["id"]))

                group_num = (i // ratio) + 1
                idx_in_grp = (i % ratio) + 1
                assigned.append({
                    "channel_id": ch["id"],
                    "channel_name": ch["name"],
                    "username": ch.get("username", ""),
                    "proxy": target_proxy,
                    "group": group_num,
                    "index_in_group": idx_in_grp
                })

            conn.commit()

            return {
                "success": True,
                "message": f"Đã gán thành công {len(assigned)} kênh với tỉ lệ {ratio} kênh / 1 Proxy!",
                "assigned_count": len(assigned),
                "total_channels": len(channels),
                "proxy_count": total_proxies,
                "assigned_details": assigned
            }

    def batch_clear_proxies(self, channel_ids: Optional[List[int]] = None) -> int:
        """Gỡ bỏ toàn bộ proxy và chuyển các kênh về dùng VPN mặc định"""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            if channel_ids and len(channel_ids) > 0:
                placeholders = ",".join("?" for _ in channel_ids)
                cursor.execute(f"""
                    UPDATE channels
                    SET network_type = 'vpn',
                        proxy_string = '',
                        use_vpn = 1
                    WHERE id IN ({placeholders})
                """, channel_ids)
            else:
                cursor.execute("""
                    UPDATE channels
                    SET network_type = 'vpn',
                        proxy_string = '',
                        use_vpn = 1
                """)
            count = cursor.rowcount
            conn.commit()
            return count

db = DatabaseManager()
