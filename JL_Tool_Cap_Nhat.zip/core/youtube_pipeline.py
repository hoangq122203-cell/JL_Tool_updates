# -*- coding: utf-8 -*-
"""
YOUTUBE TO TIKTOK SHORTS AUTO PIPELINE
Tự động lấy video phổ biến nhất từ YouTube (chống trùng lặp 100%),
cắt theo nhịp giữ chân khán giả, edit chuẩn dọc 9:16 có mờ viền & CTA follow,
và tự động rải lịch đăng theo ngày độc quyền cho từng kênh TikTok.
"""

import os
import sys
import math
import time
import json
import random
import re
import subprocess
from pathlib import Path
from datetime import datetime, timedelta, date
from typing import Dict, Any, List, Optional, Tuple

def _ensure_yt_dlp():
    """Đảm bảo thư viện yt_dlp luôn luôn sẵn sàng và hoạt động mượt mà"""
    try:
        import yt_dlp
        return yt_dlp
    except ImportError:
        import site
        try:
            for p in site.getsitepackages():
                if p not in sys.path:
                    sys.path.append(p)
        except Exception:
            pass
        try:
            user_site = site.getusersitepackages()
            if user_site not in sys.path:
                sys.path.append(user_site)
        except Exception:
            pass

        try:
            import yt_dlp
            return yt_dlp
        except ImportError:
            # Tự động tải và cài đặt yt-dlp chạy ngầm trong 5 giây nếu máy khách bị thiếu
            try:
                subprocess.run(
                    [sys.executable, "-m", "pip", "install", "yt-dlp", "--quiet", "--no-warn-script-location"],
                    capture_output=True, timeout=60, creationflags=0x08000000
                )
                import yt_dlp
                return yt_dlp
            except Exception:
                raise ImportError("Chưa cài đặt thư viện yt_dlp. Vui lòng bấm 'Cai_Dat_JL_Tool.bat' để tự động cài đặt!")

from database.db_manager import db
from core.anti_shadowban import get_ffmpeg_path

def _clean_filename(text: str) -> str:
    """Xóa ký tự đặc biệt khỏi tên file"""
    clean = re.sub(r'[\\/*?:"<>|]', '', text)
    return clean.strip()[:80]

def resolve_youtube_channel_title(url: str) -> str:
    """
    Tự động phân tích và lấy chính xác TÊN THẬT (Official Channel Name) của kênh YouTube từ link.
    Xử lý mọi định dạng:
    - https://www.youtube.com/channel/UC... -> Lấy tên thật (Ví dụ: 'Cong TV')
    - https://www.youtube.com/@handle -> Lấy tên thật kênh (Ví dụ: 'Wowowin')
    - https://www.youtube.com/watch?v=... -> Lấy tên kênh xuất bản
    Tuyệt đối không hiển thị đường link hay chuỗi mã ID 'UC...' thô kệch.
    """
    if not url or not url.strip():
        return ""
    
    clean_url = url.strip()

    # 1. Thử lấy siêu tốc bằng HTTP Request đọc thẻ meta og:title hoặc title tag (tốc độ ~0.2s)
    try:
        import urllib.request
        req = urllib.request.Request(
            clean_url,
            headers={'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'}
        )
        with urllib.request.urlopen(req, timeout=3.5) as resp:
            html = resp.read().decode('utf-8', errors='ignore')
            m_og = re.search(r'<meta property="og:title" content="([^"]+)"', html)
            if m_og and m_og.group(1).strip():
                t = m_og.group(1).strip()
                if not t.startswith("http") and t.lower() != "youtube" and not t.startswith("UC"):
                    return t
            m_t = re.search(r'<title>([^<]+)</title>', html)
            if m_t:
                t = re.sub(r'\s*-\s*YouTube$', '', m_t.group(1), flags=re.I).strip()
                if t and t.lower() != "youtube" and not t.startswith("UC"):
                    return t
    except Exception:
        pass

    # 2. Nếu link dạng @handle
    m = re.search(r"@([a-zA-Z0-9_\-\.]+)", clean_url)
    if m:
        return m.group(1)

    # 3. Quét dự phòng bằng yt-dlp nếu là link video hoặc dạng khác
    try:
        yt_dlp = _ensure_yt_dlp()
        with yt_dlp.YoutubeDL({'extract_flat': True, 'quiet': True}) as ydl:
            info = ydl.extract_info(clean_url, download=False)
            if info:
                name = info.get('channel') or info.get('uploader') or info.get('title')
                if name and not name.startswith("UC"):
                    return name
    except Exception:
        pass

    return ""

def normalize_youtube_source_url(raw_url: str, sort_mode: str = "popular") -> str:
    """
    Tự động chuẩn hóa mọi link YouTube (link trang chủ, link @handle, link /featured, có tham số ?si=...)
    thành URL danh sách video công khai chuẩn 100% để tool tự động vào lấy video.
    """
    u = (raw_url or "").strip()
    if not u:
        return ""

    if u.startswith("@"):
        u = f"https://www.youtube.com/{u}"
    elif not u.startswith(("http://", "https://")):
        u = f"https://{u}"

    from urllib.parse import urlparse, urlunparse
    p = urlparse(u)

    # Nếu là link video cụ thể (watch?v=, youtu.be, /shorts/) -> Giữ nguyên
    if "watch" in p.path or "youtu.be" in p.netloc or "/shorts/" in p.path:
        return u

    # Làm sạch các trang con không phải video (featured, about, community...)
    path = p.path.rstrip('/')
    for suffix in ['/featured', '/community', '/about', '/channels', '/playlists', '/streams', '/store', '/videos']:
        if path.endswith(suffix):
            path = path[:-len(suffix)]
            break

    # Trỏ thẳng vào tab /videos của kênh
    path += '/videos'

    # Gán tiêu chí sắp xếp
    q = 'view=0&sort=p' if sort_mode == 'popular' else ('view=0&sort=dd' if sort_mode == 'latest' else 'view=0&sort=da')
    return urlunparse((p.scheme or 'https', p.netloc or 'www.youtube.com', path, '', q, ''))


def parse_views_str(text: str) -> int:
    """Chuyển chuỗi view YouTube (25M, 1.2M, 850K, 12,345) thành số nguyên view chính xác"""
    m = re.search(r"([\d\.]+)\s*([kmbt])?", (text or "").replace(",", "").lower())
    if not m:
        return 0
    val = float(m.group(1))
    unit = m.group(2)
    if unit == "k":
        val *= 1_000
    elif unit == "m":
        val *= 1_000_000
    elif unit == "b":
        val *= 1_000_000_000
    return int(val)

def parse_duration_str(text: str) -> int:
    """Chuyển chuỗi thời lượng (12:34, 1:02:30) thành tổng số giây"""
    parts = [int(p) for p in re.findall(r"\d+", text or "")]
    if len(parts) == 3:
        return parts[0] * 3600 + parts[1] * 60 + parts[2]
    elif len(parts) == 2:
        return parts[0] * 60 + parts[1]
    elif len(parts) == 1:
        return parts[0]
    return 0

def fetch_innertube_channel_videos(channel_url: str, sort_mode: str = "popular") -> List[Dict[str, Any]]:
    """
    Trích xuất danh sách video YouTube chính xác 100% theo đúng tab phân loại (Popular, Oldest, Latest)
    sử dụng trực tiếp InnerTube API chuẩn của YouTube Web.
    Đảm bảo:
    - popular: Luôn luôn lấy đúng video nhiều view nhất của kênh (triệu view / chục triệu view).
    - oldest: Luôn luôn lấy đúng video cũ nhất (tập 1 / khởi đầu của kênh).
    - latest: Luôn luôn lấy đúng video mới tải lên gần đây nhất.
    """
    import requests
    import urllib.parse
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36",
        "Accept-Language": "en-US,en;q=0.9"
    }
    u = channel_url.rstrip("/")
    if not u.endswith("/videos"):
        u += "/videos"

    try:
        r = requests.get(u, headers=headers, timeout=10)
        m = re.search(r"var ytInitialData = ({.*?});</script>", r.text)
        if not m:
            return []
        data = json.loads(m.group(1))

        uploader_name = ""
        try:
            uploader_name = data.get("header", {}).get("pageHeaderRenderer", {}).get("pageTitle", "")
            if not uploader_name:
                uploader_name = data.get("metadata", {}).get("channelMetadataRenderer", {}).get("title", "")
        except Exception:
            pass

        chips = []
        initial_items = []
        tabs = data.get("contents", {}).get("twoColumnBrowseResultsRenderer", {}).get("tabs", [])
        for t in tabs:
            tab_r = t.get("tabRenderer", {})
            if tab_r.get("selected"):
                rg = tab_r.get("content", {}).get("richGridRenderer", {})
                chips = rg.get("header", {}).get("chipBarViewModel", {}).get("chips", [])
                initial_items = rg.get("contents", [])
                break

        target_chip = "Popular" if sort_mode == "popular" else ("Oldest" if sort_mode == "oldest" else "Latest")
        token = None
        for c in chips:
            vm = c.get("chipViewModel", {})
            if vm.get("text", "").lower() == target_chip.lower():
                token = vm.get("tapCommand", {}).get("innertubeCommand", {}).get("continuationCommand", {}).get("token")
                break

        def extract_from_items(raw_items):
            vids = []
            for it in raw_items:
                lk = it.get("richItemRenderer", {}).get("content", {}).get("lockupViewModel")
                if lk:
                    vid = lk.get("contentId")
                    if not vid:
                        continue
                    meta = lk.get("metadata", {}).get("lockupMetadataViewModel", {})
                    title = meta.get("title", {}).get("content", "")
                    rows = meta.get("metadata", {}).get("contentMetadataViewModel", {}).get("metadataRows", [])
                    view_str = ""
                    if rows:
                        parts = rows[0].get("metadataParts", [])
                        if len(parts) > 0:
                            view_str = parts[0].get("text", {}).get("content", "")
                    dur_str = ""
                    for ov in lk.get("contentImage", {}).get("thumbnailViewModel", {}).get("overlays", []):
                        for b in ov.get("thumbnailOverlayBadgeViewModel", {}).get("thumbnailBadges", []):
                            dur_str = b.get("thumbnailBadgeViewModel", {}).get("text", "")
                    vids.append({
                        "id": vid,
                        "title": title,
                        "view_count": parse_views_str(view_str),
                        "duration": parse_duration_str(dur_str),
                        "url": f"https://www.youtube.com/watch?v={vid}",
                        "uploader_name": uploader_name or "YouTube Source"
                    })
            return vids

        if token:
            unquoted = urllib.parse.unquote(token)
            payload = {
                "context": {
                    "client": {
                        "clientName": "WEB",
                        "clientVersion": "2.20261106.01.00",
                        "hl": "en",
                        "gl": "US"
                    }
                },
                "continuation": unquoted
            }
            res = requests.post("https://www.youtube.com/youtubei/v1/browse", json=payload, headers=headers, timeout=10).json()
            actions = res.get("onResponseReceivedActions", [])
            for act in actions:
                c_items = act.get("reloadContinuationItemsCommand", {}).get("continuationItems", [])
                extracted = extract_from_items(c_items)
                if extracted:
                    return extracted

        return extract_from_items(initial_items)
    except Exception:
        return []

def fetch_best_youtube_video(
    source_url: str,
    channel_id: int,
    sort_mode: str = "popular",
    log_func=None,
    exclude_ids: Optional[set] = None,
    min_duration_sec: float = 0.0
) -> Optional[Dict[str, Any]]:
    """
    Tìm video phù hợp nhất từ kênh/playlist/video YouTube theo tiêu chí:
    - popular: Video phổ biến nhất (nhiều view nhất)
    - latest: Video mới tải lên gần đây nhất
    - oldest: Video cũ nhất (tập đầu tiên / khởi đầu của kênh)
    Đảm bảo kênh TikTok này CHƯA TỪNG LẤY video đó trước đây.
    """
    def log(msg: str):
        if log_func:
            try: log_func(msg)
            except Exception: pass

    yt_dlp = _ensure_yt_dlp()

    raw_input = source_url.strip()
    if not raw_input:
        return None

    # Tự động nhận diện và chuẩn hóa mọi định dạng link trang chủ YouTube
    url = normalize_youtube_source_url(raw_input, sort_mode=sort_mode)

    sort_labels = {
        "popular": "Phổ Biến Nhất (Nhiều View Nhất)",
        "latest": "Mới Nhất (Vừa Tải Lên Gần Đây)",
        "oldest": "Cũ Nhất (Từ Tập Đầu Tiên / Khởi Đầu)"
    }
    mode_name = sort_labels.get(sort_mode, sort_mode)
    log(f"🔎 [YouTube AI] Đang vào nguồn YouTube '{url}' theo tiêu chí: [{mode_name}]...")

    processed_ids = db.get_processed_youtube_ids(channel_id)
    if exclude_ids:
        processed_ids = processed_ids.union(exclude_ids)

    # ƯU TIÊN SỐ 1: Trích xuất chuẩn xác 100% từ YouTube InnerTube API theo đúng tab Popular / Oldest / Latest
    # Đảm bảo tuyệt đối không nhầm lẫn:
    # - Popular: Lấy đúng video nhiều view nhất lịch sử kênh (25M, 18M, 10M views...)
    # - Oldest: Lấy đúng video từ tập 1 / video đầu tiên của kênh
    # - Latest: Lấy đúng video vừa mới tải lên gần đây nhất
    pref_min_dur = max(30.0, float(min_duration_sec or 0.0))
    if any(k in raw_input for k in ["@", "/channel/", "/c/", "/user/"]) and not any(k in raw_input for k in ["watch?v=", "youtu.be", "/shorts/"]):
        try:
            it_videos = fetch_innertube_channel_videos(raw_input, sort_mode=sort_mode)
            if it_videos:
                log(f"📊 [YouTube AI InnerTube] Đã đồng bộ chuẩn xác danh sách tab [{mode_name}] ({len(it_videos)} video).")
                chosen_it = None
                fallback_it = None
                for iv in it_videos:
                    vid_id = iv["id"]
                    if vid_id in processed_ids:
                        continue
                    dur = iv.get("duration", 0)
                    if dur > 0 and dur < 30:
                        continue
                    if dur > 0 and dur < pref_min_dur:
                        if fallback_it is None:
                            fallback_it = iv
                        continue
                    chosen_it = iv
                    break

                selected_iv = chosen_it or fallback_it
                if selected_iv:
                    vid_id = selected_iv["id"]
                    dur = selected_iv.get("duration", 0)
                    v_str = f"{selected_iv['view_count']:,} views" if selected_iv.get("view_count") else "N/A views"
                    dur_s = f"{dur // 60}m{dur % 60}s" if dur else "Đang kiểm tra"
                    badge = "🔥 [CHỌN VIDEO PHỔ BIẾN NHẤT]" if sort_mode == "popular" else ("⏳ [CHỌN VIDEO CŨ NHẤT / TẬP 1]" if sort_mode == "oldest" else "✨ [CHỌN VIDEO MỚI NHẤT]")
                    log(f"{badge}: '{selected_iv['title']}' ({v_str} | {dur_s}) [Nguồn: @{selected_iv.get('uploader_name')}]")
                    return {
                        "id": vid_id,
                        "title": selected_iv["title"],
                        "url": selected_iv["url"],
                        "view_count": selected_iv.get("view_count", 0),
                        "duration": dur,
                        "thumbnail": f"https://i.ytimg.com/vi/{vid_id}/hqdefault.jpg",
                        "uploader_name": selected_iv.get("uploader_name", "")
                    }
        except Exception as e_it:
            log(f"ℹ️ Chuyển sang quét dự phòng: {e_it}")

    ydl_opts = {
        'extract_flat': True,
        'quiet': True,
        'no_warnings': True,
        'playlistend': 250,  # Quét danh sách sâu lên tới 250 video để không bao giờ cạn nguồn
        'socket_timeout': 10,
    }

    try:
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            info = ydl.extract_info(url, download=False)
            if not info:
                log("⚠️ Không tìm thấy thông tin từ link YouTube cung cấp.")
                return None

            entries = []
            if 'entries' in info and info['entries']:
                entries = list(info['entries'])
            else:
                entries = [info]

            log(f"📊 Tìm thấy tổng cộng {len(entries)} video trên nguồn YouTube.")

            # MẶC ĐỊNH CHỈ LẤY VIDEO CÔNG KHAI (PUBLIC VIDEOS ONLY):
            # Tự động loại bỏ hoàn toàn: video Hội viên (subscriber_only, members_only, needs_auth),
            # video riêng tư/không công khai (private, unlisted), video công chiếu chưa phát (is_upcoming, is_live).
            candidate_videos = []
            for e in entries:
                vid_id = e.get('id') or ''
                if not vid_id:
                    continue
                if vid_id in processed_ids:
                    continue

                # 1. Kiểm tra trạng thái phát trực tiếp / công chiếu
                live_st = str(e.get('live_status') or '').lower()
                if live_st in ('is_upcoming', 'is_live', 'post_live'):
                    continue

                # 2. MẶC ĐỊNH CHỈ LẤY VIDEO CÔNG KHAI: Loại bỏ 100% video Hội viên hoặc bị khóa quyền
                avail = str(e.get('availability') or '').lower()
                if avail and avail not in ('public', 'none', ''):
                    continue

                # 3. Bỏ qua video quá ngắn (< 30s)
                duration = e.get('duration') or 0
                if duration > 0 and duration < 30:
                    continue

                candidate_videos.append(e)

            if not candidate_videos:
                log(f"⚠️ Toàn bộ video công khai trên nguồn này đã được xử lý cho kênh TikTok #{channel_id} rồi! (Chống trùng lặp 100%).")
                return None

            # Ưu tiên video đủ dài theo cấu hình min_duration_sec (nếu có); chỉ fallback nếu không có video nào dài hơn
            preferred_candidates = [e for e in candidate_videos if not e.get("duration") or float(e.get("duration") or 0) >= pref_min_dur]
            pool_videos = preferred_candidates if preferred_candidates else candidate_videos

            # Sắp xếp pool_videos theo sort_mode
            if sort_mode == "popular":
                def get_view_count(item):
                    v = item.get('view_count')
                    return int(v) if v is not None else 0

                pool_videos.sort(key=get_view_count, reverse=True)
                best_video = pool_videos[0]
                badge = "🔥 [CHỌN VIDEO PHỔ BIẾN NHẤT]"
            elif sort_mode == "oldest":
                # Lấy video cũ nhất (tập 1/khởi đầu): lấy từ cuối danh sách hoặc đảo ngược
                pool_videos.reverse()
                best_video = pool_videos[0]
                badge = "⏳ [CHỌN VIDEO CŨ NHẤT / TẬP 1]"
            else:  # latest
                # Mới nhất: video đầu tiên trong danh sách uploads
                best_video = pool_videos[0]
                badge = "✨ [CHỌN VIDEO MỚI NHẤT]"

            vid_id = best_video.get('id')
            title = best_video.get('title', 'Video YouTube')
            views = best_video.get('view_count', 0)
            dur = best_video.get('duration', 0)

            # Lấy tên kênh YouTube nguồn
            uploader_name = (
                info.get('uploader') or 
                info.get('channel') or 
                info.get('uploader_id') or 
                best_video.get('uploader') or 
                best_video.get('channel') or 
                ''
            )
            if not uploader_name and 'title' in info:
                t = str(info['title'])
                if ' - Videos' in t:
                    uploader_name = t.replace(' - Videos', '').strip()
                elif ' - YouTube' in t:
                    uploader_name = t.replace(' - YouTube', '').strip()
                else:
                    uploader_name = t
            if not uploader_name:
                uploader_name = "YouTube Source"

            dur_str = f"{dur // 60}m{dur % 60}s" if dur else "Đang kiểm tra"
            view_str = f"{views:,} views" if views else "N/A view"
            log(f"{badge}: '{title}' ({view_str} | {dur_str}) [Nguồn: @{uploader_name}]")
            return {
                "id": vid_id,
                "title": title,
                "url": best_video.get('url') or f"https://www.youtube.com/watch?v={vid_id}",
                "view_count": views,
                "duration": dur,
                "thumbnail": best_video.get('thumbnail', ''),
                "uploader_name": uploader_name
            }

    except Exception as e:
        log(f"❌ Lỗi khi đọc dữ liệu YouTube: {e}")
        return None

def fetch_best_popular_video(source_url: str, channel_id: int, log_func=None) -> Optional[Dict[str, Any]]:
    """Tương thích ngược: Mặc định lấy video phổ biến nhất"""
    return fetch_best_youtube_video(source_url, channel_id, sort_mode="popular", log_func=log_func)

_direct_yt_bot_blocked_until = 0.0


def _is_yt_bot_block_error(err_text: str) -> bool:
    low = (err_text or "").lower()
    return any(
        k in low
        for k in (
            "not a bot",
            "sign in to confirm",
            "confirm you’re not a bot",
            "confirm you're not a bot",
            "http error 429",
            "too many requests",
        )
    )


def _get_yt_fallback_proxies(channel_id: Optional[int] = None) -> List[str]:
    """Thu thập danh sách Proxy hợp lệ (ưu tiên Proxy của kênh, sau đó Proxy pool) dùng khi IP gốc bị YouTube chặn."""
    raw_candidates: List[str] = []
    try:
        if channel_id:
            ch = db.get_channel(channel_id)
            if ch and str(ch.get("proxy_string") or "").strip():
                raw_candidates.append(str(ch["proxy_string"]).strip())
    except Exception:
        pass
    try:
        from core.rotating_proxy_manager import rotating_proxy_mgr
        for p in (rotating_proxy_mgr.get_config().get("proxies") or []):
            if str(p).strip():
                raw_candidates.append(str(p).strip())
    except Exception:
        pass

    formatted: List[str] = []
    seen = set()
    try:
        from core.network_manager import network_mgr
        for raw_p in raw_candidates:
            parsed = network_mgr.parse_proxy_string(raw_p)
            p_url = parsed.get("url") if parsed else None
            if p_url and p_url not in seen:
                seen.add(p_url)
                formatted.append(p_url)
    except Exception:
        pass
    return formatted


def download_youtube_video(
    video_url: str,
    output_dir: str,
    log_func=None,
    channel_id: Optional[int] = None,
) -> Optional[Tuple[str, str]]:
    """
    Tải video YouTube về máy tính ở độ phân giải tốt nhất (1080p hoặc 720p).
    Tự động chuyển sang Proxy dự phòng / Cookies nếu IP gốc bị YouTube yêu cầu xác minh Bot.
    Trả về: (đường dẫn file video mp4 đã tải, tiêu đề video)
    """
    global _direct_yt_bot_blocked_until

    def log(msg: str):
        if log_func:
            try: log_func(msg)
            except Exception: pass

    yt_dlp = _ensure_yt_dlp()

    os.makedirs(output_dir, exist_ok=True)
    out_template = os.path.join(output_dir, "%(title).60s_%(id)s.%(ext)s")

    log("📥 Đang tải video tốc độ cao (Đa luồng 16 kết nối đồng thời - Turbo Download) từ YouTube về máy tính...")

    base_opts = {
        'format': 'best[height<=1080][ext=mp4]/bestvideo[height<=1080][ext=mp4]+bestaudio[ext=m4a]/bestvideo[height<=1080]+bestaudio/best[height<=1080]/best',
        'outtmpl': out_template,
        'merge_output_format': 'mp4',
        'quiet': True,
        'no_warnings': True,
        'concurrent_fragment_downloads': 3,
        'http_chunk_size': 4194304,
        'buffersize': 2 * 1024 * 1024,
        'retries': 3,
        'fragment_retries': 3,
        'socket_timeout': 15,
        'nocheckcertificate': True,
    }
    try:
        import config
        cookies_txt = os.path.join(str(config.DATA_DIR), "youtube_cookies.txt")
        if os.path.isfile(cookies_txt) and os.path.getsize(cookies_txt) > 0:
            base_opts['cookiefile'] = cookies_txt
    except Exception:
        pass

    ffmpeg_bin = get_ffmpeg_path()
    if ffmpeg_bin:
        base_opts['ffmpeg_location'] = ffmpeg_bin

    fallback_proxies = _get_yt_fallback_proxies(channel_id)
    routes: List[Optional[str]] = []
    if fallback_proxies and time.time() < _direct_yt_bot_blocked_until:
        routes.extend(fallback_proxies)
    else:
        routes.append(None)
        routes.extend(fallback_proxies)

    for proxy_url in routes:
        ydl_opts = dict(base_opts)
        if proxy_url:
            ydl_opts['proxy'] = proxy_url
            ydl_opts['concurrent_fragment_downloads'] = 2
        try:
            with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                meta = ydl.extract_info(video_url, download=True)
                filename = ydl.prepare_filename(meta)
                if not filename.endswith('.mp4'):
                    base = os.path.splitext(filename)[0]
                    if os.path.isfile(base + '.mp4'):
                        filename = base + '.mp4'

                if os.path.isfile(filename) and os.path.getsize(filename) > 50000:
                    title = meta.get('title', 'YouTube Video')
                    via_note = " (qua Proxy)" if proxy_url else ""
                    log(f"✅ Tải thành công{via_note} ({os.path.getsize(filename) / (1024*1024):.1f} MB): {os.path.basename(filename)}")
                    return filename, title
                else:
                    log("❌ Tải video không thành công hoặc file rỗng.")
                    return None
        except Exception as e:
            err_str = str(e)
            if proxy_url is None and _is_yt_bot_block_error(err_str):
                _direct_yt_bot_blocked_until = time.time() + 600
                if fallback_proxies:
                    log("⚠️ IP mạng trực tiếp đang bị YouTube chặn ('not a bot') ➔ Tự động chuyển sang Proxy để tải video...")
                    continue
                log("❌ YouTube chặn IP tải video ('Sign in to confirm you're not a bot') và chưa có Proxy dự phòng khả dụng.")
                return None
            if proxy_url is not None and len(routes) > 1:
                log(f"⚠️ Tải qua Proxy chưa thành công ({err_str[:80]}...), đang thử tuyến khác...")
                continue
            log(f"❌ Lỗi tải YouTube: {e}")
            return None

    return None

def _get_video_duration(video_path: str, ffmpeg_bin: str) -> float:
    """Lấy thời lượng video tính bằng giây qua ffprobe/ffmpeg"""
    try:
        cmd = [
            ffmpeg_bin, "-i", video_path
        ]
        r = subprocess.run(cmd, capture_output=True, text=True, creationflags=0x08000000)
        # Search for Duration: 00:00:00.00
        m = re.search(r"Duration:\s*(\d{2}):(\d{2}):(\d{2}\.\d+)", r.stderr)
        if m:
            h, mi, s = m.groups()
            return int(h) * 3600 + int(mi) * 60 + float(s)
    except Exception:
        pass
    return 0.0

def detect_channel_country_by_id(channel_id: Optional[int] = None) -> str:
    """
    Tự động nhận diện mã quốc gia của kênh dựa trên:
    1. Cấu hình vpn_region riêng của kênh
    2. Địa chỉ IP của Proxy tĩnh / Xoay tua mà kênh đang dùng
    3. Cấu hình VPN toàn cục (global_vpn_region)
    4. Trả về 'VN' nếu dùng IP Việt Nam, ngược lại trả về mã quốc gia (ví dụ: 'PH', 'US'...)
    """
    try:
        from database.db_manager import db
        ch = db.get_channel(channel_id) if channel_id else None
        if ch:
            vr = (ch.get("vpn_region") or "").lower().strip()
            if "philippin" in vr or vr == "ph": return "PH"
            if "vietnam" in vr or vr == "vn": return "VN"
            if "us" in vr or "united-states" in vr: return "US"
            if "jp" in vr or "japan" in vr: return "JP"
            if "kr" in vr or "korea" in vr: return "KR"
            if "thailand" in vr or vr == "th": return "TH"

            ps = (ch.get("proxy_string") or "").strip()
            if ps:
                m = re.search(r"(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})", ps)
                if m:
                    ip = m.group(1)
                    cached_geo = db.get_setting(f"proxy_geo_{ip}", "")
                    if cached_geo:
                        return cached_geo.upper()
                    try:
                        import urllib.request, json
                        req = urllib.request.Request(f"http://ip-api.com/json/{ip}?fields=countryCode", headers={"User-Agent": "Mozilla/5.0"})
                        res = json.loads(urllib.request.urlopen(req, timeout=2.5).read().decode("utf-8"))
                        cc = res.get("countryCode")
                        if cc:
                            cc = cc.upper()
                            db.set_setting(f"proxy_geo_{ip}", cc)
                            return cc
                    except Exception:
                        pass

        # Kiểm tra cài đặt VPN toàn cục
        g_vpn = (db.get_setting("global_vpn_region", "") or "").lower().strip()
        if "philippin" in g_vpn or g_vpn == "ph": return "PH"
        if "vietnam" in g_vpn or g_vpn == "vn": return "VN"
        if "us" in g_vpn: return "US"
        if "jp" in g_vpn: return "JP"
        if "kr" in g_vpn: return "KR"
        if "thailand" in g_vpn: return "TH"

        # Kiểm tra Rotating Proxy Pool
        pool = db.get_setting("rotating_proxy_pool", "")
        if pool:
            m = re.search(r"(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})", pool)
            if m:
                ip = m.group(1)
                cached_geo = db.get_setting(f"proxy_geo_{ip}", "")
                if cached_geo:
                    return cached_geo.upper()
                try:
                    import urllib.request, json
                    req = urllib.request.Request(f"http://ip-api.com/json/{ip}?fields=countryCode", headers={"User-Agent": "Mozilla/5.0"})
                    res = json.loads(urllib.request.urlopen(req, timeout=2.5).read().decode("utf-8"))
                    cc = res.get("countryCode")
                    if cc:
                        cc = cc.upper()
                        db.set_setting(f"proxy_geo_{ip}", cc)
                        return cc
                except Exception:
                    pass
    except Exception:
        pass
    return "VN"


def get_localized_series_strings(country_code: str, num_parts: int, part_num: int, clean_title: str) -> dict:
    """
    Tạo tiêu đề gắn trên video (header_text), lời kêu gọi follow (footer_text), 
    và caption đăng video theo đúng ngôn ngữ bản địa của quốc gia đang fake IP.
    """
    cc = (country_code or "VN").upper()
    is_vn = (cc in ["VN", "VIETNAM"])
    is_th = (cc in ["TH", "THAILAND"])
    is_jp = (cc in ["JP", "JAPAN"])
    is_kr = (cc in ["KR", "KOREA"])

    # Xóa bớt nếu tiêu đề gốc đã bị lặp 'Part X' hoặc 'Tập X' ở đầu
    title_display = clean_title
    title_display = re.sub(r'^(part|tập|ep|episode)\s*\d+[\s:\-–—|]*', '', title_display, flags=re.IGNORECASE).strip()
    if not title_display:
        title_display = clean_title

    if is_vn:
        if num_parts == 1:
            part_name = f"{title_display}"
            header_text = f"{title_display[:38]}"
            footer_text = "👉 Follow kênh để đón xem video mới nhất!"
            caption = f"{title_display} #fyp #trending #viral #foryou"
            out_suffix = "Short"
        else:
            if part_num < num_parts:
                part_name = f"{title_display} ｜ Tập {part_num}"
                header_text = f"{title_display[:32]} ｜ Tập {part_num}"
                footer_text = "👉 Follow kênh để đón xem Tập tiếp theo!"
                caption = f"{title_display} - Tập {part_num}/{num_parts} | Xem tập tiếp theo tại kênh! #fyp #trending #viral #foryou"
            else:
                part_name = f"{title_display} ｜ Tập {part_num} (Tập cuối)"
                header_text = f"{title_display[:28]} ｜ Tập {part_num} (Tập Cuối)"
                footer_text = "👉 Follow kênh để đón xem Series mới!"
                caption = f"{title_display} - Tập {part_num}/{num_parts} (Tập cuối) | Follow để đón xem Series mới! #fyp #trending #viral #foryou"
            out_suffix = f"Tap_{part_num:02d}"
    elif is_th:
        if num_parts == 1:
            part_name = f"{title_display}"
            header_text = f"{title_display[:38]}"
            footer_text = "👉 ติดตามเพื่อรับชมวิดีโอใหม่ล่าสุด!"
            caption = f"{title_display} #fyp #trending #viral #foryou"
            out_suffix = "Short"
        else:
            if part_num < num_parts:
                part_name = f"{title_display} | ตอนที่ {part_num}"
                header_text = f"{title_display[:32]} | ตอนที่ {part_num}"
                footer_text = "👉 ติดตามเพื่อรับชมตอนต่อไป!"
                caption = f"{title_display} - ตอนที่ {part_num}/{num_parts} | ดูตอนต่อไปได้ที่ช่อง! #fyp #trending #viral #foryou"
            else:
                part_name = f"{title_display} | ตอนที่ {part_num} (ตอนจบ)"
                header_text = f"{title_display[:28]} | ตอนที่ {part_num} (ตอนจบ)"
                footer_text = "👉 ติดตามเพื่อรับชมซีรีส์ใหม่!"
                caption = f"{title_display} - ตอนที่ {part_num}/{num_parts} (ตอนจบ) | ติดตามเพื่อรับชมซีรีส์ใหม่! #fyp #trending #viral #foryou"
            out_suffix = f"Part_{part_num:02d}"
    elif is_jp:
        if num_parts == 1:
            part_name = f"{title_display}"
            header_text = f"{title_display[:38]}"
            footer_text = "👉 フォローして最新動画をチェック！"
            caption = f"{title_display} #fyp #trending #viral #foryou"
            out_suffix = "Short"
        else:
            if part_num < num_parts:
                part_name = f"{title_display} | 第{part_num}話"
                header_text = f"{title_display[:32]} | 第{part_num}話"
                footer_text = "👉 フォローして次のパートを見る！"
                caption = f"{title_display} - 第{part_num}話/{num_parts}話 | 続きはチャンネルで！ #fyp #trending #viral #foryou"
            else:
                part_name = f"{title_display} | 第{part_num}話 (最終回)"
                header_text = f"{title_display[:28]} | 第{part_num}話 (最終回)"
                footer_text = "👉 フォローして新しいシリーズを見る！"
                caption = f"{title_display} - 第{part_num}話/{num_parts}話 (最終回) | 新シリーズもお楽しみに！ #fyp #trending #viral #foryou"
            out_suffix = f"Part_{part_num:02d}"
    elif is_kr:
        if num_parts == 1:
            part_name = f"{title_display}"
            header_text = f"{title_display[:38]}"
            footer_text = "👉 팔로우하고 최신 영상 보기!"
            caption = f"{title_display} #fyp #trending #viral #foryou"
            out_suffix = "Short"
        else:
            if part_num < num_parts:
                part_name = f"{title_display} | 파트 {part_num}"
                header_text = f"{title_display[:32]} | 파트 {part_num}"
                footer_text = "👉 다음 파트를 보려면 팔로우하세요!"
                caption = f"{title_display} - 파트 {part_num}/{num_parts} | 다음 파트는 채널에서 확인하세요! #fyp #trending #viral #foryou"
            else:
                part_name = f"{title_display} | 파트 {part_num} (최종화)"
                header_text = f"{title_display[:28]} | 파트 {part_num} (최종화)"
                footer_text = "👉 팔로우하고 새 시리즈 보기!"
                caption = f"{title_display} - 파트 {part_num}/{num_parts} (최종화) | 새 시리즈도 기대해주세요! #fyp #trending #viral #foryou"
            out_suffix = f"Part_{part_num:02d}"
    else:
        # Quốc gia Quốc tế (Philippines PH, Hoa Kỳ US, Anh GB, Úc AU, Canada CA, Singapore SG...)
        if num_parts == 1:
            part_name = f"{title_display}"
            header_text = f"{title_display[:38]}"
            footer_text = "👉 Follow for more new videos!"
            caption = f"{title_display} #fyp #trending #viral #foryou"
            out_suffix = "Short"
        else:
            if part_num < num_parts:
                next_part = part_num + 1
                part_name = f"{title_display} | Part {part_num}"
                header_text = f"{title_display[:32]} | Part {part_num}"
                footer_text = f"👉 Follow for Part {next_part}!"
                caption = f"{title_display} - Part {part_num}/{num_parts} | Watch next part on channel! #fyp #trending #viral #foryou"
            else:
                part_name = f"{title_display} | Part {part_num} (Finale)"
                header_text = f"{title_display[:28]} | Part {part_num} (Finale)"
                footer_text = "👉 Follow for more series!"
                caption = f"{title_display} - Part {part_num}/{num_parts} (Finale) | Follow for more series! #fyp #trending #viral #foryou"
            out_suffix = f"Part_{part_num:02d}"

    return {
        "part_name": part_name,
        "header_text": header_text,
        "footer_text": footer_text,
        "caption": caption,
        "out_suffix": out_suffix,
        "country_code": cc
    }


def _compute_optimal_part_count(
    total_dur: float,
    min_s: float,
    max_s: float,
    speed_scale: float = 0.975
) -> int:
    """Tính số tập tối ưu sao cho thời lượng xuất thực tế nằm trọn trong [min_s, max_s]."""
    eff_total = max(1.0, float(total_dur) * float(speed_scale))
    if eff_total <= max_s:
        return 1
    k_min = max(1, int(math.ceil(eff_total / max_s)))
    k_max = max(1, int(math.floor(eff_total / min_s)))
    target_dur = (min_s + max_s) / 2.0
    ideal_k = max(1, round(eff_total / target_dur))
    if k_min <= k_max:
        return min(max(ideal_k, k_min), k_max)

    # Khoảng giao (vd: 3m30s với mức 2–3p): chọn số tập ít sai lệch khỏi [min_s, max_s] nhất mà không bỏ dở video
    candidates = sorted({k_max, k_min})
    def _violation(k: int) -> float:
        d = eff_total / k
        if d < min_s:
            return min_s - d
        if d > max_s:
            return d - max_s
        return 0.0
    return min(candidates, key=_violation)


def _validate_rendered_mp4(video_path: str, ffmpeg_bin: str, expected_sec: float) -> Tuple[bool, float]:
    """Kiểm tra file MP4 vừa cắt có đầy đủ moov header và thời lượng hợp lệ."""
    if not os.path.isfile(video_path) or os.path.getsize(video_path) <= 10000:
        return False, 0.0
    dur = _get_video_duration(video_path, ffmpeg_bin)
    min_acceptable = max(5.0, float(expected_sec) * 0.65)
    if expected_sec < 10.0:
        min_acceptable = max(2.0, float(expected_sec) * 0.65)
    return (dur >= min_acceptable), dur


def auto_slice_and_edit_shorts(
    src_video_path: str,
    output_dir: str,
    target_parts: Optional[int] = None,
    segment_duration: int = 35,
    min_duration_sec: float = 30.0,
    max_duration_sec: float = 60.0,
    show_title: str = "",
    crop_mode: str = "blur_9_16",
    target_country: str = "",
    channel_id: Optional[int] = None,
    log_func=None,
    progress_callback=None
) -> List[Dict[str, Any]]:
    """
    Phân tích video và tự động cắt thành các tập ngắn (Tập 1, Tập 2... Tập cuối) 
    chuẩn dọc 9:16 TikTok, mờ viền trên dưới, chèn Header tò mò và Footer kêu gọi follow.
    Tự động tính toán số tập tối ưu theo khoảng thời lượng yêu cầu [min_duration_sec, max_duration_sec],
    đảm bảo các tập đều nhau, không bị cắt dở dang hoặc tập cuối quá ngắn.
    """
    def log(msg: str):
        if log_func:
            try: log_func(msg)
            except Exception: pass

    ffmpeg_bin = get_ffmpeg_path()
    if not ffmpeg_bin:
        log("❌ Không tìm thấy công cụ FFmpeg để cắt video.")
        return []

    total_dur = _get_video_duration(src_video_path, ffmpeg_bin)
    if total_dur < 10:
        log("⚠️ Thời lượng video quá ngắn (< 10 giây), không thể xử lý.")
        return []

    # Xử lý khoảng thời lượng min - max theo yêu cầu người dùng
    min_s = float(min_duration_sec) if min_duration_sec else 30.0
    max_s = float(max_duration_sec) if max_duration_sec else 60.0
    if min_s > max_s:
        min_s, max_s = max_s, min_s
    min_s = max(10.0, min_s)
    max_s = max(min_s, max_s)

    min_desc = f"{int(min_s // 60)}m{int(min_s % 60)}s" if min_s >= 60 else f"{int(min_s)}s"
    max_desc = f"{int(max_s // 60)}m{int(max_s % 60)}s" if max_s >= 60 else f"{int(max_s)}s"
    log(f"🎬 [Biên Tập Tự Động] Tổng thời lượng video gốc: {int(total_dur // 60)}m{int(total_dur % 60)}s ({total_dur:.1f}s). Yêu cầu mỗi tập: từ {min_desc} đến {max_desc}.")

    # Tính số tập tối ưu có tính đến hệ số tốc độ setpts=0.975*PTS để mỗi tập xuất ra nằm chuẩn [min_s, max_s]:
    try:
        target_parts_int = int(target_parts) if target_parts else 0
    except (ValueError, TypeError):
        target_parts_int = 0

    if target_parts_int > 0:
        num_parts = target_parts_int
    else:
        num_parts = _compute_optimal_part_count(total_dur, min_s, max_s, speed_scale=0.975)

    # Chia đều thời lượng cho mỗi tập để không bị tập cuối quá ngắn hoặc bị cắt dở dang
    seg_len = total_dur / num_parts
    est_out_len = seg_len * 0.975
    seg_min = int(est_out_len // 60)
    seg_sec = int(est_out_len % 60)
    time_str = f"{seg_min} phút {seg_sec} giây" if seg_min > 0 else f"{est_out_len:.1f} giây"
    log(f"⚡ [AI Smart Slice] Tự động chia video thành {num_parts} tập hoàn chỉnh (mỗi tập ~{time_str} đúng chuẩn khoảng {min_desc} – {max_desc})...")

    # Xác định quốc gia / ngôn ngữ của kênh (dựa trên proxy/VPN/cài đặt)
    country_code = (target_country or "").strip().upper()
    if not country_code:
        country_code = detect_channel_country_by_id(channel_id)

    country_name_map = {
        "PH": "Philippines (Tiếng Anh / Tagalog)",
        "US": "Hoa Kỳ (English)",
        "GB": "Vương Quốc Anh (English)",
        "AU": "Úc (English)",
        "CA": "Canada (English)",
        "SG": "Singapore (English)",
        "TH": "Thái Lan (ภาษาไทย)",
        "JP": "Nhật Bản (日本語)",
        "KR": "Hàn Quốc (한국어)",
        "VN": "Việt Nam (Tiếng Việt)"
    }
    lang_name = country_name_map.get(country_code, f"Quốc tế ({country_code}) - English")
    log(f"🌐 [Ngôn Ngữ Kênh] Kênh thuộc khu vực: {lang_name}. Mọi chữ gắn trên video, kêu gọi Follow và Caption đều được tự động đồng bộ 100% theo ngôn ngữ này!")

    os.makedirs(output_dir, exist_ok=True)
    clean_title = _clean_filename(show_title or Path(src_video_path).stem)

    # Tìm font chữ trên máy tính để viết chữ đẹp
    font_path = r"C\:/Windows/Fonts/arialbd.ttf"
    if not os.path.isfile(r"C:\Windows\Fonts\arialbd.ttf"):
        font_path = r"C\:/Windows/Fonts/arial.ttf"

    # Thông số camera giả lập iPhone 15 Pro
    mobile_make = "Apple"
    mobile_model = "iPhone 15 Pro Max"
    mobile_encoder = "Apple QuickTime 17.2"

    import concurrent.futures

    cpu_cnt = os.cpu_count() or 4
    max_workers = min(4, max(2, cpu_cnt // 4)) if num_parts > 1 else 1
    ffmpeg_threads = max(2, min(6, cpu_cnt // max_workers))

    def _render_part(i):
        start_sec = i * seg_len
        # Tập cuối cùng lấy trọn vẹn đến hết video, các tập trước lấy đúng seg_len
        if i == num_parts - 1:
            actual_len = total_dur - start_sec
        else:
            actual_len = seg_len

        part_num = i + 1
        
        # Tiêu đề & Hook theo chuẩn bản địa của quốc gia fake IP
        loc_str = get_localized_series_strings(
            country_code=country_code,
            num_parts=num_parts,
            part_num=part_num,
            clean_title=clean_title
        )
        part_name = loc_str["part_name"]
        header_text = loc_str["header_text"]
        footer_text = loc_str["footer_text"]
        caption = loc_str["caption"]
        out_suffix = loc_str["out_suffix"]
        out_file = os.path.join(output_dir, f"{clean_title}_{out_suffix}.mp4")

        # Escape các ký tự đặc biệt cho FFmpeg drawtext
        escaped_header = header_text.replace("'", "").replace(":", "\\:").replace("｜", "|")
        escaped_footer = footer_text.replace("'", "").replace(":", "\\:")

        # Bộ lọc FFmpeg theo tùy chọn khung hình (crop_mode):
        if crop_mode == "crop_9_16":
            # Cắt giữa dọc 9:16 (1080x1920)
            filter_complex = (
                f"[0:v]crop=ih*9/16:ih:(iw-ih*9/16)/2:0,scale=1080:1920:flags=fast_bilinear[cropped];"
                f"[cropped]drawtext=fontfile='{font_path}':text='{escaped_header}':fontcolor=white:fontsize=42:box=1:boxcolor=black@0.65:boxborderw=15:x=(w-text_w)/2:y=220,"
                f"drawtext=fontfile='{font_path}':text='{escaped_footer}':fontcolor=#FACC15:fontsize=36:box=1:boxcolor=black@0.65:boxborderw=12:x=(w-text_w)/2:y=h-260,"
                f"setpts=0.975*PTS[vout]"
            )
        elif crop_mode == "crop_1_1":
            # Cắt vuông 1:1 (1080x1080)
            filter_complex = (
                f"[0:v]crop=min(iw\\,ih):min(iw\\,ih):(iw-min(iw\\,ih))/2:(ih-min(iw\\,ih))/2,scale=1080:1080:flags=fast_bilinear[cropped];"
                f"[cropped]drawtext=fontfile='{font_path}':text='{escaped_header}':fontcolor=white:fontsize=38:box=1:boxcolor=black@0.65:boxborderw=12:x=(w-text_w)/2:y=100,"
                f"drawtext=fontfile='{font_path}':text='{escaped_footer}':fontcolor=#FACC15:fontsize=32:box=1:boxcolor=black@0.65:boxborderw=10:x=(w-text_w)/2:y=h-130,"
                f"setpts=0.975*PTS[vout]"
            )
        elif crop_mode == "crop_16_9":
            # Cắt / Scale ngang 16:9 (1920x1080)
            filter_complex = (
                f"[0:v]scale=1920:1080:force_original_aspect_ratio=decrease:flags=fast_bilinear,pad=1920:1080:(ow-iw)/2:(oh-ih)/2[cropped];"
                f"[cropped]drawtext=fontfile='{font_path}':text='{escaped_header}':fontcolor=white:fontsize=40:box=1:boxcolor=black@0.65:boxborderw=12:x=(w-text_w)/2:y=100,"
                f"drawtext=fontfile='{font_path}':text='{escaped_footer}':fontcolor=#FACC15:fontsize=32:box=1:boxcolor=black@0.65:boxborderw=10:x=(w-text_w)/2:y=h-130,"
                f"setpts=0.975*PTS[vout]"
            )
        elif crop_mode == "original":
            # Giữ nguyên độ phân giải gốc
            filter_complex = (
                f"[0:v]drawtext=fontfile='{font_path}':text='{escaped_header}':fontcolor=white:fontsize=36:box=1:boxcolor=black@0.65:boxborderw=10:x=(w-text_w)/2:y=60,"
                f"drawtext=fontfile='{font_path}':text='{escaped_footer}':fontcolor=#FACC15:fontsize=30:box=1:boxcolor=black@0.65:boxborderw=8:x=(w-text_w)/2:y=h-80,"
                f"setpts=0.975*PTS[vout]"
            )
        else:
            # Mặc định 'blur_9_16': Scale tạo nền mờ 1080x1920 (blur background)
            # TỐI ƯU SIÊU TỐC: Downscale background xuống 180x320 trước khi blur -> Giảm tải 36 lần tính toán!
            # Sau đó upscale 1080x1920 bằng fast_bilinear tạo nền mờ mịn màng chuẩn điện ảnh, tốc độ tăng gấp 6 - 8 lần!
            filter_complex = (
                f"[0:v]scale=180:320:force_original_aspect_ratio=increase:flags=fast_bilinear,crop=180:320,boxblur=4:1,scale=1080:1920:flags=fast_bilinear[bg];"
                f"[0:v]scale=1080:-1:force_original_aspect_ratio=decrease:flags=fast_bilinear[fg];"
                f"[bg][fg]overlay=(W-w)/2:(H-h)/2[combined];"
                f"[combined]drawtext=fontfile='{font_path}':text='{escaped_header}':fontcolor=white:fontsize=42:box=1:boxcolor=black@0.65:boxborderw=15:x=(w-text_w)/2:y=220,"
                f"drawtext=fontfile='{font_path}':text='{escaped_footer}':fontcolor=#FACC15:fontsize=36:box=1:boxcolor=black@0.65:boxborderw=12:x=(w-text_w)/2:y=h-260,"
                f"setpts=0.975*PTS[vout]"
            )

        tmp_file = f"{out_file}.tmp.mp4"
        try:
            if os.path.exists(tmp_file):
                os.remove(tmp_file)
        except Exception:
            pass

        cmd = [
            ffmpeg_bin,
            "-y",
            "-threads", str(ffmpeg_threads),
            "-filter_complex_threads", str(ffmpeg_threads),
            "-ss", str(start_sec),
            "-t", str(actual_len),
            "-i", src_video_path,
            "-filter_complex", filter_complex,
            "-map", "[vout]",
            "-map", "0:a?",
            "-af", "atempo=1.025",
            "-c:v", "libx264",
            "-preset", "superfast",
            "-crf", "24",
            "-maxrate", "4500k",
            "-bufsize", "9000k",
            "-c:a", "aac",
            "-b:a", "128k",
            "-movflags", "+faststart",
            "-map_metadata", "-1",
            "-metadata", f"make={mobile_make}",
            "-metadata", f"model={mobile_model}",
            "-metadata", f"encoder={mobile_encoder}",
            tmp_file
        ]

        log(f"⚡ Đang render siêu tốc Part {part_num}/{num_parts} (Đa luồng CPU + Blur tối ưu)...")
        render_timeout = max(300, int(actual_len * 3.5))
        # 0x08000000 (CREATE_NO_WINDOW) | 0x00004000 (BELOW_NORMAL_PRIORITY_CLASS): Giữ giao diện/Windows luôn mượt
        ffmpeg_flags = 0x08000000 | 0x00004000 if os.name == "nt" else 0
        expected_out_len = actual_len * 0.975
        res = subprocess.run(cmd, capture_output=True, text=True, timeout=render_timeout, creationflags=ffmpeg_flags)

        ok_primary, dur_primary = (res.returncode == 0, 0.0)
        if ok_primary:
            ok_primary, dur_primary = _validate_rendered_mp4(tmp_file, ffmpeg_bin, expected_out_len)

        if ok_primary:
            os.replace(tmp_file, out_file)
            log(f"✅ Hoàn thành render Part {part_num}/{num_parts} ({dur_primary:.1f}s)!")
            return {
                "part_number": part_num,
                "file_path": out_file,
                "title": part_name,
                "caption": caption,
                "duration": round(dur_primary, 2)
            }

        # Xóa file tạm hỏng trước khi chạy phương án dự phòng
        try:
            if os.path.exists(tmp_file):
                os.remove(tmp_file)
        except Exception:
            pass

        # Dự phòng an toàn: Render cắt khung cơ bản + genpts + faststart (tránh lỗi ký tự hoặc lỗi moov atom)
        vf_fallback = (
            "scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920"
            if crop_mode in ("blur_9_16", "crop_9_16")
            else (
                "scale=1080:1080:force_original_aspect_ratio=increase,crop=1080:1080"
                if crop_mode == "crop_1_1"
                else "scale=1920:1080:force_original_aspect_ratio=decrease,pad=1920:1080:(ow-iw)/2:(oh-ih)/2"
            )
        )
        cmd_fallback = [
            ffmpeg_bin, "-y",
            "-threads", str(ffmpeg_threads),
            "-filter_threads", str(ffmpeg_threads),
            "-fflags", "+genpts",
            "-ss", str(start_sec), "-t", str(actual_len),
            "-i", src_video_path,
            "-vf", vf_fallback,
            "-c:v", "libx264", "-preset", "superfast", "-crf", "24", "-maxrate", "4500k", "-bufsize", "9000k",
            "-c:a", "aac", "-b:a", "128k",
            "-movflags", "+faststart",
            tmp_file
        ]
        res_fb = subprocess.run(cmd_fallback, capture_output=True, text=True, timeout=render_timeout, creationflags=ffmpeg_flags)
        ok_fb, dur_fb = (res_fb.returncode == 0, 0.0)
        if ok_fb:
            ok_fb, dur_fb = _validate_rendered_mp4(tmp_file, ffmpeg_bin, actual_len)

        if ok_fb:
            os.replace(tmp_file, out_file)
            log(f"✅ Hoàn thành render Part {part_num}/{num_parts} ({dur_fb:.1f}s - Dự phòng)!")
            return {
                "part_number": part_num,
                "file_path": out_file,
                "title": part_name,
                "caption": caption,
                "duration": round(dur_fb, 2)
            }

        try:
            if os.path.exists(tmp_file):
                os.remove(tmp_file)
        except Exception:
            pass
        err_detail = (res.stderr or res_fb.stderr or "")[-140:]
        log(f"⚠️ Render Part {part_num}/{num_parts} không thành công (dur={dur_primary:.1f}s/{dur_fb:.1f}s): {err_detail}")
        return None

    # Tối ưu số luồng song song theo CPU (tối đa 4 tập cùng lúc, kết hợp BELOW_NORMAL_PRIORITY_CLASS để UI vẫn mượt)
    created_parts = []
    done_cnt = 0
    with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = [executor.submit(_render_part, i) for i in range(num_parts)]
        for f in concurrent.futures.as_completed(futures):
            part_res = f.result()
            done_cnt += 1
            if part_res:
                created_parts.append(part_res)
            if progress_callback:
                try:
                    progress_callback(done_cnt, num_parts)
                except Exception:
                    pass

    created_parts.sort(key=lambda x: x["part_number"])
    if len(created_parts) < num_parts:
        log(f"⚠️ Cảnh báo: Chỉ cắt hoàn chỉnh được {len(created_parts)}/{num_parts} tập (thiếu {num_parts - len(created_parts)} tập do lỗi render).")
    else:
        log(f"🎉 Đã biên tập hoàn chỉnh {len(created_parts)}/{num_parts} tập Shorts chuẩn TikTok!")
    return created_parts

import random

def compute_daily_schedule_slots(
    videos_per_day: int = 2,
    schedule_mode: str = "golden",
    interval_minutes: int = 180,
    start_time_str: str = "08:00",
    custom_hours_list: Optional[List[str]] = None
) -> List[str]:
    """
    Tính toán danh sách các khung giờ đăng trong ngày theo chiến lược được chọn:
    - golden: Khung giờ vàng TikTok đề xuất triệu view theo số lượng video
    - interval: Cách nhau cố định X phút (bắt đầu từ start_time_str)
    - custom: Danh sách khung giờ tùy chỉnh do người dùng chỉ định
    """
    if schedule_mode == "custom" and custom_hours_list:
        return custom_hours_list[:videos_per_day] if len(custom_hours_list) >= videos_per_day else custom_hours_list

    if schedule_mode == "interval":
        try:
            parts = start_time_str.split(':')
            sh, sm = int(parts[0]), int(parts[1])
        except Exception:
            sh, sm = 8, 0
        start_m = sh * 60 + sm
        slots = []
        for i in range(max(1, videos_per_day)):
            cur_m = (start_m + i * max(1, interval_minutes)) % 1440
            slots.append(f"{cur_m // 60:02d}:{cur_m % 60:02d}")
        return slots

    # Mặc định: Chiến lược Khung Giờ Vàng TikTok tối ưu đề xuất
    GOLDEN_HOURS_PRESETS = {
        1: ["19:30"],
        2: ["11:30", "19:30"],
        3: ["07:15", "11:45", "20:00"],
        4: ["07:00", "11:30", "17:30", "20:30"],
        5: ["07:00", "11:15", "14:00", "17:30", "20:45"],
        6: ["07:00", "09:30", "11:45", "14:30", "18:00", "21:00"],
    }
    if videos_per_day in GOLDEN_HOURS_PRESETS:
        return GOLDEN_HOURS_PRESETS[videos_per_day]

    # Nếu nhiều hơn 6 video/ngày: Rải đều từ 07:00 đến 22:00
    start_m = 7 * 60
    end_m = 22 * 60
    step = (end_m - start_m) // max(1, videos_per_day - 1)
    slots = []
    for i in range(videos_per_day):
        m = start_m + i * step
        slots.append(f"{m // 60:02d}:{m % 60:02d}")
    return slots

def schedule_series_for_channel(
    channel_id: int,
    parts: List[Dict[str, Any]],
    videos_per_day: int = 2,
    golden_hours: Optional[List[str]] = None,
    schedule_mode: str = "golden",
    interval_minutes: int = 180,
    start_time_str: str = "08:00",
    use_jitter: bool = True,
    start_date: Optional[date] = None,
    upload_mode: str = "cloud",
    log_func=None
) -> Dict[str, Any]:
    """
    Rải đều toàn bộ các tập vừa cắt vào lịch hẹn độc quyền của kênh TikTok,
    tự động nối tiếp mốc thời gian sau video cuối cùng (không bị trùng giờ khi đổi nguồn YouTube),
    hỗ trợ nhiều chiến lược hẹn giờ (Giờ vàng, Cách X phút, Tùy chỉnh, Jitter mô phỏng người thật),
    lưu trữ lên Đám Mây TikTok và báo cáo chi tiết tổng số video.
    """
    def log(msg: str):
        if log_func:
            try: log_func(msg)
            except Exception: pass

    if not parts:
        return {"schedules_added": 0, "total_pending": 0, "today_count": 0, "end_date_str": ""}

    ch = db.get_channel(channel_id)
    ch_name = ch.get("name", f"Kênh #{channel_id}") if ch else f"Kênh #{channel_id}"

    # Tính toán danh sách khung giờ đăng theo chiến lược đã chọn
    daily_slots = compute_daily_schedule_slots(
        videos_per_day=videos_per_day,
        schedule_mode=schedule_mode,
        interval_minutes=interval_minutes,
        start_time_str=start_time_str,
        custom_hours_list=golden_hours
    )

    strat_desc = {
        "golden": f"🔥 Khung Giờ Vàng TikTok ({', '.join(daily_slots)})",
        "interval": f"⏱️ Cách đều nhau {interval_minutes} phút (Từ {start_time_str})",
        "custom": f"✏️ Khung giờ tùy chỉnh ({', '.join(daily_slots)})"
    }.get(schedule_mode, f"Khung giờ ({', '.join(daily_slots)})")

    jitter_desc = " + 🎲 Jitter chống Bot (±3-7 phút)" if use_jitter else ""
    log(f"⏰ Chiến lược hẹn lịch: {strat_desc}{jitter_desc}")

    now = datetime.now()
    
    # TỰ ĐỘNG NỐI TIẾP: Kiểm tra xem kênh này đã có video nào trong tương lai chưa
    last_dt = db.get_channel_latest_schedule_time(channel_id)
    
    if last_dt and last_dt > now:
        # Kênh đã có lịch hẹn trước đó (ví dụ: ngày mai có video cuối) -> Nối tiếp ngay sau video cuối
        log(f"🔗 [Nối Tiếp Thông Minh] Phát hiện kênh đã có video hẹn đến: {last_dt.strftime('%d/%m/%Y %H:%M')}. Hệ thống sẽ tự động xếp các tập mới nối tiếp sau mốc này mà không bị trùng giờ!")
        
        # Bắt đầu từ ngày tiếp theo hoặc slot giờ sau video cuối
        last_date = last_dt.date()
        # Tìm slot kế tiếp trong ngày của last_dt
        next_slot_idx = None
        for s_idx, s_time in enumerate(daily_slots):
            tp = [int(x) for x in s_time.split(':')]
            test_dt = datetime(last_date.year, last_date.month, last_date.day, tp[0], tp[1], 0)
            if test_dt > last_dt + timedelta(minutes=45):
                next_slot_idx = s_idx
                break
        
        if next_slot_idx is not None and next_slot_idx < videos_per_day:
            current_day = last_date
            slot_idx = next_slot_idx
        else:
            current_day = last_date + timedelta(days=1)
            slot_idx = 0
    else:
        # Chưa có lịch hẹn nào hoặc bắt đầu series mới: Luôn luôn bắt đầu từ Slot 0 (Video 1 đúng giờ bắt đầu)
        current_day = start_date or date.today()
        first_slot = daily_slots[0]
        tp0 = [int(x) for x in first_slot.split(':')]
        first_today_dt = datetime(current_day.year, current_day.month, current_day.day, tp0[0], tp0[1], 0)
        if first_today_dt <= now + timedelta(minutes=15):
            current_day += timedelta(days=1)
        slot_idx = 0

    log(f"📅 [Lên Lịch Tự Động] Bắt đầu rải {len(parts)} tập cho kênh '@{ch_name}' từ ngày {current_day.strftime('%d/%m/%Y')} ({videos_per_day} video/ngày)...")

    schedules_added = 0

    for idx, p in enumerate(parts):
        # Xác định giờ đăng
        hour_str = daily_slots[slot_idx % len(daily_slots)]
        time_parts = [int(x) for x in hour_str.split(':')]
        target_dt = datetime(current_day.year, current_day.month, current_day.day, time_parts[0], time_parts[1], 0)

        # Áp dụng Jitter ngẫu nhiên mô phỏng người thật nếu bật
        if use_jitter:
            j_offset = random.randint(-6, 6)
            target_dt += timedelta(minutes=j_offset)

        # Chống trôi vào quá khứ
        if target_dt <= now:
            current_day += timedelta(days=1)
            target_dt = datetime(current_day.year, current_day.month, current_day.day, time_parts[0], time_parts[1], 0)
            if use_jitter:
                target_dt += timedelta(minutes=random.randint(1, 8))

        sched_time_str = target_dt.strftime("%Y-%m-%d %H:%M:%S")

        # 1. Thêm video vào bảng videos nếu chưa có
        vid_id = db.add_video(
            channel_id=channel_id,
            title=p["title"],
            file_path=p["file_path"],
            duration=p.get("duration", 30),
            caption=p.get("caption", p["title"])
        )

        # 2. Thêm vào bảng schedules (Lưu vào Đám Mây TikTok)
        db.add_schedule(
            channel_id=channel_id,
            video_id=vid_id,
            scheduled_time=sched_time_str,
            caption=p.get("caption", p["title"]),
            hashtags="#fyp #trending #viral #foryou",
            upload_mode=upload_mode
        )

        schedules_added += 1

        # Chuyển slot giờ tiếp theo
        slot_idx += 1
        if slot_idx % videos_per_day == 0 or slot_idx >= len(daily_slots):
            current_day += timedelta(days=1)
            slot_idx = 0

    # Tự động quét và dọn sạch 100% video trùng lặp ngay khi về kho
    dup_cleaned = db.clean_duplicate_pending_schedules(channel_id)
    if dup_cleaned > 0:
        log(f"🧹 [Tự Động Quét Kho] Đã loại bỏ {dup_cleaned} video bị cắt trùng lặp, đảm bảo không đăng trùng!")

    # Thống kê tổng hợp sau khi lên lịch xong
    summary = db.get_channel_schedule_summary(channel_id)
    summary["schedules_added"] = schedules_added
    summary["videos_per_day"] = videos_per_day

    log(
        f"🎉 [Lên Lịch Hoàn Tất] Đã nối tiếp thành công {schedules_added} video cho kênh '@{ch_name}'!\n"
        f"📊 TỔNG KẾT KÊNH: Hôm nay đăng {summary['today_count']} video ｜ Tổng cộng hiện có {summary['total_pending']} video trong lịch hẹn.\n"
        f"⏳ Lịch đăng được đảm bảo liên tục đến ngày {summary['end_date_str']}.\n"
        f"☁️ Toàn bộ video được lưu trữ lên Đám Mây TikTok an toàn!"
    )

    return summary

