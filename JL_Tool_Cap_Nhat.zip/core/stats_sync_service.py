import os
import sys
import time
import json
import re
import threading
from typing import Dict, Any, Optional, Callable, List
from database.db_manager import db
from core.chrome_manager import chrome_mgr


def parse_metric_count(val: Any) -> int:
    """Chuyển đổi các định dạng số kiểu TikTok (9.2K, 150K, 1.2M, 500) thành số nguyên"""
    if val is None:
        return 0
    if isinstance(val, (int, float)):
        return int(val)
    s = str(val).strip().upper().replace(",", ".").replace(" ", "")
    try:
        if "M" in s:
            num = float(re.search(r'[\d\.]+', s).group(0))
            return int(num * 1_000_000)
        elif "K" in s:
            num = float(re.search(r'[\d\.]+', s).group(0))
            return int(num * 1_000)
        elif "B" in s:
            num = float(re.search(r'[\d\.]+', s).group(0))
            return int(num * 1_000_000_000)
        m = re.search(r'\d+', s)
        return int(m.group(0)) if m else 0
    except Exception:
        return 0


class StatsSyncService:
    """
    Dịch vụ chạy ngầm TỰ ĐỘNG ĐỒNG BỘ CHỈ SỐ KÊNH TIKTOK LIÊN TỤC THEO THỜI GIAN THỰC (REAL-TIME)
    - Quét trực tiếp Rehydration JSON của TikTok để đảm bảo số liệu chính xác 100%
    - Tự động chạy tuần hoàn liên tục (Real-Time Auto Loop) để bắt kịp từng lượt Follow và Like/View tăng lên trên TikTok
    - Tự động cập nhật vào Database và bắn tín hiệu đẩy thẳng lên màn hình giao diện
    """
    def __init__(self, interval_seconds: int = 60):
        self._thread: Optional[threading.Thread] = None
        self._is_syncing = False
        self._running = False
        self._interval = max(30, interval_seconds)
        self._wake_event = threading.Event()
        self._callbacks: List[Callable[[int, int, int], None]] = []

    def register_callback(self, cb: Callable[[int, int, int], None]):
        """Đăng ký callback nhận dữ liệu khi 1 kênh được đồng bộ xong (cid, followers, views)"""
        if cb and cb not in self._callbacks:
            self._callbacks.append(cb)

    def unregister_callback(self, cb: Callable[[int, int, int], None]):
        if cb in self._callbacks:
            self._callbacks.remove(cb)

    def _notify(self, cid: int, followers: int, views: int):
        for cb in list(self._callbacks):
            try:
                cb(cid, followers, views)
            except Exception as e:
                print(f"[StatsSync] Lỗi gọi callback: {e}")

    def start_background_sync(self, delay_start: float = 10.0, interval_seconds: int = 600):
        """Khởi động luồng quét ngầm định kỳ (mặc định 10 phút/lần để tránh bị TikTok chặn IP)"""
        self._interval = max(300, interval_seconds)
        if self._running:
            # Nếu đã chạy thì đánh thức ngay để đồng bộ chu kỳ mới
            self.trigger_sync_now()
            return

        self._running = True

        def loop_worker():
            time.sleep(delay_start)
            while self._running:
                try:
                    self.sync_all_channels()
                except Exception as e:
                    print(f"[StatsSync] Lỗi trong chu kỳ đồng bộ: {e}")

                # Chờ chu kỳ tiếp theo hoặc được đánh thức bởi trigger_sync_now()
                self._wake_event.wait(self._interval)
                self._wake_event.clear()

        self._thread = threading.Thread(target=loop_worker, daemon=True)
        self._thread.start()

    def stop_background_sync(self):
        """Dừng luồng quét ngầm khi tắt ứng dụng"""
        self._running = False
        self._wake_event.set()

    def trigger_sync_now(self):
        """Kích hoạt quét đồng bộ ngay lập tức mà không cần chờ hết chu kỳ"""
        self._wake_event.set()

    def _get_browser_launch_args(self):
        chrome_exe = chrome_mgr.get_chrome_path()
        kwargs = {
            "headless": True,
            "args": [
                "--mute-audio",
                "--no-first-run",
                "--no-default-browser-check",
                "--disable-blink-features=AutomationControlled",
                "--disable-features=Translate"
            ]
        }
        if chrome_exe and os.path.isfile(chrome_exe):
            kwargs["executable_path"] = chrome_exe
        return kwargs

    def fetch_channel_profile_stats(self, username: str, timeout: int = 15000) -> Dict[str, Any]:
        """
        Lấy trực tiếp thông số chuẩn xác (Followers, Likes, Videos) từ trang công khai TikTok
        thông qua script Rehydration JSON siêu tốc không cần đăng nhập.
        """
        clean_user = username.lstrip("@").strip()
        if not clean_user:
            return {"followers": 0, "likes": 0, "videos": 0}

        try:
            from playwright.sync_api import sync_playwright
            with sync_playwright() as p:
                browser = p.chromium.launch(**self._get_browser_launch_args())
                context = browser.new_context(
                    user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
                )
                page = context.new_page()
                page.goto(f"https://www.tiktok.com/@{clean_user}", timeout=timeout, wait_until="domcontentloaded")
                page.wait_for_timeout(2000)

                stats = self._extract_stats_from_page(page)
                browser.close()

                if stats:
                    return {
                        "followers": parse_metric_count(stats.get("followers", 0)),
                        "likes": parse_metric_count(stats.get("likes", 0)),
                        "videos": parse_metric_count(stats.get("videos", 0))
                    }
        except Exception as e:
            print(f"[StatsSync] Không thể lấy profile @{clean_user}: {e}")

        return {"followers": 0, "likes": 0, "videos": 0}

    def _extract_stats_from_page(self, page) -> Optional[Dict[str, Any]]:
        """Trích xuất dữ liệu từ thẻ script __UNIVERSAL_DATA_FOR_REHYDRATION__ hoặc DOM"""
        return page.evaluate("""() => {
            const el = document.getElementById('__UNIVERSAL_DATA_FOR_REHYDRATION__');
            if (el) {
                try {
                    const data = JSON.parse(el.innerText);
                    const def = data['__DEFAULT_SCOPE__'] || {};
                    const udetail = def['webapp.user-detail'] || {};
                    const uinfo = udetail['userInfo'] || {};
                    const s = uinfo['stats'] || {};
                    if (s && ('followerCount' in s || 'heartCount' in s)) {
                        return {
                            followers: s['followerCount'] || 0,
                            likes: s['heartCount'] || s['heart'] || 0,
                            videos: s['videoCount'] || 0
                        };
                    }
                } catch(e) {}
            }
            // Fallback đọc DOM text nếu script JSON không có
            const text = document.body.innerText || '';
            const lines = text.split('\\n').map(l => l.trim()).filter(Boolean);
            let f = null, l = null;
            for (let i = 0; i < lines.length; i++) {
                const line = lines[i].toLowerCase();
                if ((line === 'follower' || line === 'người theo dõi' || line === 'followers') && i > 0) {
                    f = lines[i-1];
                }
                if ((line === 'lượt thích' || line === 'thích' || line === 'likes') && i > 0) {
                    l = lines[i-1];
                }
            }
            if (f !== null || l !== null) {
                return { followers: f || 0, likes: l || 0, videos: 0 };
            }
            return null;
        }""")

    def _save_channel_stats(self, cid: int, followers: int, likes: int, videos_cnt: int = 0):
        """Lưu số liệu chuẩn vào DB và phát tín hiệu lên UI"""
        cur_ch = db.get_channel(cid)
        cur_f = cur_ch.get("followers_count", 0) if cur_ch else 0
        cur_v = cur_ch.get("views_count", 0) if cur_ch else 0

        final_f = followers if followers > 0 else cur_f
        final_v = likes if likes > 0 else cur_v

        # 1. Cập nhật bảng channels
        db.update_channel_stats(cid, followers_count=final_f, views_count=final_v)

        # 2. Cập nhật bảng channel_analytics
        try:
            with db._get_connection() as conn:
                cur = conn.cursor()
                cur.execute("""
                    INSERT INTO channel_analytics (channel_id, followers_count, likes_count, videos_count, avg_views, last_analyzed)
                    VALUES (?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
                    ON CONFLICT(channel_id) DO UPDATE SET
                        followers_count = excluded.followers_count,
                        likes_count = excluded.likes_count,
                        videos_count = excluded.videos_count,
                        avg_views = excluded.avg_views,
                        last_analyzed = CURRENT_TIMESTAMP
                """, (cid, final_f, final_v, videos_cnt, final_v))
                conn.commit()
        except Exception:
            pass

        # 3. Bắn thông báo cập nhật UI theo thời gian thực
        self._notify(cid, final_f, final_v)
        return {"followers": final_f, "views": final_v}

    def sync_channel(self, channel_data: Dict[str, Any]) -> Dict[str, int]:
        """Quét và đồng bộ số liệu chuẩn xác cho 1 kênh riêng lẻ"""
        cid = channel_data.get("id")
        cname = channel_data.get("name", "")
        raw_user = channel_data.get("username", "") or f"@{cname}"
        clean_user = raw_user.lstrip("@").strip()

        stats = self.fetch_channel_profile_stats(clean_user)
        followers = stats.get("followers", 0)
        likes = stats.get("likes", 0)
        videos_cnt = stats.get("videos", 0)

        return self._save_channel_stats(cid, followers, likes, videos_cnt)

    def sync_all_channels(self):
        """
        Duyệt qua tất cả các kênh và tự động cập nhật số liệu chuẩn xác nhất theo thời gian thực
        Tận dụng 1 instance trình duyệt duy nhất để quét siêu nhanh, tiết kiệm RAM tối đa.
        """
        if self._is_syncing:
            return
        self._is_syncing = True

        try:
            channels = db.get_all_channels()
            if not channels:
                return

            from playwright.sync_api import sync_playwright
            with sync_playwright() as p:
                try:
                    browser = p.chromium.launch(**self._get_browser_launch_args())
                except Exception:
                    # Fallback chạy với browser mặc định của Playwright nếu exe gặp sự cố
                    browser = p.chromium.launch(headless=True)

                context = browser.new_context(
                    user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
                )
                page = context.new_page()

                for ch in channels:
                    if not self._running and self._thread is not None:
                        break

                    cid = ch.get("id")
                    cname = ch.get("name", "")
                    raw_user = (ch.get("username") or cname or "").lstrip("@").strip()
                    if not raw_user:
                        continue

                    try:
                        url = f"https://www.tiktok.com/@{raw_user}"
                        page.goto(url, timeout=18000, wait_until="domcontentloaded")
                        page.wait_for_timeout(1800)

                        stats = self._extract_stats_from_page(page)
                        if stats:
                            f = parse_metric_count(stats.get("followers", 0))
                            l = parse_metric_count(stats.get("likes", 0))
                            v = parse_metric_count(stats.get("videos", 0))

                            # Nếu lấy được số liệu thực tế từ TikTok -> Lưu ngay & bắn thông báo cập nhật UI!
                            if f > 0 or l > 0:
                                self._save_channel_stats(cid, f, l, v)
                                print(f"[StatsSync Live] @{raw_user}: {f:,} Flow | {l:,} Likes (Cập nhật thành công)")
                    except Exception as err:
                        print(f"[StatsSync] Bỏ qua kênh @{raw_user} do timeout/lỗi: {err}")

                    time.sleep(0.5)

                try:
                    browser.close()
                except Exception:
                    pass

        except Exception as e:
            print(f"[StatsSync] Lỗi tổng thể sync_all_channels: {e}")
        finally:
            self._is_syncing = False


stats_sync_service = StatsSyncService()
