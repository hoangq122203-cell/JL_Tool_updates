# -*- coding: utf-8 -*-
"""
LICENSE PROTECTION & HARDWARE-ID (HWID) MANAGER
Hệ thống khóa bản quyền độc quyền theo mã máy tính cho Tool Quản Lý Kênh TikTok.
Chống chia sẻ file ra ngoài, hỗ trợ gia hạn và quản lý danh sách khách hàng.
"""

import os
import sys
import time
import json
import base64
import hmac
import hashlib
import subprocess
from datetime import datetime, date, timedelta
from typing import Dict, Any, Tuple, Optional, List

# Khóa bí mật nội bộ dùng để ký và xác thực mã bản quyền (Không chia sẻ)
MASTER_SECRET_KEY = "JL_MASTER_AUTH_KEY_2026_TIKTOK_MGMT_SECURE_981248"

from pathlib import Path
BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
DATA_DIR.mkdir(parents=True, exist_ok=True)

LICENSE_FILE_PATH = str(DATA_DIR / "license.lic")
ADMIN_DB_FILE = str(DATA_DIR / "admin_license_db.json")
REVOKED_DB_FILE = str(DATA_DIR / "revoked_licenses.json")

# Kênh đồng bộ đám mây thời gian thực (Cloud Real-Time License Blacklist)
# 1. GitHub Raw (Không giới hạn lượt đọc từ máy khách hàng)
GITHUB_REVOKED_RAW_URL = "https://raw.githubusercontent.com/hoangq122203-cell/JL_Tool_updates/main/revoked_licenses.json"
# 2. API đồng bộ nhanh dự phòng (Lưu ý: api.restful-api.dev bản free giới hạn 50 req/ngày)
CLOUD_REVOKED_API_URL = "https://api.restful-api.dev/objects/ff808181a09d98f701a1c11b301b721f"

class LicenseManager:
    _cached_hwid: Optional[str] = None
    _cached_cloud_revoked: List[str] = []
    _last_cloud_check_ts: float = 0
    _is_fetching_cloud: bool = False

    @classmethod
    def get_hardware_id(cls) -> str:
        """
        Lấy mã định danh phần cứng duy nhất của máy tính Windows (HWID).
        Kết hợp Motherboard UUID, CPU ID và Registry MachineGuid.
        Định dạng chuẩn: JL-XXXX-XXXX-XXXX
        """
        if cls._cached_hwid:
            return cls._cached_hwid

        components = []

        # 1. Motherboard UUID
        try:
            r = subprocess.run(
                ['wmic', 'csproduct', 'get', 'uuid'],
                capture_output=True, text=True, timeout=5, creationflags=0x08000000
            )
            lines = [line.strip() for line in r.stdout.splitlines() if line.strip() and 'UUID' not in line]
            if lines and lines[0] and lines[0] != 'FFFFFFFF-FFFF-FFFF-FFFF-FFFFFFFFFFFF':
                components.append(lines[0])
        except Exception:
            pass

        # 2. PowerShell Fallback for Motherboard
        if not components:
            try:
                r = subprocess.run(
                    ['powershell', '-Command', '(Get-CimInstance Win32_ComputerSystemProduct).UUID'],
                    capture_output=True, text=True, timeout=5, creationflags=0x08000000
                )
                uid = r.stdout.strip()
                if uid:
                    components.append(uid)
            except Exception:
                pass

        # 3. CPU ID
        try:
            r = subprocess.run(
                ['wmic', 'cpu', 'get', 'processorid'],
                capture_output=True, text=True, timeout=5, creationflags=0x08000000
            )
            lines = [line.strip() for line in r.stdout.splitlines() if line.strip() and 'ProcessorId' not in line]
            if lines and lines[0]:
                components.append(lines[0])
        except Exception:
            pass

        # 4. Registry MachineGuid (Độ tương thích 100% trên mọi bản Windows 10/11)
        try:
            import winreg
            k = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r'SOFTWARE\Microsoft\Cryptography')
            guid, _ = winreg.QueryValueEx(k, 'MachineGuid')
            if guid:
                components.append(guid)
        except Exception:
            pass

        # 5. Fallback cuối cùng nếu không lấy được (tránh crash)
        if not components:
            import uuid
            components.append(str(uuid.getnode()))

        raw_str = "_".join(components)
        h = hashlib.sha256(raw_str.encode('utf-8')).hexdigest().upper()
        formatted_hwid = f"JL-{h[0:4]}-{h[4:8]}-{h[8:12]}"
        cls._cached_hwid = formatted_hwid
        return formatted_hwid

    @classmethod
    def generate_license_key(cls, hwid: str, days: int, plan_name: str = "PRO") -> str:
        """
        Tạo mã bản quyền (Key) dành riêng cho một HWID với thời hạn cụ thể:
        - days = -1: Vĩnh viễn (Lifetime)
        - days > 0: Số ngày sử dụng kể từ thời điểm tạo key
        """
        clean_hwid = hwid.strip().upper()
        now_ts = int(time.time())
        exp_ts = 0 if days == -1 else (now_ts + days * 86400)

        payload = f"{clean_hwid}|{exp_ts}|{plan_name}|{now_ts}"
        sig = hmac.new(MASTER_SECRET_KEY.encode(), payload.encode(), hashlib.sha256).hexdigest()[:16].upper()
        raw_token = f"{payload}|{sig}"

        b32 = base64.b32encode(raw_token.encode('utf-8')).decode('utf-8').rstrip('=')
        chunks = [b32[i:i+5] for i in range(0, len(b32), 5)]
        return "JLKEY-" + "-".join(chunks)

    @classmethod
    def verify_license_key(cls, key_str: str, target_hwid: Optional[str] = None) -> Tuple[bool, str, Dict[str, Any]]:
        """
        Kiểm tra tính hợp lệ của Key bản quyền đối với mã máy tính.
        Trả về: (Hợp_Lệ_Hay_Không, Thông_Điệp, Thông_Tin_Bản_Quyền)
        """
        if not key_str or not isinstance(key_str, str):
            return False, "Vui lòng nhập mã kích hoạt!", {}

        raw_key = key_str.strip()
        if not raw_key.startswith("JLKEY-"):
            return False, "Định dạng Key không hợp lệ (Phải bắt đầu bằng 'JLKEY-')!", {}

        clean = raw_key.replace("JLKEY-", "").replace("-", "").strip().upper()
        pad = (8 - len(clean) % 8) % 8
        clean += "=" * pad

        try:
            raw_token = base64.b32decode(clean).decode('utf-8')
            parts = raw_token.split('|')
            if len(parts) != 5:
                return False, "Mã kích hoạt bị sai cấu trúc hoặc không đầy đủ!", {}

            key_hwid, exp_str, plan_name, created_ts_str, sig = parts
            exp_ts = int(exp_str)

            # 1. Kiểm tra chữ ký mật mã HMAC
            payload = f"{key_hwid}|{exp_ts}|{plan_name}|{created_ts_str}"
            expected_sig = hmac.new(MASTER_SECRET_KEY.encode(), payload.encode(), hashlib.sha256).hexdigest()[:16].upper()
            if sig != expected_sig:
                return False, "Chữ ký bảo mật không hợp lệ (Key không chính hãng hoặc đã bị can thiệp)!", {}

            # 2. Kiểm tra mã máy tính
            current_hwid = target_hwid or cls.get_hardware_id()
            if key_hwid != current_hwid:
                return False, (
                    f"Mã Key này được cấp riêng cho máy khác ({key_hwid}), "
                    f"không thể dùng trên máy tính của bạn ({current_hwid})!"
                ), {}

            # 3. Kiểm tra hạn sử dụng
            now_ts = int(time.time())
            is_lifetime = (exp_ts == 0)
            if not is_lifetime and now_ts > exp_ts:
                exp_date_str = datetime.fromtimestamp(exp_ts).strftime("%d/%m/%Y %H:%M")
                return False, f"Bản quyền đã hết hạn sử dụng vào ngày {exp_date_str}!", {
                    "is_expired": True,
                    "hwid": key_hwid,
                    "exp_ts": exp_ts,
                    "exp_date_str": exp_date_str
                }

            days_left = 99999 if is_lifetime else max(0, int((exp_ts - now_ts) / 86400))
            exp_date_str = "Vĩnh Viễn (Lifetime)" if is_lifetime else datetime.fromtimestamp(exp_ts).strftime("%d/%m/%Y")

            return True, "Kích hoạt bản quyền thành công!", {
                "hwid": key_hwid,
                "plan": plan_name,
                "exp_ts": exp_ts,
                "exp_date_str": exp_date_str,
                "days_left": days_left,
                "is_lifetime": is_lifetime
            }

        except Exception as e:
            return False, f"Không thể giải mã Key: {e}", {}

    @classmethod
    def save_installed_license(cls, key_str: str) -> bool:
        """Lưu trữ Key đã kích hoạt vào file license bảo mật và Database"""
        clean_key = key_str.strip()
        try:
            os.makedirs(os.path.dirname(LICENSE_FILE_PATH), exist_ok=True)
            with open(LICENSE_FILE_PATH, "w", encoding="utf-8") as f:
                f.write(clean_key)
        except Exception:
            pass

        try:
            from database.db_manager import db
            db.set_setting("installed_license_key", clean_key)
        except Exception:
            pass

        # Khi kích hoạt thành công bằng Key mới hợp lệ từ Admin:
        # Tự động gỡ bỏ mã máy này khỏi danh sách thu hồi (Unban) để khách sử dụng lại bình thường
        try:
            current_h = cls.get_hardware_id().strip().upper()
            revoked = cls.get_revoked_hwids()
            if current_h in revoked:
                revoked = [h for h in revoked if h != current_h]
                with open(REVOKED_DB_FILE, "w", encoding="utf-8") as f:
                    json.dump(revoked, f, ensure_ascii=False, indent=2)
        except Exception:
            pass

        return True

    @classmethod
    def get_installed_license(cls) -> str:
        """Đọc Key bản quyền hiện tại đã cài đặt trên máy"""
        # 1. Đọc từ file license
        if os.path.isfile(LICENSE_FILE_PATH):
            try:
                with open(LICENSE_FILE_PATH, "r", encoding="utf-8") as f:
                    k = f.read().strip()
                    if k:
                        return k
            except Exception:
                pass

        # 2. Đọc từ Database
        try:
            from database.db_manager import db
            k = db.get_setting("installed_license_key", "")
            if k:
                return k.strip()
        except Exception:
            pass

        return ""

    @classmethod
    def get_revoked_hwids(cls) -> List[str]:
        """Lấy danh sách mã máy bị Admin thu hồi/xóa bản quyền từ file cục bộ"""
        if not os.path.isfile(REVOKED_DB_FILE):
            return []
        try:
            with open(REVOKED_DB_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
                if isinstance(data, list):
                    return [str(h).strip().upper() for h in data]
        except Exception:
            pass
        return []

    _last_api_check_ts: float = 0
    _last_cloud_error: str = ""

    @classmethod
    def _async_cloud_worker(cls):
        """Tiến trình ngầm độc lập kéo blacklist từ đám mây (Chạy ngầm, 100% không bao giờ block UI)"""
        import requests
        combined_revoked = set(cls._cached_cloud_revoked or [])
        now = time.time()

        # 1. Kênh chính không giới hạn lượt tải: GitHub Raw (revoked_licenses.json)
        try:
            r_gh = requests.get(f"{GITHUB_REVOKED_RAW_URL}?t={int(now)}", timeout=4.0)
            if r_gh.status_code == 200:
                gh_data = r_gh.json()
                gh_list = gh_data if isinstance(gh_data, list) else (gh_data.get("revoked", []) if isinstance(gh_data, dict) else [])
                for h in gh_list:
                    if h:
                        combined_revoked.add(str(h).strip().upper())
        except Exception:
            pass

        # 2. Kênh dự phòng restful-api.dev (chỉ gọi tối đa 30 phút/lần để không vượt 50 req/24h)
        if now - cls._last_api_check_ts > 1800:
            cls._last_api_check_ts = now
            try:
                r = requests.get(CLOUD_REVOKED_API_URL, timeout=3.0)
                if r.status_code == 200:
                    data = r.json()
                    rev_list = data.get("data", {}).get("revoked", [])
                    if isinstance(rev_list, list):
                        for h in rev_list:
                            if h:
                                combined_revoked.add(str(h).strip().upper())
            except Exception:
                pass

        try:
            if combined_revoked:
                cls._cached_cloud_revoked = sorted(combined_revoked)
            cls._last_cloud_check_ts = time.time()
            # Kiểm tra xem mã máy hiện tại có bị thu hồi không
            cur_h = cls.get_hardware_id().strip().upper()
            if cur_h in combined_revoked:
                loc = cls.get_revoked_hwids()
                if cur_h not in loc:
                    loc.append(cur_h)
                    with open(REVOKED_DB_FILE, "w", encoding="utf-8") as f:
                        json.dump(loc, f, ensure_ascii=False, indent=2)
        except Exception:
            pass
        finally:
            cls._is_fetching_cloud = False

    @classmethod
    def fetch_cloud_revoked_hwids(cls, force: bool = False) -> List[str]:
        """
        Lấy danh sách blacklist TỨC THÌ từ RAM (0ms - Siêu mượt, tuyệt đối không gây giật lag giao diện).
        Kích hoạt luồng ngầm tự động cập nhật từ đám mây định kỳ (mỗi 60s qua GitHub Raw).
        """
        now = time.time()
        if (now - cls._last_cloud_check_ts > 60 or force) and not cls._is_fetching_cloud:
            cls._is_fetching_cloud = True
            import threading
            threading.Thread(target=cls._async_cloud_worker, daemon=True).start()

        return cls._cached_cloud_revoked

    @classmethod
    def push_cloud_revoked_hwids(cls, revoked_list: List[str]) -> bool:
        """Đẩy danh sách thu hồi thời gian thực lên Đám Mây khi Admin thao tác Xóa hoặc Cấp Key"""
        import requests
        cls._last_cloud_error = ""
        try:
            clean_list = list(set([str(h).strip().upper() for h in revoked_list if h]))
            payload = {
                "name": "JL_Revoked_List",
                "data": {
                    "revoked": clean_list,
                    "updated_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                }
            }
            r = requests.put(CLOUD_REVOKED_API_URL, json=payload, timeout=4.0)
            if r.status_code == 200:
                cls._cached_cloud_revoked = clean_list
                cls._last_cloud_check_ts = time.time()
                return True
            cls._last_cloud_error = f"HTTP {r.status_code}: {r.text[:160]}"
        except Exception as e:
            cls._last_cloud_error = str(e)
        return False

    @classmethod
    def is_hwid_revoked(cls, hwid: str) -> bool:
        """
        Kiểm tra xem mã máy có bị Admin xóa hoặc thu hồi bản quyền hay không:
        1. Nằm trong danh sách blacklist revoked_licenses.json nội bộ.
        2. Nằm trong danh sách blacklist Đám Mây thời gian thực (Cloud Sync).
        3. Hoặc nếu admin_license_db.json tồn tại (trên máy Admin): mã máy đã bị xóa khỏi danh sách.
        """
        clean_h = (hwid or "").strip().upper()
        if not clean_h:
            return False

        # 1. Kiểm tra blacklist revoked nội bộ
        if clean_h in cls.get_revoked_hwids():
            return True

        # 2. Kiểm tra blacklist revoked thời gian thực từ Đám Mây (Cloud Sync)
        cloud_revoked = cls.fetch_cloud_revoked_hwids()
        if clean_h in cloud_revoked:
            # Tự động ghi nhận vĩnh viễn vào blacklist nội bộ của máy này
            try:
                local_rev = cls.get_revoked_hwids()
                if clean_h not in local_rev:
                    local_rev.append(clean_h)
                    with open(REVOKED_DB_FILE, "w", encoding="utf-8") as f:
                        json.dump(local_rev, f, ensure_ascii=False, indent=2)
            except Exception:
                pass
            return True

        # 3. Kiểm tra nếu admin_license_db.json tồn tại:
        # Nếu danh sách Admin có dữ liệu khách hàng nhưng không còn HWID này (bị Admin ấn nút Xóa 🗑️)
        if os.path.isfile(ADMIN_DB_FILE):
            try:
                customers = cls.admin_get_all_customers()
                if customers:
                    allowed_hwids = [c.get("hwid", "").strip().upper() for c in customers if c.get("hwid")]
                    if allowed_hwids and clean_h not in allowed_hwids:
                        return True
            except Exception:
                pass

        return False

    @classmethod
    def revoke_installed_license(cls):
        """Xóa sạch toàn bộ key bản quyền trên máy hiện tại khi bị Admin thu hồi"""
        try:
            if os.path.isfile(LICENSE_FILE_PATH):
                os.remove(LICENSE_FILE_PATH)
        except Exception:
            pass
        try:
            from database.db_manager import db
            db.set_setting("installed_license_key", "")
        except Exception:
            pass

    @classmethod
    def check_current_license(cls) -> Tuple[bool, str, Dict[str, Any]]:
        """
        Kiểm tra trạng thái bản quyền hiện tại của máy tính này:
        1. Nếu bị Admin xóa khỏi danh sách cấp key -> Tự động out, xóa key ngay.
        2. Nếu hết hạn sử dụng -> Khóa toàn bộ tính năng, chỉ cho phép gia hạn.
        Trả về: (Hợp_Lệ, Thông_Điệp, Thông_Tin_Chi_Tiết)
        """
        current_hwid = cls.get_hardware_id().strip().upper()

        # 1. Kiểm tra xem mã máy có bị Admin thu hồi hoặc xóa khỏi danh sách hay không
        if cls.is_hwid_revoked(current_hwid):
            cls.revoke_installed_license()
            return False, f"Mã máy tính của bạn ({current_hwid}) đã bị Quản Trị Viên (Admin) xóa hoặc thu hồi bản quyền khỏi hệ thống!", {
                "status": "REVOKED",
                "is_revoked": True,
                "hwid": current_hwid
            }

        # 2. Đọc mã key cài đặt
        installed_key = cls.get_installed_license()
        if not installed_key:
            return False, "Chưa cài đặt mã bản quyền. Vui lòng kích hoạt!", {
                "status": "NOT_ACTIVATED",
                "hwid": current_hwid
            }

        # 3. Xác thực mã key
        valid, msg, info = cls.verify_license_key(installed_key, current_hwid)
        if not valid:
            status = "EXPIRED" if info.get("is_expired") else "INVALID"
            info["status"] = status
            info["hwid"] = current_hwid
            return False, msg, info

        info["status"] = "ACTIVE"
        info["key"] = installed_key
        info["hwid"] = current_hwid
        return True, msg, info

    # ================= QUẢN LÝ DANH SÁCH KHÁCH HÀNG (DÀNH CHO ADMIN) =================
    @classmethod
    def admin_save_customer(
        cls,
        customer_name: str,
        hwid: str,
        plan_name: str,
        days: int,
        license_key: str,
        phone_contact: str = ""
    ) -> bool:
        """Lưu thông tin khách hàng vào danh sách quản lý của Admin"""
        records = cls.admin_get_all_customers()
        clean_hwid = hwid.strip().upper()
        now_str = datetime.now().strftime("%d/%m/%Y %H:%M")
        exp_date_str = "Vĩnh Viễn" if days == -1 else (datetime.now().date() + timedelta(days=days)).strftime("%d/%m/%Y")

        new_entry = {
            "customer_name": customer_name.strip() or "Khách hàng",
            "hwid": clean_hwid,
            "plan_name": plan_name,
            "days": days,
            "issued_at": now_str,
            "expires_at": exp_date_str,
            "license_key": license_key,
            "contact": phone_contact.strip()
        }

        # Cập nhật nếu đã tồn tại mã máy này hoặc thêm mới
        updated = False
        for idx, item in enumerate(records):
            if item.get("hwid") == clean_hwid:
                records[idx] = new_entry
                updated = True
                break

        if not updated:
            records.insert(0, new_entry)

        # Nếu máy này trước đó từng bị thu hồi, khi Admin cấp key mới thì tự động bỏ khỏi danh sách blacklist
        revoked = cls.get_revoked_hwids()
        if clean_hwid in revoked:
            revoked = [h for h in revoked if h != clean_hwid]
            try:
                with open(REVOKED_DB_FILE, "w", encoding="utf-8") as f:
                    json.dump(revoked, f, ensure_ascii=False, indent=2)
            except Exception:
                pass
            # Đồng bộ gỡ thu hồi trên Đám Mây để khách sử dụng lại bình thường
            cls.push_cloud_revoked_hwids(revoked)

        try:
            os.makedirs(os.path.dirname(ADMIN_DB_FILE), exist_ok=True)
            with open(ADMIN_DB_FILE, "w", encoding="utf-8") as f:
                json.dump(records, f, ensure_ascii=False, indent=2)
            return True
        except Exception:
            return False

    @classmethod
    def admin_get_all_customers(cls) -> List[Dict[str, Any]]:
        """Lấy danh sách toàn bộ khách hàng và mã máy đã cấp"""
        if not os.path.isfile(ADMIN_DB_FILE):
            return []
        try:
            with open(ADMIN_DB_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return []

    @classmethod
    def admin_delete_customer(cls, hwid: str) -> bool:
        """Xóa một mã máy khỏi danh sách quản lý của Admin và đưa vào danh sách thu hồi bản quyền"""
        clean_h = (hwid or "").strip().upper()
        if not clean_h:
            return False

        records = cls.admin_get_all_customers()
        records = [r for r in records if r.get("hwid") != clean_h]
        try:
            with open(ADMIN_DB_FILE, "w", encoding="utf-8") as f:
                json.dump(records, f, ensure_ascii=False, indent=2)
        except Exception:
            pass

        # Ghi vào danh sách blacklist thu hồi
        revoked = cls.get_revoked_hwids()
        if clean_h not in revoked:
            revoked.append(clean_h)
            try:
                with open(REVOKED_DB_FILE, "w", encoding="utf-8") as f:
                    json.dump(revoked, f, ensure_ascii=False, indent=2)
            except Exception:
                pass

        # ĐỒNG BỘ ĐÁM MÂY THỜI GIAN THỰC NGAY LẬP TỨC:
        cls._last_cloud_sync_ok = cls.push_cloud_revoked_hwids(revoked)

        # Nếu chính là mã máy hiện tại đang chạy thì xóa ngay key bản quyền
        if clean_h == cls.get_hardware_id().strip().upper():
            cls.revoke_installed_license()

        return True

license_mgr = LicenseManager
