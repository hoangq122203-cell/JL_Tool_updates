import sys
import os
import shutil
import uuid
from pathlib import Path
from typing import Optional
from database.db_manager import db

def _safe_log(msg: str):
    try:
        print(msg)
    except Exception:
        try:
            print(msg.encode("ascii", "replace").decode("ascii"))
        except Exception:
            pass

class VideoVault:
    """
    KHO VIDEO NỘI BỘ CỦA TOOL (DATA/VIDEOS)
    - Tự động chuyển toàn bộ file video được lên lịch vào kho nội bộ của Tool.
    - Người dùng có thể tự do xóa, đổi tên, dọn dẹp file gốc trên máy tính (Desktop/Downloads...)
      mà lịch đăng ngầm của Tool vẫn 100% nguyên vẹn và hoạt động bình thường.
    - Khi video đã được đăng thành công, hệ thống tự động xóa video đó khỏi kho video của Tool.
    - File gốc trên máy tính của người dùng TUYỆT ĐỐI không bao giờ bị Tool xóa hay làm ảnh hưởng.
    """

    def __init__(self):
        self.base_dir = Path(__file__).resolve().parent.parent
        self.vault_dir = self.base_dir / "data" / "videos"
        self.vault_dir.mkdir(parents=True, exist_ok=True)

    def get_vault_dir(self) -> Path:
        self.vault_dir.mkdir(parents=True, exist_ok=True)
        return self.vault_dir

    def is_in_vault(self, file_path: str) -> bool:
        """Kiểm tra đường dẫn có thuộc kho video nội bộ data/videos hay không"""
        if not file_path:
            return False
        try:
            p = Path(file_path).resolve()
            v = self.vault_dir.resolve()
            return v in p.parents or p == v or str(p).lower().startswith(str(v).lower())
        except Exception:
            return False

    def import_video_to_vault(self, src_path: str, title: str = "") -> str:
        """
        Sao chép file video vào kho video của Tool.
        Trả về đường dẫn an toàn mới trong kho data/videos.
        Nếu file đã nằm sẵn trong kho hoặc không tìm thấy nguồn thì trả về đường dẫn hiện tại.
        """
        if not src_path:
            return ""

        norm_src = os.path.normpath(src_path)
        if not os.path.isfile(norm_src):
            return src_path

        # Nếu đã nằm trong kho thì không cần copy lại
        if self.is_in_vault(norm_src):
            return norm_src.replace("\\", "/")

        self.vault_dir.mkdir(parents=True, exist_ok=True)
        base_name = os.path.basename(norm_src)
        dst_path = self.vault_dir / base_name

        try:
            # Nếu đã có file cùng tên trong kho
            if dst_path.exists():
                src_sz = os.path.getsize(norm_src)
                dst_sz = os.path.getsize(dst_path)
                if src_sz == dst_sz:
                    # Cùng nội dung dung lượng, dùng chung file trong kho
                    return str(dst_path).replace("\\", "/")
                else:
                    # Trùng tên nhưng khác file -> tạo tên độc nhất
                    stem = dst_path.stem
                    suffix = dst_path.suffix
                    dst_path = self.vault_dir / f"{stem}_{uuid.uuid4().hex[:6]}{suffix}"

            # Sao chép vào kho nội bộ
            shutil.copy2(norm_src, dst_path)
            return str(dst_path).replace("\\", "/")
        except Exception as e:
            _safe_log(f"[VideoVault] Lỗi sao chép video vào kho: {e}")
            return norm_src.replace("\\", "/")

    def cleanup_vault_video(self, video_path: str, schedule_id: Optional[int] = None) -> bool:
        """
        Tự động xóa video đã đăng thành công khỏi kho video của Tool.
        - Chỉ xóa file nằm TRONG KHO (data/videos). Không đụng tới file gốc ngoài máy tính.
        - Kiểm tra xem còn kênh nào khác đang chờ đăng video này không (nếu có, giữ lại đến khi kênh cuối cùng đăng xong).
        - Dọn dẹp bản ghi trong bảng videos.
        """
        if not video_path:
            return False

        norm_path = os.path.normpath(video_path)

        # TUYỆT ĐỐI CHỈ XÓA NẾU FILE NẰM TRONG KHO TOOL
        if not self.is_in_vault(norm_path):
            return False

        try:
            with db._get_connection() as conn:
                cursor = conn.cursor()
                p1 = norm_path
                p2 = norm_path.replace("\\", "/")

                # Kiểm tra còn lịch nào khác đang pending/processing dùng file này không
                if schedule_id:
                    cursor.execute("""
                        SELECT count(*) FROM schedules s
                        JOIN videos v ON s.video_id = v.id
                        WHERE (v.file_path = ? OR v.file_path = ?)
                          AND s.id != ?
                          AND s.status IN ('pending', 'processing')
                    """, (p1, p2, schedule_id))
                else:
                    cursor.execute("""
                        SELECT count(*) FROM schedules s
                        JOIN videos v ON s.video_id = v.id
                        WHERE (v.file_path = ? OR v.file_path = ?)
                          AND s.status IN ('pending', 'processing')
                    """, (p1, p2))

                row = cursor.fetchone()
                other_pending = row[0] if row else 0

                if other_pending > 0:
                    # Vẫn còn kênh khác chờ đăng file này, chưa xóa vội
                    return False

                # Đã đăng xong tất cả các kênh -> Xóa file khỏi kho
                if os.path.isfile(norm_path):
                    try:
                        os.remove(norm_path)
                        _safe_log(f"[VideoVault] Đã xóa thành công video hoàn tất khỏi kho: {norm_path}")
                    except Exception as err:
                        _safe_log(f"[VideoVault] Lỗi khi xóa file đĩa: {err}")

                # Xóa khỏi bảng videos trong cơ sở dữ liệu
                cursor.execute("""
                    DELETE FROM videos
                    WHERE file_path = ? OR file_path = ?
                """, (p1, p2))
                conn.commit()
                return True
        except Exception as e:
            _safe_log(f"[VideoVault] Lỗi cleanup_vault_video: {e}")
            return False

    def sync_existing_schedules_to_vault(self) -> int:
        """
        Tự động quét và di chuyển tất cả các video của lịch hẹn đang chờ (pending)
        vào kho nội bộ của Tool nếu file gốc trên máy tính vẫn còn tồn tại.
        """
        migrated = 0
        try:
            schedules = db.get_all_schedules("pending")
            for s in schedules:
                v_path = s.get("video_path", "")
                if v_path and os.path.isfile(v_path) and not self.is_in_vault(v_path):
                    vault_p = self.import_video_to_vault(v_path, s.get("video_title", ""))
                    if vault_p and vault_p != v_path:
                        db.update_schedule_video_path(s["id"], vault_p)
                        migrated += 1
        except Exception as e:
            _safe_log(f"[VideoVault] Lỗi đồng bộ video cũ vào kho: {e}")
        return migrated

video_vault = VideoVault()
