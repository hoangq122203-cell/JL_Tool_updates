import sys
import os
import re
import time
import shutil
import uuid
from pathlib import Path
from typing import Any, Dict, Optional, Set
from database.db_manager import db


def _safe_log(msg: str):
    try:
        print(msg)
    except Exception:
        try:
            print(msg.encode("ascii", "replace").decode("ascii"))
        except Exception:
            pass


def _safe_remove_file(file_path: str, retries: int = 3) -> bool:
    """Xóa file an toàn trên Windows, tự thử lại ngắn nếu Chrome vừa đóng chưa nhả lock."""
    if not file_path or not os.path.isfile(file_path):
        return False
    for attempt in range(retries):
        try:
            os.remove(file_path)
            return True
        except PermissionError:
            if attempt < retries - 1:
                time.sleep(0.15)
        except Exception as err:
            _safe_log(f"[VideoVault] Lỗi khi xóa file đĩa '{file_path}': {err}")
            return False
    return False


def _extract_channel_id(dir_name: str) -> Optional[int]:
    """Tách channel_id từ tên thư mục dạng 'channel_<id>_...' hoặc 'channel_<id>'."""
    m = re.match(r"^channel_(\d+)(?:_|$)", str(dir_name or ""))
    return int(m.group(1)) if m else None


def _norm_key(p: str) -> str:
    return os.path.normcase(os.path.abspath(os.path.normpath(p))) if p else ""


def _remove_empty_dirs(root_dir: Path, remove_root: bool = False) -> None:
    if not root_dir.exists():
        return
    for cur, dirs, files in os.walk(str(root_dir), topdown=False):
        if Path(cur) == root_dir and not remove_root:
            continue
        try:
            if not os.listdir(cur):
                os.rmdir(cur)
        except Exception:
            pass


class VideoVault:
    """
    KHO VIDEO NỘI BỘ CỦA TOOL (DATA/VIDEOS)
    - Tự động chuyển toàn bộ file video được lên lịch vào thư mục riêng của từng kênh.
    - Người dùng có thể tự do xóa, đổi tên, dọn dẹp file gốc trên máy tính (Desktop/Downloads...)
      mà lịch đăng ngầm của Tool vẫn 100% nguyên vẹn và hoạt động bình thường.
    - Khi video đã được đăng thành công, hệ thống tự động xóa video đó khỏi kho video của Tool.
    - Tự động dọn dẹp file video thừa, file tạm và file không liên quan đến kênh đang chạy.
    - File gốc trên máy tính của người dùng TUYỆT ĐỐI không bao giờ bị Tool xóa hay làm ảnh hưởng.
    """

    def __init__(self):
        self.base_dir = Path(__file__).resolve().parent.parent
        self.vault_dir = self.base_dir / "data" / "videos"
        self.vault_dir.mkdir(parents=True, exist_ok=True)

    def get_vault_dir(self) -> Path:
        self.vault_dir.mkdir(parents=True, exist_ok=True)
        return self.vault_dir

    def get_channel_vault_dir(self, channel_id: Optional[int] = None, channel_name: str = "") -> Path:
        """Lấy thư mục riêng biệt cho từng kênh để đảm bảo mỗi kênh sở hữu file video riêng."""
        self.vault_dir.mkdir(parents=True, exist_ok=True)
        if channel_id:
            try:
                prefix = f"channel_{int(channel_id)}_"
                for entry in self.vault_dir.iterdir():
                    if entry.is_dir() and (entry.name.startswith(prefix) or entry.name == f"channel_{int(channel_id)}"):
                        return entry
            except Exception:
                pass
            raw_name = channel_name or f"id{channel_id}"
            safe_name = "".join(c for c in raw_name if c.isalnum() or c in ("-", "_", ".")).strip() or f"id{channel_id}"
            ch_dir = self.vault_dir / f"channel_{int(channel_id)}_{safe_name}"
            ch_dir.mkdir(parents=True, exist_ok=True)
            return ch_dir
        if channel_name:
            safe_name = "".join(c for c in channel_name if c.isalnum() or c in ("-", "_", ".")).strip()
            if safe_name:
                ch_dir = self.vault_dir / safe_name
                ch_dir.mkdir(parents=True, exist_ok=True)
                return ch_dir
        return self.vault_dir

    def _is_file_used_by_other_channel(self, file_path: str, channel_id: Optional[int]) -> bool:
        if not channel_id or not file_path:
            return False
        try:
            p_low = os.path.normpath(file_path).replace("\\", "/").lower()
            with db._get_connection() as conn:
                row = conn.execute(r"""
                    SELECT count(*) FROM schedules s
                    JOIN videos v ON s.video_id = v.id
                    WHERE LOWER(REPLACE(v.file_path, '\', '/')) = ?
                      AND s.channel_id != ?
                      AND s.status IN ('pending', 'processing', 'failed')
                """, (p_low, int(channel_id))).fetchone()
                return bool(row and row[0] > 0)
        except Exception:
            return False

    def is_in_vault(self, file_path: str) -> bool:
        """Kiểm tra đường dẫn có thuộc kho video nội bộ data/videos hay không"""
        if not file_path:
            return False
        try:
            p = Path(file_path).resolve()
            v = self.vault_dir.resolve()
            return v in p.parents or p == v or str(p).lower().startswith(str(v).lower())
        except Exception:
            return False

    def import_video_to_vault(
        self,
        src_path: str,
        title: str = "",
        channel_id: Optional[int] = None,
        channel_name: str = ""
    ) -> str:
        """
        Sao chép file video vào thư mục riêng của từng kênh trong kho Tool (data/videos/channel_<id>_<name>).
        Đảm bảo mỗi kênh luôn dùng file riêng biệt, xóa xong kênh nào chỉ xóa đúng file của kênh đó.
        """
        if not src_path:
            return ""

        norm_src = os.path.normpath(src_path)
        if not os.path.isfile(norm_src):
            return src_path

        target_dir = self.get_channel_vault_dir(channel_id, channel_name)
        target_dir.mkdir(parents=True, exist_ok=True)

        # Nếu file đã nằm đúng thư mục riêng của kênh này và không bị kênh khác dùng chung -> giữ nguyên
        if self.is_in_vault(norm_src):
            src_resolved = Path(norm_src).resolve()
            target_resolved = target_dir.resolve()
            in_target = (target_resolved in src_resolved.parents) or (src_resolved.parent == target_resolved)
            if (not channel_id or in_target) and not self._is_file_used_by_other_channel(norm_src, channel_id):
                return norm_src.replace("\\", "/")

        base_name = os.path.basename(norm_src)
        dst_path = target_dir / base_name

        try:
            if dst_path.exists():
                if _norm_key(str(dst_path)) == _norm_key(norm_src):
                    return str(dst_path).replace("\\", "/")
                src_sz = os.path.getsize(norm_src)
                dst_sz = os.path.getsize(dst_path)
                if src_sz == dst_sz and not self._is_file_used_by_other_channel(str(dst_path), channel_id):
                    return str(dst_path).replace("\\", "/")
                dst_path = target_dir / f"{dst_path.stem}_{uuid.uuid4().hex[:6]}{dst_path.suffix}"

            shutil.copy2(norm_src, dst_path)
            return str(dst_path).replace("\\", "/")
        except Exception as e:
            _safe_log(f"[VideoVault] Lỗi sao chép video vào kho: {e}")
            return norm_src.replace("\\", "/")

    def cleanup_vault_video(self, video_path: str, schedule_id: Optional[int] = None) -> bool:
        """
        Tự động xóa video đã đăng thành công khỏi kho video của Tool.
        - Chỉ xóa file nằm TRONG KHO (data/videos). Không đụng tới file gốc ngoài máy tính.
        - Kiểm tra xem còn lịch nào khác đang chờ đăng video này không.
        - Dọn dẹp bản ghi trong bảng videos và thư mục tạm rỗng.
        """
        if not video_path:
            return False

        norm_path = os.path.normpath(video_path)

        # TUYỆT ĐỐI CHỈ XÓA NẾU FILE NẰM TRONG KHO TOOL
        if not self.is_in_vault(norm_path):
            return False

        try:
            with db._get_connection() as conn:
                cursor = conn.cursor()
                p_low = norm_path.replace("\\", "/").lower()

                # Kiểm tra còn lịch nào khác đang pending/processing dùng file này không
                if schedule_id:
                    cursor.execute(r"""
                        SELECT count(*) FROM schedules s
                        JOIN videos v ON s.video_id = v.id
                        WHERE LOWER(REPLACE(v.file_path, '\', '/')) = ?
                          AND s.id != ?
                          AND s.status IN ('pending', 'processing')
                    """, (p_low, schedule_id))
                else:
                    cursor.execute(r"""
                        SELECT count(*) FROM schedules s
                        JOIN videos v ON s.video_id = v.id
                        WHERE LOWER(REPLACE(v.file_path, '\', '/')) = ?
                          AND s.status IN ('pending', 'processing')
                    """, (p_low,))

                row = cursor.fetchone()
                other_pending = row[0] if row else 0

                if other_pending > 0:
                    return False

                # Đã đăng xong -> Xóa file khỏi kho (có retry nhả lock Windows)
                if os.path.isfile(norm_path) and _safe_remove_file(norm_path, retries=3):
                    _safe_log(f"[VideoVault] Đã xóa thành công video hoàn tất khỏi kho: {norm_path}")

                # Xóa khỏi bảng videos trong cơ sở dữ liệu
                cursor.execute(r"""
                    DELETE FROM videos
                    WHERE LOWER(REPLACE(file_path, '\', '/')) = ?
                """, (p_low,))
                conn.commit()
                return True
        except Exception as e:
            _safe_log(f"[VideoVault] Lỗi cleanup_vault_video: {e}")
            return False

    def purge_orphan_and_excess_videos(
        self,
        active_channel_ids: Optional[Set[int]] = None,
        max_temp_age_seconds: int = 1800,
        min_orphan_age_seconds: int = 60,
        include_test_dl: bool = True,
    ) -> Dict[str, Any]:
        """
        Quét và loại bỏ tự động:
        1. File video thừa/không còn lịch hẹn hoạt động trong data/videos (hoặc thuộc kênh đã bị xóa).
        2. File tạm temp_antiban / youtube_raw quá hạn của các kênh đang rảnh.
        3. Bản ghi videos mồ côi không còn lịch hẹn nào tham chiếu và thư mục rỗng dư thừa.
        """
        stats = {"deleted_files": 0, "freed_bytes": 0, "freed_mb": 0.0, "deleted_db_videos": 0}
        active_cids = {int(c) for c in (active_channel_ids or set()) if c is not None}
        now_ts = time.time()

        try:
            self.vault_dir.mkdir(parents=True, exist_ok=True)
            with db._get_connection() as conn:
                ch_rows = conn.execute("SELECT id, name FROM channels").fetchall()
                existing_ch_ids = {int(r["id"]) for r in ch_rows}
                existing_ch_names = {str(r["name"]).strip().lower(): int(r["id"]) for r in ch_rows if r["name"]}

                active_rows = conn.execute("""
                    SELECT v.file_path FROM schedules s
                    JOIN videos v ON s.video_id = v.id
                    WHERE s.status IN ('pending', 'processing', 'failed')
                """).fetchall()
                active_keys = {_norm_key(r["file_path"]) for r in active_rows if r["file_path"]}

            def _resolve_folder_cid(folder_name: str) -> Optional[int]:
                cid = _extract_channel_id(folder_name)
                if cid is None and folder_name:
                    cid = existing_ch_names.get(folder_name.lower())
                return cid

            def _try_purge(file_path: Path, min_age: float, force_check: bool = True) -> None:
                try:
                    if not file_path.is_file():
                        return
                    st = file_path.stat()
                    if force_check and (now_ts - st.st_mtime) < min_age:
                        return
                    sz = st.st_size
                    if _safe_remove_file(str(file_path), retries=2):
                        stats["deleted_files"] += 1
                        stats["freed_bytes"] += sz
                except Exception:
                    pass

            # 1. Quét data/videos (trừ youtube_raw và tách riêng temp_antiban)
            for root_str, _, files in os.walk(str(self.vault_dir)):
                root_p = Path(root_str)
                try:
                    rel_parts = root_p.relative_to(self.vault_dir).parts
                except Exception:
                    continue

                if rel_parts and rel_parts[0] == "youtube_raw":
                    continue

                folder_cid = _resolve_folder_cid(rel_parts[0]) if rel_parts else None
                if folder_cid in active_cids:
                    continue

                if "temp_antiban" in rel_parts:
                    for fn in files:
                        _try_purge(root_p / fn, max_temp_age_seconds)
                    continue

                is_deleted_channel_dir = bool(rel_parts and _extract_channel_id(rel_parts[0]) is not None and folder_cid not in existing_ch_ids)
                for fn in files:
                    fpath = root_p / fn
                    if _norm_key(str(fpath)) not in active_keys:
                        _try_purge(fpath, 0 if is_deleted_channel_dir else min_orphan_age_seconds, force_check=not is_deleted_channel_dir)

            # 2. Quét youtube_raw (chỉ xóa bản tải thô / .part cũ của kênh không bận)
            yt_raw_dir = self.vault_dir / "youtube_raw"
            if yt_raw_dir.is_dir():
                for root_str, _, files in os.walk(str(yt_raw_dir)):
                    root_p = Path(root_str)
                    rel_parts = root_p.relative_to(yt_raw_dir).parts
                    folder_cid = _resolve_folder_cid(rel_parts[0]) if rel_parts else None
                    if folder_cid in active_cids:
                        continue
                    for fn in files:
                        _try_purge(root_p / fn, max_temp_age_seconds)
                _remove_empty_dirs(yt_raw_dir, remove_root=False)

            # 3. Quét data/test_dl cũ nếu tồn tại
            if include_test_dl:
                test_dl_dir = self.base_dir / "data" / "test_dl"
                if test_dl_dir.is_dir():
                    for root_str, _, files in os.walk(str(test_dl_dir)):
                        root_p = Path(root_str)
                        for fn in files:
                            _try_purge(root_p / fn, max_temp_age_seconds)
                    _remove_empty_dirs(test_dl_dir, remove_root=True)

            # 4. Dọn thư mục temp_antiban rỗng & thư mục của kênh không còn tồn tại
            for entry in list(self.vault_dir.iterdir()):
                if not entry.is_dir() or entry.name == "youtube_raw":
                    continue
                _remove_empty_dirs(entry / "temp_antiban", remove_root=True)
                cid_in_name = _extract_channel_id(entry.name)
                is_stale_ch = (cid_in_name is not None and cid_in_name not in existing_ch_ids) or (
                    cid_in_name is None and entry.name.lower() not in existing_ch_names
                )
                if is_stale_ch:
                    _remove_empty_dirs(entry, remove_root=True)

            # 5. Dọn các dòng mồ côi trong bảng videos
            with db._get_connection() as conn:
                cur = conn.execute(
                    "DELETE FROM videos WHERE id NOT IN (SELECT DISTINCT video_id FROM schedules WHERE video_id IS NOT NULL)"
                )
                stats["deleted_db_videos"] = cur.rowcount or 0
                if stats["deleted_db_videos"] > 0:
                    conn.commit()
        except Exception as e:
            _safe_log(f"[VideoVault] Lỗi purge_orphan_and_excess_videos: {e}")

        stats["freed_mb"] = round(stats["freed_bytes"] / 1048576, 1)
        return stats

    def sync_existing_schedules_to_vault(self) -> int:
        """
        Tự động quét và di chuyển tất cả các video của lịch hẹn đang chờ (pending)
        vào thư mục kho riêng của từng kênh nếu file gốc vẫn còn tồn tại.
        """
        migrated = 0
        try:
            schedules = db.get_all_schedules("pending")
            for s in schedules:
                v_path = s.get("video_path", "")
                if v_path and os.path.isfile(v_path) and not self.is_in_vault(v_path):
                    vault_p = self.import_video_to_vault(
                        v_path,
                        s.get("video_title", ""),
                        channel_id=s.get("channel_id"),
                        channel_name=s.get("channel_name", "")
                    )
                    if vault_p and vault_p != v_path:
                        db.update_schedule_video_path(s["id"], vault_p)
                        migrated += 1
        except Exception as e:
            _safe_log(f"[VideoVault] Lỗi đồng bộ video cũ vào kho: {e}")
        return migrated


video_vault = VideoVault()
