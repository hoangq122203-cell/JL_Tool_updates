# -*- coding: utf-8 -*-
"""
CHANNEL HEALTH & ANALYTICS AUDITOR (BÁC SĨ KÊNH & CHIẾN LƯỢC AI)
Tự động quét chỉ số thực tế của từng kênh TikTok qua TikTok Studio,
đếm chính xác số video 0 view, phát hiện shadowban và đưa ra chiến lược tăng trưởng 10K Follow chuẩn Mobile.
"""

import os
import sys
import time
import re
from typing import Dict, Any, Optional, List
from database.db_manager import db
from core.chrome_manager import chrome_mgr

def _parse_tiktok_number(text: Any) -> int:
    """Chuyển đổi số kiểu TikTok (1.2K, 3.5M, 500, '0') thành số nguyên"""
    if text is None:
        return 0
    t = str(text).strip().upper()
    if not t or t == '0':
        return 0
    try:
        if 'K' in t:
            clean = t.replace('K', '').replace(',', '.').strip()
            return int(float(clean) * 1000)
        elif 'M' in t:
            clean = t.replace('M', '').replace(',', '.').strip()
            return int(float(clean) * 1000000)
        elif 'B' in t:
            clean = t.replace('B', '').replace(',', '.').strip()
            return int(float(clean) * 1000000000)
        clean = re.sub(r'[^\d]', '', t)
        return int(clean) if clean else 0
    except Exception:
        return 0

def _build_10k_growth_strategy(res: Dict[str, Any], channel_data: Dict[str, Any]) -> str:
    """
    Xây dựng báo cáo Chiến Lược Tăng Trưởng 10.000 Follow Chuyên Sâu,
    kết hợp cơ chế Nuôi Chăm Kênh Chuẩn Mobile và kế hoạch hành động chi tiết riêng cho từng kênh.
    """
    ch_name = channel_data.get("name", f"Kênh #{res['channel_id']}")
    f_count = res.get("followers_count", 0)
    l_count = res.get("likes_count", 0)
    v_count = res.get("videos_count", 0)
    avg_v = res.get("avg_views", 0)
    zero_cnt = res.get("zero_view_count", 0)
    viral_cnt = res.get("viral_count", 0)
    status = res.get("health_status", "healthy")
    score = res.get("health_score", 85)

    # Tính toán tiến trình 10k follow
    pct_10k = min(100.0, round((f_count / 10000.0) * 100, 1))
    remain_10k = max(0, 10000 - f_count)

    html_parts = []

    # ==================== PHẦN 1: MỤC TIÊU 10K FOLLOWERS ====================
    html_parts.append(f"""
    <div style="background-color: #0F2038; border: 1.5px solid #0284C7; border-radius: 8px; padding: 12px; margin-bottom: 12px;">
        <div style="display: flex; justify-content: space-between; align-items: center;">
            <b style="color: #38BDF8; font-size: 14px;">🎯 LỘ TRÌNH TĂNG TRƯỞNG 10,000 FOLLOW (MỤC TIÊU BẬT KIẾM TIỀN):</b>
        </div>
        <div style="margin-top: 6px; color: #E2E8F0; font-size: 12px;">
            • Tiến độ hiện tại: <b style="color: #FACC15; font-size: 14px;">{f_count:,} / 10,000 Follower</b> 
            <span style="color: #38BDF8;">({pct_10k}%)</span> | Còn thiếu: <b style="color: #F43F5E;">{remain_10k:,} follow</b><br>
            • Đã tích lũy: <b style="color: #34D399;">{l_count:,} lượt thích</b> trên <b style="color: #38BDF8;">{v_count} video đã đăng</b>.<br>
            • <b>Quyền lợi khi cán mốc 10K:</b> Mở khóa <b>Quỹ Tác Giả TikTok (Creator Rewards Program)</b>, mở tính năng <b>TikTok Shop Affiliate</b> và gắn link Bio kiếm tiền.
        </div>
    </div>
    """)

    # ==================== PHẦN 2: CƠ CHẾ NUÔI CHĂM CHUẨN MOBILE ====================
    html_parts.append("""
    <div style="background-color: #111D33; border: 1.5px solid #1E3A8A; border-radius: 8px; padding: 12px; margin-bottom: 12px;">
        <b style="color: #60A5FA; font-size: 13px;">📱 CƠ CHẾ NUÔI KÊNH HÀNG LOẠT HIỆU QUẢ NHƯ ĐIỆN THOẠI THẬT:</b>
        <div style="margin-top: 6px; color: #94A3B8; font-size: 12px; line-height: 1.5;">
            TikTok luôn ưu tiên đề xuất video đăng từ điện thoại gấp <b>3 - 5 lần</b> web thông thường. Tool đã tự động tích hợp 4 công nghệ giả lập di động độc quyền:<br>
            • <b>Vân tay camera di động (Mobile EXIF):</b> Tự động tiêm metadata Apple iPhone 15 Pro / Samsung S23 Ultra vào file video, xóa sạch vết file tải từ web.<br>
            • <b>Làm ấm phiên hoạt động (Feed Warm-up 15-30s):</b> Tự động lướt feed xem 1-2 video trên For You để tạo lịch sử tương tác người dùng thật trước khi đăng.<br>
            • <b>Lách bản quyền FFmpeg nâng cao:</b> Đổi tốc độ 1.025x, tinh chỉnh 1.03 độ bão hòa màu để biến video thành bản thể độc nhất 100%.<br>
            • <b>Cách ly mạng Proxy tĩnh & VPN:</b> Mỗi kênh sở hữu dải IP sạch riêng biệt, triệt tiêu nguy cơ bị dán nhãn Spam cụm máy tính.
        </div>
    </div>
    """)

    # ==================== PHẦN 3: ĐÁNH GIÁ SỨC KHỎE HIỆN TẠI ====================
    if status == "shadowban" or zero_cnt >= 3:
        status_box = f"""
        <div style="background-color: #2D1519; border: 1.5px solid #DC2626; border-radius: 8px; padding: 12px; margin-bottom: 12px;">
            <b style="color: #F87171; font-size: 13px;">🚨 BÁO ĐỘNG ĐỎ: KÊNH DÍNH SHADOWBAN (0 VIEW HÀNG LOẠT)!</b>
            <div style="margin-top: 6px; color: #FCA5A5; font-size: 12px; line-height: 1.5;">
                • <b>Thực trạng:</b> Hệ thống quét thấy <b>{zero_cnt} video liên tiếp bị 0 view</b> (video hoàn toàn không được phân phối vào For You Feed).<br>
                • <b>HÀNH ĐỘNG CỨU KÊNH KHẨN CẤP:</b><br>
                1. <b>Tạm dừng đăng video 24 - 48 giờ</b> để thuật toán TikTok hạ cờ phạt Spam Bot.<br>
                2. <b>Bật tính năng 'AI Auto-Pilot'</b> bên dưới để Tool tự động hoãn các lịch đăng dồn dập.<br>
                3. Đảm bảo tính năng <b>'Làm ấm kênh (Warm-up)'</b> và <b>'Lách bản quyền FFmpeg'</b> luôn bật trong Cài Đặt.
            </div>
        </div>
        """
    elif zero_cnt > 0:
        status_box = f"""
        <div style="background-color: #2C1E11; border: 1.5px solid #D97706; border-radius: 8px; padding: 12px; margin-bottom: 12px;">
            <b style="color: #FBBF24; font-size: 13px;">⚠️ CẢNH BÁO: KÊNH CÓ {zero_cnt} VIDEO BỊ 0 VIEW!</b>
            <div style="margin-top: 6px; color: #FDE68A; font-size: 12px; line-height: 1.5;">
                • <b>Thực trạng:</b> View trung bình đạt <b>{avg_v:,} view</b>, nhưng có {zero_cnt} video không cắn view do AI nhận diện nội dung reup cũ.<br>
                • <b>Giải pháp:</b> Bật tính năng 'Lách bản quyền FFmpeg' để tự động đổi vân tay video trước khi đăng.
            </div>
        </div>
        """
    elif avg_v >= 1000 or viral_cnt >= 1:
        status_box = f"""
        <div style="background-color: #11281E; border: 1.5px solid #16A34A; border-radius: 8px; padding: 12px; margin-bottom: 12px;">
            <b style="color: #4ADE80; font-size: 13px;">🔥 KÊNH ĐANG CẮN ĐỀ XUẤT RẤT MẠNH (View TB: {avg_v:,} view)!</b>
            <div style="margin-top: 6px; color: #BBF7D0; font-size: 12px; line-height: 1.5;">
                • Thuật toán đang chấm điểm tín nhiệm (Trust Score) rất cao cho kênh. Hãy tận dụng đà tăng trưởng này để kéo follow nhanh nhất!
            </div>
        </div>
        """
    else:
        status_box = f"""
        <div style="background-color: #162033; border: 1.5px solid #2563EB; border-radius: 8px; padding: 12px; margin-bottom: 12px;">
            <b style="color: #60A5FA; font-size: 13px;">✅ KÊNH ĐANG HOẠT ĐỘNG ỔN ĐỊNH (View TB: {avg_v:,} view):</b>
            <div style="margin-top: 6px; color: #CBD5E1; font-size: 12px; line-height: 1.5;">
                • Kênh đang trong giai đoạn học tệp khán giả. Tiếp tục duy trì đều đặn nhịp đăng để thuật toán phân loại đúng chủ đề.
            </div>
        </div>
        """
    html_parts.append(status_box)

    # ==================== PHẦN 4: CHIẾN LƯỢC KÉO 10K FOLLOW THỰC CHIẾN ====================
    html_parts.append("""
    <div style="background-color: #171E2E; border: 1.5px solid #334155; border-radius: 8px; padding: 12px;">
        <b style="color: #FBBF24; font-size: 13px;">⚡ CHIẾN LƯỢC TĂNG TỐC ĐẠT 10K FOLLOW TRONG 30 NGÀY TỪ AI:</b>
        <div style="margin-top: 6px; color: #E2E8F0; font-size: 12px; line-height: 1.6;">
            <b>1. Kỹ Thuật Series (Part 1 - Part 2 - Part 3):</b><br>
            • Đây là mồi câu kéo follow tự nhiên mạnh nhất TikTok! Khi khán giả tò mò xem tập kế tiếp, họ <b>bắt buộc phải bấm Follow</b> kênh.<br>
            • <i>Mẹo:</i> Luôn cắt video ở cao trào kịch tính nhất và đặt tiêu đề rõ ràng: <i>'Part 1', 'Part 2'...</i><br><br>

            <b>2. Hook Giữ Chân 3 Giây Đầu (Retention Rate > 60%):</b><br>
            • 80% người xem sẽ lướt qua nếu 3 giây đầu không hấp dẫn. Hãy chèn tiêu đề chữ lớn (Text Overlay) gây tò mò ngay khung hình đầu tiên.<br>
            • Thời lượng tối ưu nhất: <b>20 - 45 giây</b> để tối đa hóa tỷ lệ xem hết (Completion Rate).<br><br>

            <b>3. Mồi Câu Follow Ngầm (Call-To-Action):</b><br>
            • Cuối video hoặc trong Caption, luôn kèm lời mời: <i>'👉 Bấm Follow kênh để xem ngay tập tiếp theo khi lên sóng!'</i><br><br>

            <b>4. Khung Giờ Vàng Đăng Bài Chuẩn Tệp:</b><br>
            • Buổi trưa: <b>11:30 - 13:00</b> (Giờ nghỉ trưa, tương tác tăng vọt).<br>
            • Buổi tối: <b>19:30 - 21:30</b> (Giờ vàng cao điểm nhất trong ngày).<br>
            • <i>Tần suất nuôi chuẩn:</i> <b>2 - 3 video/ngày</b>, mỗi video cách nhau tối thiểu <b>3 - 4 tiếng</b> (không đăng dồn cùng lúc).
        </div>
    </div>
    """)

    return "".join(html_parts)

def analyze_channel_health(channel_data: Dict[str, Any], headless: bool = True, log_func=None) -> Dict[str, Any]:
    """
    Truy cập ngầm vào Profile / TikTok Studio của kênh, đọc thông số video và analytics thực tế,
    chấm điểm sức khỏe và đưa ra chiến lược tối ưu cắn đề xuất.
    """
    def log(msg: str):
        if log_func:
            try:
                log_func(msg)
            except Exception:
                pass

    channel_id = channel_data["id"]
    channel_name = channel_data.get("name", f"Kênh #{channel_id}")
    profile_dir = channel_data.get("profile_dir") or chrome_mgr.get_profile_dir(channel_id)

    log(f"🩺 [Bác Sĩ Kênh AI] Đang bắt đầu khám sức khỏe thực tế cho kênh: {channel_name}...")

    result = {
        "channel_id": channel_id,
        "followers_count": 0,
        "likes_count": 0,
        "videos_count": channel_data.get("posted_count", 0),
        "avg_views": 0,
        "zero_view_count": 0,
        "viral_count": 0,
        "health_status": "healthy",
        "health_score": 50,
        "ai_recommendation": ""
    }

    try:
        from playwright.sync_api import sync_playwright
        from core.stealth_engine import get_stealth_init_script
        from core.network_manager import network_mgr
        from core.rotating_proxy_manager import rotating_proxy_mgr

        chrome_exe = chrome_mgr.get_chrome_path()
        if not chrome_exe or not os.path.isfile(chrome_exe):
            log("⚠️ Không tìm thấy trình duyệt Google Chrome!")
            return result

        # Xử lý mạng & Proxy
        net_info = rotating_proxy_mgr.resolve_channel_network(channel_data)
        pw_proxy = None
        chrome_proxy_arg = None
        
        # Chỉ dùng proxy nếu không phải là IP mẫu/fictitious (203.0.113.x)
        proxy_str = net_info.get("proxy_string", "")
        if net_info["network_type"] == "proxy" and proxy_str and not "203.0.113." in proxy_str:
            parsed = network_mgr.parse_proxy_string(proxy_str)
            if parsed:
                bridge_url = network_mgr.start_local_proxy_bridge(parsed)
                pw_proxy = {"server": bridge_url}
                chrome_proxy_arg = f"--proxy-server={bridge_url}"
                log(f"🌐 Kết nối qua Proxy kênh: {parsed['host']}:{parsed['port']}")

        args = [
            "--disable-blink-features=AutomationControlled",
            "--no-first-run",
            "--no-default-browser-check"
        ]
        if chrome_proxy_arg:
            args.append(chrome_proxy_arg)

        with sync_playwright() as p:
            context = p.chromium.launch_persistent_context(
                user_data_dir=profile_dir,
                executable_path=chrome_exe,
                headless=headless,
                args=args,
                proxy=pw_proxy,
                viewport={"width": 1280, "height": 850}
            )
            context.add_init_script(get_stealth_init_script())
            page = context.pages[0] if context.pages else context.new_page()

            # 1. Truy cập trực tiếp TikTok Studio Content để đọc View chính xác từng video
            log("🔍 Đang kết nối TikTok Studio để đọc danh sách video & lượt xem thực tế...")
            try:
                page.goto("https://www.tiktok.com/tiktokstudio/content", timeout=35000, wait_until="domcontentloaded")
                time.sleep(5)
            except Exception as ge:
                log(f"⚠️ Mở Studio tải chậm: {ge}")

            # Đợi bảng nội dung tải xong (tìm từ khóa Quyền riêng tư hoặc Duration)
            for _ in range(6):
                has_content = page.evaluate("""() => {
                    const text = document.body.innerText || '';
                    return text.includes('Mọi người') || text.includes('Public') || text.includes('Chỉ mình tôi') || /\\b\\d{1,2}:\\d{2}\\b/.test(text);
                }""")
                if has_content:
                    break
                time.sleep(1.5)

            # Quét các video trên TikTok Studio với bộ lọc chống va chạm timestamp
            parsed_videos: List[Dict[str, Any]] = page.evaluate("""() => {
                const items = [];
                const allEls = Array.from(document.querySelectorAll('div, tr'));
                const seen = new Set();
                
                for (const el of allEls) {
                    const text = (el.innerText || '').trim();
                    const lines = text.split('\\n').map(s => s.trim()).filter(Boolean);
                    
                    // Kiểm tra hàng video: lines[0] là thời lượng (ví dụ 01:22, 2:38, 00:45)
                    if (lines.length >= 5 && /^\\d{1,2}:\\d{2}$/.test(lines[0])) {
                        const hasAnotherDuration = lines.slice(1).some(l => /^\\d{1,2}:\\d{2}$/.test(l));
                        if (!hasAnotherDuration) {
                            const privIdx = lines.findIndex(l => ['mọi người', 'public', 'công khai', 'chỉ mình tôi', 'private', 'bạn bè', 'friends'].includes(l.toLowerCase()));
                            if (privIdx >= 2 && privIdx + 1 < lines.length) {
                                const viewStr = lines[privIdx + 1];
                                const likeStr = (privIdx + 2 < lines.length) ? lines[privIdx + 2] : "0";
                                const commentStr = (privIdx + 3 < lines.length) ? lines[privIdx + 3] : "0";
                                const title = lines.slice(1, privIdx - 1).join(' ') || lines[1];
                                const dateStr = lines[privIdx - 1];
                                
                                const key = title + '_' + dateStr;
                                if (!seen.has(key)) {
                                    seen.add(key);
                                    items.push({
                                        title: title,
                                        views: viewStr,
                                        likes: likeStr,
                                        comments: commentStr,
                                        date: dateStr
                                    });
                                }
                            }
                        }
                    }
                }
                return items;
            }""") or []

            log(f"📋 Đã quét thấy {len(parsed_videos)} video trên TikTok Studio của kênh.")

            # 2. Truy cập trang cá nhân để lấy Follower, Like nếu có
            try:
                username = channel_data.get("username", "")
                if username:
                    clean_user = username.replace("@", "").strip()
                    page.goto(f"https://www.tiktok.com/@{clean_user}", timeout=15000, wait_until="domcontentloaded")
                    time.sleep(2)
                    profile_stats = page.evaluate("""() => {
                        let followers = 0;
                        let likes = 0;
                        const strongs = Array.from(document.querySelectorAll('strong[data-e2e*="count"], strong, [title*="Followers"]'));
                        for (const s of strongs) {
                            const parent = s.parentElement ? s.parentElement.innerText.toLowerCase() : '';
                            const val = s.innerText.trim();
                            if (parent.includes('follower') || parent.includes('người theo dõi')) {
                                followers = val;
                            } else if (parent.includes('like') || parent.includes('thích')) {
                                likes = val;
                            }
                        }
                        return { followers, likes };
                    }""")
                    result["followers_count"] = _parse_tiktok_number(profile_stats.get("followers", "0"))
                    result["likes_count"] = _parse_tiktok_number(profile_stats.get("likes", "0"))
            except Exception:
                pass

            context.close()

            # 3. Phân tích số liệu video thực tế
            if parsed_videos:
                view_numbers = [_parse_tiktok_number(v["views"]) for v in parsed_videos]
                total_scanned = len(view_numbers)
                zero_view_cnt = sum(1 for v in view_numbers if v == 0)
                viral_cnt = sum(1 for v in view_numbers if v >= 1000)
                avg_view = int(sum(view_numbers) / total_scanned) if total_scanned > 0 else 0

                result["videos_count"] = max(total_scanned, channel_data.get("posted_count", 0))
                result["avg_views"] = avg_view
                result["zero_view_count"] = zero_view_cnt
                result["viral_count"] = viral_cnt
                result["has_scanned_studio"] = True
                log(f"📊 Kết quả đo lường: {total_scanned} video | {zero_view_cnt} video 0 VIEW | View TB: {avg_view}")
            else:
                # Nếu không quét được từ Studio (chặn hoặc lỗi mạng)
                posted = channel_data.get("posted_count", 0)
                result["videos_count"] = posted
                result["has_scanned_studio"] = False
                log("⚠️ Không thể tải danh sách video từ TikTok Studio (Kiểm tra lại phiên đăng nhập).")

    except Exception as e:
        log(f"⚠️ Quá trình khám gặp sự cố: {e}")

    # 4. THUẬT TOÁN ĐÁNH GIÁ SỨC KHỎE
    zero_cnt = result["zero_view_count"]
    v_cnt = result["videos_count"]
    avg_v = result["avg_views"]
    has_scanned = result.get("has_scanned_studio", False)

    if has_scanned and (zero_cnt >= 3 or (zero_cnt > 0 and zero_cnt >= v_cnt * 0.7)):
        result["health_status"] = "shadowban"
        result["health_score"] = max(15, 40 - zero_cnt * 3)
    elif has_scanned and zero_cnt > 0:
        result["health_status"] = "warning"
        result["health_score"] = max(40, 70 - zero_cnt * 10)
    elif has_scanned and (avg_v >= 1000 or result["viral_count"] >= 1):
        result["health_status"] = "healthy"
        result["health_score"] = min(100, 85 + result["viral_count"] * 5)
    elif has_scanned and avg_v > 0 and avg_v < 300 and v_cnt >= 3:
        result["health_status"] = "warning"
        result["health_score"] = 65
    elif not has_scanned and v_cnt > 0:
        result["health_status"] = "warning"
        result["health_score"] = 50
    elif v_cnt == 0:
        result["health_status"] = "healthy"
        result["health_score"] = 80
    else:
        result["health_status"] = "healthy"
        result["health_score"] = 85

    # 5. XÂY DỰNG CHIẾN LƯỢC TĂNG TRƯỞNG 10K FOLLOW CHI TIẾT
    result["ai_recommendation"] = _build_10k_growth_strategy(result, channel_data)

    # Lưu kết quả thực tế vào database
    db.save_channel_analytics(channel_id, result)
    db.update_channel_stats(channel_id, result.get("followers_count", 0), result.get("avg_views", 0))
    log(f"🎉 Khám sức khỏe hoàn tất! Điểm sức khỏe: {result['health_score']}/100 | Trạng thái: {result['health_status'].upper()}")

    return result
