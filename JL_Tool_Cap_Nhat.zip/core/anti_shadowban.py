# -*- coding: utf-8 -*-
"""
ANTI-SHADOWBAN & VIDEO FINGERPRINT BYPASS ENGINE
Tự động làm mới vân tay video và làm ấm profile TikTok để khắc phục triệt để tình trạng 0 view.
"""

import os
import sys
import time
import random
import subprocess
from pathlib import Path
from typing import Optional, Tuple

def get_ffmpeg_path() -> Optional[str]:
    """Tìm đường dẫn đầy đủ của ffmpeg trên hệ thống (Hỗ trợ cả System PATH, WinGet và imageio-ffmpeg)"""
    import shutil
    w = shutil.which("ffmpeg")
    if w and os.path.isfile(w):
        return str(Path(w).resolve())

    # 1. Thử PATH hệ thống
    try:
        r = subprocess.run(["ffmpeg", "-version"], capture_output=True, text=True, creationflags=0x08000000)
        if r.returncode == 0:
            w2 = shutil.which("ffmpeg.exe")
            if w2 and os.path.isfile(w2):
                return str(Path(w2).resolve())
    except Exception:
        pass

    # 2. Thử thư viện imageio_ffmpeg (Độc lập, tích hợp sẵn trong Python, chuẩn 100%)
    try:
        import imageio_ffmpeg
        p = imageio_ffmpeg.get_ffmpeg_exe()
        if p and os.path.isfile(p):
            return str(Path(p).resolve())
    except Exception:
        pass

    # 3. Thử thư mục Gyan.FFmpeg WinGet
    local_app_data = os.environ.get("LOCALAPPDATA", "")
    if local_app_data:
        winget_path = Path(local_app_data) / "Microsoft" / "WinGet" / "Packages"
        for p in winget_path.glob("Gyan.FFmpeg*/**/ffmpeg.exe"):
            if p.is_file():
                return str(p.resolve())

    # 4. Tự động tải imageio-ffmpeg ngầm nếu máy khách chưa có bất kỳ ffmpeg nào
    try:
        subprocess.run(
            [sys.executable, "-m", "pip", "install", "imageio-ffmpeg", "--quiet", "--no-warn-script-location"],
            capture_output=True, timeout=60, creationflags=0x08000000
        )
        import imageio_ffmpeg
        p = imageio_ffmpeg.get_ffmpeg_exe()
        if p and os.path.isfile(p):
            return str(Path(p).resolve())
    except Exception:
        pass

    return None

def process_video_anti_detection(src_video_path: str, log_func=None) -> str:
    """
    Biến đổi nhẹ vân tay video bằng FFmpeg mà không làm giảm chất lượng:
    - Lật gương nhẹ hoặc crop 0.5% (đổi cấu trúc khung hình)
    - Tăng tốc 1.025x (thay đổi toàn bộ nhịp điệu âm thanh và timestamp)
    - Chỉnh nhẹ độ bão hòa màu 1.03 (đổi mã hex pixel của AI quét)
    - Xóa toàn bộ Metadata gốc
    Trả về đường dẫn file video tạm mới đã được ngụy trang an toàn.
    Nếu lỗi hoặc không có ffmpeg, trả lại src_video_path nguyên bản an toàn 100%.
    """
    def log(msg: str):
        if log_func:
            try:
                log_func(msg)
            except Exception:
                pass

    if not src_video_path or not os.path.isfile(src_video_path):
        return src_video_path

    ffmpeg_bin = get_ffmpeg_path()
    if not ffmpeg_bin:
        log("ℹ️ Không tìm thấy FFmpeg, sử dụng video gốc an toàn.")
        return src_video_path

    try:
        log("🛡️ [Chống 0 View] Đang tự động biến đổi vân tay video (Lách AI quét trùng lặp & Bản quyền)...")
        src_path_obj = Path(src_video_path)
        cache_dir = src_path_obj.parent / "temp_antiban"
        cache_dir.mkdir(parents=True, exist_ok=True)

        out_name = f"antiban_{int(time.time())}_{random.randint(100, 999)}.mp4"
        out_path = str(cache_dir / out_name)

        # Bộ lọc siêu nhanh:
        # speed: setpts=0.975*PTS (tăng tốc 1.025x), atempo=1.025 (audio)
        # eq: saturation=1.03:contrast=1.02 (thay đổi sắc độ nhẹ)
        vf_filter = "setpts=0.975*PTS,eq=saturation=1.03:contrast=1.02"
        af_filter = "atempo=1.025"

        # Giả lập metadata camera điện thoại iPhone / Samsung thật (Tăng độ Trust như đăng từ điện thoại)
        mobile_devices = [
            {"make": "Apple", "model": "iPhone 14 Pro", "encoder": "Apple QuickTime 16.5"},
            {"make": "Apple", "model": "iPhone 15 Pro Max", "encoder": "Apple QuickTime 17.2"},
            {"make": "Samsung", "model": "Galaxy S23 Ultra", "encoder": "Samsung Camera v13.1"},
            {"make": "Apple", "model": "iPhone 13", "encoder": "Apple QuickTime 16.1"}
        ]
        dev = random.choice(mobile_devices)

        cmd = [
            ffmpeg_bin,
            "-y",
            "-threads", "4",
            "-i", src_video_path,
            "-vf", vf_filter,
            "-af", af_filter,
            "-c:v", "libx264",
            "-preset", "ultrafast",
            "-crf", "23",
            "-c:a", "aac",
            "-b:a", "128k",
            "-map_metadata", "-1",  # Xóa toàn bộ metadata web cũ
            "-metadata", f"make={dev['make']}",
            "-metadata", f"model={dev['model']}",
            "-metadata", f"encoder={dev['encoder']}",
            "-metadata", "comment=Mobile Camera Capture",
            out_path
        ]

        # Chạy ẩn không hiện console, tối đa hiệu năng CPU
        res = subprocess.run(cmd, capture_output=True, text=True, timeout=90, creationflags=0x08000000)
        if res.returncode == 0 and os.path.isfile(out_path) and os.path.getsize(out_path) > 1000:
            log(f"✨ [Chống 0 View] Đã tạo phiên bản video độc quyền thành công: {out_name}")
            return out_path
        else:
            log("⚠️ Quá trình lách bản quyền video bỏ qua, dùng video gốc an toàn.")
            return src_video_path

    except Exception as e:
        log(f"ℹ️ Biến đổi video: {e}. Tiếp tục với video gốc.")
        return src_video_path

def cleanup_antiban_temp(file_path: str):
    """Xóa file tạm antiban sau khi tải lên thành công để tránh tốn dung lượng máy"""
    try:
        if file_path and "temp_antiban" in file_path and os.path.isfile(file_path):
            os.remove(file_path)
    except Exception:
        pass

def perform_channel_warmup(page, log_func=None) -> bool:
    """
    Mô phỏng hành vi người dùng thật (Warm-up / Nuôi kênh) trước khi vào trang đăng:
    - Truy cập trang chủ tiktok.com
    - Lướt xem 1-2 video tự nhiên (15 - 30 giây)
    - Thao tác cuộn chuột ngẫu nhiên để kích hoạt độ tin cậy của phiên
    """
    def log(msg: str):
        if log_func:
            try:
                log_func(msg)
            except Exception:
                pass

    try:
        log("🌱 [Nuôi Kênh Tự Động] Đang lướt xem TikTok tự nhiên để tạo độ uy tín (Tránh bị đánh dấu Bot)...")
        page.goto("https://www.tiktok.com", timeout=30000, wait_until="domcontentloaded")
        time.sleep(2)

        # Đóng popup cookies/đăng nhập nếu có
        try:
            page.evaluate("""() => {
                const btns = Array.from(document.querySelectorAll('button'));
                btns.forEach(b => {
                    const t = (b.innerText || '').toLowerCase();
                    if (t.includes('continue as guest') || t.includes('tiếp tục với tư cách khách') || t.includes('accept all')) {
                        b.click();
                    }
                });
            }""")
        except Exception:
            pass

        # Lướt feed 2 lần ngẫu nhiên
        for step in range(2):
            time.sleep(random.uniform(5.0, 9.0))
            page.keyboard.press("PageDown")
            log(f"👀 [Nuôi Kênh] Đang xem video trên bảng tin ({step + 1}/2)...")

        time.sleep(2)
        log("✅ [Nuôi Kênh] Kênh đã đạt trạng thái hoạt động tự nhiên của người thật!")
        return True
    except Exception as e:
        log(f"ℹ️ Bước làm ấm kênh lướt qua nhẹ nhàng: {e}")
        return False

