import time
import os
import threading
from datetime import datetime, timedelta
from typing import List, Dict, Any, Callable, Optional
import config
from database.db_manager import db
from core.tiktok_uploader import uploader
from core.video_resolver import resolve_video_path
from core.video_vault import video_vault

def set_keep_awake(enable: bool = True):
    """
    Ngăn Windows rơi vào trạng thái ngủ sâu (Sleep / Standby / Suspend).
    Đảm bảo khi tắt màn hình hoặc không dùng máy, Tool vẫn hoạt động ngầm 100%.
    """
    try:
        import ctypes
        ES_CONTINUOUS = 0x80000000
        ES_SYSTEM_REQUIRED = 0x00000001
        ES_AWAYMODE_REQUIRED = 0x00000040
        if enable:
            ctypes.windll.kernel32.SetThreadExecutionState(ES_CONTINUOUS | ES_SYSTEM_REQUIRED | ES_AWAYMODE_REQUIRED)
        else:
            ctypes.windll.kernel32.SetThreadExecutionState(ES_CONTINUOUS)
    except Exception:
        pass

class SchedulerService:
    """
    Dịch vụ chạy ngầm kiểm tra lịch hẹn giờ và TỰ ĐỘNG ĐĂNG HÀNG LOẠT ĐỒNG THỜI (PARALLEL MULTI-CHANNEL):
    - Toàn bộ kênh đến giờ hẹn được phép đăng đồng loạt cùng lúc, không phải chờ từng kênh một.
    - Đảm bảo 100% đúng IP, không bị kẹt profile và không bỏ sót lịch.
    - Chống Windows Sleep: Tắt màn hình hoặc đi ngủ máy vẫn tự đăng và báo về Telegram!
    """
    def __init__(self):
        self.is_running = False
        self.thread: Optional[threading.Thread] = None
        self.log_callback: Optional[Callable[[str], None]] = None
        self._active_channels: set = set()
        self._active_schedules: set = set()
        self._active_refilling_channels: set = set()
        self._refill_cooldowns: Dict[int, float] = {}
        self._lock = threading.Lock()

    def start(self, log_callback=None):
        if self.is_running:
            return
        self.is_running = True
        self.log_callback = log_callback

        # 1. Kích hoạt cờ chống ngủ sâu Windows
        set_keep_awake(True)

        # 2. Khôi phục bất kỳ lịch nào bị kẹt ở trạng thái processing do khởi động lại app
        try:
            db.reset_stuck_processing_schedules()
            db.clean_orphan_schedules()

            cleaned_count = db.delete_successful_schedules()
            if cleaned_count > 0:
                self._log(f"🧹 Đã tự động dọn dẹp {cleaned_count} lịch trình video đã đăng thành công khỏi danh sách!")

            skipped = db.clean_duplicate_pending_schedules()
            if skipped > 0:
                self._log(f"🧹 Đã quét qua toàn bộ lịch và tự động xóa {skipped} video trùng lặp vì tiêu đề đã được đăng thành công trước đó!")

            migrated = video_vault.sync_existing_schedules_to_vault()
            if migrated > 0:
                self._log(f"📦 Đã tự động chuyển an toàn {migrated} video lịch hẹn vào kho video của Tool!")

            if db.get_setting("auto_retry_failed", "1") == "1":
                cnt = db.recover_overdue_failed_schedules(cooldown_seconds=0, max_retries=0)
                if cnt > 0:
                    self._log(f"🚀 [Chạy lại đến khi thành công] Tự động kích hoạt đăng lại {cnt} video lỗi ngay khi khởi động!")
        except Exception:
            pass

        self.thread = threading.Thread(target=self._run_loop, daemon=True)
        self.thread.start()
        self._log("🟢 Dịch vụ hẹn giờ đăng video đã bắt đầu chạy ngầm (Chế độ đăng đồng loạt đa kênh & Chống ngủ Windows kích hoạt)...")

    def stop(self):
        self.is_running = False
        set_keep_awake(False)
        self._log("⚪ Đã dừng dịch vụ hẹn giờ.")

    def _log(self, text: str):
        if self.log_callback:
            self.log_callback(text)
        try:
            print(f"[Scheduler] {text}")
        except Exception:
            try:
                print(f"[Scheduler] {text.encode('ascii', 'replace').decode()}")
            except Exception:
                pass

    def _execute_single_schedule(self, item: Dict[str, Any]):
        """Thực thi đăng tải độc lập cho 1 kênh (Chạy trong luồng Worker riêng biệt)"""
        schedule_id = item["id"]
        channel_id = item["channel_id"]
        ch_name = item.get("channel_name", f"Kênh #{channel_id}")
        video_path = item["video_path"]
        caption = item.get("caption") or item.get("video_title", "")
        hashtags = item.get("hashtags", "")

        try:
            # KIỂM TRA CHỈ TIÊU ĐĂNG TỐI ĐA TRONG NGÀY (MẶC ĐỊNH 3 VIDEO/NGÀY HOẶC THEO CÀI ĐẶT KÊNH)
            max_daily = db.get_channel_max_daily_posts(channel_id, default=3)
            posted_today = db.get_channel_today_posted_count(channel_id)
            if posted_today >= max_daily:
                try:
                    cur_st = datetime.strptime(item.get("scheduled_time", ""), "%Y-%m-%d %H:%M:%S")
                    new_st = (cur_st + timedelta(days=1)).strftime("%Y-%m-%d %H:%M:%S")
                except Exception:
                    new_st = (datetime.now() + timedelta(days=1)).strftime("%Y-%m-%d %H:%M:%S")
                with db._get_connection() as conn:
                    conn.cursor().execute(
                        "UPDATE schedules SET scheduled_time = ?, status = 'pending', error_message = ? WHERE id = ?",
                        (new_st, f"Đã đạt chỉ tiêu ngày ({posted_today}/{max_daily} video). Tự động dời sang {new_st}", schedule_id)
                    )
                    conn.commit()
                self._log(
                    f"🛑 [ĐÃ ĐỦ CHỈ TIÊU NGÀY] Kênh '@{ch_name}' đã đăng thành công {posted_today}/{max_daily} video hôm nay! "
                    f"Tự động dừng đăng hôm nay & dời video '{caption[:35]}' sang ngày mai ({new_st}) để giữ an toàn tuyệt đối cho tài khoản."
                )
                return

            # KIỂM TRA CHẾ ĐỘ AI AUTO-PILOT CỦA KÊNH:
            # Nếu kênh đang bật Auto-Pilot và bị đánh dấu Shadowban (nhiều video 0 view) -> Tự động hoãn 12 tiếng để bảo vệ kênh!
            if db.is_channel_autopilot(channel_id):
                analytics = db.get_channel_analytics(channel_id)
                if analytics and analytics.get("health_status") == "shadowban":
                    # Hoãn lịch đăng lại 12 tiếng để tránh chết kênh
                    new_sched = (datetime.now() + timedelta(hours=12)).strftime("%Y-%m-%d %H:%M:%S")
                    with db._get_connection() as conn:
                        conn.execute("UPDATE schedules SET scheduled_time = ?, status = 'pending', error_message = 'AI Auto-Pilot: Tự động hoãn 12h do kênh đang dính shadowban để bảo vệ nick' WHERE id = ?", (new_sched, schedule_id))
                        conn.commit()
                    self._log(f"🛡️ [AI Auto-Pilot] Kênh '{ch_name}' đang bị TikTok bóp view (Shadowban) ➔ AI tự động hoãn lịch đăng đến {new_sched} để bảo toàn kênh!")
                    return

            # QUÉT KIỂM TRA QUY TẮC: 1 VIDEO 1 TIÊU ĐỀ CHỈ ĐĂNG 1 LẦN THÀNH CÔNG DUY NHẤT
            if db.is_video_already_posted(channel_id=channel_id, video_title=caption, video_path=video_path, current_schedule_id=schedule_id):
                self._log(f"⏭️ [BỎ QUA TRÙNG LẶP] Kênh '{ch_name}' đã đăng thành công video tiêu đề: '{caption}' trước đó. Tự động xóa khỏi lịch trình!")
                db.delete_schedule(schedule_id)
                return

            # TỰ ĐỘNG PHÁT HIỆN VÀ KHÔI PHỤC ĐƯỜNG DẪN VIDEO NẾU BỊ ĐỔI THƯ MỤC HOẶC TÊN FILE
            actual_path = resolve_video_path(video_path, caption, extra_folder=item.get("video_folder", ""))
            if actual_path and actual_path != video_path:
                self._log(f"🔍 [Tự động khớp] Đã phát hiện và cập nhật đường dẫn video mới ({ch_name}): '{os.path.basename(actual_path)}'")
                db.update_schedule_video_path(schedule_id, actual_path)
                video_path = actual_path

            # TỰ ĐỘNG CHUYỂN VÀO KHO VIDEO TRONG TOOL
            if video_path and os.path.isfile(video_path) and not video_vault.is_in_vault(video_path):
                vault_path = video_vault.import_video_to_vault(video_path, caption)
                if vault_path and vault_path != video_path:
                    db.update_schedule_video_path(schedule_id, vault_path)
                    video_path = vault_path
                    self._log(f"📦 [Kho Video] Đã tự động lưu trữ video an toàn vào kho: '{os.path.basename(vault_path)}'")

            if not video_path or not os.path.isfile(video_path):
                f_name = os.path.basename(video_path) if video_path else caption
                err_file = f"File video không tồn tại trên máy tính: {f_name}"
                db.update_schedule_status(schedule_id, "failed", err_file, increment_retry=True)
                self._log(f"⚠️ [Mất file] Không tìm thấy file '{f_name}' trên máy tính ({ch_name}). Hệ thống sẽ tự động quét lại!")
                return

            channel_data = {
                "id": item["channel_id"],
                "name": item["channel_name"],
                "profile_dir": item["profile_dir"],
                "network_type": item.get("network_type", "vpn"),
                "use_vpn": item.get("use_vpn", 1),
                "proxy_string": item.get("proxy_string", ""),
                "vpn_region": item.get("vpn_region", ""),
                "target_country": item.get("target_country", ""),
                "pia_username": item.get("pia_username", ""),
                "pia_password": item.get("pia_password", "")
            }

            # ==================== KIỂM SOÁT TỰ ĐỘNG BẰNG AI AUTO-PILOT ====================
            cid = item["channel_id"]
            if db.is_channel_autopilot(cid):
                analytics = db.get_channel_analytics(cid)
                if analytics:
                    zero_cnt = analytics.get("zero_view_count", 0)
                    status = analytics.get("health_status", "healthy")
                    last_analyzed = analytics.get("last_analyzed", "")

                    # Nếu kênh đang có dấu hiệu Shadowban (>= 3 video 0 view)
                    if status == "shadowban" or zero_cnt >= 3:
                        now = datetime.now()
                        should_cooldown = True
                        if last_analyzed:
                            try:
                                t_analyzed = datetime.strptime(last_analyzed, "%Y-%m-%d %H:%M:%S")
                                if (now - t_analyzed).total_seconds() > 24 * 3600:
                                    should_cooldown = False
                            except Exception:
                                pass

                        if should_cooldown:
                            new_time = (now + timedelta(hours=24)).strftime("%Y-%m-%d %H:%M:%S")
                            with db._get_connection() as conn:
                                conn.cursor().execute("UPDATE schedules SET scheduled_time = ?, status = 'pending' WHERE id = ?", (new_time, schedule_id))
                                conn.commit()
                            self._log(
                                f"🛡️ [AI Auto-Pilot Tự Chữa Kênh] Kênh '{ch_name}' đang có {zero_cnt} video 0 view (Dấu hiệu Shadowban)! "
                                f"Hệ thống TỰ ĐỘNG HOÃN ĐĂNG 24h để bảo vệ tài khoản khỏi cờ Spam Bot. Lịch mới: {new_time}"
                            )
                            try:
                                from core.notifier import notifier
                                notifier.send_telegram_msg(
                                    f"🛡️ <b>[AI Auto-Pilot Tự Chữa Kênh]</b>\n"
                                    f"• Kênh: <b>@{ch_name}</b>\n"
                                    f"• Cảnh báo: <b>{zero_cnt} video 0 view liên tiếp</b>\n"
                                    f"• Hành động: <b>Tự động hoãn đăng 24 giờ</b> để xả cờ phạt TikTok.\n"
                                    f"• Lịch hẹn dời sang: <code>{new_time}</code>"
                                )
                            except Exception:
                                pass
                            return

            self._log(f"🚀 [Đăng Đồng Loạt] Kích hoạt tiến trình đăng video: '{item['video_title']}' ➔ {ch_name}")
            db.update_schedule_status(schedule_id, "processing")

            max_immediate = 2
            attempt = 0
            success = False
            err = ""

            # TỰ ĐỘNG CẮT KHUNG HÌNH (AUTO-CROP) THEO CẤU HÌNH KÊNH HOẶC LỊCH ĐĂNG
            crop_mode = item.get("crop_frame") or channel_data.get("crop_frame") or "original"
            if crop_mode and crop_mode != "original":
                try:
                    from core.video_cropper import crop_single_video
                    self._log(f"✂️ [{ch_name}] Đang tự động cắt video '{os.path.basename(video_path)}' sang khung chuẩn [{crop_mode}]...")
                    cropped_v = crop_single_video(video_path, crop_mode, log_func=self._log)
                    if cropped_v and os.path.isfile(cropped_v):
                        video_path = cropped_v
                except Exception as e_cr:
                    self._log(f"⚠️ [{ch_name}] Cắt khung video bỏ qua: {e_cr}")

            while attempt < max_immediate and self.is_running:
                attempt += 1
                if attempt > 1:
                    self._log(f"🔄 [Tự động khắc phục] Kích hoạt phương án dự phòng lần {attempt}/{max_immediate} cho video '{item['video_title']}' ({ch_name})...")
                    if "cửa sổ chrome" in err.lower() or "lock" in err.lower() or "kẹt" in err.lower():
                        try:
                            from core.tiktok_uploader import cleanup_profile_locks
                            cleanup_profile_locks(channel_data.get("profile_dir", ""))
                        except Exception:
                            pass
                    time.sleep(1.5)

                is_cloud_preupload = bool(item.get("_is_cloud_preupload", False))
                sched_time_arg = item.get("scheduled_time") if is_cloud_preupload else None
                success, err = uploader.upload_video(
                    channel_data=channel_data,
                    video_path=video_path,
                    caption=caption,
                    hashtags=hashtags,
                    headless=True,
                    log_callback=self._log,
                    schedule_time_str=sched_time_arg
                )

                if success:
                    break
                else:
                    self._log(f"⚠️ [{ch_name}] Lần {attempt}/{max_immediate} chưa hoàn tất: {err}")

            if success:
                # Lấy số video còn lại trong lịch đăng của kênh này
                remaining_count = db.get_channel_remaining_schedules_count(item["channel_id"])

                if item.get("_is_cloud_preupload"):
                    db.update_schedule_status(schedule_id, "cloud_scheduled")
                    self._log(
                        f"☁️ [ĐÃ LƯU LÊN ĐÁM MÂY TIKTOK] Video '{item['video_title']}' ({ch_name}) đã được nạp sẵn lên máy chủ TikTok! "
                        f"Đúng {item.get('scheduled_time')} TikTok sẽ tự động đăng kể cả khi bạn TẮT MÁY TÍNH HOÀN TOÀN! "
                        f"(📊 Kênh còn lại: {remaining_count} video trong lịch hẹn)"
                    )
                else:
                    db.update_schedule_status(schedule_id, "success")
                    self._log(f"🎉 ĐĂNG THÀNH CÔNG 100%: '{item['video_title']}' lên kênh '{ch_name}'! (📊 Kênh còn lại: {remaining_count} video trong lịch hẹn)")

                    # Thông báo Telegram & Windows ngay lập tức
                    try:
                        from core.notifier import notifier
                        notifier.notify_upload_success(
                            channel_name=item.get("channel_name", "Kênh TikTok"),
                            video_title=item.get("video_title") or caption,
                            extra_info={
                                'region': item.get('vpn_region') or item.get('target_country') or '',
                                'remaining_count': remaining_count
                            }
                        )
                    except Exception:
                        pass

                    # Cập nhật video_id đã đăng
                    try:
                        if item.get("video_id"):
                            db.update_video_posted(item["video_id"])
                    except Exception:
                        pass

                    # Dọn dẹp kho video
                    try:
                        video_vault.cleanup_vault_video(video_path, schedule_id=schedule_id)
                    except Exception:
                        pass

                    # Tự động xóa lịch trình đã thành công (chỉ để lại các video chưa đăng)
                    try:
                        db.delete_schedule(schedule_id)
                    except Exception:
                        pass

            else:
                db.update_schedule_status(schedule_id, "failed", f"Lỗi: {err}", increment_retry=True)
                self._log(f"❌ Video '{item['video_title']}' ({ch_name}) gặp sự cố: {err}. Hệ thống sẽ tự động thử lại đến khi thành công!")
                try:
                    from core.notifier import notifier
                    notifier.notify_upload_failed(
                        channel_name=item.get("channel_name", "Kênh TikTok"),
                        video_title=item.get("video_title") or caption,
                        error_msg=f"Sự cố: {err[:80]}. Đang tự động thử lại..."
                    )
                except Exception:
                    pass

        except Exception as e:
            self._log(f"⚠️ Lỗi ngoại lệ khi xử lý video ({ch_name}): {str(e)}")
        finally:
            with self._lock:
                self._active_channels.discard(channel_id)
                self._active_schedules.discard(schedule_id)
                remaining = len(self._active_channels)

            # Thông báo cho Rotating Proxy Manager: Nếu 5 kênh của đợt này đã đăng xong ➔ Tự động OFF Proxy & giải phóng
            try:
                from core.rotating_proxy_manager import rotating_proxy_mgr
                rotating_proxy_mgr.on_schedule_finished(schedule_id, channel_id, log_func=self._log)
            except Exception:
                pass

            # NẾU TOÀN BỘ CÁC TIẾN TRÌNH ĐĂNG ĐỒNG LOẠT ĐÃ HOÀN TẤT:
            # Tự động ngắt VPN để trả lại 100% tốc độ mạng gốc siêu tốc cho máy tính!
            if remaining == 0:
                if db.get_setting("auto_disconnect_vpn_after_post", "0") == "1":
                    try:
                        from core.network_manager import network_mgr
                        network_mgr.pia_disconnect()
                        self._log("⚡ [Tối ưu tốc độ mạng] Đã hoàn tất đăng tải ➔ Tự động ngắt VPN để trả lại 100% tốc độ Download/Upload tối đa cho máy tính!")
                    except Exception:
                        pass

    def _run_loop(self):
        last_auto_retry_check = 0
        last_auto_refill_check = 0
        while self.is_running:
            try:
                now_ts = time.time()
                # 0. WATCHDOG: Tự động giải phóng bất kỳ lịch nào bị kẹt ở trạng thái processing quá 8 phút (và không còn luồng chạy)
                try:
                    with self._lock:
                        active_sids = list(self._active_schedules)
                    with db._get_connection() as conn:
                        cursor = conn.cursor()
                        if active_sids:
                            placeholders = ",".join("?" for _ in active_sids)
                            cursor.execute(f"""
                                UPDATE schedules
                                SET status = 'pending',
                                    error_message = 'Tự động giải phóng do quá thời gian xử lý...'
                                WHERE status = 'processing'
                                  AND id NOT IN ({placeholders})
                                  AND last_attempt IS NOT NULL
                                  AND (strftime('%s', datetime('now', 'localtime')) - strftime('%s', last_attempt)) > 480
                            """, active_sids)
                        else:
                            cursor.execute("""
                                UPDATE schedules
                                SET status = 'pending',
                                    error_message = 'Tự động giải phóng do quá thời gian xử lý...'
                                WHERE status = 'processing'
                                  AND last_attempt IS NOT NULL
                                  AND (strftime('%s', datetime('now', 'localtime')) - strftime('%s', last_attempt)) > 480
                            """)
                        if cursor.rowcount > 0:
                            conn.commit()
                            self._log(f"⚡ [Watchdog] Đã tự động giải phóng {cursor.rowcount} lịch đăng bị quá hạn xử lý về hàng chờ!")
                except Exception:
                    pass

                # KIỂM TRA BẢN QUYỀN MÁY TÍNH TRƯỚC KHI ĐĂNG
                from core.license_manager import license_mgr
                is_lic, _, _ = license_mgr.check_current_license()
                if not is_lic:
                    time.sleep(5)
                    continue

                # Tự động quét và kích hoạt đăng lại các video lỗi siêu tốc (mỗi 5 giây)
                if now_ts - last_auto_retry_check >= 5:
                    last_auto_retry_check = now_ts
                    skipped = db.clean_duplicate_pending_schedules()
                    if skipped > 0:
                        self._log(f"🧹 Đã quét và tự động bỏ qua {skipped} lịch hẹn vì tiêu đề đã được đăng thành công trước đó!")

                    if db.get_setting("auto_retry_failed", "1") == "1":
                        cooldown = int(db.get_setting("auto_retry_cooldown", "60"))
                        retried_cnt = db.recover_overdue_failed_schedules(cooldown_seconds=cooldown, max_retries=0)
                        if retried_cnt > 0:
                            self._log(f"🔄 [Tự động khắc phục] Đã kích hoạt lại {retried_cnt} video vào hàng chờ đăng!")

                # TỰ ĐỘNG NẠP ĐẦY KHO VIDEO ĐÁM MÂY (AUTO-REFILL ENGINE)
                # Khi kênh hết video hoặc chỉ còn <= 1 video cuối cùng -> Tự động kéo video YouTube mới, cắt và nạp thẳng lên Đám Mây TikTok
                if now_ts - last_auto_refill_check >= 30:
                    last_auto_refill_check = now_ts
                    self._check_and_auto_refill_channels()

                now_dt = datetime.now()
                now_str = now_dt.strftime("%Y-%m-%d %H:%M:%S")

                # 1. Tự động hoàn tất các lịch Đám Mây TikTok đã đến giờ đăng
                try:
                    cloud_done = db.complete_due_cloud_scheduled_items(now_str)
                    if cloud_done > 0:
                        self._log(f"☁️ [Đám Mây TikTok] {cloud_done} video hẹn giờ trên máy chủ TikTok đã đến giờ và tự động công khai thành công!")
                except Exception:
                    pass

                # 2. Lấy các lịch đã đến giờ đăng ngay
                due_items = db.get_due_schedules(now_str)

                # 3. Nếu không còn lịch đến giờ ngay, tự động lấy các lịch hẹn tương lai (từ 22 phút đến 10 ngày tới)
                # để ĐẨY TRƯỚC LÊN MÁY CHỦ ĐÁM MÂY TIKTOK (chỉ khi người dùng chủ động bật trong cài đặt)
                if not due_items and db.get_setting("auto_cloud_preupload", "0") == "1":
                    from datetime import timedelta as _td
                    min_f = (now_dt + _td(minutes=22)).strftime("%Y-%m-%d %H:%M:%S")
                    max_f = (now_dt + _td(days=10)).strftime("%Y-%m-%d %H:%M:%S")
                    future_cloud_items = db.get_future_cloud_schedulable_items(min_f, max_f)
                    if future_cloud_items:
                        for f_item in future_cloud_items:
                            f_item["_is_cloud_preupload"] = True
                        due_items = future_cloud_items
                        # Đặt thêm đồng hồ đánh thức phần cứng BIOS/RTC cho lịch sớm nhất
                        try:
                            from core.startup_manager import set_hardware_wake_timer
                            earliest_dt = datetime.strptime(future_cloud_items[0]["scheduled_time"], "%Y-%m-%d %H:%M:%S")
                            set_hardware_wake_timer(earliest_dt)
                        except Exception:
                            pass

                if due_items:
                    max_concurrent = int(db.get_setting("max_concurrent_tasks", "3"))
                    
                    # TÍCH HỢP ĐIỀU PHỐI XOAY TUA PROXY (5 KÊNH / ĐỢT)
                    from core.rotating_proxy_manager import rotating_proxy_mgr
                    rotating_active_cids = set()
                    if rotating_proxy_mgr.is_enabled():
                        # Kiểm tra xem có cần khởi động thêm đợt 5 kênh mới không
                        next_batch = rotating_proxy_mgr.get_next_batch_for_upload(due_items, self._active_channels)
                        if next_batch:
                            self._log(
                                f"🛡️ [Xoay Tua Proxy] BẮT ĐẦU ĐỢT #{next_batch['batch_id']}: "
                                f"Đã gán Proxy [{next_batch['proxy'].split('@')[-1]}] cho 5 kênh ({len(next_batch['channel_ids'])} kênh) để bắt đầu đăng!"
                            )
                            # Cập nhật trực tiếp thông tin proxy mới nhất cho các lịch thuộc đợt này (giữ nguyên cờ _is_cloud_preupload)
                            batch_cids = set(next_batch["channel_ids"])
                            for d_it in due_items:
                                if d_it["channel_id"] in batch_cids:
                                    d_it["proxy_string"] = next_batch["proxy"]
                                    d_it["network_type"] = "proxy"

                        # Thu thập toàn bộ ID kênh thuộc các đợt đang được cấp proxy
                        with rotating_proxy_mgr._lock:
                            for p_info in rotating_proxy_mgr._active_batches.values():
                                rotating_active_cids.update(p_info["channel_ids"])

                    items_to_dispatch = []
                    with self._lock:
                        for item in due_items:
                            # Nếu chế độ xoay tua Proxy đang bật:
                            # Các kênh ĐÃ TÍCH CHỌN XOAY TUA PROXY chỉ được chạy khi đang thuộc đợt được cấp Proxy
                            # Các kênh KHÔNG TÍCH CHỌN sẽ chạy bình thường theo VPN/IP gốc của kênh đó
                            if rotating_proxy_mgr.is_enabled():
                                rot_targets = set(rotating_proxy_mgr.get_config().get("target_channel_ids") or [])
                                if (not rot_targets or item["channel_id"] in rot_targets) and item["channel_id"] not in rotating_active_cids:
                                    continue
                            ch_id = item["channel_id"]
                            s_id = item["id"]

                            # KIỂM TRA CHỈ TIÊU ĐĂNG TỐI ĐA TRONG NGÀY (MẶC ĐỊNH 3 VIDEO/NGÀY HOẶC THEO CÀI ĐẶT KÊNH)
                            max_daily = db.get_channel_max_daily_posts(ch_id, default=3)
                            posted_today = db.get_channel_today_posted_count(ch_id)
                            if posted_today >= max_daily:
                                try:
                                    cur_st = datetime.strptime(item.get("scheduled_time", ""), "%Y-%m-%d %H:%M:%S")
                                    new_st = (cur_st + timedelta(days=1)).strftime("%Y-%m-%d %H:%M:%S")
                                except Exception:
                                    new_st = (datetime.now() + timedelta(days=1)).strftime("%Y-%m-%d %H:%M:%S")
                                try:
                                    with db._get_connection() as conn:
                                        conn.cursor().execute(
                                            "UPDATE schedules SET scheduled_time = ?, status = 'pending', error_message = ? WHERE id = ?",
                                            (new_st, f"Đã đạt chỉ tiêu ngày ({posted_today}/{max_daily} video). Tự động dời sang {new_st}", s_id)
                                        )
                                        conn.commit()
                                    self._log(
                                        f"🛑 [ĐÃ ĐỦ CHỈ TIÊU NGÀY] Kênh '@{item.get('channel_name')}' đã đăng đủ {posted_today}/{max_daily} video hôm nay. "
                                        f"Tự động dừng đăng hôm nay & dời video sang {new_st}!"
                                    )
                                except Exception:
                                    pass
                                continue

                            # Đảm bảo 1 kênh chỉ mở 1 cửa sổ Profile tại 1 thời điểm, nhưng CÁC KÊNH KHÁC NHAU ĐƯỢC CHẠY ĐỒNG THỜI
                            if ch_id not in self._active_channels and s_id not in self._active_schedules:
                                if len(self._active_channels) + len(items_to_dispatch) < max_concurrent:
                                    self._active_channels.add(ch_id)
                                    self._active_schedules.add(s_id)
                                    try:
                                        db.update_schedule_status(s_id, "processing")
                                    except Exception:
                                        pass
                                    items_to_dispatch.append(item)

                    if items_to_dispatch:
                        self._log(f"🚀 [Đăng Đồng Loạt Hàng Loạt] Phát hiện {len(items_to_dispatch)} kênh đã đến giờ hẹn ➔ Bắt đầu tiến trình đăng đồng thời!")
                        for item in items_to_dispatch:
                            t = threading.Thread(target=self._execute_single_schedule, args=(item,), daemon=True)
                            t.start()

            except Exception as e:
                self._log(f"Lỗi kiểm tra lịch: {str(e)}")

            time.sleep(1.5)

    def _check_and_auto_refill_channels(self):
        """Quét các kênh có gắn link nguồn YouTube: nếu hết video hoặc còn <= 1 video -> Tự động nạp luôn vào Đám Mây TikTok"""
        if db.get_setting("auto_refill_youtube", "1") != "1":
            return

        try:
            channels = db.get_all_channels()
            now_ts = time.time()
            for ch in channels:
                cid = ch["id"]
                source_url = str(ch.get("youtube_source_url") or "").strip()
                if not source_url:
                    continue

                with self._lock:
                    if cid in self._active_refilling_channels:
                        continue

                # Nếu nguồn này vừa báo cạn video, nghỉ 5 phút trước khi thử lại
                if now_ts - self._refill_cooldowns.get(cid, 0) < 300:
                    continue

                # Đếm số lượng video còn lại trong lịch hẹn của kênh
                rem = db.get_channel_remaining_schedules_count(cid)
                # NGUYÊN TẮC: Chỉ lấy đúng 1 video để cắt, khi đăng xong TOÀN BỘ các tập (rem == 0) mới được lấy tiếp video mới
                if rem == 0:
                    with self._lock:
                        self._active_refilling_channels.add(cid)
                    t = threading.Thread(target=self._worker_auto_refill, args=(ch, rem), daemon=True)
                    t.start()
        except Exception as e:
            self._log(f"⚠️ Lỗi quét tự động nạp video: {e}")

    def _worker_auto_refill(self, ch: Dict[str, Any], rem: int):
        cid = ch["id"]
        ch_name = ch.get("name", f"Kênh #{cid}")
        source_url = ch["youtube_source_url"]
        self._refill_cooldowns[cid] = time.time()
        try:
            # KIỂM TRA CHẶT CHẼ: Kênh phải có đúng 0 video còn lại
            current_rem = db.get_channel_remaining_schedules_count(cid)
            if current_rem > 0:
                self._log(f"ℹ️ [Đang Có Series] Kênh '@{ch_name}' hiện còn {current_rem} tập đang chờ đăng. Tool tuân thủ nguyên tắc chỉ lấy 1 video để cắt, khi đăng hết toàn bộ mới lấy tiếp video mới!")
                return

            self._log(
                f"🔄 [Tự Động Nạp Nối Tiếp] Kênh '@{ch_name}' đã hoàn tất đăng toàn bộ các tập của video trước. "
                f"Tool bắt đầu lấy duy nhất 1 video mới phù hợp từ YouTube để cắt và xếp lịch!"
            )

            from core.youtube_pipeline import (
                fetch_best_youtube_video,
                download_youtube_video,
                auto_slice_and_edit_shorts,
                schedule_series_for_channel
            )
            import os

            # 1 & 2. Tìm và tải video công khai tiếp theo theo thứ tự (tự động bỏ qua video Hội viên/bị chặn)
            raw_dir = os.path.join(str(config.DATA_DIR / "videos" / "youtube_raw"), ch_name)
            download_res = None
            best_vid = None
            session_excluded = set()
            for _ in range(8):
                best_vid = fetch_best_youtube_video(source_url, cid, sort_mode="popular", log_func=self._log, exclude_ids=session_excluded)
                if not best_vid:
                    break

                yt_channel_name = best_vid.get("uploader_name", "")
                self._log(f"📥 [Tự Động Nạp] Đang tải video từ @{yt_channel_name}: '{best_vid['title'][:45]}...'")
                download_res = download_youtube_video(best_vid["url"], raw_dir, log_func=self._log)
                if download_res:
                    if yt_channel_name:
                        db.update_channel_youtube_source(cid, source_url, yt_channel_name)
                    break

                # Bỏ qua video bị lỗi/giới hạn trong phiên này, chuyển sang video tiếp theo
                self._log(f"⚠️ Video '{best_vid['title'][:35]}' không tải được hoặc bị giới hạn. Tự động chuyển video tiếp theo...")
                session_excluded.add(best_vid["id"])

            if not download_res or not best_vid:
                self._log(f"⚠️ [Tự Động Nạp] Không tìm thấy video công khai mới nào trên nguồn YouTube cho kênh '@{ch_name}'.")
                self._refill_cooldowns[cid] = time.time()
                return

            raw_file, original_title = download_res

            # 3. Cắt & render theo khung đã chọn
            shorts_dir = os.path.join(str(config.DATA_DIR / "videos"), ch_name)
            ch_info = db.get_channel(cid)
            channel_crop = (ch_info.get("crop_frame") if ch_info else "blur_9_16") or "blur_9_16"
            self._log(f"✂️ [Tự Động Nạp] Đang tự động cắt theo khung [{channel_crop}] thành các tập chuẩn giữ chân cho kênh '@{ch_name}'...")
            created_parts = auto_slice_and_edit_shorts(
                src_video_path=raw_file,
                output_dir=shorts_dir,
                target_parts=None,
                segment_duration=35,
                show_title=original_title,
                crop_mode=channel_crop,
                channel_id=cid,
                log_func=self._log
            )
            if not created_parts:
                return

            # 4. Lên lịch nối tiếp vào Đám Mây TikTok
            summary = schedule_series_for_channel(
                channel_id=cid,
                parts=created_parts,
                videos_per_day=2,
                golden_hours=["11:30", "19:30"],
                upload_mode="cloud",
                log_func=self._log
            )

            # 5. Lưu vết
            db.save_youtube_processed_video(
                channel_id=cid,
                youtube_video_id=best_vid["id"],
                title=original_title,
                view_count=best_vid.get("view_count", 0),
                duration=best_vid.get("duration", 0),
                parts_created=len(created_parts),
                source_url=source_url
            )

            count = summary.get("schedules_added", len(created_parts))
            total = summary.get("total_pending", count)
            today_cnt = summary.get("today_count", 0)
            end_date = summary.get("end_date_str", "")

            # 6. Báo cáo thông báo Telegram & Windows Toast ngay lập tức!
            from core.notifier import notifier
            msg_toast = f"Kênh '@{ch_name}' đã tự động nạp thêm {count} tập từ YouTube!\n☁️ Tổng kho: {total} video (Đến ngày {end_date})"
            notifier.notify("☁️ JL Tool - Tự Động Nạp Video Đám Mây", msg_toast, is_success=True)

            tg_msg = (
                f"🔄 <b>[TỰ ĐỘNG NẠP ĐẦY KHO VIDEO ĐÁM MÂY]</b>\n\n"
                f"📺 <b>Kênh TikTok:</b> <code>@{ch_name}</code>\n"
                f"🔗 <b>Kênh Nguồn YouTube:</b> <code>@{yt_channel_name}</code>\n"
                f"⚡ <b>Hành động:</b> Phát hiện kênh sắp hết video ➔ Tự động lấy và cắt nạp luôn không phải chờ!\n"
                f"✂️ <b>Số tập vừa tạo:</b> <b>{count} tập chuẩn 9:16</b>\n"
                f"📅 <b>Tần suất:</b> 2 video / ngày\n"
                f"📊 <b>Hôm nay:</b> {today_cnt} video\n"
                f"📦 <b>Tổng kho lịch hẹn:</b> <b>{total} video</b>\n"
                f"⏳ <b>Lịch đăng kéo dài đến:</b> <code>{end_date}</code>\n"
                f"☁️ <b>Trạng thái:</b> <i>Đã lưu vào Đám Mây TikTok, sẵn sàng đăng!</i>"
            )
            notifier.send_telegram_msg(tg_msg)
            self._log(f"🎉 [Tự Động Nạp Hoàn Tất] Kênh '@{ch_name}' đã có {total} video sẵn sàng trên Đám Mây TikTok đến ngày {end_date}!")

        except Exception as e:
            self._log(f"⚠️ [Tự Động Nạp Lỗi] Kênh '@{ch_name}': {e}")
        finally:
            with self._lock:
                self._active_refilling_channels.discard(cid)

scheduler_service = SchedulerService()
