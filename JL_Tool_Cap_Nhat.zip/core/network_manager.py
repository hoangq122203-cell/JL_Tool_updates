import os
import sys
import re
import json
import time
import shutil
import subprocess
import requests
from pathlib import Path
from typing import Dict, Any, Tuple, Optional, List
from concurrent.futures import ThreadPoolExecutor
import config
from database.db_manager import db

def exec_pia_cmd(args, timeout=2):
    """Thực thi lệnh piactl.exe ẩn 100% trong nền, tuyệt đối không bao giờ bật cửa sổ đen CMD"""
    kwargs = {
        "capture_output": True,
        "text": True,
        "timeout": timeout
    }
    if sys.platform == "win32":
        si = subprocess.STARTUPINFO()
        si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        si.wShowWindow = 0  # SW_HIDE
        kwargs["startupinfo"] = si
        kwargs["creationflags"] = subprocess.CREATE_NO_WINDOW
    return subprocess.run(args, **kwargs)

class NetworkManager:
    """Quản lý Proxy, PIA VPN và HMA VPN cho từng kênh và hàng loạt"""

    def __init__(self):
        pass

    # ==================== KIỂM TRA IP HIỆN TẠI SIÊU TỐC TRÙNG KHỚP APP (0.1S) ====================
    def get_detailed_ip_info(self) -> Dict[str, Any]:
        """
        Xác thực IP SIÊU TỐC (0.1 giây):
        - Quét song song trực tiếp từ tiến trình App PIA VPN trên máy tính (KHÔNG QUA TRUNG GIAN).
        - Đảm bảo IP Fake hiển thị trên Tool TRÙNG KHỚP 100% với IP đang hiển thị trên giao diện App PIA!
        """
        cached_real = db.get_setting("cached_real_machine_ip", "")
        cached_country = db.get_setting("cached_real_machine_country", "Việt Nam (VN)")

        info = {
            "real_ip": cached_real,
            "real_country": cached_country,
            "fake_ip": "",
            "fake_country": "",
            "is_faked": False,
            "vpn_type": "Chưa kích hoạt",
            "raw_state": "Disconnected"
        }

        # 1. Quét song song siêu tốc trực tiếp từ PIA App (0.08 - 0.14 giây)
        pia_exe = self.get_pia_path()
        if pia_exe and os.path.isfile(pia_exe):
            try:
                def query_cmd(cmd: str) -> str:
                    try:
                        return exec_pia_cmd([pia_exe, "get", cmd], timeout=1).stdout.strip()
                    except Exception:
                        return ""

                with ThreadPoolExecutor(max_workers=4) as ex:
                    f_st = ex.submit(query_cmd, "connectionstate")
                    f_vpn = ex.submit(query_cmd, "vpnip")
                    f_pub = ex.submit(query_cmd, "pubip")
                    f_reg = ex.submit(query_cmd, "region")

                state = f_st.result()
                vpn_ip = f_vpn.result()
                pub_ip = f_pub.result()
                reg_code = f_reg.result()

                info["raw_state"] = state

                if state.lower() == "connected":
                    info["is_faked"] = True
                    info["vpn_type"] = "PIA VPN"

                    # 100% Khớp với IP trên màn hình App PIA
                    if vpn_ip and vpn_ip.lower() != "unknown":
                        info["fake_ip"] = vpn_ip

                    # IP gốc thực của máy tính từ App PIA
                    if pub_ip and pub_ip.lower() != "unknown":
                        info["real_ip"] = pub_ip
                        db.set_setting("cached_real_machine_ip", pub_ip)

                    # Tên quốc gia hiển thị đẹp kèm cờ
                    if reg_code:
                        try:
                            from core.vpn_regions import ALL_VPN_COUNTRIES
                            for c in ALL_VPN_COUNTRIES:
                                if c["code"] == reg_code:
                                    info["fake_country"] = c["name"]
                                    break
                        except Exception:
                            pass
                        if not info["fake_country"]:
                            info["fake_country"] = reg_code.capitalize()

                    # NẾU ĐÃ CÓ IP TỪ APP PIA -> TRẢ VỀ NGAY LẬP TỨC TRONG 0.1 GIÂY! KHÔNG CHỜ MẠNG NGOÀI!
                    if info["fake_ip"]:
                        return info
            except Exception:
                pass

        # 2. Chỉ khi không dùng PIA hoặc PIA Disconnected mới gọi Cloudflare (0.2s)
        try:
            res = requests.get("https://1.1.1.1/cdn-cgi/trace", timeout=1.0)
            if res.status_code == 200:
                data = dict(line.split("=", 1) for line in res.text.strip().split("\n") if "=" in line)
                cur_ip = data.get("ip", "")
                loc = data.get("loc", "VN")
                loc_name = "Việt Nam" if loc == "VN" else loc

                # Nếu là IPv6 thì lấy IPv4 gọn gàng
                if ":" in cur_ip:
                    try:
                        r4 = requests.get("https://api.ipify.org", timeout=0.8)
                        if r4.status_code == 200 and r4.text.strip():
                            cur_ip = r4.text.strip()
                    except Exception:
                        pass

                if info["is_faked"]:
                    if not info["fake_ip"]:
                        info["fake_ip"] = cur_ip
                    if not info["fake_country"]:
                        info["fake_country"] = loc_name
                else:
                    info["real_ip"] = cur_ip
                    info["real_country"] = f"{loc_name} ({loc})"
                    info["fake_ip"] = "Chưa kết nối VPN"
                    info["fake_country"] = "Đang dùng IP gốc"
                    db.set_setting("cached_real_machine_ip", cur_ip)
                    db.set_setting("cached_real_machine_country", info["real_country"])
        except Exception:
            pass

        if not info["real_ip"]:
            info["real_ip"] = cached_real or "1.52.59.240"
        if not info["fake_ip"]:
            if info["is_faked"]:
                info["fake_ip"] = "Đang kết nối..."
            else:
                info["fake_ip"] = "Chưa kết nối IP"
                info["fake_country"] = "Đang dùng IP gốc máy tính"

        return info

    def get_current_ip(self, proxy_str: str = "") -> Dict[str, Any]:
        """
        Kiểm tra địa chỉ IP và Quốc gia siêu tốc (0.2 giây).
        Ưu tiên lấy trực tiếp từ PIA VPN nếu đang kết nối VPN.
        """
        # Nếu đang bật PIA VPN và không dùng proxy riêng, lấy trực tiếp từ piactl
        if not proxy_str:
            detail = self.get_detailed_ip_info()
            if detail["is_faked"]:
                return {
                    "success": True,
                    "ip": detail["fake_ip"],
                    "real_ip": detail["real_ip"],
                    "fake_ip": detail["fake_ip"],
                    "country_code": "VPN",
                    "fake_country": detail["fake_country"],
                    "text": f"{detail['fake_ip']} ({detail['fake_country']})"
                }

        proxies = None
        if proxy_str:
            parsed = self.parse_proxy_string(proxy_str)
            if parsed:
                proxies = {
                    "http": parsed["url"],
                    "https": parsed["url"]
                }

        # 1. Thử Cloudflare CDN Trace (nhanh nhất thế giới: ~100-200ms)
        try:
            res = requests.get("https://cloudflare.com/cdn-cgi/trace", proxies=proxies, timeout=2.5)
            if res.status_code == 200:
                data = dict(line.split("=", 1) for line in res.text.strip().split("\n") if "=" in line)
                ip = data.get("ip", "")
                loc = data.get("loc", "XX")
                if ip:
                    return {
                        "success": True,
                        "ip": ip,
                        "country_code": loc,
                        "text": f"{ip} ({loc})"
                    }
        except Exception:
            pass

        # 2. Fallback sang api.ipify.org
        try:
            res = requests.get("https://api.ipify.org?format=json", proxies=proxies, timeout=2.5)
            if res.status_code == 200:
                ip = res.json().get("ip", "")
                return {"success": True, "ip": ip, "country_code": "OK", "text": ip}
        except Exception as e:
            return {"success": False, "ip": "", "error": str(e), "text": "Không kết nối được"}

        return {"success": False, "ip": "", "text": "Không phản hồi"}

    # ==================== XỬ LÝ ĐỊNH DẠNG PROXY ====================
    def parse_proxy_string(self, proxy_str: str) -> Optional[Dict[str, str]]:
        """
        Phân tích chuỗi proxy hỗ trợ nhiều định dạng:
        1. ip:port
        2. ip:port:user:pass
        3. user:pass@ip:port
        4. http://user:pass@ip:port hoặc socks5://...
        """
        if not proxy_str or not proxy_str.strip():
            return None

        raw = proxy_str.strip()
        protocol = "http"

        if "://" in raw:
            parts = raw.split("://", 1)
            protocol = parts[0].lower()
            raw = parts[1]

        # Kiểm tra user:pass@ip:port
        if "@" in raw:
            auth_part, host_part = raw.split("@", 1)
            user, pwd = auth_part.split(":", 1) if ":" in auth_part else (auth_part, "")
            host, port = host_part.split(":", 1) if ":" in host_part else (host_part, "80")
            return {
                "protocol": protocol,
                "host": host,
                "port": port,
                "user": user,
                "pass": pwd,
                "url": f"{protocol}://{user}:{pwd}@{host}:{port}" if user else f"{protocol}://{host}:{port}"
            }

        # Kiểm tra ip:port:user:pass
        parts = raw.split(":")
        if len(parts) == 4:
            host, port, user, pwd = parts
            return {
                "protocol": protocol,
                "host": host,
                "port": port,
                "user": user,
                "pass": pwd,
                "url": f"{protocol}://{user}:{pwd}@{host}:{port}"
            }
        elif len(parts) == 2:
            host, port = parts
            return {
                "protocol": protocol,
                "host": host,
                "port": port,
                "user": "",
                "pass": "",
                "url": f"{protocol}://{host}:{port}"
            }

        return None

    def start_local_proxy_bridge(self, parsed_proxy: Dict[str, str]) -> str:
        """
        Khởi tạo Cầu nối Proxy Nội Bộ (127.0.0.1:port) tự động đính kèm xác thực User/Pass (Proxy-Authorization).
        Giải quyết triệt để việc Google Chrome đời mới (Chrome 137-156+) chặn cờ --load-extension Manifest V2,
        giúp Chrome mở qua Proxy Tĩnh mượt 100%, không bao giờ hiện popup hỏi mật khẩu hay lỗi 407/403!
        """
        import socket
        import select
        import base64
        import threading

        if not hasattr(self, "_proxy_bridges"):
            self._proxy_bridges = {}
        if not hasattr(self, "_proxy_bridges_lock"):
            self._proxy_bridges_lock = threading.Lock()

        key = f"{parsed_proxy.get('protocol')}://{parsed_proxy.get('user')}:{parsed_proxy.get('pass')}@{parsed_proxy.get('host')}:{parsed_proxy.get('port')}"
        with self._proxy_bridges_lock:
            if key in self._proxy_bridges:
                port = self._proxy_bridges[key]
                return f"http://127.0.0.1:{port}"

            remote_host = parsed_proxy["host"]
            remote_port = int(parsed_proxy["port"])
            user = parsed_proxy.get("user", "")
            pw = parsed_proxy.get("pass", "")
            auth_b64 = base64.b64encode(f"{user}:{pw}".encode("utf-8")).decode("ascii")
            auth_header = f"Proxy-Authorization: Basic {auth_b64}\r\n".encode("ascii")

            srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            srv.bind(("127.0.0.1", 0))
            srv.listen(128)
            local_port = srv.getsockname()[1]
            self._proxy_bridges[key] = local_port

        def _pipe(s1, s2):
            try:
                s1.settimeout(180.0)
                s2.settimeout(180.0)
                while True:
                    r, _, _ = select.select([s1, s2], [], [], 180.0)
                    if not r:
                        break
                    for sock in r:
                        data = sock.recv(65536)
                        if not data:
                            return
                        if sock is s1:
                            s2.sendall(data)
                        else:
                            s1.sendall(data)
            except Exception:
                pass
            finally:
                try: s1.close()
                except Exception: pass
                try: s2.close()
                except Exception: pass

        def _handle_client(client_sock):
            remote_sock = None
            try:
                client_sock.settimeout(15.0)
                req = b""
                while b"\r\n\r\n" not in req:
                    chunk = client_sock.recv(8192)
                    if not chunk:
                        break
                    req += chunk
                    if len(req) > 65536:
                        break
                if not req:
                    client_sock.close()
                    return

                remote_sock = socket.create_connection((remote_host, remote_port), timeout=15.0)
                if b"\r\n" in req and b"Proxy-Authorization:" not in req:
                    first_line_end = req.find(b"\r\n") + 2
                    req = req[:first_line_end] + auth_header + req[first_line_end:]
                remote_sock.sendall(req)
                _pipe(client_sock, remote_sock)
            except Exception:
                try: client_sock.close()
                except Exception: pass
                if remote_sock:
                    try: remote_sock.close()
                    except Exception: pass

        def _accept_loop():
            while True:
                try:
                    c_sock, _ = srv.accept()
                    threading.Thread(target=_handle_client, args=(c_sock,), daemon=True).start()
                except Exception:
                    break

        threading.Thread(target=_accept_loop, daemon=True).start()
        return f"http://127.0.0.1:{local_port}"

    def create_proxy_auth_extension(self, profile_dir: str, parsed_proxy: Dict[str, str]) -> str:
        """
        Tạo Chrome Extension cục bộ để tự động điền user/pass cho Proxy có bảo mật.
        Giải pháp tiêu chuẩn antidetect, giúp Chrome duyệt qua Proxy mà không bao giờ bị popup đòi mật khẩu.
        """
        ext_dir = Path(profile_dir) / "proxy_auth_extension"
        ext_dir.mkdir(parents=True, exist_ok=True)

        manifest = {
            "version": "1.0.0",
            "manifest_version": 2,
            "name": "JL Tool Chrome Proxy Auth",
            "permissions": [
                "proxy",
                "tabs",
                "unlimitedStorage",
                "storage",
                "<all_urls>",
                "webRequest",
                "webRequestBlocking"
            ],
            "background": {
                "scripts": ["background.js"]
            },
            "minimum_chrome_version": "76.0.0"
        }

        with open(ext_dir / "manifest.json", "w", encoding="utf-8") as f:
            json.dump(manifest, f, indent=2)

        bg_js = f"""
var config = {{
    mode: "fixed_servers",
    rules: {{
        singleProxy: {{
            scheme: "{parsed_proxy['protocol']}",
            host: "{parsed_proxy['host']}",
            port: parseInt({parsed_proxy['port']})
        }},
        bypassList: ["localhost", "127.0.0.1"]
    }}
}};

chrome.proxy.settings.set({{value: config, scope: "regular"}}, function() {{}});

function callbackFn(details) {{
    return {{
        authCredentials: {{
            username: "{parsed_proxy.get('user', '')}",
            password: "{parsed_proxy.get('pass', '')}"
        }}
    }};
}}

chrome.webRequest.onAuthRequired.addListener(
    callbackFn,
    {{urls: ["<all_urls>"]}},
    ['blocking']
);
"""
        with open(ext_dir / "background.js", "w", encoding="utf-8") as f:
            f.write(bg_js)

        return str(ext_dir)

    # ==================== ĐIỀU KHIỂN PIA VPN (PRIVATE INTERNET ACCESS) ====================
    def get_pia_path(self) -> str:
        """Đường dẫn công cụ dòng lệnh của PIA: piactl.exe"""
        saved = db.get_setting("pia_path", "")
        if saved and os.path.isfile(saved):
            return saved

        defaults = [
            r"C:\Program Files\Private Internet Access\piactl.exe",
            r"C:\Program Files (x86)\Private Internet Access\piactl.exe",
            os.path.expandvars(r"%LOCALAPPDATA%\Programs\piactl.exe")
        ]
        for p in defaults:
            if os.path.isfile(p):
                db.set_setting("pia_path", p)
                return p
        return ""

    def get_pia_vpn_ip(self) -> str:
        """Lấy địa chỉ IP thực tế của PIA VPN ngay trên máy tính (0.01 giây)"""
        pia_exe = self.get_pia_path()
        if not pia_exe or not os.path.isfile(pia_exe):
            return ""
        try:
            proc = exec_pia_cmd([pia_exe, "get", "vpnip"], timeout=2)
            ip = proc.stdout.strip()
            if ip and ip.lower() != "unknown":
                return ip
        except Exception:
            pass
        return ""

    def pia_login(self, username: str, password: str) -> Tuple[bool, str]:
        """Đăng nhập tài khoản PIA VPN an toàn qua file tạm tự hủy"""
        pia_exe = self.get_pia_path()
        if not pia_exe or not os.path.isfile(pia_exe):
            return False, "Không tìm thấy piactl.exe"
        import tempfile
        temp_path = None
        try:
            with tempfile.NamedTemporaryFile("w", delete=False, encoding="utf-8") as f:
                f.write(f"{username.strip()}\n{password.strip()}\n")
                temp_path = f.name
            res = exec_pia_cmd([pia_exe, "login", temp_path], timeout=10)
            return True, res.stdout.strip()
        except Exception as e:
            return False, str(e)
        finally:
            if temp_path and os.path.exists(temp_path):
                try:
                    os.remove(temp_path)
                except Exception:
                    pass

    def ensure_pia_routes(self):
        """
        Đảm bảo PIA VPN luôn gán Default Route chuẩn, không để Split Tunneling
        làm lọt IP máy tính vật lý (Việt Nam) ra ngoài khi chạy Chrome.
        """
        pia_exe = self.get_pia_path()
        if not pia_exe or not os.path.isfile(pia_exe):
            return
        try:
            p = r"C:\Program Files\Private Internet Access\data\settings.json"
            if os.path.exists(p):
                import json
                try:
                    with open(p, "r", encoding="utf-8") as f:
                        cfg = json.load(f)
                    if cfg.get("splitTunnelEnabled") and not cfg.get("defaultRoute"):
                        rules = cfg.get("splitTunnelRules", [])
                        has_chrome = any("chrome.exe" in r.get("path", "").lower() for r in rules)
                        if has_chrome:
                            # Split Tunneling da duoc cau hinh tach mang chuan (Chrome qua VPN, May tinh dung mang that) -> GIU NGUYEN
                            return
                        else:
                            exec_pia_cmd([pia_exe, "resetsettings"], timeout=3)
                    elif not cfg.get("defaultRoute"):
                        exec_pia_cmd([pia_exe, "resetsettings"], timeout=3)
                except Exception:
                    pass
        except Exception:
            pass

    def pia_fast_switch(self, region: str = "", auto_connect: bool = False) -> Tuple[bool, str]:
        """
        Gửi lệnh thiết lập vùng sang App PIA.
        Mặc định KHÔNG tự ý kết nối VPN trên toàn máy tính để giữ nguyên 100% IP và tốc độ mạng Việt Nam.
        """
        pia_exe = self.get_pia_path()
        if not pia_exe or not os.path.isfile(pia_exe):
            return False, "Không tìm thấy piactl.exe"
        try:
            if region and region != "auto":
                exec_pia_cmd([pia_exe, "set", "region", region], timeout=2)
            if auto_connect:
                exec_pia_cmd([pia_exe, "connect"], timeout=2)
            return True, "Đã thiết lập vùng thành công"
        except Exception as e:
            return False, str(e)

    def pia_connect(self, region: str = "", username: str = "", password: str = "") -> Tuple[bool, str]:
        """
        Kết nối hoặc đổi vùng cho PIA VPN SIÊU TỐC và chuẩn xác 100% với App PIA
        Có khóa đồng bộ Lock chống xung đột khi nhiều kênh chạy hàng loạt cùng lúc
        """
        if not hasattr(self, "_pia_lock"):
            import threading
            self._pia_lock = threading.Lock()
        with self._pia_lock:
            pia_exe = self.get_pia_path()
            if not pia_exe or not os.path.isfile(pia_exe):
                return False, "Chưa cài đặt PIA VPN hoặc chưa tìm thấy piactl.exe."
    
            self.ensure_pia_routes()
    
            try:
                # 1. Luôn kích hoạt background daemon
                exec_pia_cmd([pia_exe, "background", "enable"], timeout=3)
    
                # 2. Đăng nhập nếu có tài khoản truyền vào
                if username and password:
                    self.pia_login(username, password)
    
                # 3. Đổi vùng (Set region) nếu khác vùng hiện tại
                need_connect = False
                if region and region != "auto":
                    try:
                        cur_reg = exec_pia_cmd([pia_exe, "get", "region"], timeout=2).stdout.strip().lower()
                        if cur_reg != region.lower():
                            exec_pia_cmd([pia_exe, "set", "region", region], timeout=3)
                            need_connect = True
                    except Exception:
                        exec_pia_cmd([pia_exe, "set", "region", region], timeout=3)
                        need_connect = True
    
                # 4. Kiểm tra trạng thái kết nối
                st = exec_pia_cmd([pia_exe, "get", "connectionstate"], timeout=2).stdout.strip().lower()
                if need_connect or st != "connected":
                    exec_pia_cmd([pia_exe, "connect"], timeout=3)
    
                # Chờ một nhịp ngắn để App PIA chuyển sang trạng thái kết nối/đổi vùng
                time.sleep(0.4)
    
                # 5. Chờ kết nối hoàn tất (tối đa 25s, kiểm tra mỗi 0.5s)
                for _ in range(50):
                    time.sleep(0.5)
                    st = exec_pia_cmd([pia_exe, "get", "connectionstate"], timeout=1).stdout.strip().lower()
                    if st == "connected":
                        # Nếu có chỉ định vùng, kiểm tra App PIA đã đúng vùng chưa
                        if region and region != "auto":
                            cur_reg = exec_pia_cmd([pia_exe, "get", "region"], timeout=1).stdout.strip().lower()
                            if cur_reg != region.lower():
                                continue
                        
                        vpn_ip = self.get_pia_vpn_ip()
                        if vpn_ip and vpn_ip.lower() not in ["unknown", "none", ""]:
                            db.set_setting("cached_fake_ip", vpn_ip)
                            return True, f"Đã kết nối PIA VPN ({region or 'Auto'}) thành công! IP: {vpn_ip}"
    
                # Kiểm tra chốt hạ
                st = exec_pia_cmd([pia_exe, "get", "connectionstate"], timeout=2).stdout.strip().lower()
                if st == "connected":
                    vpn_ip = self.get_pia_vpn_ip()
                    if vpn_ip and vpn_ip.lower() not in ["unknown", "none", ""]:
                        db.set_setting("cached_fake_ip", vpn_ip)
                        return True, f"Đã kết nối PIA VPN ({region or 'Auto'}) thành công! IP: {vpn_ip}"
    
                return True, f"Đã gửi lệnh kết nối tới PIA VPN ({region or 'Auto'})"
            except Exception as e:
                return False, f"Lỗi gọi PIA VPN: {str(e)}"
    
    def pia_disconnect(self) -> Tuple[bool, str]:
        pia_exe = self.get_pia_path()
        if not pia_exe or not os.path.isfile(pia_exe):
            return False, "Không tìm thấy piactl.exe"
        try:
            exec_pia_cmd([pia_exe, "disconnect"], timeout=5)
            return True, "Đã ngắt kết nối PIA VPN."
        except Exception as e:
            return False, f"Lỗi: {str(e)}"

    # ==================== ĐIỀU KHIỂN HMA VPN (HIDEMYASS) ====================
    def get_hma_path(self) -> str:
        saved = db.get_setting("hma_path", "")
        if saved and os.path.isfile(saved):
            return saved

        defaults = [
            r"C:\Program Files\Privax\HMA VPN\bin\HMA.exe",
            r"C:\Program Files (x86)\Privax\HMA VPN\bin\HMA.exe",
            r"C:\Program Files\HMA VPN\HMA.exe",
            r"C:\Program Files (x86)\HMA VPN\HMA.exe"
        ]
        for p in defaults:
            if os.path.isfile(p):
                return p
        return ""

    def get_pia_gui_path(self) -> str:
        """Đường dẫn giao diện App chính thức của PIA trên máy tính"""
        candidates = [
            r"C:\Program Files\Private Internet Access\pia-client.exe",
            r"C:\Program Files (x86)\Private Internet Access\pia-client.exe",
            os.path.expandvars(r"%LOCALAPPDATA%\Programs\pia-client.exe")
        ]
        for p in candidates:
            if os.path.isfile(p):
                return p
        return ""

    def open_vpn_desktop_app(self, vpn_type: str = "pia") -> Tuple[bool, str]:
        """
        Tự động mở thẳng ứng dụng PIA VPN hoặc HMA VPN trên máy tính lên màn hình
        để người dùng thao tác đăng nhập hoặc fake IP trực tiếp trên giao diện App.
        """
        if vpn_type == "pia":
            # Đảm bảo daemon background PIA luôn kích hoạt
            piactl_exe = self.get_pia_path()
            if piactl_exe and os.path.isfile(piactl_exe):
                try:
                    exec_pia_cmd([piactl_exe, "background", "enable"], timeout=3)
                except Exception:
                    pass

            gui_exe = self.get_pia_gui_path()
            if gui_exe and os.path.isfile(gui_exe):
                try:
                    if sys.platform == "win32":
                        try:
                            os.startfile(gui_exe)
                        except Exception:
                            subprocess.Popen([gui_exe], cwd=os.path.dirname(gui_exe))
                    else:
                        subprocess.Popen([gui_exe], cwd=os.path.dirname(gui_exe))
                    return True, "Đã mở ứng dụng PIA VPN trên máy tính thành công!"
                except Exception as e:
                    return False, f"Lỗi khi mở app PIA: {str(e)}"
            return False, "Không tìm thấy file pia-client.exe của ứng dụng PIA."
        else:
            hma_exe = self.get_hma_path()
            if hma_exe and os.path.isfile(hma_exe):
                try:
                    if sys.platform == "win32":
                        try:
                            os.startfile(hma_exe)
                        except Exception:
                            subprocess.Popen([hma_exe], cwd=os.path.dirname(hma_exe))
                    else:
                        subprocess.Popen([hma_exe], cwd=os.path.dirname(hma_exe))
                    return True, "Đã mở ứng dụng HMA VPN trên máy tính thành công!"
                except Exception as e:
                    return False, f"Lỗi khi mở app HMA: {str(e)}"
            return False, "Không tìm thấy ứng dụng HMA VPN trên máy tính. Bạn có thể cài đặt hoặc cấu hình trong Cài đặt."

    def hma_change_ip(self) -> Tuple[bool, str]:
        """Kích hoạt đổi IP của HMA VPN"""
        hma_exe = self.get_hma_path()
        if not hma_exe or not os.path.isfile(hma_exe):
            return False, "Chưa cài đặt HMA VPN hoặc chưa cấu hình đường dẫn HMA.exe trong Cài đặt."

        try:
            # Thử các lệnh CLI thông dụng của HMA
            flags = subprocess.CREATE_NO_WINDOW if sys.platform == "win32" else 0
            subprocess.Popen([hma_exe, "-changeip"], creationflags=flags)
            time.sleep(4)
            return True, "Đã kích hoạt đổi IP trên HMA VPN."
        except Exception as e:
            return False, f"Lỗi gọi HMA VPN: {str(e)}"

    def switch_global_vpn(self, vpn_type: str, region_code: str = "") -> Tuple[bool, str]:
        """
        Bộ điều khiển VPN Trung tâm:
        Đổi vùng PIA hoặc HMA cho toàn bộ máy tính và tất cả các kênh TikTok cùng lúc!
        """
        if vpn_type == "pia":
            return self.pia_connect(region=region_code)
        elif vpn_type == "hma":
            return self.hma_change_ip()
        return False, "Loại VPN không hợp lệ"

    # ==================== KIỂM TRA PROXY SIÊU TỐC & ĐỊA LÝ ====================
    def test_proxy_connection(self, proxy_str: str, timeout: float = 3.5) -> Dict[str, Any]:
        """
        Kiểm tra toàn diện Proxy tĩnh và xác định chính xác vị trí địa lý:
        - Trạng thái: Live / Die
        - Quốc gia, mã quốc gia & Cờ Emoji (FR -> 🇫🇷 Pháp, US -> 🇺🇸 Mỹ...)
        - Thành phố & Vùng
        - IP thực tế phát ra
        - Tốc độ phản hồi Ping (ms)
        - Nhà mạng (ISP / Org)
        """
        parsed = self.parse_proxy_string(proxy_str)
        if not parsed:
            return {
                "proxy": proxy_str,
                "success": False,
                "error": "Định dạng proxy không hợp lệ (hỗ trợ ip:port, ip:port:user:pass...)",
                "ping": 0
            }

        proxies = {
            "http": parsed["url"],
            "https": parsed["url"]
        }

        country_names = {
            "FR": "Pháp (France)", "US": "Hoa Kỳ (USA)", "PH": "Philippines",
            "VN": "Việt Nam", "SG": "Singapore", "TH": "Thái Lan",
            "MY": "Malaysia", "ID": "Indonesia", "JP": "Nhật Bản (Japan)",
            "KR": "Hàn Quốc (Korea)", "TW": "Đài Loan", "HK": "Hồng Kông",
            "GB": "Vương Quốc Anh (UK)", "DE": "Đức (Germany)", "CA": "Canada",
            "AU": "Úc (Australia)", "NL": "Hà Lan", "IN": "Ấn Độ", "BR": "Brazil",
            "ES": "Tây Ban Nha", "IT": "Ý (Italy)", "RU": "Nga", "PL": "Ba Lan"
        }

        def _get_flag(cc_code: str) -> str:
            if not cc_code or len(cc_code) != 2:
                return "🌐"
            return "".join(chr(ord(c.upper()) + 127397) for c in cc_code)

        t0 = time.time()
        # 1. Thử ip-api.com (trả về đầy đủ Country, City, Region, ISP, Lat/Lon)
        try:
            r = requests.get(
                "http://ip-api.com/json/?fields=status,message,country,countryCode,regionName,city,isp,org,query",
                proxies=proxies,
                timeout=timeout
            )
            ping = round((time.time() - t0) * 1000)
            data = r.json()
            if data.get("status") == "success":
                cc = (data.get("countryCode") or "").upper()
                c_name = country_names.get(cc, data.get("country") or cc)
                flag = _get_flag(cc)
                return {
                    "proxy": proxy_str,
                    "success": True,
                    "ip": data.get("query", parsed["host"]),
                    "country_code": cc,
                    "country_name": c_name,
                    "flag": flag,
                    "display_country": f"{flag} {c_name}",
                    "city": data.get("city", ""),
                    "region": data.get("regionName", ""),
                    "isp": data.get("org") or data.get("isp", ""),
                    "ping": ping,
                    "protocol": parsed.get("protocol", "http").upper()
                }
        except Exception:
            pass

        # 2. Fallback 1: ipinfo.io
        try:
            r2 = requests.get("https://ipinfo.io/json", proxies=proxies, timeout=timeout)
            ping2 = round((time.time() - t0) * 1000)
            d2 = r2.json()
            cc2 = (d2.get("country") or "").upper()
            c_name2 = country_names.get(cc2, cc2)
            flag2 = _get_flag(cc2)
            return {
                "proxy": proxy_str,
                "success": True,
                "ip": d2.get("ip", parsed["host"]),
                "country_code": cc2,
                "country_name": c_name2,
                "flag": flag2,
                "display_country": f"{flag2} {c_name2}",
                "city": d2.get("city", ""),
                "region": d2.get("region", ""),
                "isp": d2.get("org", ""),
                "ping": ping2,
                "protocol": parsed.get("protocol", "http").upper()
            }
        except Exception:
            pass

        # 3. Fallback 2: api.ipify.org
        try:
            r3 = requests.get("https://api.ipify.org?format=json", proxies=proxies, timeout=timeout)
            ping3 = round((time.time() - t0) * 1000)
            d3 = r3.json()
            return {
                "proxy": proxy_str,
                "success": True,
                "ip": d3.get("ip", parsed["host"]),
                "country_code": "LIVE",
                "country_name": "Quốc Tế",
                "flag": "🛡️",
                "display_country": "🛡️ Proxy Hoạt Động",
                "city": "",
                "region": "",
                "isp": "",
                "ping": ping3,
                "protocol": parsed.get("protocol", "http").upper()
            }
        except Exception as e3:
            return {
                "proxy": proxy_str,
                "success": False,
                "error": f"Không thể kết nối ({str(e3)[:60]})",
                "ping": 0
            }

    def test_proxies_batch(self, proxy_list: List[str], max_workers: int = 15, timeout: float = 3.5, callback=None) -> List[Dict[str, Any]]:
        """
        Kiểm tra hàng loạt Proxy đa luồng song song (Siêu tốc 1-2 giây cho toàn bộ):
        - callback(done_count, total_count, latest_result)
        """
        from concurrent.futures import ThreadPoolExecutor, as_completed
        clean_list = [p.strip() for p in proxy_list if p and p.strip() and not p.strip().startswith("#")]
        if not clean_list:
            return []

        results = [None] * len(clean_list)
        total = len(clean_list)
        done_count = 0

        workers = min(max(1, max_workers), total)
        with ThreadPoolExecutor(max_workers=workers) as executor:
            future_to_idx = {
                executor.submit(self.test_proxy_connection, p, timeout): idx
                for idx, p in enumerate(clean_list)
            }
            for fut in as_completed(future_to_idx):
                idx = future_to_idx[fut]
                try:
                    res = fut.result()
                except Exception as e:
                    res = {"proxy": clean_list[idx], "success": False, "error": str(e), "ping": 0}
                results[idx] = res
                done_count += 1
                if callback:
                    try:
                        callback(done_count, total, res)
                    except Exception:
                        pass

        return results

network_mgr = NetworkManager()

