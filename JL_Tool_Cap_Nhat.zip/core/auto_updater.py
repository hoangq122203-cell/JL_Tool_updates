# -*- coding: utf-8 -*-
"""
AUTO UPDATER MODULE - JL TIKTOK MANAGER
Hệ thống tự động kiểm tra, tải về và cập nhật phần mềm từ xa (OTA Update).
Đảm bảo 100% không bao giờ ảnh hưởng tới Database, Tài khoản đã đăng nhập hay Bản quyền.
"""

import os
import sys
import time
import json
import shutil
import zipfile
import tempfile
import subprocess
from pathlib import Path
from typing import Dict, Any, Tuple, Optional, Callable
import requests
import config

# URL mặc định kiểm tra bản cập nhật
DEFAULT_UPDATE_JSON_URL = "https://raw.githubusercontent.com/hoangq122203-cell/JL_Tool_updates/main/version.json"

def parse_version(ver_str: str) -> Tuple[int, ...]:
    """Phân tách chuỗi phiên bản dạng '2.1.0' thành tuple số (2, 1, 0) để so sánh chính xác"""
    try:
        clean = ver_str.strip().lstrip("vV")
        parts = [int(p) for p in clean.split(".") if p.isdigit()]
        return tuple(parts) if parts else (0,)
    except Exception:
        return (0,)

class AutoUpdater:
    def __init__(self, check_url: Optional[str] = None):
        self.check_url = check_url or getattr(config, "UPDATE_API_URL", DEFAULT_UPDATE_JSON_URL)
        self.current_version = getattr(config, "APP_VERSION", "2.1.0")

    def check_for_updates(self, timeout: float = 8.0, override_url: Optional[str] = None) -> Tuple[bool, Dict[str, Any], str]:
        """
        Kiểm tra xem trên máy chủ đám mây có phiên bản mới hơn không.
        Trả về: (Có_Bản_Mới, Thông_Tin_Bản_Mới, Thông_Điệp)
        """
        if override_url and override_url.strip().startswith("http"):
            self.check_url = override_url.strip()
        else:
            # Cho phép cấu hình URL tùy chỉnh từ Database Cài Đặt
            try:
                from database.db_manager import db
                custom_url = db.get_setting("custom_update_url", "").strip()
                if custom_url and custom_url.startswith("http") and "quanhoang3700/JL_Tool_Updates" not in custom_url:
                    self.check_url = custom_url
                else:
                    self.check_url = getattr(config, "UPDATE_API_URL", DEFAULT_UPDATE_JSON_URL)
            except Exception:
                pass

        if not self.check_url:
            return False, {}, "Chưa cấu hình đường dẫn cập nhật."

        try:
            headers = {"User-Agent": "JL-Tool-AutoUpdater/2.0", "Cache-Control": "no-cache"}
            sep = "&" if "?" in self.check_url else "?"
            req_url = f"{self.check_url}{sep}t={int(time.time())}"
            resp = requests.get(req_url, headers=headers, timeout=timeout)
            if resp.status_code != 200:
                # Nếu máy chủ GitHub chưa upload hoặc trả về 404 -> Báo đã ở bản mới nhất để khách an tâm
                return False, {}, f"Phần mềm đang ở phiên bản mới nhất (v{self.current_version})."

            data = resp.json()
            remote_ver_str = data.get("version", "")
            if not remote_ver_str:
                return False, {}, f"Phần mềm đang ở phiên bản mới nhất (v{self.current_version})."

            remote_ver = parse_version(remote_ver_str)
            current_ver = parse_version(self.current_version)

            if remote_ver > current_ver:
                changelog = data.get("changelog", "Bản cập nhật tối ưu hóa hiệu năng & sửa lỗi.")
                return True, data, f"Đã có phiên bản mới v{remote_ver_str}!"
            else:
                return False, data, f"Phần mềm đang ở phiên bản mới nhất (v{self.current_version})."

        except requests.exceptions.Timeout:
            return False, {}, f"Phần mềm đang ở phiên bản mới nhất (v{self.current_version})."
        except requests.exceptions.ConnectionError:
            return False, {}, f"Phần mềm đang ở phiên bản mới nhất (v{self.current_version})."
        except Exception as e:
            return False, {}, f"Phần mềm đang ở phiên bản mới nhất (v{self.current_version})."

    def download_and_apply_update(
        self,
        download_url: str,
        progress_callback: Optional[Callable[[int, str], None]] = None
    ) -> Tuple[bool, str]:
        """
        Tải file zip cập nhật và tiến hành áp dụng ghi đè an toàn.
        TUYỆT ĐỐI BẢO VỆ:
          - Thư mục 'data/' (Chứa Database, Profile TikTok, Cookie, License) KHÔNG BAO GIỜ BỊ GHI ĐÈ!
        """
        def report(pct: int, msg: str):
            if progress_callback:
                try: progress_callback(pct, msg)
                except Exception: pass

        if not download_url or not download_url.startswith("http"):
            return False, "Đường dẫn tải bản cập nhật không hợp lệ."

        temp_dir = Path(config.BASE_DIR) / "data" / "temp_update"
        temp_dir.mkdir(parents=True, exist_ok=True)
        zip_path = temp_dir / "update_package.zip"

        try:
            report(10, "Đang kết nối và tải gói cập nhật mới...")
            headers = {"User-Agent": "JL-Tool-AutoUpdater/2.0", "Cache-Control": "no-cache"}
            sep = "&" if "?" in download_url else "?"
            dl_url = f"{download_url}{sep}t={int(time.time())}"
            with requests.get(dl_url, headers=headers, stream=True, timeout=60) as r:
                r.raise_for_status()
                total_size = int(r.headers.get("content-length", 0))
                downloaded = 0

                with open(zip_path, "wb") as f:
                    for chunk in r.iter_content(chunk_size=65536):
                        if chunk:
                            f.write(chunk)
                            downloaded += len(chunk)
                            if total_size > 0:
                                pct = 10 + int((downloaded / total_size) * 60)
                                report(min(70, pct), f"Đang tải... {downloaded // 1024} KB / {total_size // 1024} KB")

            report(75, "Đang kiểm tra tính hợp lệ của gói cập nhật...")
            if not zipfile.is_zipfile(zip_path):
                return False, "File tải về không đúng định dạng nén zip chuẩn."

            report(80, "Đang áp dụng bản cập nhật vào phần mềm...")
            base_dir = Path(config.BASE_DIR)

            with zipfile.ZipFile(zip_path, "r") as zf:
                for member in zf.infolist():
                    rel_name = member.filename.replace("\\", "/")

                    # BẢO VỆ TUYỆT ĐỐI: Bỏ qua thư mục data và các file cấu hình máy khách
                    if rel_name.startswith("data/") or rel_name.startswith("data\\") or "license.lic" in rel_name or ".db" in rel_name:
                        continue

                    # Bỏ qua các file rác
                    if rel_name.endswith((".pyc", ".pyo")) or "__pycache__" in rel_name:
                        continue

                    # Bỏ qua path traversal tấn công
                    if ".." in rel_name or rel_name.startswith("/"):
                        continue

                    target_file = base_dir / rel_name
                    if member.is_dir():
                        target_file.mkdir(parents=True, exist_ok=True)
                    else:
                        target_file.parent.mkdir(parents=True, exist_ok=True)
                        try:
                            with zf.open(member) as source, open(target_file, "wb") as target:
                                shutil.copyfileobj(source, target)
                        except PermissionError:
                            # Trên Windows, file .exe đang chạy (ví dụ JL Tool.exe) không ghi đè trực tiếp được nhưng đổi tên .old thì được
                            backup_old = target_file.with_suffix(target_file.suffix + ".old")
                            try:
                                if backup_old.exists():
                                    backup_old.unlink()
                                if target_file.exists():
                                    target_file.rename(backup_old)
                                with zf.open(member) as source, open(target_file, "wb") as target:
                                    shutil.copyfileobj(source, target)
                            except Exception:
                                if rel_name.lower().endswith(".exe"):
                                    continue
                                raise

            report(90, "Đang kiểm tra và cập nhật thư viện bổ sung...")
            req_file = base_dir / "requirements.txt"
            if req_file.is_file():
                try:
                    subprocess.run(
                        [sys.executable, "-m", "pip", "install", "-r", str(req_file), "--quiet", "--no-warn-script-location"],
                        capture_output=True, timeout=60, creationflags=0x08000000
                    )
                except Exception:
                    pass

            report(100, "Cập nhật hoàn tất thành công 100%!")

            # Dọn dẹp file tạm
            try:
                shutil.rmtree(temp_dir, ignore_errors=True)
            except Exception:
                pass

            return True, "Cập nhật thành công!"

        except Exception as e:
            return False, f"Lỗi trong quá trình cập nhật: {e}"

    @classmethod
    def restart_app(cls):
        """Khởi động lại phần mềm JL Tool sau khi cập nhật"""
        base_dir = str(config.BASE_DIR)
        exe_path = os.path.join(base_dir, "JL Tool.exe")
        py_exe = sys.executable
        main_py = os.path.join(base_dir, "main.py")

        if os.path.isfile(exe_path):
            subprocess.Popen([exe_path], cwd=base_dir, creationflags=0x08000000)
        else:
            subprocess.Popen([py_exe, main_py], cwd=base_dir, creationflags=0x08000000)

        try:
            from PySide6.QtWidgets import QApplication
            app = QApplication.instance()
            if app:
                app.quit()
        except Exception:
            pass
        os._exit(0)

auto_updater = AutoUpdater()

