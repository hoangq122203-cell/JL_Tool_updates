# -*- coding: utf-8 -*-
"""
core/hardware_encoder.py
Phát hiện và tự động kích hoạt bộ tăng tốc phần cứng GPU (NVIDIA NVENC / Windows Media Foundation MFT)
Giúp render/cắt video siêu tốc, tiêu tốn cực ít CPU, giữ máy luôn mát và mượt mà.
"""
import os
import subprocess

_CACHED_ENCODER = None


def get_best_video_encoder(ffmpeg_bin="ffmpeg"):
    """
    Trả về: (enc_name, extra_args_list, label)
    Tự động thử lần lượt các bộ giải mã phần cứng:
      1. h264_nvenc (NVIDIA NVENC)
      2. h264_mf (Windows Media Foundation - sử dụng GPU RTX/GTX/AMD/Intel)
      3. libx264 (CPU - dự phòng an toàn)
    """
    global _CACHED_ENCODER
    if _CACHED_ENCODER is not None:
        return _CACHED_ENCODER

    candidates = [
        # 1. NVIDIA NVENC trực tiếp
        ("h264_nvenc", ["-preset", "p4", "-cq", "24", "-b:v", "5000k", "-maxrate", "8000k"], "NVIDIA NVENC (GPU)"),
        # 2. Windows Media Foundation (sử dụng GPU thông qua DirectX/D3D11 - rất mượt, tương thích 100% card NVIDIA)
        ("h264_mf", ["-b:v", "4500k", "-maxrate", "7000k"], "Hardware MFT (GPU Tăng tốc)"),
        # 3. CPU x264 (Dự phòng an toàn)
        ("libx264", ["-preset", "superfast", "-crf", "24", "-maxrate", "4500k", "-bufsize", "9000k"], "CPU libx264 (Dự phòng)"),
    ]

    flags = 0x08000000 if os.name == "nt" else 0

    for enc_name, extra_opts, label in candidates:
        try:
            test_cmd = [
                ffmpeg_bin, "-y",
                "-f", "lavfi", "-i", "testsrc=duration=0.1:size=320x240:rate=10",
                "-c:v", enc_name
            ] + extra_opts + ["-f", "null", "-"]
            r = subprocess.run(test_cmd, capture_output=True, text=True, timeout=5, creationflags=flags)
            if r.returncode == 0:
                _CACHED_ENCODER = (enc_name, extra_opts, label)
                return _CACHED_ENCODER
        except Exception:
            continue

    _CACHED_ENCODER = ("libx264", ["-preset", "superfast", "-crf", "24", "-maxrate", "4500k", "-bufsize", "9000k"], "CPU libx264")
    return _CACHED_ENCODER
