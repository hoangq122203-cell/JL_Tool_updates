# -*- coding: utf-8 -*-
"""
VIDEO CROPPER & ASPECT RATIO CONVERTER ENGINE
Tự động cắt video theo các khung hình chuẩn TikTok (9:16, 1:1, 16:9, Nền Mờ Blur Background).
"""

import os
import sys
import time
import subprocess
import json
from pathlib import Path
from typing import Optional, Dict, Any, List, Tuple
from core.anti_shadowban import get_ffmpeg_path

# Danh mục các khung hình hỗ trợ
CROP_OPTIONS = [
    ("original", "🎬 Giữ nguyên bản gốc (Không cắt)"),
    ("blur_9_16", "📱 Dọc 9:16 - Nền Mờ Nghệ Thuật (Blur Background - Khuyên dùng)"),
    ("crop_9_16", "✂️ Dọc 9:16 - Cắt Giữa (Center Crop 1080x1920)"),
    ("crop_1_1", "⏹️ Khung Vuông 1:1 (Crop Vuông 1080x1080)"),
    ("crop_16_9", "🖥️ Khung Ngang 16:9 (Crop Ngang 1920x1080)"),
]

def get_video_dimensions(video_path: str, ffmpeg_bin: Optional[str] = None) -> Optional[Tuple[int, int]]:
    """Lấy kích thước chiều rộng (w) và chiều cao (h) của file video"""
    if not video_path or not os.path.isfile(video_path):
        return None

    bin_path = ffmpeg_bin or get_ffmpeg_path()
    if not bin_path:
        return None

    try:
        # Sử dụng ffprobe nếu có cùng thư mục với ffmpeg
        probe_bin = bin_path.replace("ffmpeg.exe", "ffprobe.exe").replace("ffmpeg", "ffprobe")
        if os.path.isfile(probe_bin):
            cmd = [
                probe_bin,
                "-v", "error",
                "-select_streams", "v:0",
                "-show_entries", "stream=width,height",
                "-of", "csv=s=x:p=0",
                video_path
            ]
            res = subprocess.run(cmd, capture_output=True, text=True, timeout=10, creationflags=0x08000000)
            if res.returncode == 0 and "x" in res.stdout:
                parts = res.stdout.strip().split("x")
                return int(parts[0]), int(parts[1])
    except Exception:
        pass

    # Dự phòng: đọc từ thông tin ffmpeg -i
    try:
        cmd = [bin_path, "-i", video_path]
        res = subprocess.run(cmd, capture_output=True, text=True, timeout=10, creationflags=0x08000000)
        # Parse dòng Stream ... Video: ... 1920x1080 ...
        import re
        m = re.search(r",\s*(\d{3,4})x(\d{3,4})", res.stderr)
        if m:
            return int(m.group(1)), int(m.group(2))
    except Exception:
        pass

    return None

def crop_single_video(
    src_video_path: str,
    crop_mode: str = "original",
    output_path: Optional[str] = None,
    log_func=None
) -> str:
    """
    Tự động cắt hoặc chuyển đổi khung hình cho 1 video theo crop_mode:
    - 'original': Giữ nguyên
    - 'blur_9_16': Dọc 9:16 có nền mờ phía sau (phù hợp video ngang biến thành TikTok)
    - 'crop_9_16': Dọc 9:16 cắt giữa (1080x1920)
    - 'crop_1_1': Khung vuông 1:1 (1080x1080)
    - 'crop_16_9': Khung ngang 16:9 (1920x1080)
    Trả về đường dẫn file đã cắt (hoặc file gốc nếu không cần cắt).
    """
    def log(msg: str):
        if log_func:
            try:
                log_func(msg)
            except Exception:
                pass

    if not src_video_path or not os.path.isfile(src_video_path):
        return src_video_path

    if not crop_mode or crop_mode == "original":
        return src_video_path

    ffmpeg_bin = get_ffmpeg_path()
    if not ffmpeg_bin:
        log("⚠️ Không tìm thấy công cụ FFmpeg, giữ nguyên video gốc.")
        return src_video_path

    # Xác định đường dẫn file đầu ra
    if not output_path:
        src_path_obj = Path(src_video_path)
        out_dir = src_path_obj.parent / "_da_cat_khung"
        out_dir.mkdir(parents=True, exist_ok=True)
        out_filename = f"{src_path_obj.stem}_{crop_mode}.mp4"
        output_path = str(out_dir / out_filename)

    # Nếu file đã được cắt trước đó và còn nguyên vẹn, trả về ngay
    if os.path.isfile(output_path) and os.path.getsize(output_path) > 10000:
        log(f"⚡ Đã có sẵn bản cắt: {os.path.basename(output_path)}")
        return output_path

    dims = get_video_dimensions(src_video_path, ffmpeg_bin)
    w, h = dims if dims else (1920, 1080)
    aspect = w / h if h > 0 else 1.0

    # Nếu video gốc đã chuẩn tỷ lệ 9:16 (0.54 - 0.58) và chọn 9:16, chỉ cần scale hoặc giữ nguyên
    if abs(aspect - 9/16) < 0.03 and crop_mode in ("blur_9_16", "crop_9_16"):
        log(f"ℹ️ Video '{os.path.basename(src_video_path)}' đã là khung dọc 9:16 chuẩn. Không cần cắt lại.")
        return src_video_path

    log(f"✂️ Đang tự động cắt video '{os.path.basename(src_video_path)}' sang chế độ [{crop_mode}]...")

    try:
        cmd = [ffmpeg_bin, "-y", "-threads", "4", "-i", src_video_path]

        if crop_mode == "blur_9_16":
            # Nền mờ 9:16 phóng to, video gốc sắc nét ở giữa (Tối ưu siêu tốc với downscale blur)
            filter_complex = (
                "[0:v]scale=180:320:force_original_aspect_ratio=increase,crop=180:320,boxblur=4:1,scale=1080:1920:flags=fast_bilinear[bg];"
                "[0:v]scale=1080:-1:force_original_aspect_ratio=decrease[fg];"
                "[bg][fg]overlay=(W-w)/2:(H-h)/2[v]"
            )
            cmd.extend([
                "-filter_complex", filter_complex,
                "-map", "[v]",
                "-map", "0:a?",
                "-c:v", "libx264",
                "-preset", "ultrafast",
                "-crf", "23",
                "-c:a", "aac",
                "-b:a", "128k"
            ])
        elif crop_mode == "crop_9_16":
            # Cắt giữa 9:16 (1080x1920)
            if aspect >= 9/16:
                vf = "crop=ih*9/16:ih:(iw-ih*9/16)/2:0,scale=1080:1920"
            else:
                vf = "crop=iw:iw*16/9:0:(ih-iw*16/9)/2,scale=1080:1920"
            cmd.extend([
                "-vf", vf,
                "-c:v", "libx264",
                "-preset", "ultrafast",
                "-crf", "23",
                "-c:a", "aac",
                "-b:a", "128k"
            ])
        elif crop_mode == "crop_1_1":
            # Cắt vuông 1:1 (1080x1080)
            vf = "crop=min(iw\\,ih):min(iw\\,ih):(iw-min(iw\\,ih))/2:(ih-min(iw\\,ih))/2,scale=1080:1080"
            cmd.extend([
                "-vf", vf,
                "-c:v", "libx264",
                "-preset", "ultrafast",
                "-crf", "23",
                "-c:a", "aac",
                "-b:a", "128k"
            ])
        elif crop_mode == "crop_16_9":
            # Cắt ngang 16:9 (1920x1080)
            if aspect >= 16/9:
                vf = "crop=ih*16/9:ih:(iw-ih*16/9)/2:0,scale=1920:1080"
            else:
                vf = "crop=iw:iw*9/16:0:(ih-iw*9/16)/2,scale=1920:1080"
            cmd.extend([
                "-vf", vf,
                "-c:v", "libx264",
                "-preset", "ultrafast",
                "-crf", "23",
                "-c:a", "aac",
                "-b:a", "128k"
            ])
        else:
            return src_video_path

        cmd.extend([
            "-map_metadata", "-1",
            output_path
        ])

        res = subprocess.run(cmd, capture_output=True, text=True, timeout=300, creationflags=0x08000000)
        if res.returncode == 0 and os.path.isfile(output_path) and os.path.getsize(output_path) > 1000:
            log(f"✅ Đã cắt xong video: {os.path.basename(output_path)}")
            return output_path
        else:
            log(f"⚠️ Lỗi xử lý cắt video (FFmpeg return {res.returncode}), sử dụng video gốc.")
            return src_video_path

    except Exception as e:
        log(f"❌ Ngoại lệ khi cắt video: {e}")
        return src_video_path

def batch_crop_folder(
    folder_path_or_files: str,
    crop_mode: str,
    progress_callback=None,
    log_func=None
) -> Tuple[int, int, str]:
    """
    Cắt hàng loạt toàn bộ video trong thư mục hoặc danh sách file.
    Trả về: (số_video_thành_công, tổng_số_video, thư_mục_đích)
    """
    def log(msg: str):
        if log_func:
            try:
                log_func(msg)
            except Exception:
                pass

    if not folder_path_or_files or crop_mode == "original":
        return 0, 0, ""

    v_exts = ('.mp4', '.mov', '.mkv', '.webm', '.avi', '.flv', '.wmv', '.m4v')
    file_list = []

    if ";" in folder_path_or_files:
        raw_files = [f.strip() for f in folder_path_or_files.split(";") if f.strip()]
        file_list = [f for f in raw_files if os.path.isfile(f) and f.lower().endswith(v_exts)]
        parent_dir = Path(file_list[0]).parent if file_list else Path(".")
    elif os.path.isdir(folder_path_or_files):
        parent_dir = Path(folder_path_or_files)
        for root, _, files in os.walk(folder_path_or_files):
            # Không quét thư mục đã cắt để tránh cắt lặp vô tận
            if "_da_cat_khung" in root or "temp_" in root:
                continue
            for fn in sorted(files):
                if fn.lower().endswith(v_exts):
                    file_list.append(os.path.join(root, fn))
    elif os.path.isfile(folder_path_or_files):
        parent_dir = Path(folder_path_or_files).parent
        file_list = [folder_path_or_files]
    else:
        return 0, 0, ""

    if not file_list:
        log("ℹ️ Không tìm thấy video hợp lệ để cắt.")
        return 0, 0, ""

    target_dir = parent_dir / "_da_cat_khung"
    target_dir.mkdir(parents=True, exist_ok=True)

    success_cnt = 0
    total = len(file_list)

    for idx, fpath in enumerate(file_list):
        if progress_callback:
            try:
                progress_callback(idx + 1, total, os.path.basename(fpath))
            except Exception:
                pass

        out_name = f"{Path(fpath).stem}_{crop_mode}.mp4"
        dest_path = str(target_dir / out_name)

        res_path = crop_single_video(fpath, crop_mode, output_path=dest_path, log_func=log)
        if res_path and os.path.isfile(res_path) and res_path == dest_path:
            success_cnt += 1

    return success_cnt, total, str(target_dir)
