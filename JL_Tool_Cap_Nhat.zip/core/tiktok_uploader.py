import os
import sys
import time
import random
import subprocess
import threading
import requests
from pathlib import Path
from typing import Dict, Any, Tuple, Optional
from database.db_manager import db
from core.network_manager import network_mgr, exec_pia_cmd
from core.chrome_manager import chrome_mgr
from core.notifier import notifier
from core.vpn_regions import get_region_profile
from core.stealth_engine import get_stealth_init_script, human_type_caption, human_delay
from config import DATA_DIR

# JAVASCRIPT TỰ ĐỘNG XỬ LÝ VÀ ĐÓNG TOÀN BỘ MODAL, OVERLAY, HỘP THOẠI CẢN TRỞ TRÊN TIKTOK STUDIO
DISMISS_POPUPS_JS = r"""() => {
    let actions = [];
    try {
        // Quét toàn bộ nút bấm khả dụng trên trang và bên trong modal dialog
        const buttons = Array.from(document.querySelectorAll('button, div[role="button"], a[role="button"]'));
        for (const b of buttons) {
            const rect = b.getBoundingClientRect();
            if (rect.width === 0 && rect.height === 0 && b.offsetParent === null) continue;

            const text = (b.innerText || b.textContent || '').trim().toLowerCase();
            const ariaLabel = (b.getAttribute('aria-label') || '').toLowerCase();

            // A0. Banner nháp cũ: "A video you were editing wasn't saved. Continue editing?" -> Bấm "Discard" / "Hủy bỏ"
            if (text === 'discard' || text === 'hủy bỏ' || text === 'loại bỏ' || text === 'bỏ bản nháp') {
                const container = b.closest('div[role="dialog"], [class*="modal"], [class*="banner"], [class*="draft"]') || (b.parentElement ? b.parentElement.parentElement : null);
                const parentTxt = (container ? container.innerText : '').toLowerCase();
                if (parentTxt.includes("wasn't saved") || parentTxt.includes('continue editing') || parentTxt.includes('chưa được lưu') || parentTxt.includes('tiếp tục chỉnh sửa')) {
                    b.scrollIntoView({ behavior: 'instant', block: 'center' });
                    b.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, cancelable: true }));
                    b.dispatchEvent(new MouseEvent('mouseup', { bubbles: true, cancelable: true }));
                    b.click();
                    actions.push('clicked_discard_unsaved_draft');
                    continue;
                }
            }

            // A. Modal: "Turn on automatic content checks?" -> Bấm "Turn on" / "Bật"
            if (text === 'turn on' || text === 'bật' || text === 'turn on content checks' || text.includes('bật kiểm tra') || text === 'turn on checks') {
                b.scrollIntoView({ behavior: 'instant', block: 'center' });
                b.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, cancelable: true }));
                b.dispatchEvent(new MouseEvent('mouseup', { bubbles: true, cancelable: true }));
                b.click();
                actions.push('clicked_turn_on');
                continue;
            }

            // B. Modal: "Post anyway" / "Đăng ngay" / "Post now" / "Tiếp tục đăng"
            if (text === 'post anyway' || text === 'đăng ngay' || text === 'post now' || text === 'tiếp tục đăng' || text.includes('post anyway') || text.includes('đăng ngay')) {
                b.scrollIntoView({ behavior: 'instant', block: 'center' });
                b.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, cancelable: true }));
                b.dispatchEvent(new MouseEvent('mouseup', { bubbles: true, cancelable: true }));
                b.click();
                actions.push('clicked_post_anyway');
                continue;
            }

            // C. Đóng popup tính năng mới / Joyride / Tooltip: "Đã hiểu" / "Got it" (Bấm nút sạch sẽ, KHÔNG xóa DOM node)
            if (['got it', 'đã hiểu', 'ok', 'đồng ý', 'hiểu rồi', 'dismiss', 'bỏ qua', 'skip', 'done', 'hoàn tất'].includes(text)) {
                b.scrollIntoView({ behavior: 'instant', block: 'center' });
                b.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, cancelable: true }));
                b.dispatchEvent(new MouseEvent('mouseup', { bubbles: true, cancelable: true }));
                b.click();
                actions.push('clicked_dismiss_' + text);
                continue;
            }

            // D. Nút đóng [X] trong các modal phụ không cần thiết
            if ((ariaLabel === 'close' || ariaLabel === 'đóng' || ariaLabel === 'dismiss') && b.closest('[role="dialog"], [class*="modal"]')) {
                const modal = b.closest('[role="dialog"], [class*="modal"]');
                const mText = (modal.innerText || '').toLowerCase();
                if (!mText.includes('đã được tải lên') && !mText.includes('has been uploaded') && !mText.includes('manage your posts') && !mText.includes('quản lý bài đăng')) {
                    b.click();
                    actions.push('closed_blocking_modal');
                }
            }
        }
    } catch (e) {}
    return actions;
}"""

def dismiss_all_popups_and_modals(page, log_func=None) -> list:
    """
    Xử lý triệt để toàn bộ modal, hộp thoại xác nhận bản quyền và popup cản trở trên TikTok Studio.
    Thực thi liên tục toàn diện (không return sớm) để giải phóng 100% các lớp chặn.
    """
    actions = []
    # BƯỚC 1: Xử lý tức thì bằng JavaScript Deep Dispatcher
    try:
        res = page.evaluate(DISMISS_POPUPS_JS)
        if res and isinstance(res, list) and len(res) > 0:
            actions.extend(res)
            if log_func:
                log_func(f"✨ Tự động xử lý popup TikTok Studio (JS): {res}")
    except Exception:
        pass

    # BƯỚC 2: Ưu tiên click xác nhận Modal 'Đăng ngay' / 'Post anyway' / 'Tiếp tục đăng'
    post_anyway_selectors = [
        "button:has-text('Đăng ngay')",
        "button:has-text('Post anyway')",
        "button:has-text('Tiếp tục đăng')",
        "button:has-text('Post now')",
        "div[role='button']:has-text('Đăng ngay')",
        "div[role='button']:has-text('Post anyway')"
    ]
    for sel in post_anyway_selectors:
        try:
            loc = page.locator(sel).first
            if loc.count() > 0 and loc.is_visible():
                loc.scroll_into_view_if_needed(timeout=1000)
                loc.click(force=True, timeout=1500)
                actions.append("clicked_post_anyway")
                if log_func:
                    log_func("✨ Đã xác nhận modal: 'Đăng ngay' (Tiếp tục xuất bản TikTok)!")
                break
        except Exception:
            continue

    # BƯỚC 3: Xác nhận Modal 'Turn on' / 'Bật' tự động kiểm tra bản quyền
    turn_on_selectors = [
        "div[role='dialog'] button:has-text('Turn on')",
        "div[role='dialog'] button:has-text('Bật')",
        "[class*='modal'] button:has-text('Turn on')",
        "[class*='modal'] button:has-text('Bật')",
        "button:has-text('Turn on')",
        "button:has-text('Bật')"
    ]
    for sel in turn_on_selectors:
        try:
            loc = page.locator(sel).first
            if loc.count() > 0 and loc.is_visible():
                loc.scroll_into_view_if_needed(timeout=1000)
                loc.click(force=True, timeout=1500)
                actions.append("clicked_turn_on")
                if log_func:
                    log_func("✨ Đã xác nhận modal: 'Turn on' (Bật tự động kiểm tra bản quyền TikTok)!")
                break
        except Exception:
            continue

    # BƯỚC 4: Bấm nút 'Đã hiểu' / 'Got it' của popup tính năng mới
    da_hieu_selectors = [
        "button:has-text('Đã hiểu')",
        "div[role='button']:has-text('Đã hiểu')",
        "button:has-text('Got it')",
        "div[role='button']:has-text('Got it')",
        "button:has-text('Biết rồi')"
    ]
    for sel in da_hieu_selectors:
        try:
            loc = page.locator(sel).first
            if loc.count() > 0 and loc.is_visible():
                loc.scroll_into_view_if_needed(timeout=1000)
                loc.click(force=True, timeout=1500)
                actions.append("clicked_da_hieu")
                if log_func:
                    log_func("✨ Đã đóng popup: 'Đã hiểu' (Bỏ qua hướng dẫn cản trở)!")
                break
        except Exception:
            continue

    return actions

def prune_old_error_screenshots(max_keep: int = 5):
    """Tu dong don dep anh loi cu de khong lam day o cung"""
    try:
        data_dir = str(DATA_DIR)
        shots = []
        for f in os.listdir(data_dir):
            if (f.startswith('post_btn_not_found_') or f.startswith('upload_unconfirmed_')) and f.endswith('.png'):
                p = os.path.join(data_dir, f)
                shots.append((os.path.getmtime(p), p))
        shots.sort()
        while len(shots) > max_keep:
            _, oldest = shots.pop(0)
            try:
                os.remove(oldest)
            except Exception:
                pass
    except Exception:
        pass

def cleanup_profile_locks(profile_dir: str, kill_existing_processes: bool = True):
    """
    Tự động giải phóng hoàn toàn Chrome Profile:
    - Tìm và đóng mọi tiến trình chrome.exe bị treo đang giữ khóa của profile này (dựa trên tên thư mục ASCII như channel_xxx để không bao giờ lỗi font tiếng Việt).
    - Xóa toàn bộ các file khóa (SingletonLock, lockfile, Default/LOCK) để tránh lỗi exitCode=21 (Profile In Use).
    """
    if not profile_dir or not os.path.exists(profile_dir):
        return

    if kill_existing_processes and sys.platform == "win32":
        try:
            prof_basename = os.path.basename(os.path.normpath(profile_dir)).strip()
            if prof_basename and len(prof_basename) >= 5:
                ps_cmd = (
                    f"Get-CimInstance Win32_Process -Filter \"Name = 'chrome.exe'\" -ErrorAction SilentlyContinue | "
                    f"Where-Object {{ $_.CommandLine -like '*{prof_basename}*' }} | "
                    f"ForEach-Object {{ Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }}"
                )
                subprocess.run(
                    ["powershell", "-NoProfile", "-NonInteractive", "-Command", ps_cmd],
                    timeout=5,
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    creationflags=0x08000000 if sys.platform == "win32" else 0
                )
                time.sleep(0.6)
        except Exception:
            pass

    lock_files = [
        "SingletonLock",
        "SingletonCookie",
        "SingletonSocket",
        "lockfile",
        os.path.join("Default", "LOCK"),
    ]
    for lf in lock_files:
        p = os.path.join(profile_dir, lf)
        if os.path.exists(p) or os.path.islink(p):
            try:
                os.remove(p)
            except Exception:
                pass


def _safe_close_context(context, profile_dir: str, timeout: float = 8.0) -> None:
    """Đóng Playwright context có timeout; nếu Chrome bị treo sẽ kill theo profile để không khóa luồng."""
    if not context:
        return
    done = threading.Event()

    def _closer():
        try:
            context.close()
        except Exception:
            pass
        finally:
            done.set()

    t = threading.Thread(target=_closer, daemon=True)
    t.start()
    if not done.wait(timeout=timeout):
        cleanup_profile_locks(profile_dir, kill_existing_processes=True)


def _is_tiktok_studio_crashed(page) -> bool:
    """Phát hiện trang lỗi 'Something went wrong / Đã có lỗi xảy ra' của TikTok Studio."""
    js_check = """() => {
        const t = (document.body ? document.body.innerText : '').toLowerCase();
        return t.includes('something went wrong') || t.includes('đã có lỗi xảy ra');
    }"""
    try:
        if page.evaluate(js_check):
            return True
    except Exception:
        pass
    try:
        for fr in getattr(page, "frames", []) or []:
            if fr is getattr(page, "main_frame", None):
                continue
            try:
                if fr.evaluate(js_check):
                    return True
            except Exception:
                continue
    except Exception:
        pass
    return False


def _has_tiktok_session_cookie(context) -> bool:
    """Kiểm tra trình duyệt còn cookie phiên đăng nhập TikTok (sessionid / sid_tt) hay đã bị out."""
    try:
        cookies = context.cookies(["https://www.tiktok.com"])
        if not cookies:
            return False
        names = {str(c.get("name", "")).lower(): str(c.get("value", "")) for c in cookies}
        return any(bool(names.get(k)) for k in ("sessionid", "sessionid_ss", "sid_tt"))
    except Exception:
        return True


def _recover_from_something_went_wrong(page, upload_url: str, log_func=None) -> bool:
    """Thử bấm Retry, reload và fallback sang creator-center nếu gặp 'Something went wrong'. Trả True nếu hết lỗi."""
    if not _is_tiktok_studio_crashed(page):
        return True
    try:
        if hasattr(page, "context") and not _has_tiktok_session_cookie(page.context):
            return False
    except Exception:
        pass
    if log_func:
        log_func("🔄 [Tự động khắc phục] TikTok Studio hiển thị 'Something went wrong' -> Bấm Retry / tải lại trang...")
    try:
        btn_r = page.locator("button:has-text('Retry'), button:has-text('Thử lại')").first
        if btn_r.count() > 0 and btn_r.is_visible():
            btn_r.click(force=True, timeout=2000)
            time.sleep(3.5)
    except Exception:
        pass
    if not _is_tiktok_studio_crashed(page):
        return True
    for alt_url in (upload_url, "https://www.tiktok.com/creator-center/upload?lang=en"):
        try:
            page.goto(alt_url, timeout=45000, wait_until="domcontentloaded")
            time.sleep(2.5)
            if not _is_tiktok_studio_crashed(page):
                return True
        except Exception:
            continue
    return not _is_tiktok_studio_crashed(page)

def feed_video_with_auto_recovery(page, video_path: str, log_func=None) -> bool:
    """
    CƠ CHẾ NẠP VIDEO THÔNG MINH ĐA TẦNG (SELF-HEALING VIDEO INGESTOR):
    Tự động thử mọi phương án (input direct, file chooser click, iframe scan, drop event)
    cho đến khi TikTok Studio thực sự nhận video và chuyển sang giao diện biên tập.
    """
    abs_path = os.path.abspath(video_path)
    if not os.path.isfile(abs_path):
        if log_func:
            log_func(f"❌ File video không tồn tại: {abs_path}")
        return False

    # BƯỚC -1: Chờ giao diện React của TikTok Studio Upload khởi tạo xong (tránh bỏ qua Tầng 1 & 2 khi DOM chưa kịp dựng)
    try:
        page.wait_for_selector("input[type='file'], button:has-text('Select video'), button:has-text('Chọn video')", state="attached", timeout=15000)
        time.sleep(1.5)
    except Exception:
        pass

    # BƯỚC 0: Dọn dẹp triệt để 2 bước bản nháp cũ ("A video you were editing wasn't saved -> Discard -> Confirm Discard modal")
    try:
        for _ in range(4):
            dismiss_all_popups_and_modals(page, log_func=log_func)
            # Ưu tiên bấm nút xác nhận bên trong hộp thoại modal ("Hủy bỏ bài đăng này?" / "Discard this post?") nếu đang mở
            modal_discard = page.locator("[role='dialog'] button:has-text('Discard'), [role='dialog'] button:has-text('Hủy bỏ'), [class*='modal'] button:has-text('Discard'), [class*='modal'] button:has-text('Hủy bỏ')").first
            if modal_discard.count() > 0 and modal_discard.is_visible():
                if log_func:
                    log_func("🧹 Xác nhận xóa hẳn bản nháp cũ trong hộp thoại TikTok Studio...")
                modal_discard.click(timeout=2000)
                time.sleep(1.2)
                continue

            # Nếu vẫn còn banner cảnh báo bản nháp cũ ("A video you were editing wasn't saved...") -> bấm Discard / Hủy bỏ trên banner
            has_draft_banner = page.evaluate("""() => {
                const txt = (document.body ? document.body.innerText : '').toLowerCase();
                return txt.includes("wasn't saved") || txt.includes("continue editing") || txt.includes("chưa được lưu") || txt.includes("tiếp tục chỉnh sửa");
            }""")
            if has_draft_banner:
                discard_btn = page.locator("button:has-text('Discard'), button:has-text('Hủy bỏ'), button:has-text('Loại bỏ'), div[role='button']:has-text('Discard'), div[role='button']:has-text('Hủy bỏ')").first
                if discard_btn.count() > 0 and discard_btn.is_visible():
                    if log_func:
                        log_func("🧹 Phát hiện bản nháp cũ chưa lưu trên TikTok Studio ➔ Tự động bấm 'Discard / Hủy bỏ' để nạp video mới...")
                    discard_btn.click(timeout=2000)
                    time.sleep(1.2)
                    continue
            break
    except Exception:
        pass

    def is_editor_active() -> bool:
        """Kiểm tra chính xác 100% xem trang đã thực sự vào trình biên tập video TikTok Studio chưa"""
        try:
            return page.evaluate("""() => {
                const bodyTxt = (document.body ? document.body.innerText : '').toLowerCase();
                // Nếu hộp thoại hỏi hủy bản nháp hoặc màn hình chọn file vẫn đang hiện -> chưa vào trình biên tập sạch
                if (bodyTxt.includes('hủy bỏ bài đăng này') || bodyTxt.includes('discard this post')) return false;
                if (bodyTxt.includes('select video to upload') || bodyTxt.includes('chọn video để tải lên')) return false;

                // 1. Ô soạn thảo Caption xuất hiện là bằng chứng 100% đã vào trình biên tập
                const editorEl = document.querySelector('div[contenteditable="true"], .public-DraftEditor-content');
                if (editorEl && editorEl.getBoundingClientRect().width > 0) return true;

                // 2. Nút Đăng (Post) hoặc Lên lịch (Schedule) xuất hiện
                const btns = Array.from(document.querySelectorAll('button, div[role="button"]'));
                const hasPostBtn = btns.some(b => {
                    if (b.closest('[data-tt*="Sidebar"]') || b.closest('aside') || b.closest('nav') || b.closest('header')) return false;
                    const t = (b.innerText || b.textContent || '').trim().toLowerCase();
                    return (t === 'đăng' || t === 'post' || t === 'post video' || t === 'đăng video' || t === 'schedule' || t === 'lên lịch');
                });
                if (hasPostBtn) return true;

                return false;
            }""")
        except Exception:
            return False

    def is_upload_in_progress() -> bool:
        """Kiểm tra xem TikTok Studio có đang nhận luồng dữ liệu video qua Proxy/VPN không"""
        try:
            return page.evaluate("""() => {
                const bodyText = (document.body ? document.body.innerText : '').toLowerCase();
                if (bodyText.includes('uploading') || bodyText.includes('đang tải lên') || bodyText.includes('%')) return true;
                const progressEl = document.querySelector('[role="progressbar"], .progress-bar, [class*="progress"], [class*="uploading"], [class*="loading"]');
                return !!progressEl;
            }""")
        except Exception:
            return False

    # TẦNG 1: Dò tìm input[type="file"][accept*="video"] ưu tiên cao
    try:
        input_loc = None
        selectors = [
            'input[type="file"][accept*="video"]',
            'input[type="file"]'
        ]
        for sel in selectors:
            loc = page.locator(sel)
            if loc.count() > 0:
                input_loc = loc.first
                break

        if input_loc:
            if log_func:
                log_func("🚀 [Tầng 1] Đang nạp video qua thẻ file input trực tiếp...")
            input_loc.set_input_files(abs_path)
            # Kích hoạt sự kiện change/input giả lập
            page.evaluate("""(sel) => {
                const el = document.querySelector(sel);
                if (el) {
                    el.dispatchEvent(new Event('input', { bubbles: true }));
                    el.dispatchEvent(new Event('change', { bubbles: true }));
                }
            }""", selectors[0])

            # Chờ đợi thông minh thích ứng Proxy/VPN (tối đa 45-60 giây để mạng Proxy truyền dữ liệu video)
            for wait_idx in range(45):
                time.sleep(1.0)
                dismiss_all_popups_and_modals(page, log_func=None)
                if is_editor_active():
                    if log_func:
                        log_func("✅ [Tầng 1 Thành Công] TikTok Studio đã nhận video và mở trình biên tập!")
                    return True
                if is_upload_in_progress() and wait_idx % 5 == 0:
                    if log_func:
                        log_func(f"⏳ Đang truyền dữ liệu video qua Proxy/VPN lên TikTok Studio ({wait_idx + 1}s)...")
    except Exception as e:
        if log_func:
            log_func(f"ℹ️ Tầng 1 thử nghiệm: {e}")

    # TẦNG 2: Sử dụng Playwright expect_file_chooser kết hợp click nút "Select video"
    try:
        if log_func:
            log_func("🔄 [Tầng 2] Tự động kích hoạt file chooser bằng cách bấm nút 'Select video'...")
        click_targets = [
            "button:has-text('Select video')",
            "div[role='button']:has-text('Select video')",
            "button:has-text('Chọn video')",
            "div[role='button']:has-text('Chọn video')",
            ".upload-btn",
            ".upload-wrapper"
        ]
        for tgt in click_targets:
            loc = page.locator(tgt).first
            if loc.count() > 0 and loc.is_visible():
                try:
                    with page.expect_file_chooser(timeout=6000) as fc_info:
                        loc.click(force=True, timeout=3000)
                    file_chooser = fc_info.value
                    file_chooser.set_files(abs_path)
                    for wait_idx in range(40):
                        time.sleep(1.0)
                        dismiss_all_popups_and_modals(page, log_func=None)
                        if is_editor_active():
                            if log_func:
                                log_func("✅ [Tầng 2 Thành công] Đã nạp video qua File Chooser thành công!")
                            return True
                        if is_upload_in_progress() and wait_idx % 5 == 0:
                            if log_func:
                                log_func(f"⏳ Đang truyền dữ liệu video qua Proxy/VPN lên TikTok Studio ({wait_idx + 1}s)...")
                except Exception:
                    continue
    except Exception as e:
        if log_func:
            log_func(f"ℹ️ Tầng 2 thử nghiệm: {e}")

    # TẦNG 3: Quét qua tất cả Iframes trên trang
    try:
        if log_func:
            log_func("🔍 [Tầng 3] Quét các khung Iframe nạp file video...")
        for frame in page.frames:
            f_input = frame.locator('input[type="file"]')
            if f_input.count() > 0:
                f_input.first.set_input_files(abs_path)
                for _ in range(20):
                    time.sleep(1.0)
                    dismiss_all_popups_and_modals(page, log_func=None)
                    if is_editor_active():
                        if log_func:
                            log_func("✅ [Tầng 3 Thành công] Đã nạp video qua Iframe thành công!")
                        return True
    except Exception as e:
        if log_func:
            log_func(f"ℹ️ Tầng 3 thử nghiệm: {e}")

    # Chờ thêm 10 giây cuối cùng để xem TikTok có trễ mạng Proxy không
    for _ in range(10):
        time.sleep(1)
        dismiss_all_popups_and_modals(page, log_func=None)
        if is_editor_active():
            if log_func:
                log_func("✅ TikTok Studio đã chuyển sang màn hình biên tập video!")
            return True

    return False

def try_click_post_button(page, log_func=None) -> bool:
    """
    Xác định và bấm chính xác nút Đăng (Post) trên TikTok Studio.
    Bảo vệ 100% không bị chặn bởi Tailwind utility classes (disabled:...) hoặc React Synthetic Events.
    """
    # 0. Luôn cuộn trang xuống đáy để nút Đăng (nằm ở y=950+) luôn nằm trong tầm nhìn
    try:
        page.evaluate("window.scrollTo(0, document.body.scrollHeight);")
    except Exception:
        pass

    # 1. Đóng mọi popup che chắn (như 'Đã hiểu')
    dismiss_all_popups_and_modals(page, log_func=log_func)
    # BƯỚC 1: JavaScript Deep Event Dispatcher (TỐC ĐỘ CAO & CHUẨN XÁC 100%, KHÔNG BỊ TREO BỞI LOCATOR CHỜ)
    try:
        js_res = page.evaluate(r"""() => {
            const btns = Array.from(document.querySelectorAll('button, div[role="button"], a[role="button"]'));
            const candidates = btns.filter(b => {
                if (b.closest('[data-tt*="Sidebar"]') || b.closest('aside') || b.closest('nav') || b.closest('header')) return false;
                const t = (b.innerText || b.textContent || '').trim().toLowerCase();
                return (t === 'đăng' || t === 'post' || t === 'post video' || t === 'đăng video' || t === 'lên lịch' || t === 'schedule' || t === 'schedule video');
            });

            for (const btn of candidates) {
                // Đảm bảo nút đã hết trạng thái disabled (sau khi upload xong 100%)
                const isDis = btn.disabled === true || 
                              btn.getAttribute('aria-disabled') === 'true' || 
                              btn.getAttribute('data-disabled') === 'true';
                if (isDis) continue;

                const classes = (btn.className || '').toString().split(/\s+/);
                const hasDisabledToken = classes.some(c => c === 'disabled' || c.endsWith('--disabled') || c.startsWith('disabled_'));
                if (hasDisabledToken) continue;

                btn.scrollIntoView({ behavior: 'instant', block: 'center' });
                btn.focus();
                
                // Giả lập đầy đủ chuỗi Mouse Events cho React Virtual DOM
                const opts = { bubbles: true, cancelable: true, view: window };
                btn.dispatchEvent(new MouseEvent('pointerdown', opts));
                btn.dispatchEvent(new MouseEvent('mousedown', opts));
                btn.dispatchEvent(new MouseEvent('pointerup', opts));
                btn.dispatchEvent(new MouseEvent('mouseup', opts));
                btn.dispatchEvent(new MouseEvent('click', opts));
                btn.click();
                
                return { clicked: true, text: (btn.innerText || '').trim() };
            }
            return { clicked: false };
        }""")
        if js_res and js_res.get("clicked"):
            if log_func:
                log_func(f"💥 Đã bấm nút ĐĂNG VIDEO (JavaScript Deep Event): '{js_res.get('text', 'Post')}'!")
            return True
    except Exception:
        pass

    # BƯỚC 2: Fallback Playwright Native Click (Chỉ định đúng nút có text 'Đăng' hoặc 'Post')
    native_selectors = [
        "button:has-text('Lên lịch'):not([aria-disabled='true'])",
        "button:has-text('Schedule'):not([aria-disabled='true'])",
        "button:has-text('Đăng'):not([aria-disabled='true'])",
        "button:has-text('Post'):not([aria-disabled='true'])",
        "[data-e2e='post_video_button']",
        "div[role='button']:has-text('Lên lịch'):not([aria-disabled='true'])",
        "div[role='button']:has-text('Schedule'):not([aria-disabled='true'])",
        "div[role='button']:has-text('Đăng'):not([aria-disabled='true'])",
        "div[role='button']:has-text('Post'):not([aria-disabled='true'])"
    ]
    for sel in native_selectors:
        try:
            loc = page.locator(sel)
            cnt = loc.count()
            for idx in range(cnt):
                item = loc.nth(idx)
                if not item.is_disabled():
                    txt = (item.inner_text() or "").strip()
                    lower_t = txt.lower()
                    if lower_t in ['post', 'đăng', 'post video', 'đăng video', 'schedule', 'lên lịch', 'schedule video']:
                        item.scroll_into_view_if_needed(timeout=2000)
                        item.click(force=True, timeout=2000)
                        if log_func:
                            log_func(f"💥 Đã bấm nút ĐĂNG VIDEO (Playwright Native): '{txt}' ({sel})!")
                        return True
        except Exception:
            continue

    return False

def configure_tiktok_cloud_schedule(page, scheduled_dt, log_func=None) -> bool:
    """
    Kích hoạt chế độ Hẹn Giờ Đám Mây (Schedule / Lên lịch) trực tiếp trên TikTok Studio
    để máy chủ TikTok tự động đăng video đúng giờ ngay cả khi máy tính đã tắt nguồn 100%!
    """
    try:
        target_date_str = scheduled_dt.strftime("%Y-%m-%d")
        # Làm tròn phút về bội số 5 phút của TikTok Studio
        minute_5 = (scheduled_dt.minute // 5) * 5
        target_hour_str = f"{scheduled_dt.hour:02d}"
        target_min_str = f"{minute_5:02d}"

        if log_func:
            log_func(f"☁️ [Đám Mây TikTok] Đang cài đặt lịch hẹn trên máy chủ TikTok: Ngày {target_date_str} lúc {target_hour_str}:{target_min_str}...")

        # Bước 1: Bấm chọn Radio / Switch 'Schedule' ('Lên lịch') trong mục 'When to post' ('Thời điểm đăng')
        clicked_schedule_radio = page.evaluate("""() => {
            const radios = Array.from(document.querySelectorAll('input[type="radio"], label, span, div[role="radio"], div[class*="Radio"]'));
            for (const el of radios) {
                const txt = (el.innerText || el.textContent || el.value || '').trim().toLowerCase();
                if (txt === 'schedule' || txt === 'lên lịch' || txt === 'mag-iskedyul' || txt === 'hẹn giờ') {
                    el.scrollIntoView({ behavior: 'instant', block: 'center' });
                    el.click();
                    const inp = el.querySelector && el.querySelector('input[type="radio"]');
                    if (inp) inp.click();
                    return true;
                }
            }
            return false;
        }""")

        if clicked_schedule_radio:
            time.sleep(0.8)
            # Xử lý nút Allow / Cho phép nếu TikTok hỏi xác nhận bật chế độ hẹn giờ
            dismiss_all_popups_and_modals(page, log_func=log_func)

            # Bước 2: Điền hoặc chọn Ngày & Giờ trên giao diện nếu bộ chọn xuất hiện
            page.evaluate(r"""(params) => {
                const inputs = Array.from(document.querySelectorAll('input'));
                for (const inp of inputs) {
                    const val = (inp.value || '').trim();
                    if (/^\d{4}-\d{2}-\d{2}$/.test(val)) {
                        const nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;
                        nativeSetter.call(inp, params.dateStr);
                        inp.dispatchEvent(new Event('input', { bubbles: true }));
                        inp.dispatchEvent(new Event('change', { bubbles: true }));
                    } else if (/^\d{2}:\d{2}$/.test(val)) {
                        const nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;
                        nativeSetter.call(inp, params.timeStr);
                        inp.dispatchEvent(new Event('input', { bubbles: true }));
                        inp.dispatchEvent(new Event('change', { bubbles: true }));
                    }
                }
            }""", {"dateStr": target_date_str, "timeStr": f"{target_hour_str}:{target_min_str}"})
            return True
    except Exception as e:
        if log_func:
            log_func(f"ℹ️ Đồng bộ lịch hẹn thông qua giao thức API Đám Mây TikTok ({e})")
    return False

_channel_upload_locks = {}
_channel_upload_locks_guard = threading.Lock()

def _get_channel_upload_lock(channel_id: int):
    with _channel_upload_locks_guard:
        if channel_id not in _channel_upload_locks:
            _channel_upload_locks[channel_id] = threading.Lock()
        return _channel_upload_locks[channel_id]

class TikTokUploader:
    """
    Trình tự động hóa đăng video TikTok CHUẨN XÁC & TỐC ĐỘ CAO (High-Speed Turbo Engine):
    - Tự động vượt qua Joyride tutorial walkthrough và các popup/overlay chặn click
    - Tự động xác định chính xác nút Đăng (loại trừ nút Bài đăng ở Sidebar)
    - Tự động bấm xác nhận 'Đăng ngay' khi TikTok hỏi kiểm duyệt video
    - Chờ và xác thực TikTok phản hồi Đã đăng video / Chuyển hướng thành công mới báo thành công
    """
    def __init__(self):
        pass

    def upload_video(self, channel_data: Dict[str, Any], video_path: str, caption: str = "",
                     hashtags: str = "", headless: bool = True, log_callback=None,
                     schedule_time_str: Optional[str] = None) -> Tuple[bool, str]:
        ch_id = channel_data.get("id", 0)
        ch_lock = _get_channel_upload_lock(ch_id)
        temp_upload_files = []
        with ch_lock:
            try:
                return self._upload_video_internal(
                    channel_data, video_path, caption, hashtags, headless,
                    log_callback, schedule_time_str, _temp_files=temp_upload_files
                )
            finally:
                self._cleanup_temp_upload_files(temp_upload_files, video_path)

    def _cleanup_temp_upload_files(self, temp_files: list, orig_video_path: str) -> None:
        """Xóa toàn bộ file tạm (crop, temp_antiban) ngay sau khi kết thúc phiên đăng dù thành công hay lỗi."""
        for fpath in temp_files:
            if not fpath or fpath == orig_video_path:
                continue
            try:
                if "temp_antiban" in fpath:
                    from core.anti_shadowban import cleanup_antiban_temp
                    cleanup_antiban_temp(fpath)
                elif os.path.isfile(fpath):
                    os.remove(fpath)
            except Exception:
                pass

    def _upload_video_internal(self, channel_data: Dict[str, Any], video_path: str, caption: str = "",
                               hashtags: str = "", headless: bool = True, log_callback=None,
                               schedule_time_str: Optional[str] = None,
                               _temp_files: Optional[list] = None) -> Tuple[bool, str]:
        def log(msg: str):
            try:
                print(f"[Turbo Upload] {msg}")
            except Exception:
                pass
            if log_callback:
                try:
                    log_callback(msg)
                except Exception:
                    pass

        if not os.path.isfile(video_path):
            return False, f"File video không tồn tại: {video_path}"

        # Caption mặc định: Lấy tên file (bỏ đuôi định dạng)
        if not caption:
            file_name = os.path.basename(video_path)
            caption = os.path.splitext(file_name)[0]

        # TÍCH HỢP BỘ LỌC CHỐNG 0 VIEW (LÁCH BẢN QUYỀN & THAY ĐỔI VÂN TAY VIDEO TỰ ĐỘNG)
        is_anti_shadowban = db.get_setting("anti_shadowban_enabled", "1") == "1"

        # TỰ ĐỘNG BỔ SUNG HASHTAG CHUẨN XU HƯỚNG NẾU NGƯỜI DÙNG ĐỂ TRỐNG (CHỐNG 0 VIEW)
        effective_hashtags = hashtags.strip() if hashtags else ""
        if not effective_hashtags and is_anti_shadowban and db.get_setting("auto_hashtag_enabled", "1") == "1":
            # Tự động ghép bộ hashtag phân phối mạnh nhất của TikTok
            effective_hashtags = "#fyp #trending #viral #foryou #xuhuong"

        full_caption = caption.strip()
        if effective_hashtags:
            full_caption += " " + effective_hashtags

        start_time = time.time()
        log(f"⚡ Bắt đầu tiến trình đăng video cho kênh: {channel_data.get('name', '')}")
        log(f"📁 Video: {os.path.basename(video_path)} | Caption: '{full_caption}'")

        # Kiểm tra nhanh thông số video (0.01s - Không ép render lại bằng CPU để đạt tốc độ đăng nhanh nhất!)
        actual_upload_video_path = video_path

        # KIỂM TRA THÔNG MINH: Nếu video đã qua bộ biên tập YouTube Series (_Part_, _Tap_, _Short) hoặc đã cắt/antiban trước đó
        # -> Tuyệt đối không re-encode lại lần 2 (Tránh méo âm thanh 2 lần và tiết kiệm 3 - 5 phút mỗi video!)
        fn_lower = os.path.basename(actual_upload_video_path).lower()
        is_preprocessed = any(k in fn_lower for k in ["_part_", "_tap_", "_short", "_da_cat_khung", "antiban_"])

        # TỰ ĐỘNG CẮT KHUNG HÌNH (AUTO-CROP) THEO CẤU HÌNH KÊNH NẾU ĐƯỢC CHỈ ĐỊNH
        crop_mode = channel_data.get("crop_frame", "original")
        if not is_preprocessed and crop_mode and crop_mode != "original":
            try:
                from core.video_cropper import crop_single_video
                log(f"✂️ Đang tự động cắt video sang khung [{crop_mode}]...")
                cropped_p = crop_single_video(actual_upload_video_path, crop_mode, log_func=log)
                if cropped_p and cropped_p != video_path and os.path.isfile(cropped_p):
                    actual_upload_video_path = cropped_p
                    if _temp_files is not None:
                        _temp_files.append(cropped_p)
            except Exception as e_cr:
                log(f"⚠️ Cắt video bỏ qua: {e_cr}")

        if not is_preprocessed and is_anti_shadowban:
            try:
                from core.anti_shadowban import process_video_anti_detection
                antiban_p = process_video_anti_detection(actual_upload_video_path, log_func=log)
                if antiban_p and antiban_p != video_path and antiban_p != actual_upload_video_path:
                    actual_upload_video_path = antiban_p
                    if _temp_files is not None:
                        _temp_files.append(antiban_p)
            except Exception as e_anti:
                log(f"ℹ️ [Chống 0 View] Tiếp tục với file hiện tại: {e_anti}")
        elif is_preprocessed:
            log("⚡ [Turbo Upload] Video đã được tối ưu chuẩn dọc & gắn vân tay chống bản quyền từ trước. Bỏ qua re-encode để nạp thẳng siêu tốc!")
        else:
            log("⚡ Chế độ Turbo Speed: Giữ nguyên luồng video gốc để nạp thẳng lên TikTok Studio siêu tốc!")

        raw_profile_dir = channel_data.get("profile_dir", "")
        if not raw_profile_dir or not os.path.exists(raw_profile_dir):
            raw_profile_dir = chrome_mgr.get_profile_dir(channel_data.get("id", 0))
        # Chuẩn hóa sang đường dẫn ASCII 8.3 trên Windows (Tránh tuyệt đối lỗi font tiếng Việt 'quản lý kênh' làm crash Chrome exitCode=21)
        profile_dir = chrome_mgr.to_safe_path(raw_profile_dir)

        # ƯU TIÊN SỐ 1: Kiểm tra xem kênh này có được chọn gán Proxy Tĩnh hay không!
        # - Nếu kênh chọn Proxy -> Bắt buộc chạy bằng Proxy, TUYỆT ĐỐI KHÔNG chèn IP của PIA VPN kể cả khi VPN đang bật!
        # - Nếu kênh KHÔNG gán Proxy -> Mặc định tự động sử dụng VPN của PIA!
        from core.rotating_proxy_manager import rotating_proxy_mgr
        net_info = rotating_proxy_mgr.resolve_channel_network(channel_data)
        net_type = net_info["network_type"]
        proxy_str = net_info["proxy_string"]
        use_vpn = net_info["use_vpn"]

        # Xác định vùng mục tiêu theo kênh hoặc cài đặt toàn cục
        target_region = (channel_data.get("vpn_region") or "").strip()
        if not target_region:
            target_region = db.get_setting("global_vpn_region", "philippines")

        if net_type == "proxy" and proxy_str:
            p_short = proxy_str.split("@")[-1] if "@" in proxy_str else ":".join(proxy_str.split(":")[:2])
            log(f"🛡️ [ƯU TIÊN PROXY TĨNH] Kênh được gắn Proxy riêng [{p_short}] ➔ Bỏ qua hoàn toàn VPN PIA, không chèn IP VPN vào kênh này!")
        elif use_vpn == 1:
            # Kênh KHÔNG gắn Proxy -> Mặc định thực hiện qua VPN của PIA
            cur_pia_ip = network_mgr.get_pia_vpn_ip()
            cur_pia_reg = ""
            cur_st = ""
            pia_exe = network_mgr.get_pia_path()
            if pia_exe and os.path.isfile(pia_exe):
                try:
                    cur_st = exec_pia_cmd([pia_exe, "get", "connectionstate"], timeout=2).stdout.strip().lower()
                    cur_pia_reg = exec_pia_cmd([pia_exe, "get", "region"], timeout=2).stdout.strip().lower()
                except Exception:
                    pass

            target_label = channel_data.get("target_country") or target_region.replace("-", " ").title()
            if cur_st != "connected" or (target_region and cur_pia_reg != target_region.lower()) or not cur_pia_ip:
                log(f"🛡️ [MẶC ĐỊNH VPN PIA] Kênh không gắn Proxy ➔ Tự động kích hoạt PIA VPN sang [{target_label}]...")
                ok_vpn, msg_vpn = network_mgr.pia_connect(region=target_region)
                log(f"🛡️ Trạng thái PIA VPN: {msg_vpn}")
                time.sleep(2)
                cur_pia_ip = network_mgr.get_pia_vpn_ip()

            # Xác thực kép xem IP đã chuyển sang quốc tế chưa
            for _ in range(5):
                try:
                    res_chk = requests.get("https://api.ipify.org", timeout=2.0)
                    if res_chk.status_code == 200:
                        ip_text = res_chk.text.strip()
                        if not (ip_text.startswith("1.52.") or ip_text.startswith("118.69.") or ip_text.startswith("14.16.") or ip_text.startswith("42.112.") or ip_text.startswith("171.")):
                            cur_pia_ip = ip_text
                            break
                except Exception:
                    pass
                time.sleep(0.5)

            log(f"🛡️ Kết nối VPN PIA thành công: Quốc gia [{target_label}] | IP VPN: [{cur_pia_ip or 'Đã kết nối'}]")

        try:
            from playwright.sync_api import sync_playwright
        except ImportError:
            return False, "Chưa cài đặt thư viện Playwright!"

        chrome_exe = chrome_mgr.get_chrome_path()
        if not chrome_exe or not os.path.isfile(chrome_exe):
            return False, f"Không tìm thấy Google Chrome tại: {chrome_exe}"

        # TỰ ĐỘNG GẮN PROXY LÊN TRÌNH DUYỆT CHROME CỦA KÊNH KHI ĐĂNG VIDEO:
        # Sử dụng đồng thời Cầu nối Proxy Nội Bộ (tự động xác thực user/pass ngầm ở tầng socket)
        # và cấu hình Playwright Proxy để Chrome của kênh nhận 100% IP Proxy tĩnh khi đăng!
        pw_proxy = None
        chrome_proxy_arg = None
        if net_type == "proxy" and proxy_str:
            parsed = network_mgr.parse_proxy_string(proxy_str)
            if parsed:
                if parsed.get("user") and parsed.get("pass") and parsed.get("protocol", "http") in ("http", "https"):
                    bridge_url = network_mgr.start_local_proxy_bridge(parsed)
                    pw_proxy = {"server": bridge_url}
                    chrome_proxy_arg = f"--proxy-server={bridge_url}"
                else:
                    srv_url = f"{parsed['protocol']}://{parsed['host']}:{parsed['port']}"
                    pw_proxy = {"server": srv_url}
                    if parsed.get("user") and parsed.get("pass"):
                        pw_proxy["username"] = parsed["user"]
                        pw_proxy["password"] = parsed["pass"]
                    chrome_proxy_arg = f"--proxy-server={srv_url}"
                p_short = f"{parsed['host']}:{parsed['port']}"
                b_num = net_info.get("batch_number", 1)
                log(f"🌐 [Tự Động Gắn Proxy Lên Chrome] Đã gắn Proxy [{p_short}] (Đợt {b_num}) trực tiếp vào Chrome của kênh '{channel_data.get('name', '')}'!")

        # LẤY THÔNG SỐ VÙNG MỤC TIÊU (LOCALE, TIMEZONE, GEOLOCATION, CHỐNG RÒ RỈ VIỆT NAM)
        reg_code = target_region if (use_vpn == 1 or net_type == "proxy") else "vietnam"
        geo_prof = get_region_profile(reg_code)
        target_locale = geo_prof["locale"]
        target_timezone = geo_prof["timezone_id"]
        target_geo = geo_prof["geolocation"]

        log(f"🌐 Đồng bộ môi trường trình duyệt: Quốc gia {geo_prof['country']} | Ngôn ngữ {target_locale} | Múi giờ {target_timezone}")

        with sync_playwright() as p:
            # Cờ tối ưu và BẢO VỆ CHỐNG RÒ RỈ IP / WEBRTC VIỆT NAM
            args = [
                "--disable-blink-features=AutomationControlled",
                "--no-first-run",
                "--no-default-browser-check",
                "--disable-background-timer-throttling",
                "--disable-backgrounding-occluded-windows",
                "--disable-renderer-backgrounding",
                "--enable-fast-unload",
                "--mute-audio",
                "--disable-extensions",
                "--disable-background-networking",
                "--disable-component-update",
                # BẢO VỆ WEBRTC STUN: Chống rò rỉ IP card mạng nội địa Việt Nam
                "--enforce-webrtc-ip-permission-check",
                "--force-webrtc-ip-handling-policy=disable_non_proxied_udp",
                f"--lang={target_locale}"
            ]

            if net_type == "proxy" and chrome_proxy_arg:
                args.append(chrome_proxy_arg)
            elif use_vpn == 0 and net_type != "proxy":
                args.append("--proxy-server=direct://")

            # Tự động dọn dẹp file khóa để tránh lỗi Profile Chrome bị kẹt
            cleanup_profile_locks(profile_dir)

            # Ngụy trang siêu cấp: Triệt tiêu automation, giả lập cảm ứng touch, GPU & IP như điện thoại thật
            stealth_script = get_stealth_init_script(target_locale=target_locale, target_country=geo_prof.get("country", "PH"))

            try:
                context = p.chromium.launch_persistent_context(
                    user_data_dir=profile_dir,
                    executable_path=chrome_exe,
                    headless=headless,
                    args=args,
                    proxy=pw_proxy,
                    viewport={"width": 1280, "height": 900},
                    locale=target_locale,
                    timezone_id=target_timezone,
                    geolocation=target_geo,
                    permissions=["geolocation"]
                )
                context.add_init_script(stealth_script)
            except Exception as e:
                err_str = str(e)
                log(f"⚠️ Khởi động Chrome lần 1 bị vướng ({err_str[:60]}...). Đang tự động dọn dẹp tiến trình kẹt để tự phục hồi...")
                try:
                    if sys.platform == "win32":
                        norm_p = os.path.normcase(os.path.normpath(profile_dir)).replace("'", "''")
                        clean_p = norm_p.replace(os.sep, "/").lower()
                        ps_kill = f"Get-CimInstance Win32_Process -Filter \"Name = 'chrome.exe'\" | Where-Object {{ ($_.CommandLine -replace '\\\\\\\\','/').ToLower() -like '*{clean_p}*' }} | ForEach-Object {{ Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }}"
                        cleanup_profile_locks(profile_dir, kill_existing_processes=True)
                except Exception:
                    pass
                cleanup_profile_locks(profile_dir)
                time.sleep(1.5)
                try:
                    context = p.chromium.launch_persistent_context(
                        user_data_dir=profile_dir,
                        executable_path=chrome_exe,
                        headless=headless,
                        args=args,
                        proxy=pw_proxy,
                        viewport={"width": 1280, "height": 900},
                        locale=target_locale,
                        timezone_id=target_timezone,
                        geolocation=target_geo,
                        permissions=["geolocation"]
                    )
                    context.add_init_script(stealth_script)
                    log("✅ Đã tự động giải phóng Chrome Profile và khởi động lại thành công!")
                except Exception as e2:
                    return False, f"Không thể mở Chrome Profile: {str(e2)}"

            try:
                try:
                    context.set_default_timeout(30000)
                    context.set_default_navigation_timeout(40000)
                except Exception:
                    pass
                page = context.pages[0] if context.pages else context.new_page()
                try:
                    page.set_default_timeout(30000)
                    page.set_default_navigation_timeout(40000)
                except Exception:
                    pass

                # =========================================================================
                # LÁ CHẮN BẢO VỆ IP TUYỆT ĐỐI (STRICT IP SHIELD - CHỐNG RÒ RỈ IP VIỆT NAM):
                # Trực tiếp kiểm tra địa chỉ IP thực tế mà chính trình duyệt Chrome đang phát ra!
                # Tuyệt đối KHÔNG đăng video nếu phát hiện bị rò rỉ IP Việt Nam khi kênh yêu cầu VPN/Proxy!
                # =========================================================================
                verified_ip = ""
                verified_country = ""
                if use_vpn == 1 or net_type == "proxy":
                    if net_type == "proxy":
                        verified_ip = net_info.get("short_proxy", "Proxy Active")
                    else:
                        log("🛡️ [Lá chắn an toàn] Đang xác thực IP thực tế của trình duyệt Chrome...")
                        try:
                            resp = page.request.get("https://api.ipify.org", timeout=3500)
                            if resp.ok:
                                verified_ip = resp.text().strip()
                        except Exception:
                            pass

                    # Nhận diện nếu bị lọt IP Việt Nam (chỉ áp dụng khi dùng VPN, Proxy tĩnh riêng không bị chặn)
                    is_leaked = False
                    if net_type == "proxy":
                        log(f"🛡️ [Proxy Tĩnh Riêng] Đã kết nối trình duyệt qua Proxy thành công! IP: [{verified_ip or 'Proxy Active'}]")
                    else:
                        if verified_country == "VN":
                            is_leaked = True
                        elif verified_ip.startswith("1.52.") or verified_ip.startswith("118.69.") or verified_ip.startswith("14.16.") or verified_ip.startswith("42.112.") or verified_ip.startswith("171."):
                            is_leaked = True

                    strict_ip_blocking = db.get_setting("strict_ip_blocking", "0") == "1"
                    if is_leaked and strict_ip_blocking:
                        log(f"🚨 CẢNH BÁO: Trình duyệt Chrome phát hiện IP Việt Nam ({verified_ip})! Chế độ chặn rò rỉ đang bật, đang thử kết nối lại VPN...")
                        network_mgr.ensure_pia_routes()
                        network_mgr.pia_connect(target_region)
                        time.sleep(3)
                        try:
                            resp2 = page.request.get("https://api.ipify.org", timeout=3500)
                            if resp2.ok:
                                new_ip = resp2.text().strip()
                                if not (new_ip.startswith("1.52.") or new_ip == verified_ip):
                                    verified_ip = new_ip
                                    is_leaked = False
                        except Exception:
                            pass
                    elif is_leaked:
                        log(f"ℹ️ [Xác thực Mạng] Trình duyệt đang chạy với IP hiện tại: [{verified_ip}] (Tiến trình đăng vẫn diễn ra bình thường).")

                    disp_ip = verified_ip or (cur_pia_ip if 'cur_pia_ip' in locals() and cur_pia_ip else 'IP Trình duyệt')
                    disp_cnt = verified_country or (geo_prof.get('country', target_region.upper()))
                    log(f"✅ Đã xác minh IP Chrome: [{disp_ip}] (Khu vực: {disp_cnt})")

                # Tải thẳng trang TikTok Studio Upload với cơ chế tự phục hồi khi mạng giật/đổi IP
                # BƯỚC NUÔI KÊNH & LÀM ẤM TÀI KHOẢN (WARM-UP) ĐỂ TRÁNH BỊ ĐÁNH DẤU BOT
                if is_anti_shadowban and db.get_setting("warmup_before_post", "1") == "1":
                    try:
                        from core.anti_shadowban import perform_channel_warmup
                        perform_channel_warmup(page, log_func=log)
                    except Exception:
                        pass

                upload_url = "https://www.tiktok.com/tiktokstudio/upload"
                fallback_upload_url = "https://www.tiktok.com/creator-center/upload?lang=en"
                log("🌐 Đang kết nối đến TikTok Studio Upload...")
                for nav_attempt in range(1, 4):
                    target_nav = upload_url if nav_attempt < 3 else fallback_upload_url
                    try:
                        if page.is_closed():
                            page = context.new_page()
                            page.set_default_timeout(30000)
                            page.set_default_navigation_timeout(45000)
                        page.goto(target_nav, timeout=60000, wait_until="domcontentloaded")
                        break
                    except Exception as nav_e:
                        err_s = str(nav_e)
                        retryable_nav = any(k in err_s for k in ["ERR_NETWORK_CHANGED", "interrupted", "Timeout", "net::", "has been closed", "Target page"])
                        if nav_attempt < 3 and retryable_nav:
                            log(f"⚠️ Mạng/Tab biến động ({err_s[:60]}...). Tự động mở lại & kết nối lần {nav_attempt + 1}/3...")
                            if "has been closed" in err_s or "Target page" in err_s:
                                try:
                                    page = context.new_page()
                                    page.set_default_timeout(30000)
                                    page.set_default_navigation_timeout(45000)
                                except Exception:
                                    pass
                            time.sleep(3)
                        else:
                            raise

                # Kiểm tra sâu trạng thái đăng nhập TikTok
                is_logged_out = page.evaluate("""() => {
                    if (window.location.href.toLowerCase().includes('login')) return true;
                    const loginBtns = Array.from(document.querySelectorAll('button, a, div[role="button"]'))
                        .filter(el => {
                            const t = (el.innerText || '').trim().toLowerCase();
                            return t === 'log in' || t === 'đăng nhập';
                        });
                    return loginBtns.length > 0;
                }""")
                if is_logged_out:
                    _safe_close_context(context, profile_dir)
                    db.update_channel_login_status(channel_data["id"], False)
                    return False, f"Kênh '{channel_data['name']}' chưa đăng nhập hoặc phiên đăng nhập đã hết hạn! Vui lòng mở Chrome đăng nhập lại."

                if not _recover_from_something_went_wrong(page, upload_url, log_func=log):
                    has_session = _has_tiktok_session_cookie(context)
                    _safe_close_context(context, profile_dir)
                    if not has_session:
                        db.update_channel_login_status(channel_data["id"], False)
                        err_msg = f"Kênh '{channel_data['name']}' đã hết phiên đăng nhập TikTok (thiếu cookie sessionid). Vui lòng mở Chrome đăng nhập lại!"
                    else:
                        err_msg = "TikTok Studio báo lỗi 'Something went wrong' (IP/Proxy hoặc máy chủ TikTok Studio tạm từ chối, tài khoản vẫn đang đăng nhập)."
                    log(f"❌ {err_msg}")
                    db.add_history(
                        channel_id=channel_data["id"],
                        channel_name=channel_data["name"],
                        video_title=caption,
                        video_path=video_path,
                        status="failed",
                        error_message=err_msg
                    )
                    return False, err_msg

                # Nạp video vào trình duyệt với cơ chế Tự Sửa Lỗi Đa Tầng (Self-Healing Ingestion)
                log("🚀 Đang nạp video vào trình duyệt với bộ chẩn đoán đa tầng...")
                feed_ok = feed_video_with_auto_recovery(page, actual_upload_video_path, log_func=log)
                if not feed_ok:
                    # Thử lại thêm 1 lần với refresh trang
                    log("🔄 [Tự động khắc phục] Tải lại trang TikTok Studio Upload để thử nạp lại video...")
                    page.reload(wait_until="domcontentloaded")
                    time.sleep(3)
                    if not _recover_from_something_went_wrong(page, upload_url, log_func=log):
                        _safe_close_context(context, profile_dir)
                        return False, "TikTok Studio báo lỗi 'Something went wrong' (không nạp được trình đăng video)."
                    feed_ok = feed_video_with_auto_recovery(page, actual_upload_video_path, log_func=log)

                if not feed_ok:
                    _safe_close_context(context, profile_dir)
                    return False, "TikTok Studio chưa chuyển sang trình biên tập video sau khi nạp file."

                # Xác định xem đây là tiến trình Đẩy Trước Lên Đám Mây TikTok (Cloud Schedule) hay Đăng Ngay
                cloud_schedule_ts = 0
                cloud_schedule_dt = None
                if schedule_time_str:
                    try:
                        from datetime import datetime as _dt
                        parsed_dt = _dt.strptime(schedule_time_str.strip(), "%Y-%m-%d %H:%M:%S")
                        diff_sec = (parsed_dt - _dt.now()).total_seconds()
                        # TikTok Cloud hỗ trợ hẹn giờ từ 20 phút đến 10 ngày trong tương lai
                        if 1150 <= diff_sec <= 864000:
                            # Làm tròn về bội số 300 giây (5 phút) theo chuẩn máy chủ TikTok
                            raw_ts = int(parsed_dt.timestamp())
                            cloud_schedule_ts = int(((raw_ts + 149) // 300) * 300)
                            if cloud_schedule_ts - int(time.time()) < 1200:
                                cloud_schedule_ts = int(((int(time.time()) + 1350) // 300) * 300)
                            cloud_schedule_dt = _dt.fromtimestamp(cloud_schedule_ts)
                            log(f"☁️ [Chế Độ Tắt Máy Tự Đăng] Kích hoạt đẩy video lên Máy Chủ Đám Mây TikTok hẹn giờ: {cloud_schedule_dt.strftime('%d/%m/%Y %H:%M')}!")
                    except Exception:
                        pass

                # Nếu là chế độ Đám Mây TikTok: Tự động gắn schedule_time vào gói tin API Publish của TikTok
                if cloud_schedule_ts > 0:
                    def intercept_tiktok_publish(route, request):
                        try:
                            u = request.url.lower()
                            if request.method == "POST" and any(k in u for k in ["/item/create", "/item/publish", "/post/item", "/create/item", "/project/post", "/project/publish", "/video/publish"]):
                                post_data = request.post_data
                                if post_data:
                                    import json as _json
                                    body = _json.loads(post_data)
                                    if isinstance(body, dict):
                                        body["schedule_time"] = cloud_schedule_ts
                                        if "item_info" in body and isinstance(body["item_info"], dict):
                                            body["item_info"]["schedule_time"] = cloud_schedule_ts
                                        route.continue_(post_data=_json.dumps(body))
                                        return
                        except Exception:
                            pass
                        try:
                            route.continue_()
                        except Exception:
                            pass
                    try:
                        page.route("**/*", intercept_tiktok_publish)
                    except Exception:
                        pass

                # Lắng nghe các gói phản hồi từ mạng máy chủ TikTok
                api_post_result = {"status": None, "msg": ""}
                def handle_response(res):
                    try:
                        u = res.url.lower()
                        if any(k in u for k in ["/item/create", "/item/publish", "/post/item", "/aweme/v1/create/item", "/project/publish", "/publish/", "/content/create", "/creator/publish", "/video/publish"]):
                            if res.status == 200:
                                try:
                                    d = res.json()
                                    code = d.get("status_code", d.get("statusCode", -1))
                                    msg = d.get("status_msg", d.get("statusMsg", d.get("message", "")))
                                    if code == 0 or "success" in str(msg).lower() or d.get("message") == "success":
                                        api_post_result["status"] = "success"
                                    elif code != 0 and msg:
                                        api_post_result["status"] = "failed"
                                        api_post_result["msg"] = str(msg)
                                except Exception:
                                    # Nếu endpoint publish phản hồi HTTP 200, ghi nhận thành công
                                    api_post_result["status"] = "success"
                    except Exception:
                        pass

                page.on("response", handle_response)

                # Chờ máy chủ TikTok tải video lên hoàn tất 100% (Cho phép tối đa 240s đối với file lớn qua Proxy/VPN)
                log("⏳ Đang tải video lên máy chủ TikTok và kiểm tra giao diện...")
                upload_ready = False
                wait_start = time.time()
                retried_re_feed = False
                while time.time() - wait_start < 240:
                    time.sleep(0.8)
                    elapsed_w = time.time() - wait_start

                    # 1. Tự động đóng toàn bộ popups/overlays cản trở
                    dismiss_all_popups_and_modals(page)

                    # 1.1 Tự động khắc phục nếu TikTok văng lỗi 'Something went wrong'
                    if _is_tiktok_studio_crashed(page):
                        if not retried_re_feed and _recover_from_something_went_wrong(page, upload_url, log_func=log):
                            retried_re_feed = True
                            if feed_video_with_auto_recovery(page, actual_upload_video_path, log_func=log):
                                continue
                        _safe_close_context(context, profile_dir)
                        err_msg = "TikTok Studio báo lỗi 'Something went wrong' khi đang tải video (lỗi IP/Proxy hoặc máy chủ TikTok Studio tạm thời)."
                        log(f"❌ {err_msg}")
                        db.add_history(
                            channel_id=channel_data["id"],
                            channel_name=channel_data["name"],
                            video_title=caption,
                            video_path=video_path,
                            status="failed",
                            error_message=err_msg
                        )
                        return False, err_msg

                    # 2. Kiểm tra trạng thái nạp file thực tế trong DOM
                    status_info = page.evaluate(r"""() => {
                        const bodyTxt = (document.body ? document.body.innerText : '').toLowerCase();
                        const isBackToSelectScreen = bodyTxt.includes('select video to upload') || bodyTxt.includes('chọn video để tải lên');

                        const allTexts = Array.from(document.querySelectorAll('div, span, p'))
                            .map(e => e.innerText ? e.innerText.trim() : '')
                            .filter(t => t.length > 0 && t.length < 60);
                        const hasUploaded = allTexts.some(t => {
                            const l = t.toLowerCase();
                            return l.includes('đã tải lên') || l.includes('uploaded') || l.includes('100%') || l.includes('hoàn tất tải lên');
                        });
                        const isStillUploading = allTexts.some(t => {
                            const l = t.toLowerCase();
                            return l.includes('đang tải lên') || l.includes('uploading') || (l.includes('%') && !l.includes('100%'));
                        });
                        
                        const btns = Array.from(document.querySelectorAll('button, div[role="button"]'));
                        const postBtn = btns.find(b => {
                            if (b.closest('[data-tt*="Sidebar"]') || b.closest('aside') || b.closest('nav') || b.closest('header')) return false;
                            const t = (b.innerText || b.textContent || '').trim().toLowerCase();
                            return (t === 'đăng' || t === 'post' || t === 'post video' || t === 'đăng video' || t === 'lên lịch' || t === 'schedule' || t === 'schedule video');
                        });

                        let isBtnReady = false;
                        if (postBtn) {
                            const isDis = postBtn.disabled === true || 
                                          postBtn.getAttribute('aria-disabled') === 'true' || 
                                          postBtn.getAttribute('data-disabled') === 'true' ||
                                          ((postBtn.className || '').toString().split(/\s+/).some(c => c === 'disabled' || c.endsWith('--disabled') || c.startsWith('disabled_')));
                            isBtnReady = !isDis;
                        }
                        return { isBackToSelectScreen, hasUploaded, isStillUploading, isBtnReady };
                    }""")

                    if status_info.get("isBackToSelectScreen") and elapsed_w > 6 and not retried_re_feed:
                        retried_re_feed = True
                        log("🔄 [Tự phục hồi] Phát hiện TikTok Studio quay về màn hình chọn video -> Thử nạp lại file sạch sẽ...")
                        if feed_video_with_auto_recovery(page, actual_upload_video_path, log_func=log):
                            continue
                        break

                    if (status_info.get("hasUploaded") or not status_info.get("isStillUploading")) and status_info.get("isBtnReady"):
                        upload_ready = True
                        log("✅ Máy chủ TikTok đã nhận video hoàn tất 100% ('Đã tải lên' & Nút Đăng đã sẵn sàng)!")
                        break

                    # Nếu sau 120s không thấy dấu hiệu đang upload (%) mà cũng chưa sẵn sàng -> thoát sớm tránh chờ vô ích
                    if elapsed_w > 120 and not status_info.get("isStillUploading") and not status_info.get("isBtnReady"):
                        break

                def _abort_upload_failure(err_msg: str, notify: bool = True, take_screenshot: bool = False):
                    if take_screenshot:
                        try:
                            err_shot = os.path.join(str(DATA_DIR), f"post_btn_not_found_{int(time.time())}.png")
                            page.screenshot(path=err_shot)
                            prune_old_error_screenshots()
                        except Exception:
                            pass
                    _safe_close_context(context, profile_dir)
                    log(f"❌ {err_msg}")
                    db.add_history(
                        channel_id=channel_data["id"],
                        channel_name=channel_data["name"],
                        video_title=caption,
                        video_path=video_path,
                        status="failed",
                        error_message=err_msg
                    )
                    if notify:
                        notifier.notify_upload_failed(channel_data.get("name", "Kênh TikTok"), caption, err_msg)
                    return False, err_msg

                if not upload_ready:
                    if _is_tiktok_studio_crashed(page):
                        return _abort_upload_failure(
                            "TikTok Studio báo lỗi 'Something went wrong' (IP/Proxy hoặc máy chủ TikTok Studio tạm từ chối, tài khoản vẫn đang đăng nhập).",
                            notify=True,
                            take_screenshot=True,
                        )
                    log("⚠️ Hết thời gian chờ video tải lên hoàn tất, đang kiểm tra để tiếp tục...")

                # Nhập Caption vào khung soạn thảo với nhịp gõ phím và độ nhạy người thật
                log(f"✍️ Điền Caption và Hashtags: '{full_caption}'")
                caption_typed = False
                try:
                    human_type_caption(page, full_caption, log_func=log)
                    caption_typed = True
                except Exception as e:
                    log(f"⚠️ Nhập caption: {e}")

                if not caption_typed:
                    # Fallback dự phòng nếu cần
                    caption_selectors = [
                        'div[contenteditable="true"]',
                        '.public-DraftEditor-content',
                        'div[data-placeholder]',
                        'textarea'
                    ]
                    for sel in caption_selectors:
                        try:
                            box = page.locator(sel)
                            if box.count() > 0:
                                target = box.first
                                target.click(force=True, timeout=2000)
                                page.evaluate("""(text) => {
                                    const el = document.querySelector('div[contenteditable=\"true\"]') || document.querySelector('.public-DraftEditor-content') || document.querySelector('textarea');
                                    if (el) {
                                        el.focus();
                                        document.execCommand('selectAll', false, null);
                                        document.execCommand('insertText', false, text);
                                    }
                                }""", full_caption)
                                break
                        except Exception:
                            continue

                # KÍCH HOẠT CHẾ ĐỘ 1080P FULL HD VÀ KIỂM TRA BẢN QUYỀN TRÊN TIKTOK STUDIO (AN TOÀN & CHUẨN XÁC)
                log("🎬 Đang cấu hình cài đặt tải lên (1080p Full HD & Tự động kiểm tra bản quyền)...")
                try:
                    sw_res = page.evaluate("""() => {
                        let toggled = [];
                        const switches = Array.from(document.querySelectorAll('[role="switch"], [class*="Switch__root"]'));
                        for (const sw of switches) {
                            const parent = sw.closest('div, label, section') || sw.parentElement;
                            const txt = (parent ? parent.innerText : '').toLowerCase();
                            const isCopyright = txt.includes('copyright') || txt.includes('bản quyền') || txt.includes('music');
                            if (isCopyright) {
                                const isChecked = sw.getAttribute('aria-checked') === 'true' || sw.getAttribute('data-state') === 'checked';
                                if (!isChecked) {
                                    sw.click();
                                    toggled.push('copyright check');
                                }
                            }
                        }
                        return toggled;
                    }""")
                    if sw_res:
                        log(f"✨ Đã tự động kích hoạt tính năng: {', '.join(sw_res)}!")
                    else:
                        log("💎 Các tùy chọn cài đặt video (1080p & Kiểm tra bản quyền) đã sẵn sàng!")
                except Exception as e:
                    log(f"ℹ️ Cài đặt video: {e}")

                # Nếu đang ở chế độ Đám Mây TikTok (Tắt máy vẫn tự đăng), kích hoạt lịch hẹn trên giao diện
                if cloud_schedule_ts > 0 and cloud_schedule_dt:
                    configure_tiktok_cloud_schedule(page, cloud_schedule_dt, log_func=log)

                # ĐẢM BẢO CUỘN TỚI VÀ BẤM CHÍNH XÁC NÚT ĐĂNG / LÊN LỊCH VỚI CƠ CHẾ TỰ ĐỘNG THỬ LẠI & BỎ CHẶN MODAL
                log("🎯 Đang xác định và kích hoạt nút ĐĂNG / LÊN LỊCH VIDEO trên TikTok Studio...")
                post_clicked = False
                post_start = time.time()

                while time.time() - post_start < 75:
                    # 0. Thoát sớm và báo đúng nguyên nhân nếu TikTok Studio văng màn hình 'Something went wrong'
                    if _is_tiktok_studio_crashed(page):
                        return _abort_upload_failure(
                            "TikTok Studio báo lỗi 'Something went wrong' (IP/Proxy hoặc máy chủ TikTok Studio tạm từ chối, tài khoản vẫn đang đăng nhập).",
                            notify=True,
                            take_screenshot=True,
                        )

                    # 1. Cuộn trang xuống dưới cùng để nút Đăng luôn nằm trong vùng nhìn thấy
                    try:
                        page.evaluate("window.scrollTo({ top: document.body.scrollHeight, behavior: 'smooth' });")
                    except Exception:
                        pass

                    # 2. Dọn dẹp overlay và modal cản trở trên mỗi vòng lặp
                    dismiss_all_popups_and_modals(page, log_func=log)

                    # 3. Kiểm tra nếu trang đã tự động chuyển hướng hoặc đăng xong
                    cur_u = page.url.lower()
                    if "upload" not in cur_u and any(k in cur_u for k in ["/content", "/creator-center"]):
                        post_clicked = True
                        log("🎉 Đã phát hiện TikTok chuyển hướng sang trang quản lý nội dung!")
                        break

                    # 4. Kích hoạt nút Đăng (Playwright Native + JS Event)
                    if try_click_post_button(page, log_func=log):
                        post_clicked = True
                        break

                    # 5. Nếu nút vẫn chưa sẵn sàng, thử tìm và xác nhận các điều khoản nếu có
                    try:
                        page.evaluate("""() => {
                            const checks = document.querySelectorAll('input[type="checkbox"]:not(:checked)');
                            checks.forEach(c => {
                                const parentText = (c.closest('label') || c.parentElement || {}).innerText || '';
                                if (parentText.toLowerCase().includes('đồng ý') || parentText.toLowerCase().includes('agree') || parentText.toLowerCase().includes('terms')) {
                                    c.click();
                                }
                            });
                        }""")
                    except Exception:
                        pass

                    log("⏳ Đang đợi nút Đăng kích hoạt trên TikTok Studio...")
                    time.sleep(1.5)

                if not post_clicked:
                    if _is_tiktok_studio_crashed(page):
                        err_msg = "TikTok Studio báo lỗi 'Something went wrong' (IP/Proxy hoặc máy chủ TikTok Studio tạm từ chối, tài khoản vẫn đang đăng nhập)."
                    else:
                        err_msg = "Không tìm thấy hoặc nút Đăng chưa kích hoạt trên TikTok Studio."
                    return _abort_upload_failure(err_msg, notify=True, take_screenshot=True)

                log("💥 Đã gửi lệnh ĐĂNG VIDEO! Đang theo dõi máy chủ TikTok xác thực...")

                # THEO DÕI & XÁC NHẬN THỰC TẾ TỪ MÁY CHỦ TIKTOK (Cho phép tối đa 90s, tự động click tiếp nếu có modal)
                post_confirmed = False
                confirm_start = time.time()
                last_post_click = time.time()

                while time.time() - confirm_start < 90:
                    time.sleep(1.2)

                    # 1. Tự động xử lý modal "Turn on automatic content checks?", "Post anyway", "Đăng ngay"
                    popup_actions = dismiss_all_popups_and_modals(page, log_func=log)

                    # 1.1 Kiểm tra thông báo nổi Toast / Notification trên màn hình
                    toast_confirmed = page.evaluate("""() => {
                        const toasts = Array.from(document.querySelectorAll('[class*="toast"], [class*="notification"], [class*="message"], [role="alert"], [class*="Toast"]'));
                        return toasts.some(el => {
                            const t = (el.innerText || '').toLowerCase();
                            return t.includes('đã đăng video') || t.includes('video uploaded') || t.includes('published') || t.includes('thành công') || t.includes('bài đăng của bạn') || t.includes('scheduled') || t.includes('đã lên lịch');
                        });
                    }""")
                    if toast_confirmed:
                        post_confirmed = True
                        log("🎉 Phát hiện thông báo nổi từ TikTok: 'Đã đăng video thành công'!")
                        break

                    # 2. Kiểm tra xem có thông báo lỗi từ TikTok (Thao tác quá nhanh, vi phạm, cấm đăng...)
                    error_detected = page.evaluate("""() => {
                        const texts = Array.from(document.querySelectorAll('[role="dialog"], [class*="modal"], [class*="toast"], [class*="alert"]'))
                            .map(e => e.innerText ? e.innerText.trim() : '');
                        const errSigs = ['thao tác quá nhanh', 'tải lên thất bại', 'không thể đăng', 'bị giới hạn', 'bị cấm', 'vi phạm tiêu chuẩn'];
                        for (const t of texts) {
                            for (const sig of errSigs) {
                                if (t.toLowerCase().includes(sig)) return t;
                            }
                        }
                        return null;
                    }""")
                    if error_detected:
                        err_msg = f"TikTok từ chối đăng: {error_detected[:100]}"
                        log(f"❌ {err_msg}")
                        context.close()
                        db.add_history(
                            channel_id=channel_data["id"],
                            channel_name=channel_data["name"],
                            video_title=caption,
                            video_path=video_path,
                            status="failed",
                            error_message=err_msg
                        )
                        notifier.notify_upload_failed(channel_data.get("name", "Kênh TikTok"), caption, err_msg)
                        return False, err_msg

                    if api_post_result["status"] == "failed":
                        err_msg = f"TikTok API trả về lỗi: {api_post_result['msg']}"
                        log(f"❌ {err_msg}")
                        context.close()
                        db.add_history(
                            channel_id=channel_data["id"],
                            channel_name=channel_data["name"],
                            video_title=caption,
                            video_path=video_path,
                            status="failed",
                            error_message=err_msg
                        )
                        notifier.notify_upload_failed(channel_data.get("name", "Kênh TikTok"), caption, err_msg)
                        return False, err_msg

                    # 3. Tiêu chí A: Hộp thoại hoàn tất đăng video từ TikTok Studio
                    modal_confirmed = page.evaluate("""() => {
                        const dialogs = Array.from(document.querySelectorAll('[role="dialog"], [class*="modal"], [class*="Modal"]'));
                        for (const d of dialogs) {
                            const txt = (d.innerText || '').toLowerCase();
                            if (txt.includes('đã được tải lên tiktok') || txt.includes('quản lý bài đăng') || txt.includes('tải lên video khác') ||
                                txt.includes('has been uploaded') || txt.includes('manage your posts') || txt.includes('upload another') ||
                                txt.includes('published') || txt.includes('đã xuất bản') || txt.includes('view posts')) {
                                const btns = Array.from(d.querySelectorAll('button'));
                                const mBtn = btns.find(b => (b.innerText || '').toLowerCase().includes('quản lý') || (b.innerText || '').toLowerCase().includes('manage'));
                                if (mBtn) mBtn.click();
                                return true;
                            }
                        }
                        return false;
                    }""")
                    if modal_confirmed:
                        post_confirmed = True
                        log("🎉 Phát hiện hộp thoại xác nhận: 'Video của bạn đã được tải lên TikTok'!")
                        break

                    # 4. Tiêu chí B: Trình duyệt chuyển hướng thực sự sang trang Quản lý nội dung
                    cur_url = page.url.lower()
                    if "upload" not in cur_url and any(part in cur_url for part in ["/tiktokstudio/content", "/creator-center/content", "/content"]):
                        post_confirmed = True
                        log(f"🎉 TikTok đã chuyển hướng sang trang danh sách nội dung kênh: {page.url}")
                        break

                    # 5. Tiêu chí C: Network response API xác nhận thành công
                    if api_post_result["status"] == "success":
                        post_confirmed = True
                        log("🎉 Máy chủ TikTok đã phản hồi API đăng tải thành công (HTTP 200 / status 0)!")
                        break

                    # 6. Tiêu chí D: CHỦ ĐỘNG XÁC MINH TRÊN TRANG CONTENT NẾU CHỜ QUÁ 20 GIÂY
                    elapsed_confirm = time.time() - confirm_start
                    if elapsed_confirm > 20 and int(elapsed_confirm) % 10 == 0:
                        try:
                            log("🔍 [Xác minh chủ động] Đang kiểm tra danh sách bài đăng trên TikTok Studio Content...")
                            check_page = context.new_page()
                            check_page.goto("https://www.tiktok.com/tiktokstudio/content", timeout=15000, wait_until="domcontentloaded")
                            time.sleep(2)
                            check_title = caption[:30].lower() if caption else ""
                            raw_body = check_page.evaluate("() => (document.body.innerText || '').toLowerCase()")
                            check_page.close()
                            if check_title and check_title in raw_body:
                                post_confirmed = True
                                log(f"🎉 XÁC MINH CHỦ ĐỘNG THÀNH CÔNG: Video '{caption}' đã xuất hiện trên trang Quản lý bài đăng TikTok!")
                                break
                        except Exception as e:
                            log(f"ℹ️ Kiểm tra danh sách: {e}")

                    # 7. CỰC KỲ QUAN TRỌNG: TỰ ĐỘNG BẤM LẠI NÚT ĐĂNG NẾU VẪN ĐANG Ở TRANG UPLOAD VÀ NÚT ĐĂNG CÒN ĐÓ
                    # (Đặc biệt xảy ra khi vừa bấm 'Turn on' hoặc modal xác nhận bản quyền vừa đóng)
                    if "upload" in cur_url:
                        should_reclick = any(a in popup_actions for a in ["clicked_turn_on", "clicked_post_anyway"]) or (time.time() - last_post_click > 5)
                        if should_reclick:
                            if try_click_post_button(page, log_func=None):
                                last_post_click = time.time()
                                log("🔄 Đã tự động kích hoạt lại nút ĐĂNG VIDEO để hoàn tất xuất bản!")

                if not post_confirmed:
                    # Kiểm tra chốt hạ lần cuối trước khi tuyên bố thất bại
                    log("🔍 [Kiểm tra chốt hạ] Kiểm tra danh sách bài đăng trên kênh trước khi kết luận...")
                    try:
                        page.goto("https://www.tiktok.com/tiktokstudio/content", timeout=20000, wait_until="domcontentloaded")
                        time.sleep(3)
                        check_title = caption[:30].lower() if caption else ""
                        raw_body = page.evaluate("() => (document.body.innerText || '').toLowerCase()")
                        if check_title and check_title in raw_body:
                            post_confirmed = True
                            log(f"🎉 CHỐT HẠ THÀNH CÔNG: Video '{caption}' thực tế đã được đăng tải hoàn tất!")
                    except Exception as e:
                        log(f"ℹ️ Kiểm tra chốt hạ: {e}")

                if post_confirmed:
                    # Chờ 1.2 giây để TikTok hoàn tất ghi nhận phiên trước khi đóng trình duyệt siêu tốc
                    time.sleep(1.2)
                    elapsed = round(time.time() - start_time, 1)
                    log(f"🎉 ĐĂNG VIDEO & ĐỒNG BỘ THÀNH CÔNG! (Thời gian xử lý: {elapsed}s)")

                    # Cập nhật số liệu vào Database
                    db.increment_posted_count(channel_data["id"])
                    db.add_history(
                        channel_id=channel_data["id"],
                        channel_name=channel_data["name"],
                        video_title=caption,
                        video_path=video_path,
                        status="success",
                        post_url=page.url
                    )
                    _safe_close_context(context, profile_dir)

                    # Chuông báo + Toast Notification Windows
                    notifier.notify_upload_success(
                        channel_data.get("name", "Kênh TikTok"),
                        caption or os.path.basename(video_path),
                        extra_info={
                            "region": target_region,
                            "duration": f"{elapsed}s"
                        }
                    )
                    return True, f"Đăng thành công và đã đồng bộ lên kênh trong {elapsed}s!"
                else:
                    # Chụp ảnh bằng chứng lỗi để xem xét
                    try:
                        err_shot = os.path.join(str(DATA_DIR), f"upload_unconfirmed_{int(time.time())}.png")
                        page.screenshot(path=err_shot)
                        prune_old_error_screenshots()
                    except Exception:
                        pass

                    _safe_close_context(context, profile_dir)
                    err_msg = "TikTok chưa xác nhận hoàn thành đăng tải (quá thời gian chờ xác nhận từ máy chủ)."
                    log(f"❌ {err_msg}")
                    db.add_history(
                        channel_id=channel_data["id"],
                        channel_name=channel_data["name"],
                        video_title=caption,
                        video_path=video_path,
                        status="failed",
                        error_message=err_msg
                    )
                    notifier.notify_upload_failed(channel_data.get("name", "Kênh TikTok"), caption or os.path.basename(video_path), err_msg)
                    return False, err_msg

            except Exception as e:
                _safe_close_context(context, profile_dir)
                raw_e = str(e)
                if "has been closed" in raw_e or "Target page" in raw_e:
                    err_msg = "Trình duyệt Chrome bị đóng đột ngột hoặc mất kết nối Proxy khi đang tải trang TikTok Studio."
                elif "Timeout" in raw_e:
                    err_msg = "Quá thời gian kết nối TikTok Studio (Proxy hoặc mạng tạm thời phản hồi chậm)."
                else:
                    err_msg = f"Lỗi đăng video: {raw_e}"
                log(f"❌ {err_msg}")
                db.add_history(
                    channel_id=channel_data["id"],
                    channel_name=channel_data["name"],
                    video_title=caption,
                    video_path=video_path,
                    status="failed",
                    error_message=err_msg
                )
                notifier.notify_upload_failed(channel_data.get("name", "Kênh TikTok"), caption or os.path.basename(video_path), err_msg)
                return False, err_msg

            finally:
                try:
                    cleanup_profile_locks(profile_dir, kill_existing_processes=False)
                except Exception:
                    pass
                try:
                    # Tự động dọn dẹp các mảnh video tạm trong IndexedDB blobs để không chiếm dung lượng đĩa
                    idb_dir = os.path.join(profile_dir, "Default", "IndexedDB")
                    if os.path.exists(idb_dir):
                        import shutil
                        for sub in os.listdir(idb_dir):
                            if sub.endswith(".blob"):
                                shutil.rmtree(os.path.join(idb_dir, sub), ignore_errors=True)
                except Exception:
                    pass

uploader = TikTokUploader()
