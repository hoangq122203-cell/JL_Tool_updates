import os
import re
import time
import unicodedata
from typing import Optional, List, Dict
from pathlib import Path

COMMON_SEARCH_ROOTS = [
    str(Path(__file__).resolve().parent.parent / "data" / "videos"),
    str(Path.home() / "Desktop" / "hitomi_downloaded_youtube"),
    str(Path.home() / "Desktop" / "hitomi_downloaded_tiktok"),
    str(Path.home() / "Downloads"),
]

# Bộ nhớ đệm kết quả tìm kiếm (tránh quét đĩa liên tục gây giật lag)
_RESOLVE_CACHE: Dict[str, Optional[str]] = {}
_LAST_CACHE_TIME: float = 0.0

def normalize_text(text: str) -> str:
    """Chuẩn hóa chuỗi văn bản để so khớp nhanh không phụ thuộc vào dấu unicode"""
    if not text:
        return ""
    text = unicodedata.normalize('NFKD', text)
    text = text.replace('｜', '|').replace('：', ':').replace('＊', '*').replace('　', ' ')
    text = re.sub(r'[\r\n\t]+', ' ', text)
    return text.strip().lower()

def resolve_video_path(video_path: str, caption: str = "", extra_folder: str = "") -> Optional[str]:
    """
    Tự động tìm kiếm đường dẫn video với cơ chế Cache thông minh và giới hạn độ sâu quét.
    Tuyệt đối không quét tràn lan toàn bộ ổ đĩa, đảm bảo ứng dụng luôn mượt mà 60 FPS.
    """
    global _RESOLVE_CACHE, _LAST_CACHE_TIME

    if video_path and os.path.isfile(video_path):
        return os.path.normpath(video_path)

    if not video_path and not caption:
        return None

    cache_key = f"{video_path}|{caption}|{extra_folder}"
    now = time.time()

    # Dọn cache sau mỗi 60 giây
    if now - _LAST_CACHE_TIME > 60:
        _RESOLVE_CACHE.clear()
        _LAST_CACHE_TIME = now

    if cache_key in _RESOLVE_CACHE:
        cached_result = _RESOLVE_CACHE[cache_key]
        if cached_result and os.path.isfile(cached_result):
            return cached_result
        elif cached_result is None:
            return None

    filename = os.path.basename(video_path) if video_path else ""
    clean_target_name = normalize_text(filename)

    search_dirs = []
    if extra_folder and os.path.isdir(extra_folder):
        search_dirs.append(extra_folder)
    for root in COMMON_SEARCH_ROOTS:
        if os.path.isdir(root) and root not in search_dirs:
            search_dirs.append(root)

    # Quét nhanh có giới hạn độ sâu (chỉ quét tối đa 2 cấp thư mục: root/folder/file.mp4)
    if filename:
        for root_dir in search_dirs:
            try:
                for entry in os.scandir(root_dir):
                    if entry.is_file() and entry.name.lower() == filename.lower():
                        found = os.path.normpath(entry.path)
                        _RESOLVE_CACHE[cache_key] = found
                        return found
                    elif entry.is_dir():
                        try:
                            for sub in os.scandir(entry.path):
                                if sub.is_file() and sub.name.lower() == filename.lower():
                                    found = os.path.normpath(sub.path)
                                    _RESOLVE_CACHE[cache_key] = found
                                    return found
                        except Exception:
                            continue
            except Exception:
                continue

    # Thử quét theo tên chuẩn hóa nếu chưa tìm thấy
    if clean_target_name:
        for root_dir in search_dirs:
            try:
                for entry in os.scandir(root_dir):
                    if entry.is_dir():
                        try:
                            for sub in os.scandir(entry.path):
                                if sub.is_file() and normalize_text(sub.name) == clean_target_name:
                                    found = os.path.normpath(sub.path)
                                    _RESOLVE_CACHE[cache_key] = found
                                    return found
                        except Exception:
                            continue
            except Exception:
                continue

    _RESOLVE_CACHE[cache_key] = None
    return None
