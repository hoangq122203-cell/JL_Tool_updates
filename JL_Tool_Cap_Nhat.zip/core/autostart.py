"""
Module tương thích cho autostart (chuyển hướng sang core.startup_manager)
"""
import sys
try:
    from core.startup_manager import (
        enable_windows_startup,
        disable_windows_startup,
        is_windows_startup_enabled,
        keep_system_awake
    )

    def enable_autostart():
        return enable_windows_startup(True)

    def disable_autostart():
        return enable_windows_startup(False)
except Exception:
    def enable_autostart():
        pass
    def disable_autostart():
        pass

