# Danh mục toàn diện các quốc gia với mã vùng CHUẨN XÁC 100% của PIA VPN & HMA VPN

ALL_VPN_COUNTRIES = [
    # ==================== CHÂU Á & THÁI BÌNH DƯƠNG ====================
    {"name": "🇻🇳 Việt Nam (Vietnam)", "code": "vietnam", "region": "asia"},
    {"name": "🇯🇵 Nhật Bản (Japan - Tokyo)", "code": "jp-tokyo", "region": "asia"},
    {"name": "🇰🇷 Hàn Quốc (South Korea - Seoul)", "code": "south-korea", "region": "asia"},
    {"name": "🇸🇬 Singapore", "code": "singapore", "region": "asia"},
    {"name": "🇹🇼 Đài Loan (Taiwan)", "code": "taiwan", "region": "asia"},
    {"name": "🇭🇰 Hồng Kông (Hong Kong)", "code": "hong-kong", "region": "asia"},
    {"name": "🇹🇭 Thái Lan (Thailand - Bangkok)", "code": "thailand", "region": "asia"},
    {"name": "🇲🇾 Malaysia (Kuala Lumpur)", "code": "malaysia", "region": "asia"},
    {"name": "🇮🇩 Indonesia (Jakarta)", "code": "indonesia", "region": "asia"},
    {"name": "🇵🇭 Philippines (Manila)", "code": "philippines", "region": "asia"},
    {"name": "🇮🇳 Ấn Độ (India - Mumbai)", "code": "india", "region": "asia"},
    {"name": "🇰🇭 Campuchia (Cambodia)", "code": "cambodia", "region": "asia"},
    {"name": "🇧🇩 Bangladesh (Dhaka)", "code": "bangladesh", "region": "asia"},
    {"name": "🇲🇳 Mông Cổ (Mongolia)", "code": "mongolia", "region": "asia"},
    {"name": "🇦🇺 Úc - Sydney (Australia)", "code": "au-sydney", "region": "oceania"},
    {"name": "🇦🇺 Úc - Melbourne (Australia)", "code": "au-melbourne", "region": "oceania"},
    {"name": "🇳🇿 New Zealand (Auckland)", "code": "new-zealand", "region": "oceania"},

    # ==================== HOA KỲ & CHÂU MỸ ====================
    {"name": "🇺🇸 Hoa Kỳ - California (US West)", "code": "us-california", "region": "americas"},
    {"name": "🇺🇸 Hoa Kỳ - New York (US East)", "code": "us-new-york", "region": "americas"},
    {"name": "🇺🇸 Hoa Kỳ - Texas (US South)", "code": "us-texas", "region": "americas"},
    {"name": "🇺🇸 Hoa Kỳ - Florida (US Southeast)", "code": "us-florida", "region": "americas"},
    {"name": "🇺🇸 Hoa Kỳ - Chicago (US Midwest)", "code": "us-chicago", "region": "americas"},
    {"name": "🇺🇸 Hoa Kỳ - Washington DC", "code": "us-washington-dc", "region": "americas"},
    {"name": "🇺🇸 Hoa Kỳ - Seattle", "code": "us-seattle", "region": "americas"},
    {"name": "🇺🇸 Hoa Kỳ - Silicon Valley", "code": "us-silicon-valley", "region": "americas"},
    {"name": "🇨🇦 Canada - Toronto (Ontario)", "code": "ca-toronto", "region": "americas"},
    {"name": "🇨🇦 Canada - Montreal (Quebec)", "code": "ca-montreal", "region": "americas"},
    {"name": "🇨🇦 Canada - Vancouver", "code": "ca-vancouver", "region": "americas"},
    {"name": "🇲🇽 Mexico (Mexico City)", "code": "mexico", "region": "americas"},
    {"name": "🇧🇷 Brazil (Sao Paulo)", "code": "brazil", "region": "americas"},
    {"name": "🇦🇷 Argentina (Buenos Aires)", "code": "argentina", "region": "americas"},
    {"name": "🇨🇱 Chile (Santiago)", "code": "chile", "region": "americas"},
    {"name": "🇨🇴 Colombia (Bogota)", "code": "colombia", "region": "americas"},
    {"name": "🇨🇷 Costa Rica (San Jose)", "code": "costa-rica", "region": "americas"},
    {"name": "🇵🇦 Panama (Panama City)", "code": "panama", "region": "americas"},
    {"name": "🇵🇪 Peru (Lima)", "code": "peru", "region": "americas"},

    # ==================== CHÂU ÂU ====================
    {"name": "🇬🇧 Vương Quốc Anh - London (UK)", "code": "uk-london", "region": "europe"},
    {"name": "🇬🇧 Vương Quốc Anh - Southampton (UK)", "code": "uk-southampton", "region": "europe"},
    {"name": "🇩🇪 Đức - Frankfurt (Germany)", "code": "de-frankfurt", "region": "europe"},
    {"name": "🇩🇪 Đức - Berlin (Germany)", "code": "de-berlin", "region": "europe"},
    {"name": "🇫🇷 Pháp - Paris (France)", "code": "france", "region": "europe"},
    {"name": "🇳🇱 Hà Lan (Netherlands - Amsterdam)", "code": "netherlands", "region": "europe"},
    {"name": "🇨🇭 Thụy Sĩ (Switzerland - Zurich)", "code": "switzerland", "region": "europe"},
    {"name": "🇸🇪 Thụy Điển (Sweden - Stockholm)", "code": "se-stockholm", "region": "europe"},
    {"name": "🇳🇴 Na Uy (Norway - Oslo)", "code": "norway", "region": "europe"},
    {"name": "🇩🇰 Đan Mạch (Denmark - Copenhagen)", "code": "denmark", "region": "europe"},
    {"name": "🇫🇮 Phần Lan (Finland - Helsinki)", "code": "fi-helsinki", "region": "europe"},
    {"name": "🇪🇸 Tây Ban Nha - Madrid (Spain)", "code": "es-madrid", "region": "europe"},
    {"name": "🇪🇸 Tây Ban Nha - Valencia (Spain)", "code": "es-valencia", "region": "europe"},
    {"name": "🇮🇹 Ý - Milan (Italy)", "code": "it-milano", "region": "europe"},
    {"name": "🇮🇹 Ý - Naples (Italy)", "code": "it-naples", "region": "europe"},
    {"name": "🇵🇹 Bồ Đào Nha (Portugal - Lisbon)", "code": "portugal", "region": "europe"},
    {"name": "🇧🇪 Bỉ (Belgium - Brussels)", "code": "belgium", "region": "europe"},
    {"name": "🇦🇹 Áo (Austria - Vienna)", "code": "austria", "region": "europe"},
    {"name": "🇵🇱 Ba Lan (Poland - Warsaw)", "code": "poland", "region": "europe"},
    {"name": "🇨🇿 Cộng hòa Séc (Czech Republic - Prague)", "code": "czech-republic", "region": "europe"},
    {"name": "🇬🇷 Hy Lạp (Greece - Athens)", "code": "greece", "region": "europe"},
    {"name": "🇮🇪 Ireland (Dublin)", "code": "ireland", "region": "europe"},
    {"name": "🇷🇴 Romania (Bucharest)", "code": "romania", "region": "europe"},
    {"name": "🇭🇺 Hungary (Budapest)", "code": "hungary", "region": "europe"},
    {"name": "🇹🇷 Thổ Nhĩ Kỳ (Turkey - Istanbul)", "code": "turkey", "region": "europe"},
    {"name": "🇺🇦 Ukraine (Kyiv)", "code": "ukraine", "region": "europe"},
    {"name": "🇮🇸 Iceland (Reykjavik)", "code": "iceland", "region": "europe"},
    {"name": "🇱🇺 Luxembourg", "code": "luxembourg", "region": "europe"},
    {"name": "🇧🇬 Bulgaria (Sofia)", "code": "bulgaria", "region": "europe"},
    {"name": "🇷🇸 Serbia (Belgrade)", "code": "serbia", "region": "europe"},
    {"name": "🇭🇷 Croatia (Zagreb)", "code": "croatia", "region": "europe"},
    {"name": "🇸🇰 Slovakia (Bratislava)", "code": "slovakia", "region": "europe"},
    {"name": "🇸🇮 Slovenia (Ljubljana)", "code": "slovenia", "region": "europe"},
    {"name": "🇪🇪 Estonia (Tallinn)", "code": "estonia", "region": "europe"},
    {"name": "🇱🇻 Latvia (Riga)", "code": "latvia", "region": "europe"},
    {"name": "🇱🇹 Lithuania (Vilnius)", "code": "lithuania", "region": "europe"},
    {"name": "🇨🇾 Cyprus (Nicosia)", "code": "cyprus", "region": "europe"},
    {"name": "🇲🇹 Malta", "code": "malta", "region": "europe"},

    # ==================== TRUNG ĐÔNG & CHÂU PHI ====================
    {"name": "🇦🇪 UAE - Dubai (Các Tiểu vương quốc Ả Rập)", "code": "united-arab-emirates", "region": "middle_east"},
    {"name": "🇮🇱 Israel (Tel Aviv)", "code": "israel", "region": "middle_east"},
    {"name": "🇸🇦 Ả Rập Xê Út (Saudi Arabia - Riyadh)", "code": "saudi-arabia", "region": "middle_east"},
    {"name": "🇶🇦 Qatar (Doha)", "code": "qatar", "region": "middle_east"},
    {"name": "🇿🇦 Nam Phi (South Africa - Johannesburg)", "code": "south-africa", "region": "africa"},
    {"name": "🇪🇬 Ai Cập (Egypt - Cairo)", "code": "egypt", "region": "africa"},
    {"name": "🇳🇬 Nigeria (Lagos)", "code": "nigeria", "region": "africa"},
    {"name": "🇰🇪 Kenya (Nairobi)", "code": "kenya", "region": "africa"},
    {"name": "🇲🇦 Morocco (Rabat)", "code": "morocco", "region": "africa"},
    {"name": "🇩🇿 Algeria (Algiers)", "code": "algeria", "region": "africa"}
]

# Cấu hình Môi trường Trình duyệt (Locale, Timezone, Geolocation) chuẩn từng Quốc gia
REGION_PROFILES = {
    "vietnam": {
        "locale": "vi-VN",
        "timezone_id": "Asia/Ho_Chi_Minh",
        "geolocation": {"latitude": 21.0285, "longitude": 105.8542, "accuracy": 50},
        "country": "VN"
    },
    "philippines": {
        "locale": "en-PH",
        "timezone_id": "Asia/Manila",
        "geolocation": {"latitude": 14.5995, "longitude": 120.9842, "accuracy": 50},
        "country": "PH"
    },
    "singapore": {
        "locale": "en-SG",
        "timezone_id": "Asia/Singapore",
        "geolocation": {"latitude": 1.3521, "longitude": 103.8198, "accuracy": 50},
        "country": "SG"
    },
    "jp-tokyo": {
        "locale": "ja-JP",
        "timezone_id": "Asia/Tokyo",
        "geolocation": {"latitude": 35.6762, "longitude": 139.6503, "accuracy": 50},
        "country": "JP"
    },
    "south-korea": {
        "locale": "ko-KR",
        "timezone_id": "Asia/Seoul",
        "geolocation": {"latitude": 37.5665, "longitude": 126.9780, "accuracy": 50},
        "country": "KR"
    },
    "taiwan": {
        "locale": "zh-TW",
        "timezone_id": "Asia/Taipei",
        "geolocation": {"latitude": 25.0330, "longitude": 121.5654, "accuracy": 50},
        "country": "TW"
    },
    "hong-kong": {
        "locale": "zh-HK",
        "timezone_id": "Asia/Hong_Kong",
        "geolocation": {"latitude": 22.3193, "longitude": 114.1694, "accuracy": 50},
        "country": "HK"
    },
    "thailand": {
        "locale": "th-TH",
        "timezone_id": "Asia/Bangkok",
        "geolocation": {"latitude": 13.7563, "longitude": 100.5018, "accuracy": 50},
        "country": "TH"
    },
    "malaysia": {
        "locale": "en-MY",
        "timezone_id": "Asia/Kuala_Lumpur",
        "geolocation": {"latitude": 3.1390, "longitude": 101.6869, "accuracy": 50},
        "country": "MY"
    },
    "indonesia": {
        "locale": "id-ID",
        "timezone_id": "Asia/Jakarta",
        "geolocation": {"latitude": -6.2088, "longitude": 106.8456, "accuracy": 50},
        "country": "ID"
    },
    "india": {
        "locale": "en-IN",
        "timezone_id": "Asia/Kolkata",
        "geolocation": {"latitude": 19.0760, "longitude": 72.8777, "accuracy": 50},
        "country": "IN"
    },
    "cambodia": {
        "locale": "km-KH",
        "timezone_id": "Asia/Phnom_Penh",
        "geolocation": {"latitude": 11.5564, "longitude": 104.9282, "accuracy": 50},
        "country": "KH"
    },
    "au-sydney": {
        "locale": "en-AU",
        "timezone_id": "Australia/Sydney",
        "geolocation": {"latitude": -33.8688, "longitude": 151.2093, "accuracy": 50},
        "country": "AU"
    },
    "au-melbourne": {
        "locale": "en-AU",
        "timezone_id": "Australia/Melbourne",
        "geolocation": {"latitude": -37.8136, "longitude": 144.9631, "accuracy": 50},
        "country": "AU"
    },
    "new-zealand": {
        "locale": "en-NZ",
        "timezone_id": "Pacific/Auckland",
        "geolocation": {"latitude": -36.8485, "longitude": 174.7633, "accuracy": 50},
        "country": "NZ"
    },
    "us-california": {
        "locale": "en-US",
        "timezone_id": "America/Los_Angeles",
        "geolocation": {"latitude": 34.0522, "longitude": -118.2437, "accuracy": 50},
        "country": "US"
    },
    "us-silicon-valley": {
        "locale": "en-US",
        "timezone_id": "America/Los_Angeles",
        "geolocation": {"latitude": 37.3861, "longitude": -122.0839, "accuracy": 50},
        "country": "US"
    },
    "us-seattle": {
        "locale": "en-US",
        "timezone_id": "America/Los_Angeles",
        "geolocation": {"latitude": 47.6062, "longitude": -122.3321, "accuracy": 50},
        "country": "US"
    },
    "us-new-york": {
        "locale": "en-US",
        "timezone_id": "America/New_York",
        "geolocation": {"latitude": 40.7128, "longitude": -74.0060, "accuracy": 50},
        "country": "US"
    },
    "us-washington-dc": {
        "locale": "en-US",
        "timezone_id": "America/New_York",
        "geolocation": {"latitude": 38.9072, "longitude": -77.0369, "accuracy": 50},
        "country": "US"
    },
    "us-florida": {
        "locale": "en-US",
        "timezone_id": "America/New_York",
        "geolocation": {"latitude": 25.7617, "longitude": -80.1918, "accuracy": 50},
        "country": "US"
    },
    "us-texas": {
        "locale": "en-US",
        "timezone_id": "America/Chicago",
        "geolocation": {"latitude": 29.7604, "longitude": -95.3698, "accuracy": 50},
        "country": "US"
    },
    "us-chicago": {
        "locale": "en-US",
        "timezone_id": "America/Chicago",
        "geolocation": {"latitude": 41.8781, "longitude": -87.6298, "accuracy": 50},
        "country": "US"
    },
    "ca-toronto": {
        "locale": "en-CA",
        "timezone_id": "America/Toronto",
        "geolocation": {"latitude": 43.6532, "longitude": -79.3832, "accuracy": 50},
        "country": "CA"
    },
    "ca-montreal": {
        "locale": "fr-CA",
        "timezone_id": "America/Montreal",
        "geolocation": {"latitude": 45.5017, "longitude": -73.5673, "accuracy": 50},
        "country": "CA"
    },
    "ca-vancouver": {
        "locale": "en-CA",
        "timezone_id": "America/Vancouver",
        "geolocation": {"latitude": 49.2827, "longitude": -123.1207, "accuracy": 50},
        "country": "CA"
    },
    "mexico": {
        "locale": "es-MX",
        "timezone_id": "America/Mexico_City",
        "geolocation": {"latitude": 19.4326, "longitude": -99.1332, "accuracy": 50},
        "country": "MX"
    },
    "brazil": {
        "locale": "pt-BR",
        "timezone_id": "America/Sao_Paulo",
        "geolocation": {"latitude": -23.5505, "longitude": -46.6333, "accuracy": 50},
        "country": "BR"
    },
    "uk-london": {
        "locale": "en-GB",
        "timezone_id": "Europe/London",
        "geolocation": {"latitude": 51.5074, "longitude": -0.1278, "accuracy": 50},
        "country": "GB"
    },
    "uk-southampton": {
        "locale": "en-GB",
        "timezone_id": "Europe/London",
        "geolocation": {"latitude": 50.9097, "longitude": -1.4044, "accuracy": 50},
        "country": "GB"
    },
    "de-frankfurt": {
        "locale": "de-DE",
        "timezone_id": "Europe/Berlin",
        "geolocation": {"latitude": 50.1109, "longitude": 8.6821, "accuracy": 50},
        "country": "DE"
    },
    "de-berlin": {
        "locale": "de-DE",
        "timezone_id": "Europe/Berlin",
        "geolocation": {"latitude": 52.5200, "longitude": 13.4050, "accuracy": 50},
        "country": "DE"
    },
    "france": {
        "locale": "fr-FR",
        "timezone_id": "Europe/Paris",
        "geolocation": {"latitude": 48.8566, "longitude": 2.3522, "accuracy": 50},
        "country": "FR"
    },
    "netherlands": {
        "locale": "nl-NL",
        "timezone_id": "Europe/Amsterdam",
        "geolocation": {"latitude": 52.3676, "longitude": 4.9041, "accuracy": 50},
        "country": "NL"
    },
    "switzerland": {
        "locale": "de-CH",
        "timezone_id": "Europe/Zurich",
        "geolocation": {"latitude": 47.3769, "longitude": 8.5417, "accuracy": 50},
        "country": "CH"
    },
    "se-stockholm": {
        "locale": "sv-SE",
        "timezone_id": "Europe/Stockholm",
        "geolocation": {"latitude": 59.3293, "longitude": 18.0686, "accuracy": 50},
        "country": "SE"
    },
    "norway": {
        "locale": "nb-NO",
        "timezone_id": "Europe/Oslo",
        "geolocation": {"latitude": 59.9139, "longitude": 10.7522, "accuracy": 50},
        "country": "NO"
    },
    "denmark": {
        "locale": "da-DK",
        "timezone_id": "Europe/Copenhagen",
        "geolocation": {"latitude": 55.6761, "longitude": 12.5683, "accuracy": 50},
        "country": "DK"
    },
    "es-madrid": {
        "locale": "es-ES",
        "timezone_id": "Europe/Madrid",
        "geolocation": {"latitude": 40.4168, "longitude": -3.7038, "accuracy": 50},
        "country": "ES"
    },
    "it-milano": {
        "locale": "it-IT",
        "timezone_id": "Europe/Rome",
        "geolocation": {"latitude": 45.4642, "longitude": 9.1900, "accuracy": 50},
        "country": "IT"
    },
    "poland": {
        "locale": "pl-PL",
        "timezone_id": "Europe/Warsaw",
        "geolocation": {"latitude": 52.2297, "longitude": 21.0122, "accuracy": 50},
        "country": "PL"
    },
    "turkey": {
        "locale": "tr-TR",
        "timezone_id": "Europe/Istanbul",
        "geolocation": {"latitude": 41.0082, "longitude": 28.9784, "accuracy": 50},
        "country": "TR"
    }
}

def get_region_profile(code_or_name: str = "") -> dict:
    """
    Trả về cấu hình trình duyệt (locale, timezone_id, geolocation) đồng bộ 100%
    với quốc gia fake để TikTok không bao giờ nhận diện nhầm về Việt Nam!
    """
    val = (code_or_name or "").strip().lower()
    if val in REGION_PROFILES:
        return REGION_PROFILES[val]
    
    # Tìm kiếm theo từ khóa
    if "philippines" in val or "manila" in val:
        return REGION_PROFILES["philippines"]
    if "us-" in val or "california" in val or "united states" in val or "hoa kỳ" in val:
        return REGION_PROFILES["us-california"]
    if "new-york" in val or "florida" in val:
        return REGION_PROFILES["us-new-york"]
    if "singapore" in val:
        return REGION_PROFILES["singapore"]
    if "tokyo" in val or "japan" in val or "nhật" in val:
        return REGION_PROFILES["jp-tokyo"]
    if "korea" in val or "hàn" in val:
        return REGION_PROFILES["south-korea"]
    if "london" in val or "uk" in val or "anh" in val:
        return REGION_PROFILES["uk-london"]
    if "germany" in val or "đức" in val or "frankfurt" in val:
        return REGION_PROFILES["de-frankfurt"]
    if "france" in val or "pháp" in val or "paris" in val:
        return REGION_PROFILES["france"]
    if "australia" in val or "úc" in val or "sydney" in val:
        return REGION_PROFILES["au-sydney"]
    if "canada" in val or "toronto" in val:
        return REGION_PROFILES["ca-toronto"]
    if "thailand" in val or "thái" in val or "bangkok" in val:
        return REGION_PROFILES["thailand"]
    if "taiwan" in val or "đài" in val:
        return REGION_PROFILES["taiwan"]
    if "vietnam" in val or "việt" in val:
        return REGION_PROFILES["vietnam"]

    # Mặc định an toàn cho Fake IP nước ngoài (US California)
    return REGION_PROFILES["us-california"]

def get_country_display_name(code_or_name: str = "") -> str:
    """Trả về tên hiển thị đẹp mắt, rõ ràng của quốc gia"""
    val = (code_or_name or "").strip().lower()
    for item in ALL_VPN_COUNTRIES:
        if item["code"].lower() == val or val in item["name"].lower():
            clean = item["name"]
            for icon in ["🇻🇳", "🇯🇵", "🇰🇷", "🇸🇬", "🇹🇼", "🇭🇰", "🇹🇭", "🇲🇾", "🇮🇩", "🇵🇭", "🇮🇳", "🇦🇺", "🇺🇸", "🇨🇦", "🇬🇧", "🇩🇪", "🇫🇷", "🇳🇱"]:
                clean = clean.replace(icon, "").strip()
            return clean
    prof = get_region_profile(code_or_name)
    cnt = prof.get("country", "")
    if cnt == "PH": return "Philippines (Manila)"
    if cnt == "US": return "Hoa Kỳ (Mỹ)"
    if cnt == "SG": return "Singapore"
    if cnt == "JP": return "Nhật Bản (Tokyo)"
    if cnt == "KR": return "Hàn Quốc (Seoul)"
    if cnt == "GB": return "Vương Quốc Anh (London)"
    if cnt == "DE": return "Đức (Frankfurt)"
    if cnt == "FR": return "Pháp (Paris)"
    if cnt == "AU": return "Úc (Sydney)"
    if cnt == "CA": return "Canada (Toronto)"
    return f"Quốc gia [{cnt}]" if cnt else "Quốc tế (Fake IP)"

def get_channel_region_profile(channel_data: dict) -> dict:
    """Lấy profile vùng (bao gồm timezone_id, country, locale) chuẩn xác nhất cho kênh"""
    from database.db_manager import db
    reg = (channel_data.get("vpn_region") or "").strip()
    if not reg:
        reg = (channel_data.get("target_country") or "").strip()
    if not reg:
        reg = db.get_setting("global_vpn_region", "philippines")
    prof = dict(get_region_profile(reg))
    prof["country_name"] = get_country_display_name(reg)
    return prof

# Bảng múi giờ chuẩn tích hợp sẵn (Pure Python Fallback) giúp máy khách Windows
# hoạt động 100% ổn định ngay cả khi chưa cài đặt thư viện tzdata hoặc pytz!
BUILTIN_TZ_OFFSETS = {
    "Asia/Ho_Chi_Minh": (7.0, "ICT"),
    "Asia/Bangkok": (7.0, "ICT"),
    "Asia/Phnom_Penh": (7.0, "ICT"),
    "Asia/Jakarta": (7.0, "WIB"),
    "Asia/Manila": (8.0, "PST"),
    "Asia/Singapore": (8.0, "SGT"),
    "Asia/Kuala_Lumpur": (8.0, "MYT"),
    "Asia/Taipei": (8.0, "CST"),
    "Asia/Hong_Kong": (8.0, "HKT"),
    "Asia/Tokyo": (9.0, "JST"),
    "Asia/Seoul": (9.0, "KST"),
    "Asia/Kolkata": (5.5, "IST"),
    "Australia/Sydney": (10.0, "AEST"),
    "Australia/Melbourne": (10.0, "AEST"),
    "Pacific/Auckland": (12.0, "NZST"),
    "America/Los_Angeles": (-8.0, "PST"),
    "America/Vancouver": (-8.0, "PST"),
    "America/Chicago": (-6.0, "CST"),
    "America/Mexico_City": (-6.0, "CST"),
    "America/New_York": (-5.0, "EST"),
    "America/Toronto": (-5.0, "EST"),
    "America/Montreal": (-5.0, "EST"),
    "America/Sao_Paulo": (-3.0, "BRT"),
    "Europe/London": (0.0, "GMT"),
    "Europe/Berlin": (1.0, "CET"),
    "Europe/Paris": (1.0, "CET"),
    "Europe/Amsterdam": (1.0, "CET"),
    "Europe/Zurich": (1.0, "CET"),
    "Europe/Stockholm": (1.0, "CET"),
    "Europe/Oslo": (1.0, "CET"),
    "Europe/Copenhagen": (1.0, "CET"),
    "Europe/Madrid": (1.0, "CET"),
    "Europe/Rome": (1.0, "CET"),
    "Europe/Warsaw": (1.0, "CET"),
    "Europe/Istanbul": (3.0, "TRT"),
}

def get_safe_tzinfo(timezone_id: str):
    """
    Lấy đối tượng múi giờ chuẩn xác cho mọi hệ điều hành Windows:
    1. Ưu tiên ZoneInfo (Python chuẩn + tzdata)
    2. Dự phòng pytz (nếu có)
    3. Dự phòng 100% Pure Python datetime.timezone (không bao giờ lỗi thiếu module trên máy khách!)
    """
    from datetime import timezone, timedelta
    try:
        from zoneinfo import ZoneInfo
        return ZoneInfo(timezone_id)
    except Exception:
        pass
    try:
        import pytz
        return pytz.timezone(timezone_id)
    except Exception:
        pass
    offset_hours, tz_name = BUILTIN_TZ_OFFSETS.get(timezone_id, (8.0, "UTC+8"))
    return timezone(timedelta(hours=offset_hours), name=tz_name)

def convert_target_golden_to_local(target_h: int, target_m: int, timezone_id: str, target_date=None) -> tuple:
    """
    Chuyển đổi giờ vàng ở nước mục tiêu (Fake IP) sang giờ máy tính cục bộ (Việt Nam).
    Đảm bảo video xuất bản đúng giờ cao điểm của khán giả nước ngoài!
    Trả về (datetime_o_nuoc_do, datetime_may_tinh_viet_nam)
    """
    from datetime import datetime, timedelta
    target_tz = get_safe_tzinfo(timezone_id)

    now_target = datetime.now(target_tz)
    if target_date is None:
        target_dt = now_target.replace(hour=target_h, minute=target_m, second=0, microsecond=0)
        if target_dt <= now_target:
            target_dt += timedelta(days=1)
    else:
        target_dt = datetime(target_date.year, target_date.month, target_date.day, target_h, target_m, 0, tzinfo=target_tz)
        if target_dt <= now_target:
            target_dt += timedelta(days=1)

    local_tz = datetime.now().astimezone().tzinfo
    local_dt = target_dt.astimezone(local_tz)
    return target_dt, local_dt.replace(tzinfo=None)

def convert_local_to_target_time(local_dt, timezone_id: str):
    """Chuyển đổi giờ máy tính Việt Nam sang giờ tại nước mục tiêu (Fake IP)"""
    from datetime import datetime
    target_tz = get_safe_tzinfo(timezone_id)

    local_tz = datetime.now().astimezone().tzinfo
    aware_local = local_dt.replace(tzinfo=local_tz)
    return aware_local.astimezone(target_tz)
