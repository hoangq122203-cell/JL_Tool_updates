import os
import sys
import shutil
import sqlite3
import subprocess
import tempfile
import time
import threading
from pathlib import Path
from typing import Tuple, Optional, Dict, Any, List
import config
from database.db_manager import db
from core.network_manager import network_mgr

class ChromeManager:
    def __init__(self):
        self._login_listeners = []
        self._watching_channels = {}
        self._watcher_lock = threading.Lock()
        self._watcher_running = False

    def register_login_listener(self, callback):
        """Đăng ký hàm xử lý khi có kênh đăng nhập thành công"""
        with self._watcher_lock:
            if callback not in self._login_listeners:
                self._login_listeners.append(callback)

    def unregister_login_listener(self, callback):
        with self._watcher_lock:
            if callback in self._login_listeners:
                self._login_listeners.remove(callback)

    def notify_login_detected(self, channel_id: int, channel_name: str):
        """Kích hoạt tất cả callback khi phát hiện đăng nhập"""
        with self._watcher_lock:
            listeners = list(self._login_listeners)
        for cb in listeners:
            try:
                cb(channel_id, channel_name)
            except Exception as e:
                print(f"[ChromeManager] Lỗi listener login: {e}")

    def start_login_watcher(self, channel_id: int, channel_name: str, profile_dir: str):
        """
        Bắt đầu theo dõi ngầm cookie của Profile này mỗi 1.5 - 2 giây.
        Ngay khi người dùng đăng nhập TikTok trên Web xong, Tool sẽ tự động nhận diện và đồng bộ!
        """
        if not channel_id or not profile_dir:
            return
        with self._watcher_lock:
            self._watching_channels[channel_id] = {
                "name": channel_name,
                "profile_dir": profile_dir,
                "start_time": time.time(),
                "max_duration": 600  # Theo dõi tối đa 10 phút
            }
            if not self._watcher_running:
                self._watcher_running = True
                threading.Thread(target=self._run_login_watcher_loop, daemon=True).start()

    def _run_login_watcher_loop(self):
        """Vòng lặp ngầm kiểm tra cookie của các profile đang mở đăng nhập"""
        while True:
            time.sleep(2.0)
            with self._watcher_lock:
                if not self._watching_channels:
                    self._watcher_running = False
                    break
                items = list(self._watching_channels.items())

            for cid, data in items:
                # Kiểm tra quá hạn
                if time.time() - data["start_time"] > data["max_duration"]:
                    with self._watcher_lock:
                        self._watching_channels.pop(cid, None)
                    continue

                try:
                    if self.check_login_status_by_cookies(data["profile_dir"]):
                        # Đã phát hiện đăng nhập thành công!
                        with self._watcher_lock:
                            self._watching_channels.pop(cid, None)
                        # Cập nhật ngay vào Database
                        db.update_channel_login_status(cid, True)
                        # Thông báo đồng bộ đến toàn bộ hệ thống
                        self.notify_login_detected(cid, data["name"])
                except Exception as e:
                    print(f"[LoginWatcher] Lỗi kiểm tra kênh {cid}: {e}")

    def get_chrome_path(self) -> str:
        """Lấy đường dẫn Chrome từ Cài đặt hoặc mặc định"""
        saved_path = db.get_setting("chrome_path", "")
        if saved_path and os.path.isfile(saved_path):
            return saved_path
        
        default_path = config.find_chrome_path()
        if default_path:
            db.set_setting("chrome_path", default_path)
            return default_path
            
        return ""

    def get_profile_dir(self, channel_id: int, custom_path: str = "") -> str:
        """Lấy hoặc tạo thư mục Chrome Profile riêng biệt cho kênh"""
        if custom_path and os.path.isabs(custom_path):
            p = Path(custom_path)
        else:
            base_profiles_dir = Path(db.get_setting("profiles_dir", str(config.PROFILES_DIR)))
            p = base_profiles_dir / f"channel_{channel_id}"
            
        p.mkdir(parents=True, exist_ok=True)
        return str(p)

    def resolve_profile_path(self, path_str: str) -> str:
        """Tự động chuyển đổi đường dẫn profile nếu tool được copy sang máy tính khác"""
        if not path_str:
            return ""
        p = Path(path_str)
        if p.exists():
            return str(p)
        # Nếu đường dẫn từ máy tính cũ không tồn tại trên máy mới, tự động ánh xạ vào thư mục profiles hiện tại
        local_p = config.PROFILES_DIR / p.name
        local_p.mkdir(parents=True, exist_ok=True)
        return str(local_p)

    @staticmethod
    def to_safe_path(path_str: str) -> str:
        """Chuyển đường dẫn sang 8.3 short path trên Windows để đảm bảo 100% không lỗi Unicode tiếng Việt hoặc dấu cách với Chrome/Crashpad"""
        if not path_str or sys.platform != "win32":
            return path_str
        try:
            import ctypes
            from ctypes import wintypes
            _GetShortPathNameW = ctypes.windll.kernel32.GetShortPathNameW
            _GetShortPathNameW.argtypes = [wintypes.LPCWSTR, wintypes.LPWSTR, wintypes.DWORD]
            _GetShortPathNameW.restype = wintypes.DWORD
            
            buf_size = _GetShortPathNameW(path_str, None, 0)
            if buf_size > 0:
                buf = ctypes.create_unicode_buffer(buf_size)
                if _GetShortPathNameW(path_str, buf, buf_size) > 0 and buf.value:
                    return buf.value
        except Exception:
            pass
        return path_str

    def _kill_existing_profile_processes(self, profile_dir: str):
        """Đóng sạch mọi tiến trình Chrome (đặc biệt là headless ngầm từ scheduler/Playwright) đang chiếm profile này"""
        if not profile_dir:
            return
        try:
            import psutil
            norm_target = os.path.normpath(profile_dir).lower()
            short_target = self.to_safe_path(profile_dir).lower()
            target_name = Path(profile_dir).name.lower()
            
            for p in psutil.process_iter(['pid', 'name', 'cmdline']):
                try:
                    if 'chrome' in (p.info['name'] or '').lower():
                        cmd = ' '.join(p.info['cmdline'] or []).lower()
                        if (norm_target in cmd) or (short_target in cmd) or (target_name and target_name in cmd and 'profiles' in cmd):
                            try:
                                p.terminate()
                                p.wait(timeout=1.5)
                            except Exception:
                                try:
                                    p.kill()
                                except Exception:
                                    pass
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    pass
        except Exception as e:
            print(f"[ChromeManager] Lỗi dọn tiến trình cũ: {e}")

    def _cleanup_profile_locks(self, profile_dir: str):
        """Xóa các file lock cũ để Chrome khởi chạy tương tác mà không bị kẹt singleton"""
        if not profile_dir or not os.path.isdir(profile_dir):
            return
        lock_files = ["SingletonLock", "SingletonCookie", "SingletonSocket", "lockfile"]
        for lf in lock_files:
            fp = os.path.join(profile_dir, lf)
            if os.path.exists(fp):
                try:
                    os.remove(fp)
                except Exception:
                    pass

    def _bring_chrome_to_foreground(self, profile_name: str, max_tries: int = 12):
        """Đảm bảo cửa sổ Chrome vừa mở được đưa lên vị trí trên cùng màn hình cho người dùng"""
        if sys.platform != "win32":
            return
        try:
            import ctypes
            from ctypes import wintypes
            user32 = ctypes.windll.user32
            WNDENUMPROC = ctypes.WINFUNCTYPE(ctypes.c_int, wintypes.HWND, wintypes.LPARAM)

            for _ in range(max_tries):
                time.sleep(0.5)
                found_hwnds = []

                def enum_cb(hwnd, lparam):
                    if user32.IsWindowVisible(hwnd):
                        length = user32.GetWindowTextLengthW(hwnd)
                        if length > 0:
                            buff = ctypes.create_unicode_buffer(length + 1)
                            user32.GetWindowTextW(hwnd, buff, length + 1)
                            title = buff.value.lower()
                            if "tiktok" in title or "chrome" in title or "google chrome" in title:
                                found_hwnds.append(hwnd)
                    return 1

                try:
                    user32.EnumWindows(WNDENUMPROC(enum_cb), 0)
                except Exception:
                    pass

                if found_hwnds:
                    target_hwnd = found_hwnds[-1]
                    user32.ShowWindow(target_hwnd, 9)  # 9 = SW_RESTORE
                    HWND_TOPMOST = -1
                    HWND_NOTOPMOST = -2
                    SWP_NOSIZE = 0x0001
                    SWP_NOMOVE = 0x0002
                    SWP_SHOWWINDOW = 0x0040
                    user32.SetWindowPos(target_hwnd, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_SHOWWINDOW)
                    user32.SetWindowPos(target_hwnd, HWND_NOTOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_SHOWWINDOW)
                    user32.SetForegroundWindow(target_hwnd)
                    try:
                        user32.SwitchToThisWindow(target_hwnd, True)
                    except Exception:
                        pass
                    break
        except Exception:
            pass

    def launch_chrome_for_login(self, channel_data: Dict[str, Any], url: str = "https://www.tiktok.com/") -> Tuple[bool, str]:
        """
        Mở Google Chrome với Chrome Profile riêng biệt của kênh để người dùng đăng nhập.
        Tự động cấu hình Proxy (HTTP/SOCKS5 có xác thực user/pass), PIA VPN hoặc HMA VPN.
        """
        chrome_exe = self.get_chrome_path()
        if not chrome_exe or not os.path.isfile(chrome_exe):
            return False, f"Không tìm thấy Google Chrome tại: '{chrome_exe}'. Vui lòng vào mục Cài đặt để chọn đường dẫn Chrome."

        raw_profile_dir = channel_data.get("profile_dir", "")
        profile_dir = self.resolve_profile_path(raw_profile_dir)
        if not profile_dir:
            profile_dir = self.get_profile_dir(channel_data.get("id", 0))

        if not os.path.exists(profile_dir):
            os.makedirs(profile_dir, exist_ok=True)

        # 1. Tự động đóng mọi tiến trình Chrome cũ (đặc biệt là headless background) đang khóa Profile này
        self._kill_existing_profile_processes(profile_dir)

        # 2. Xóa các lock file cũ để Chrome mở cửa sổ mới trơn tru
        self._cleanup_profile_locks(profile_dir)

        # 3. Chuẩn hóa đường dẫn ASCII 8.3 trên Windows (Tránh lỗi Crashpad/Unicode tiếng Việt)
        safe_profile_dir = self.to_safe_path(profile_dir)

        # ƯU TIÊN TUYỆT ĐỐI CHO PROXY TĨNH KHI KÊNH ĐÃ CHỌN PROXY (Kể cả khi Tool đang bật VPN PIA)
        # Các kênh không gắn Proxy thì mặc định chạy bằng VPN của PIA
        from core.rotating_proxy_manager import rotating_proxy_mgr
        net_info = rotating_proxy_mgr.resolve_channel_network(channel_data)
        network_type = net_info["network_type"]
        proxy_string = net_info["proxy_string"]
        use_vpn = net_info["use_vpn"]

        # Tham số cơ sở chuẩn Antidetect - Luôn mở cửa sổ mới độc lập
        args = [
            chrome_exe,
            f"--user-data-dir={safe_profile_dir}",
            "--profile-directory=Default",
            "--new-window",
            "--window-size=1366,850",
            "--no-first-run",
            "--no-default-browser-check",
            "--disable-features=Translate",
            "--disable-blink-features=AutomationControlled",
            "--enforce-webrtc-ip-permission-check",
            "--force-webrtc-ip-handling-policy=disable_non_proxied_udp"
        ]

        # Đồng bộ ngôn ngữ theo vùng fake nếu có
        reg_code = (channel_data.get("vpn_region") or "").strip()
        if reg_code and (use_vpn == 1 or network_type == "proxy"):
            try:
                from core.vpn_regions import get_region_profile
                prof = get_region_profile(reg_code)
                args.append(f"--lang={prof['locale']}")
            except Exception:
                pass

        # Xử lý Mạng: Ưu tiên số 1 là Proxy Tĩnh (tách biệt hoàn toàn khỏi VPN PIA)
        if network_type == "proxy" and proxy_string.strip():
            parsed = network_mgr.parse_proxy_string(proxy_string)
            if parsed:
                if parsed.get("user") and parsed.get("pass") and parsed.get("protocol", "http") in ("http", "https"):
                    local_bridge_url = network_mgr.start_local_proxy_bridge(parsed)
                    args.append(f"--proxy-server={local_bridge_url}")
                else:
                    args.append(f"--proxy-server={parsed['protocol']}://{parsed['host']}:{parsed['port']}")
        elif use_vpn == 1:
            # Kênh KHÔNG gắn Proxy -> Mặc định thực hiện qua VPN của PIA
            reg_code = (channel_data.get("vpn_region") or "").strip()
            if not reg_code:
                reg_code = db.get_setting("global_vpn_region", "philippines")
            try:
                cur_ip = network_mgr.get_pia_vpn_ip()
                pia_exe = network_mgr.get_pia_path()
                cur_st = ""
                cur_reg = ""
                if pia_exe and os.path.isfile(pia_exe):
                    from core.network_manager import exec_pia_cmd
                    cur_st = exec_pia_cmd([pia_exe, "get", "connectionstate"], timeout=1).stdout.strip().lower()
                    cur_reg = exec_pia_cmd([pia_exe, "get", "region"], timeout=1).stdout.strip().lower()
                if cur_st != "connected" or (reg_code and cur_reg != reg_code.lower()) or not cur_ip:
                    network_mgr.pia_connect(region=reg_code)
                    time.sleep(1.5)
            except Exception:
                pass
        else:
            args.append("--proxy-server=direct://")

        args.append(url)

        try:
            proc = subprocess.Popen(
                args,
                stdin=subprocess.DEVNULL,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                creationflags=subprocess.CREATE_NEW_PROCESS_GROUP if sys.platform == "win32" else 0,
                close_fds=True
            )

            # Tự động đưa cửa sổ Chrome lên phía trước màn hình
            threading.Thread(target=self._bring_chrome_to_foreground, args=(Path(profile_dir).name,), daemon=True).start()

            # TỰ ĐỘNG THEO DÕI ĐĂNG NHẬP THỜI GIAN THỰC NGAY KHI MỞ CHROME:
            ch_id = channel_data.get("id")
            ch_name = channel_data.get("name", "Kênh")
            if ch_id and profile_dir:
                self.start_login_watcher(ch_id, ch_name, profile_dir)

            return True, "Đã mở trình duyệt Chrome thành công. Hệ thống đang tự động nhận diện khi bạn đăng nhập xong trên Web."
        except Exception as e:
            return False, f"Lỗi khi khởi chạy Chrome: {str(e)}"

    def check_login_status_by_cookies(self, profile_dir: str) -> bool:
        """
        Kiểm tra trạng thái đăng nhập bằng cách đọc Cookie TikTok trong Chrome User Data.
        Tránh đụng độ file lock bằng cách copy file SQLite Cookies sang thư mục tạm,
        đồng thời copy cả file WAL và SHM nếu Chrome đang mở để lấy dữ liệu mới nhất.
        """
        resolved_dir = self.resolve_profile_path(profile_dir)
        cookie_candidates = [
            Path(resolved_dir) / "Default" / "Network" / "Cookies",
            Path(resolved_dir) / "Default" / "Cookies",
            Path(resolved_dir) / "Network" / "Cookies"
        ]

        cookie_path = None
        for cand in cookie_candidates:
            if cand.exists():
                cookie_path = cand
                break

        if not cookie_path:
            return False

        temp_dir = None
        try:
            temp_dir = tempfile.mkdtemp()
            temp_db = os.path.join(temp_dir, "Cookies")
            shutil.copy2(cookie_path, temp_db)

            # Sao chép WAL và SHM nếu có (rất quan trọng khi Chrome đang chạy và vừa đăng nhập)
            wal_file = cookie_path.parent / (cookie_path.name + "-wal")
            shm_file = cookie_path.parent / (cookie_path.name + "-shm")
            if wal_file.exists():
                try:
                    shutil.copy2(wal_file, os.path.join(temp_dir, "Cookies-wal"))
                except Exception:
                    pass
            if shm_file.exists():
                try:
                    shutil.copy2(shm_file, os.path.join(temp_dir, "Cookies-shm"))
                except Exception:
                    pass

            conn = sqlite3.connect(temp_db)
            cursor = conn.cursor()

            # Các cookie nhận diện phiên đăng nhập TikTok
            cursor.execute("""
                SELECT name FROM cookies 
                WHERE host_key LIKE '%tiktok.com%' 
                AND name IN ('sessionid', 'sessionid_ss', 'sid_guard', 'sid_tt', 'multi_sids', 'uid_tt')
            """)
            rows = cursor.fetchall()
            conn.close()

            found_names = [r[0] for r in rows]
            # Nếu có sessionid hoặc sessionid_ss hoặc sid_tt -> đã đăng nhập thành công
            if any(k in found_names for k in ['sessionid', 'sessionid_ss', 'sid_tt']):
                return True
            return False
        except Exception:
            return False
        finally:
            if temp_dir and os.path.exists(temp_dir):
                try:
                    shutil.rmtree(temp_dir, ignore_errors=True)
                except Exception:
                    pass

    def open_profile_folder(self, profile_dir: str):
        """Mở thư mục profile trong Windows Explorer"""
        resolved = self.resolve_profile_path(profile_dir)
        if resolved and os.path.exists(resolved):
            os.startfile(resolved)

    def launch_batch_profiles(self, channels: List[Dict[str, Any]], delay_seconds: float = 2.0, callback=None):
        """
        Mở hàng loạt Profile Chrome với độ trễ an toàn giữa các cửa sổ
        """
        import threading
        def worker():
            for i, ch in enumerate(channels):
                if callback:
                    callback(i + 1, len(channels), ch["name"])
                self.launch_chrome_for_login(ch)
                if i < len(channels) - 1:
                    time.sleep(delay_seconds)

        thread = threading.Thread(target=worker, daemon=True)
        thread.start()

chrome_mgr = ChromeManager()

