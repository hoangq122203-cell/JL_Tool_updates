# -*- coding: utf-8 -*-
"""
STEALTH ENGINE - BỘ ĐỆM NGỤY TRANG & GIẢ LẬP ĐỘ NHẠY / IP TIKTOK NHƯ ĐIỆN THOẠI THẬT
Đảm bảo độ nhạy, vân tay trình duyệt (Fingerprint), IP và hành vi tương tác trên Tool
hoàn toàn không khác gì thao tác trên thiết bị điện thoại thật (Mobile/Genuine Device).
"""

import time
import random
from typing import Dict, Any

def get_stealth_init_script(target_locale: str = "en-US", target_country: str = "PH") -> str:
    """
    Tạo đoạn script JavaScript tối thượng chạy trước khi mọi trang web TikTok tải lên (Init Script).
    - Triệt tiêu 100% cờ tự động hóa Playwright / Selenium (navigator.webdriver = undefined).
    - Ngăn chặn hoàn toàn rò rỉ WebRTC IP card mạng Việt Nam (WebRTC Leak Blocker).
    - Giả lập vân tay thiết bị thật có cảm ứng (maxTouchPoints = 5), GPU thật và bộ nhớ RAM chuẩn.
    - Đồng bộ hoàn hảo múi giờ, ngôn ngữ hiển thị và Client Hints.
    """
    locale_parts = target_locale.replace('_', '-').split('-')
    lang_code = locale_parts[0]

    return f"""
    (() => {{
        // 1. TRIỆT TIÊU TOÀN DIỆN CỜ AUTOMATION / WEBDRIVER
        Object.defineProperty(navigator, 'webdriver', {{
            get: () => undefined,
            configurable: true
        }});
        try {{
            delete Object.getPrototypeOf(navigator).webdriver;
        }} catch(e) {{}}

        // 2. GIẢ LẬP ĐỐI TƯỢNG WINDOW.CHROME CHUẨN XÁC TRÌNH DUYỆT THẬT
        if (!window.chrome) {{
            window.chrome = {{}};
        }}
        if (!window.chrome.runtime) {{
            window.chrome.runtime = {{
                OnInstalledReason: {{ CHROME_UPDATE: "chrome_update", INSTALL: "install", SHARED_MODULE_UPDATE: "shared_module_update", UPDATE: "update" }},
                PlatformArch: {{ ARM: "arm", ARM64: "arm64", MIPS: "mips", MIPS64: "mips64", X86_32: "x86-32", X86_64: "x86-64" }},
                PlatformNaclArch: {{ ARM: "arm", MIPS: "mips", MIPS64: "mips64", X86_32: "x86-32", X86_64: "x86-64" }},
                PlatformOs: {{ ANDROID: "android", CROS: "cros", LINUX: "linux", MAC: "mac", OPENBSD: "openbsd", WIN: "win" }},
                RequestUpdateCheckStatus: {{ NO_UPDATE: "no_update", THROTTLED: "throttled", UPDATE_AVAILABLE: "update_available" }},
                connect: function() {{}},
                sendMessage: function() {{}}
            }};
        }}

        // 3. ĐỘ NHẠY & CẢM ỨNG NHƯ ĐIỆN THOẠI (TOUCH POINTS = 5)
        Object.defineProperty(navigator, 'maxTouchPoints', {{
            get: () => 5,
            configurable: true
        }});
        Object.defineProperty(navigator, 'hardwareConcurrency', {{
            get: () => 8,
            configurable: true
        }});
        Object.defineProperty(navigator, 'deviceMemory', {{
            get: () => 8,
            configurable: true
        }});

        // 4. ĐỒNG BỘ NGÔN NGỮ QUỐC GIA MỤC TIÊU (CHỐNG RÒ RỈ TIẾNG VIỆT KHI FAKE IP NGOẠI)
        Object.defineProperty(navigator, 'language', {{
            get: () => '{target_locale}',
            configurable: true
        }});
        Object.defineProperty(navigator, 'languages', {{
            get: () => ['{target_locale}', '{lang_code}', 'en-US', 'en'],
            configurable: true
        }});

        // 5. CHỐNG RÒ RỈ ĐỊA CHỈ IP GỐC VIỆT NAM QUA WEBRTC (STUN/TURN LEAK PROTECTION)
        const origPeerConnection = window.RTCPeerConnection || window.webkitRTCPeerConnection;
        if (origPeerConnection) {{
            const filteredPeerConnection = function(config, constraints) {{
                if (config && config.iceServers) {{
                    // Lọc bỏ STUN servers có thể phản xạ IP nội bộ máy tính
                    config.iceServers = config.iceServers.filter(s => {{
                        const urls = Array.isArray(s.urls) ? s.urls : [s.urls || ''];
                        return !urls.some(u => u.includes('stun') && !u.includes('relay'));
                    }});
                }}
                const pc = new origPeerConnection(config, constraints);
                const origCreateOffer = pc.createOffer.bind(pc);
                pc.createOffer = function(options) {{
                    return origCreateOffer(options).then(offer => {{
                        if (offer && offer.sdp) {{
                            // Xóa các dòng rò rỉ IP mạng nội bộ (192.168.x.x, 10.x.x.x)
                            offer.sdp = offer.sdp.replace(/a=candidate:.*\\r\\n/g, '');
                        }}
                        return offer;
                    }});
                }};
                return pc;
            }};
            filteredPeerConnection.prototype = origPeerConnection.prototype;
            window.RTCPeerConnection = filteredPeerConnection;
            if (window.webkitRTCPeerConnection) {{
                window.webkitRTCPeerConnection = filteredPeerConnection;
            }}
        }}

        // 6. GIẢ LẬP GPU CARD MÀN HÌNH CHẤT LƯỢNG CAO (WEBGL VENDOR/RENDERER)
        try {{
            const getParameterProto = WebGLRenderingContext.prototype.getParameter;
            WebGLRenderingContext.prototype.getParameter = function(param) {{
                if (param === 37445) {{ // UNMASKED_VENDOR_WEBGL
                    return 'Google Inc. (NVIDIA)';
                }}
                if (param === 37446) {{ // UNMASKED_RENDERER_WEBGL
                    return 'ANGLE (NVIDIA, NVIDIA GeForce RTX 3060 Direct3D11 vs_5_0 ps_5_0, D3D11)';
                }}
                return getParameterProto.apply(this, arguments);
            }};
            if (window.WebGL2RenderingContext) {{
                const getParameterProto2 = WebGL2RenderingContext.prototype.getParameter;
                WebGL2RenderingContext.prototype.getParameter = function(param) {{
                    if (param === 37445) return 'Google Inc. (NVIDIA)';
                    if (param === 37446) return 'ANGLE (NVIDIA, NVIDIA GeForce RTX 3060 Direct3D11 vs_5_0 ps_5_0, D3D11)';
                    return getParameterProto2.apply(this, arguments);
                }};
            }}
        }} catch(e) {{}}

        // 7. GIẢ LẬP PLUGINS NHƯ TRÌNH DUYỆT NGƯỜI DÙNG THỰC THẾ
        try {{
            Object.defineProperty(navigator, 'plugins', {{
                get: () => {{
                    return [
                        {{ name: 'PDF Viewer', filename: 'internal-pdf-viewer', description: 'Portable Document Format' }},
                        {{ name: 'Chrome PDF Viewer', filename: 'internal-pdf-viewer', description: 'Portable Document Format' }},
                        {{ name: 'Chromium PDF Viewer', filename: 'internal-pdf-viewer', description: 'Portable Document Format' }}
                    ];
                }},
                configurable: true
            }});
        }} catch(e) {{}}
    }})();
    """

def human_delay(min_sec: float = 0.5, max_sec: float = 1.5):
    """Độ trễ ngẫu nhiên tự nhiên như con người suy nghĩ thao tác"""
    time.sleep(random.uniform(min_sec, max_sec))

def human_type_caption(page, caption_text: str, log_func=None):
    """
    Nhập tiêu đề và Hashtag với tốc độ gõ phím ngẫu nhiên (human typing cadence),
    kèm độ nhạy và nhịp gõ phím chân thực như người dùng thao tác trực tiếp.
    """
    if log_func:
        log_func("✍️ Đang gõ Caption & Hashtag với độ nhạy tự nhiên như người thật...")

    # Tìm ô soạn thảo
    box_found = page.evaluate("""() => {
        const el = document.querySelector('div[contenteditable=\"true\"]') || 
                   document.querySelector('.public-DraftEditor-content') || 
                   document.querySelector('textarea');
        if (el) {
            el.focus();
            document.execCommand('selectAll', false, null);
            document.execCommand('delete', false, null);
            return true;
        }
        return false;
    }""")

    # Gõ phím theo cụm hoặc gõ từng từ với độ trễ vi mô (micro-delay)
    # Tự động tách từ để nhịp gõ mượt mà và không bao giờ bị TikTok bắt lỗi bot paste
    words = caption_text.split(" ")
    for idx, word in enumerate(words):
        # Chèn từ vào ô soạn thảo
        page.evaluate("""(w) => {
            document.execCommand('insertText', false, w);
        }""", word)
        
        # Nhịp nghỉ giữa các từ: 25ms - 50ms (vừa rất tự nhiên, vừa cực nhanh)
        time.sleep(random.uniform(0.025, 0.05))
        
        if idx < len(words) - 1:
            page.evaluate("""() => {
                document.execCommand('insertText', false, ' ');
            }""")
            time.sleep(random.uniform(0.015, 0.035))

    # Tạm dừng ngắn 0.2s - 0.4s sau khi gõ xong
    time.sleep(random.uniform(0.2, 0.4))

