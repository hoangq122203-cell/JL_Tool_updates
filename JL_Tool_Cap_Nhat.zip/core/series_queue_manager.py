# -*- coding: utf-8 -*-
"""
SERIES QUEUE MANAGER (QUẢN LÝ TIẾN TRÌNH CẮT & RẢI LỊCH VIDEO CHẠY NGẦM TUẦN TỰ)
Đảm bảo cắt video từng kênh 1 (Sequential Processing FIFO) để không gây quá tải CPU/FFmpeg
và cho phép người dùng cấu hình hàng loạt các kênh mà không phải treo màn hình chờ đợi.
"""

import os
import sys
import time
import threading
from typing import Dict, Any, Optional, List
from PySide6.QtCore import QObject, Signal
from database.db_manager import db
import config

class SeriesQueueManager(QObject):
    task_added = Signal(int, str)             # channel_id, channel_name
    task_started = Signal(int, str)           # channel_id, channel_name
    task_progress = Signal(int, int, str)     # channel_id, progress_percent, log_msg
    task_finished = Signal(int, bool, str)    # channel_id, success, message
    queue_updated = Signal()

    def __init__(self):
        super().__init__()
        self._queue: List[Dict[str, Any]] = []
        self._current_task: Optional[Dict[str, Any]] = None
        self._status_by_channel: Dict[int, Dict[str, Any]] = {}
        self._lock = threading.Lock()
        self._worker_thread: Optional[threading.Thread] = None
        self._is_running = False

    def add_task(self, channel_id: int, config_data: Dict[str, Any]) -> bool:
        """
        Thêm một kênh vào hàng đợi xử lý ngầm.
        Nếu kênh đang chạy thì từ chối thêm trùng. Nếu đã trong hàng đợi thì cập nhật cấu hình.
        """
        ch = db.get_channel(channel_id)
        ch_name = ch.get("name", f"channel_{channel_id}") if ch else f"channel_{channel_id}"

        with self._lock:
            # 1. Nếu kênh này đang được xử lý: không thêm trùng lặp
            if self._current_task and self._current_task["channel_id"] == channel_id:
                return False

            # 2. Nếu kênh này đã nằm trong hàng đợi: cập nhật cấu hình mới nhất
            existing = next((t for t in self._queue if t["channel_id"] == channel_id), None)
            if existing:
                existing["config"] = config_data
                existing["channel_name"] = ch_name
                pos = self._status_by_channel.get(channel_id, {}).get("position", 1)
            else:
                self._queue.append({
                    "channel_id": channel_id,
                    "channel_name": ch_name,
                    "config": config_data
                })
                pos = len(self._queue)

            self._status_by_channel[channel_id] = {
                "status": "queued",
                "position": pos,
                "progress": 0,
                "step": f"Đang trong hàng đợi (Vị trí #{pos})..."
            }

        self.task_added.emit(channel_id, ch_name)
        self.queue_updated.emit()
        self._start_worker_if_needed()
        return True

    def get_channel_status(self, channel_id: int) -> Optional[Dict[str, Any]]:
        """Trả về thông tin trạng thái hiện tại của kênh (processing, queued, hoặc None)"""
        with self._lock:
            return self._status_by_channel.get(channel_id)

    def is_channel_busy(self, channel_id: int) -> bool:
        """Kiểm tra kênh có đang xử lý hoặc đang xếp hàng đợi không"""
        with self._lock:
            return channel_id in self._status_by_channel

    def cancel_channel(self, channel_id: int):
        """Hủy tác vụ của kênh trong hàng đợi tự động hóa ngầm nếu chưa chạy"""
        with self._lock:
            self._queue = [t for t in self._queue if t["channel_id"] != channel_id]
            if channel_id in self._status_by_channel and self._status_by_channel[channel_id].get("status") == "queued":
                del self._status_by_channel[channel_id]
        self.queue_updated.emit()

    def get_queue_size(self) -> int:
        with self._lock:
            return len(self._queue) + (1 if self._current_task else 0)

    def _start_worker_if_needed(self):
        with self._lock:
            if self._worker_thread and self._worker_thread.is_alive():
                return
            self._is_running = True
            self._worker_thread = threading.Thread(target=self._process_queue_loop, daemon=True)
            self._worker_thread.start()

    def _process_queue_loop(self):
        """Vòng lặp ngầm: Lấy từng kênh 1 ra xử lý tuần tự (FIFO)"""
        while True:
            task = None
            with self._lock:
                if not self._queue:
                    self._current_task = None
                    self._is_running = False
                    break
                task = self._queue.pop(0)
                self._current_task = task
                cid = task["channel_id"]
                self._status_by_channel[cid] = {
                    "status": "processing",
                    "position": 0,
                    "progress": 5,
                    "step": "Bắt đầu khởi động luồng tải và cắt video..."
                }

            self.task_started.emit(task["channel_id"], task["channel_name"])
            self.queue_updated.emit()

            success = False
            msg = ""
            try:
                # Thực thi tác vụ cắt & rải lịch tuần tự
                success, msg = self._execute_task(task)
            except Exception as e:
                success = False
                msg = f"Sự cố hệ thống khi xử lý kênh: {e}"
            finally:
                with self._lock:
                    self._status_by_channel.pop(task["channel_id"], None)
                    # Cập nhật lại vị trí các kênh còn lại trong hàng đợi
                    for idx, t in enumerate(self._queue):
                        q_cid = t["channel_id"]
                        if q_cid in self._status_by_channel:
                            self._status_by_channel[q_cid]["position"] = idx + 1
                            self._status_by_channel[q_cid]["step"] = f"Đang trong hàng đợi (Vị trí #{idx + 1})..."

                self.task_finished.emit(task["channel_id"], success, msg)
                self.queue_updated.emit()

            # Nghỉ ngắn 1.5 giây để giải phóng tài nguyên Windows / FFmpeg trước khi qua kênh tiếp theo
            time.sleep(1.5)

    def _execute_task(self, task: Dict[str, Any]) -> (bool, str):
        from core.youtube_pipeline import (
            fetch_best_youtube_video,
            download_youtube_video,
            auto_slice_and_edit_shorts,
            schedule_series_for_channel
        )

        cid = task["channel_id"]
        cname = task["channel_name"]
        cfg = task["config"]

        source_url = cfg.get("source_url", "")
        sort_mode = cfg.get("sort_mode", "popular")
        min_duration_min = float(cfg.get("min_duration_min", 0.5))
        max_duration_min = float(cfg.get("max_duration_min", 1.0))
        videos_per_day = int(cfg.get("videos_per_day", 2))
        golden_hours = cfg.get("golden_hours") or ["11:30", "19:30"]
        schedule_mode = cfg.get("schedule_mode", "golden")
        interval_minutes = int(cfg.get("interval_minutes", 180))
        start_time_str = cfg.get("start_time_str", "08:00")
        use_jitter = bool(cfg.get("use_jitter", True))
        crop_mode = cfg.get("crop_mode", "blur_9_16")

        def emit_log(percent: int, text: str):
            with self._lock:
                if cid in self._status_by_channel:
                    self._status_by_channel[cid]["progress"] = percent
                    self._status_by_channel[cid]["step"] = text
            self.task_progress.emit(cid, percent, text)

        try:
            rem = db.get_channel_remaining_schedules_count(cid)
            if rem > 0:
                emit_log(5, f"ℹ️ Kênh '@{cname}' hiện đang có {rem} video chờ đăng. Tool sẽ tự động tải, cắt và rải lịch nối tiếp vào sau các video hiện tại!")

            emit_log(10, f"🔎 Đang phân tích nguồn YouTube và tìm video phù hợp cho kênh '@{cname}'...")

            ch = db.get_channel(cid)
            raw_name = ch.get("name", f"channel_{cid}") if ch else f"channel_{cid}"
            safe_folder_name = "".join(c for c in raw_name if c.isalnum() or c in ("-", "_", ".")).strip()
            if not safe_folder_name:
                safe_folder_name = f"channel_{cid}"
            ch_folder = f"channel_{cid}_{safe_folder_name}"
            raw_dir = os.path.join(str(config.DATA_DIR / "videos" / "youtube_raw"), ch_folder)

            download_res = None
            best_vid = None
            max_attempts = 10

            session_excluded = set()
            for attempt in range(max_attempts):
                best_vid = fetch_best_youtube_video(
                    source_url=source_url,
                    channel_id=cid,
                    sort_mode=sort_mode,
                    log_func=lambda m: emit_log(15, m),
                    exclude_ids=session_excluded
                )
                if not best_vid:
                    break

                yt_channel_name = best_vid.get("uploader_name", "")
                emit_log(25, f"📥 Đang tải video từ YouTube: '{best_vid['title'][:40]}...'")
                download_res = download_youtube_video(best_vid["url"], raw_dir, log_func=lambda m: emit_log(35, m))
                if download_res:
                    db.update_channel_youtube_source(cid, source_url, yt_channel_name)
                    db.update_channel_crop_frame(cid, crop_mode)
                    break

                emit_log(20, f"⚠️ Video '{best_vid['title'][:30]}' không tải được hoặc bị giới hạn. Đang chuyển sang video tiếp theo...")
                session_excluded.add(best_vid["id"])

            if not download_res or not best_vid:
                err_msg = f"Không tìm thấy video công khai phù hợp trên nguồn YouTube cho kênh '@{cname}'!"
                emit_log(0, f"❌ {err_msg}")
                return False, err_msg

            raw_file, original_title = download_res
            emit_log(50, f"✅ Đã tải xong video gốc ({os.path.basename(raw_file)}). Đang tiến hành cắt 9:16...")

            min_sec = max(10.0, min_duration_min * 60.0)
            max_sec = max(min_sec, max_duration_min * 60.0)
            shorts_dir = os.path.join(str(config.DATA_DIR / "videos"), ch_folder)

            created_parts = auto_slice_and_edit_shorts(
                src_video_path=raw_file,
                output_dir=shorts_dir,
                target_parts=None,
                segment_duration=int((min_sec + max_sec) / 2),
                min_duration_sec=min_sec,
                max_duration_sec=max_sec,
                show_title=original_title,
                crop_mode=crop_mode,
                channel_id=cid,
                log_func=lambda m: emit_log(75, m)
            )

            if not created_parts:
                err_msg = "Không thể cắt và biên tập video bằng FFmpeg."
                emit_log(0, f"❌ {err_msg}")
                return False, err_msg

            emit_log(88, f"📅 Đang tự động rải {len(created_parts)} tập vào lịch hẹn kênh '@{cname}'...")

            summary = schedule_series_for_channel(
                channel_id=cid,
                parts=created_parts,
                videos_per_day=videos_per_day,
                golden_hours=golden_hours,
                schedule_mode=schedule_mode,
                interval_minutes=interval_minutes,
                start_time_str=start_time_str,
                use_jitter=use_jitter,
                upload_mode="cloud",
                log_func=lambda m: emit_log(95, m)
            )

            count = summary.get("schedules_added", len(created_parts))
            total_pending = summary.get("total_pending", count)
            today_cnt = summary.get("today_count", 0)
            end_date = summary.get("end_date_str", "")

            # Lưu vết video YouTube đã xử lý
            db.save_youtube_processed_video(
                channel_id=cid,
                youtube_video_id=best_vid["id"],
                title=original_title,
                view_count=best_vid.get("view_count", 0),
                duration=best_vid.get("duration", 0),
                parts_created=len(created_parts),
                source_url=source_url
            )

            # Tự động kích hoạt dịch vụ hẹn giờ ngầm nếu đang tắt
            try:
                from core.scheduler_service import scheduler_service
                if not scheduler_service.is_running:
                    scheduler_service.start()
            except Exception:
                pass

            emit_log(100, f"🎉 Đã hoàn tất cắt & rải lịch thành công cho kênh '@{cname}' ({count} tập)!")

            report_msg = (
                f"🎉 HOÀN THÀNH TỰ ĐỘNG HÓA SERIES CHO KÊNH '@{cname}'!\n\n"
                f"📺 Kênh Nguồn YouTube: @{yt_channel_name}\n"
                f"✂️ Đã cắt và biên tập: {count} tập ({min_duration_min:.1f} – {max_duration_min:.1f} phút/tập) chuẩn dọc 9:16\n"
                f"📅 Tần suất: {videos_per_day} video / ngày\n"
                f"📊 Hôm nay đăng: {today_cnt} video\n"
                f"📦 Tổng video trong lịch: {total_pending} video\n"
                f"⏳ Lịch đăng đảm bảo liên tục đến ngày: {end_date}\n"
                f"☁️ Trạng thái: Đã nạp sẵn lên Đám Mây TikTok an toàn!"
            )

            try:
                from core.notifier import notifier
                tg_msg = (
                    f"🎬 <b>[TỰ ĐỘNG SERIES HOÀN TẤT]</b>\n\n"
                    f"📺 <b>Kênh TikTok:</b> <code>@{cname}</code>\n"
                    f"🔗 <b>Kênh Nguồn YouTube:</b> <code>@{yt_channel_name}</code>\n"
                    f"✂️ <b>Đã cắt thành công:</b> <b>{count} tập (9:16)</b>\n"
                    f"📅 <b>Tần suất:</b> {videos_per_day} video/ngày\n"
                    f"📊 <b>Hôm nay:</b> {today_cnt} video\n"
                    f"📦 <b>Tổng video trong lịch:</b> <b>{total_pending} video</b>\n"
                    f"⏳ <b>Lịch đăng liên tục đến:</b> <code>{end_date}</code>\n"
                    f"☁️ <b>Trạng thái:</b> <i>Đã lưu vào Đám Mây TikTok!</i>"
                )
                notifier.send_telegram_msg(tg_msg)
            except Exception:
                pass

            return True, report_msg

        except Exception as e:
            err_msg = f"Sự cố ngoài dự kiến: {e}"
            emit_log(0, f"❌ {err_msg}")
            return False, err_msg

# Khởi tạo singleton toàn cục
series_queue_mgr = SeriesQueueManager()

