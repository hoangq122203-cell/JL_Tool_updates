import os
import json
import time
import threading
from typing import List, Dict, Any, Optional, Tuple
from database.db_manager import db

class RotatingProxyManager:
    """
    Hệ thống Điều phối Xoay Tua Proxy Tĩnh Theo Đợt & Ưu Tiên Mạng Tuyệt Đối:
    ================================================================================
    1. QUY TẮC ƯU TIÊN SỐ 1 (PROXY TĨNH):
       - Kênh nào đã được tích chọn gắn Proxy (hoặc có proxy_string), kể cả khi Tool đang bật
         PIA VPN trên máy tính, kênh đó VẪN ƯU TIÊN TUYỆT ĐỐI CHẠY QUA PROXY TĨNH!
       - Tuyệt đối không để PIA VPN chèn IP vào kênh đang dùng Proxy (cả hiển thị lẫn khi mở Chrome/đăng bài).
    2. QUY TẮC XOAY TUA 5 KÊNH / ĐỢT:
       - Mỗi đợt đăng hoặc login: Gắn 1 Proxy tĩnh cho 1 nhóm 5 tài khoản đã tích chọn.
       - Khi 5 tài khoản này đăng xong ➔ Tự động OFF proxy khỏi 5 tài khoản đó và chuyển tiếp
         chính Proxy đó sang 5 tài khoản đã tích chọn tiếp theo!
    3. QUY TẮC MẶC ĐỊNH CHO KÊNH KHÔNG GẮN PROXY:
       - Các kênh KHÔNG thực hiện gắn Proxy (bỏ tích chọn hoặc đã gỡ Proxy) thì MẶC ĐỊNH 100%
         là đang thực hiện VPN của PIA (network_type = 'vpn', use_vpn = 1)!
    """

    def __init__(self):
        self._lock = threading.Lock()
        # Theo dõi các đợt đang chạy: { proxy_str: { "batch_id": int, "channel_ids": set(), "schedule_ids": set() } }
        self._active_batches: Dict[str, Dict[str, Any]] = {}
        # Theo dõi các kênh đã hoàn thành trong phiên hiện tại
        self._completed_channels: set = set()
        self._cfg_cache: Optional[Dict[str, Any]] = None
        self._cfg_cache_ts: float = 0.0

    # =========================================================================
    # 1. QUẢN LÝ CẤU HÌNH XOAY TUA PROXY & ĐỒNG BỘ MẶC ĐỊNH VPN PIA
    # =========================================================================
    def get_config(self) -> Dict[str, Any]:
        """Lấy cấu hình Xoay tua Proxy từ cơ sở dữ liệu (có cache ngắn 2s tránh đọc lặp O(N^2))"""
        now = time.monotonic()
        with self._lock:
            if self._cfg_cache is not None and (now - self._cfg_cache_ts) < 2.0:
                return self._cfg_cache

        enabled = db.get_setting("rotating_proxy_enabled", "0") == "1"
        raw_pool = db.get_setting("rotating_proxy_pool", "")
        batch_size = int(db.get_setting("rotating_proxy_batch_size", "5"))
        auto_off = db.get_setting("rotating_proxy_auto_off", "1") == "1"

        proxies = []
        for line in raw_pool.splitlines():
            line = line.strip()
            if line and not line.startswith("#"):
                proxies.append(line)

        raw_cids = db.get_setting("rotating_proxy_channel_ids", "[]")
        try:
            target_channel_ids = json.loads(raw_cids)
            if not isinstance(target_channel_ids, list):
                target_channel_ids = []
            target_channel_ids = [int(x) for x in target_channel_ids if str(x).isdigit()]
        except Exception:
            target_channel_ids = []

        cfg = {
            "enabled": enabled,
            "proxies": proxies,
            "batch_size": max(1, batch_size),
            "auto_off": auto_off,
            "raw_pool": raw_pool,
            "target_channel_ids": target_channel_ids
        }
        with self._lock:
            self._cfg_cache = cfg
            self._cfg_cache_ts = time.monotonic()
        return cfg

    def save_config(self, enabled: bool, proxies: List[str], batch_size: int = 5,
                    auto_off: bool = True, target_channel_ids: Optional[List[int]] = None):
        """
        Lưu cấu hình Xoay tua Proxy và đồng bộ trạng thái mạng cho toàn bộ kênh:
        - Các kênh ĐƯỢC TÍCH CHỌN: Ưu tiên gắn Proxy (Đợt 1 gắn sẵn ngay vào DB, các đợt sau xoay tua).
        - Các kênh KHÔNG TÍCH CHỌN: Mặc định chuyển về thực hiện VPN của PIA (network_type='vpn', use_vpn=1).
        """
        clean_proxies = [p.strip() for p in proxies if p and p.strip() and not p.strip().startswith("#")]
        raw_pool = "\n".join(clean_proxies)
        batch_size = max(1, int(batch_size))

        db.set_setting("rotating_proxy_enabled", "1" if enabled else "0")
        db.set_setting("rotating_proxy_pool", raw_pool)
        db.set_setting("rotating_proxy_batch_size", str(batch_size))
        db.set_setting("rotating_proxy_auto_off", "1" if auto_off else "0")
        with self._lock:
            self._cfg_cache = None

        cids_clean = []
        if target_channel_ids is not None:
            cids_clean = [int(x) for x in target_channel_ids if str(x).isdigit()]
            db.set_setting("rotating_proxy_channel_ids", json.dumps(cids_clean))
        else:
            cids_clean = self.get_config().get("target_channel_ids", [])

        # Đồng bộ trực tiếp vào bảng channels để ưu tiên Proxy cho kênh đã chọn & mặc định VPN PIA cho kênh không chọn
        with db._get_connection() as conn:
            cursor = conn.cursor()
            if enabled and clean_proxies and cids_clean:
                # 1. Tất cả các kênh KHÔNG nằm trong danh sách tích chọn -> Mặc định thực hiện VPN của PIA
                placeholders = ",".join("?" for _ in cids_clean)
                cursor.execute(f"""
                    UPDATE channels
                    SET network_type = 'vpn',
                        proxy_string = '',
                        use_vpn = 1
                    WHERE id NOT IN ({placeholders})
                """, cids_clean)

                # 2. Lấy danh sách các kênh ĐÃ TÍCH CHỌN theo thứ tự STT (id ASC)
                cursor.execute(f"SELECT id FROM channels WHERE id IN ({placeholders}) ORDER BY id ASC", cids_clean)
                sorted_checked = [int(r["id"]) for r in cursor.fetchall()]

                # Gán sẵn Proxy cho Đợt 1 (5 kênh đầu tiên पर mỗi proxy trong pool) để sẵn sàng ngay lập tức
                active_slots = len(clean_proxies) * batch_size
                for idx, cid in enumerate(sorted_checked):
                    if idx < active_slots:
                        p_idx = (idx // batch_size) % len(clean_proxies)
                        cursor.execute("""
                            UPDATE channels
                            SET network_type = 'proxy',
                                proxy_string = ?,
                                use_vpn = 1
                            WHERE id = ?
                        """, (clean_proxies[p_idx], cid))
                    else:
                        # Các đợt tiếp theo trong danh sách đã tích chọn: chờ xoay tua từ đợt trước
                        cursor.execute("""
                            UPDATE channels
                            SET network_type = 'proxy',
                                proxy_string = '',
                                use_vpn = 1
                            WHERE id = ?
                        """, (cid,))
            elif not enabled:
                # Khi tắt chế độ xoay tua Proxy -> Tất cả các kênh không có proxy cố định quay về mặc định VPN của PIA
                cursor.execute("""
                    UPDATE channels
                    SET network_type = 'vpn',
                        proxy_string = '',
                        use_vpn = 1
                """)
            conn.commit()

    def is_enabled(self) -> bool:
        """Kiểm tra chế độ xoay tua Proxy có đang kích hoạt không"""
        cfg = self.get_config()
        return cfg["enabled"] and len(cfg["proxies"]) > 0

    # =========================================================================
    # 2. BỘ PHÂN GIẢI ƯU TIÊN MẠNG TUYỆT ĐỐI CHO TỪNG KÊNH (RESOLVER)
    # =========================================================================
    def resolve_channel_network(
        self,
        channel_data: Dict[str, Any],
        cached_cfg: Optional[Dict[str, Any]] = None,
        target_index_map: Optional[Dict[int, int]] = None
    ) -> Dict[str, Any]:
        """
        Xác định chính xác chế độ mạng thực tế của 1 kênh với quy tắc:
        1. Nếu kênh có Proxy tĩnh trực tiếp HOẶC nằm trong danh sách kênh đã tích chọn Proxy:
           ➔ ƯU TIÊN SỐ 1 TUYỆT ĐỐI LÀ PROXY TĨNH (Bỏ qua PIA VPN, không bao giờ chèn IP VPN vào kênh!).
        2. Nếu kênh KHÔNG gắn Proxy:
           ➔ MẶC ĐỊNH LÀ THỰC HIỆN VPN CỦA PIA (use_vpn = 1, network_type = 'vpn')!
        """
        cid = int(channel_data.get("id", 0) or 0)
        direct_proxy = str(channel_data.get("proxy_string") or "").strip()
        net_type = str(channel_data.get("network_type") or "vpn").strip().lower()

        cfg = cached_cfg if cached_cfg is not None else self.get_config()
        rot_enabled = cfg["enabled"] and len(cfg["proxies"]) > 0
        target_cids = cfg.get("target_channel_ids", [])
        batch_size = cfg.get("batch_size", 5)

        idx_in_targets = None
        if rot_enabled:
            if target_index_map is not None:
                idx_in_targets = target_index_map.get(cid)
            else:
                if not target_cids:
                    try:
                        target_cids = [int(c["id"]) for c in db.get_all_channels()]
                    except Exception:
                        target_cids = [cid] if cid else []
                if cid in target_cids:
                    sorted_targets = sorted(target_cids)
                    idx_in_targets = sorted_targets.index(cid)

        # TRƯỜNG HỢP 1: Kênh đang nằm trong danh sách tích chọn Xoay Tua Proxy (Khi chế độ Xoay Tua đang BẬT)
        if rot_enabled and idx_in_targets is not None:
            batch_num = (idx_in_targets // batch_size) + 1
            p_idx = (idx_in_targets // batch_size) % len(cfg["proxies"])
            assigned_proxy = direct_proxy if direct_proxy else cfg["proxies"][p_idx]

            p_disp = assigned_proxy.split("@")[-1] if "@" in assigned_proxy else assigned_proxy
            parts = p_disp.split(":")
            p_short = f"{parts[0]}:{parts[1]}" if len(parts) >= 2 else p_disp[:20]

            return {
                "mode": "proxy",
                "network_type": "proxy",
                "proxy_string": assigned_proxy,
                "use_vpn": 0,  # Khóa VPN = 0 trong phiên chạy để Proxy ưu tiên tuyệt đối, không bị chèn IP VPN!
                "batch_number": batch_num,
                "is_active_batch": bool(direct_proxy),
                "short_proxy": p_short,
                "badge_text": f"🛡️ PROXY (Đợt {batch_num}): {p_short}",
                "tooltip": (
                    f"🛡️ KÊNH ƯU TIÊN CHẠY PROXY TĨNH (Đợt {batch_num})\n"
                    f"• Proxy: {assigned_proxy}\n"
                    f"• Quy tắc: Ưu tiên Proxy tuyệt đối, tách biệt 100% và không bị chèn IP của PIA VPN!"
                )
            }

        # TRƯỜNG HỢP 2: Kênh được gán Proxy tĩnh cố định trực tiếp
        if direct_proxy:
            p_disp = direct_proxy.split("@")[-1] if "@" in direct_proxy else direct_proxy
            parts = p_disp.split(":")
            p_short = f"{parts[0]}:{parts[1]}" if len(parts) >= 2 else p_disp[:20]
            return {
                "mode": "proxy",
                "network_type": "proxy",
                "proxy_string": direct_proxy,
                "use_vpn": 0,  # Khóa VPN = 0 trong phiên chạy để Proxy ưu tiên tuyệt đối!
                "batch_number": 1,
                "is_active_batch": True,
                "short_proxy": p_short,
                "badge_text": f"🛡️ PROXY TĨNH: {p_short}",
                "tooltip": (
                    f"🛡️ KÊNH ƯU TIÊN CHẠY PROXY TĨNH RIÊNG\n"
                    f"• Proxy: {direct_proxy}\n"
                    f"• Quy tắc: Ưu tiên Proxy tuyệt đối, không bị ảnh hưởng bởi PIA VPN!"
                )
            }

        # TRƯỜNG HỢP 3: Các kênh KHÔNG thực hiện gắn Proxy -> MẶC ĐỊNH THỰC HIỆN VPN CỦA PIA!
        # (Chỉ khi người dùng chủ động tắt VPN riêng và net_type == 'direct' mới dùng IP gốc)
        use_vpn_flag = bool(channel_data.get("use_vpn", 1))
        if net_type == "direct" and not use_vpn_flag:
            return {
                "mode": "direct",
                "network_type": "direct",
                "proxy_string": "",
                "use_vpn": 0,
                "badge_text": "🌐 IP GỐC MÁY",
                "tooltip": "Kênh chạy bằng địa chỉ IP thật của máy tính"
            }

        return {
            "mode": "vpn",
            "network_type": "vpn",
            "proxy_string": "",
            "use_vpn": 1,
            "badge_text": "🛡️ VPN PIA",
            "tooltip": "Kênh không gắn Proxy ➔ Mặc định thực hiện kết nối qua VPN của PIA"
        }

    # =========================================================================
    # 3. PHÂN NHÓM KÊNH THEO ĐỢT (BATCH 5 KÊNH ĐÃ TÍCH CHỌN)
    # =========================================================================
    def get_batches(self, channel_ids: Optional[List[int]] = None, batch_size: int = 5) -> List[Dict[str, Any]]:
        """
        Chia danh sách kênh đã tích chọn thành từng đợt theo đúng thứ tự STT (id ASC):
        - Đợt 1: Kênh 1 - 5 trong danh sách chọn
        - Đợt 2: Kênh 6 - 10 trong danh sách chọn
        - Đợt 3: Kênh 11 - 15...
        """
        batch_size = max(1, batch_size)
        cfg = self.get_config()

        if channel_ids is None and cfg.get("target_channel_ids"):
            channel_ids = cfg["target_channel_ids"]

        with db._get_connection() as conn:
            cursor = conn.cursor()
            if channel_ids is not None:
                if len(channel_ids) == 0:
                    return []
                placeholders = ",".join("?" for _ in channel_ids)
                cursor.execute(f"SELECT id, name, username, profile_dir, network_type, proxy_string, use_vpn, is_logged_in FROM channels WHERE id IN ({placeholders}) ORDER BY id ASC", channel_ids)
            else:
                cursor.execute("SELECT id, name, username, profile_dir, network_type, proxy_string, use_vpn, is_logged_in FROM channels ORDER BY id ASC")
            all_channels = [dict(r) for r in cursor.fetchall()]

        batches = []
        for i in range(0, len(all_channels), batch_size):
            chunk = all_channels[i:i + batch_size]
            b_idx = i // batch_size
            b_num = b_idx + 1
            start_num = i + 1
            end_num = min(i + batch_size, len(all_channels))
            batches.append({
                "batch_index": b_idx,
                "batch_number": b_num,
                "label": f"Đợt {b_num} (Kênh {start_num} ➔ {end_num})",
                "start_stt": start_num,
                "end_stt": end_num,
                "channels": chunk,
                "channel_ids": [c["id"] for c in chunk]
            })
        return batches

    # =========================================================================
    # 4. GÁN PROXY VÀ TẮT (OFF) PROXY CHO NHÓM KÊNH
    # =========================================================================
    def assign_proxy_to_channels(self, channel_ids: List[int], proxy_str: str) -> bool:
        """Gán Proxy tĩnh cho nhóm kênh chỉ định (Ưu tiên Proxy số 1)"""
        if not channel_ids or not proxy_str:
            return False
        clean_proxy = proxy_str.strip()
        with db._get_connection() as conn:
            cursor = conn.cursor()
            placeholders = ",".join("?" for _ in channel_ids)
            cursor.execute(f"""
                UPDATE channels
                SET network_type = 'proxy',
                    proxy_string = ?,
                    use_vpn = 1
                WHERE id IN ({placeholders})
            """, [clean_proxy] + list(channel_ids))
            conn.commit()
        return True

    def off_proxy_from_channels(self, channel_ids: List[int]) -> bool:
        """
        OFF PROXY: Tắt và gỡ bỏ Proxy tĩnh khỏi nhóm kênh khi đã đăng xong đợt,
        đồng thời chuyển các kênh đó về MẶC ĐỊNH THỰC HIỆN VPN CỦA PIA (use_vpn = 1, network_type = 'vpn')!
        """
        if not channel_ids:
            return False
        with db._get_connection() as conn:
            cursor = conn.cursor()
            placeholders = ",".join("?" for _ in channel_ids)
            cursor.execute(f"""
                UPDATE channels
                SET network_type = 'vpn',
                    proxy_string = '',
                    use_vpn = 1
                WHERE id IN ({placeholders})
            """, list(channel_ids))
            conn.commit()
        return True

    # =========================================================================
    # 5. ĐIỀU PHỐI ĐĂNG VIDEO XOAY TUA (UPLOAD SCHEDULER COORDINATOR)
    # =========================================================================
    def get_next_batch_for_upload(self, due_schedules: List[Dict[str, Any]], active_channel_ids: set) -> Optional[Dict[str, Any]]:
        """
        Tìm và khởi động Đợt tiếp theo gồm tối đa 5 kênh ĐÃ ĐƯỢC TÍCH CHỌN để chuẩn bị đăng video:
        - Tự động thu hồi các batch cũ nếu các lịch trong batch đó đã xử lý xong.
        - Tự động xoay vòng chu kỳ mới (reset _completed_channels) ngay khi tất cả các kênh có lịch đến hạn đều đã qua 1 lượt!
        """
        cfg = self.get_config()
        if not cfg["enabled"] or not cfg["proxies"]:
            return None

        due_sids = {s["id"] for s in due_schedules}

        with self._lock:
            # 0. Tự động dọn dẹp các active_batch mà lịch trình đã hoàn tất hoặc không còn nằm trong due_schedules + active_channel_ids
            for p_key, b_info in list(self._active_batches.items()):
                still_running = (b_info["channel_ids"] & active_channel_ids) or (b_info["pending_schedules"] & due_sids)
                if not still_running or (time.time() - b_info.get("start_time", 0) > 300 and not (b_info["channel_ids"] & active_channel_ids)):
                    self.off_proxy_from_channels(list(b_info["channel_ids"]))
                    del self._active_batches[p_key]

            used_proxies = set(self._active_batches.keys())
            free_proxies = [p for p in cfg["proxies"] if p not in used_proxies]
            if not free_proxies:
                return None

            target_proxy = free_proxies[0]
            batch_size = cfg["batch_size"]
            target_cids = set(cfg.get("target_channel_ids") or [])

            def _collect_candidates():
                by_ch: Dict[int, List[Dict[str, Any]]] = {}
                for s in due_schedules:
                    cid = s["channel_id"]
                    if target_cids and cid not in target_cids:
                        continue
                    if cid not in self._completed_channels and cid not in active_channel_ids:
                        by_ch.setdefault(cid, []).append(s)
                return by_ch

            schedules_by_ch = _collect_candidates()

            # Nếu vẫn còn lịch đến hạn nhưng tất cả các kênh đó đều đã nằm trong _completed_channels của vòng trước:
            # Lập tức mở vòng xoay tua mới để chạy tiếp tục không ngừng nghỉ!
            if not schedules_by_ch and due_schedules:
                self._completed_channels.clear()
                schedules_by_ch = _collect_candidates()

            if not schedules_by_ch:
                return None

            sorted_channel_ids = sorted(schedules_by_ch.keys())
            batch_channels = sorted_channel_ids[:batch_size]

            batch_schedule_ids = set()
            batch_schedules = []
            for cid in batch_channels:
                # Mỗi lượt xoay tua lấy 1 video đến hạn sớm nhất của mỗi kênh trong 5 kênh để xoay tua cực nhanh
                first_sched = schedules_by_ch[cid][0]
                batch_schedule_ids.add(first_sched["id"])
                batch_schedules.append(first_sched)

            # TỰ ĐỘNG NẠP PROXY TĨNH CHO 5 KÊNH ĐÃ TÍCH CHỌN CỦA ĐỢT NÀY!
            self.assign_proxy_to_channels(batch_channels, target_proxy)

            batch_id = len(self._completed_channels) // batch_size + 1
            self._active_batches[target_proxy] = {
                "batch_id": batch_id,
                "proxy": target_proxy,
                "channel_ids": set(batch_channels),
                "schedule_ids": batch_schedule_ids,
                "pending_schedules": set(batch_schedule_ids),
                "start_time": time.time()
            }

            return {
                "batch_id": batch_id,
                "proxy": target_proxy,
                "channel_ids": batch_channels,
                "schedules": batch_schedules
            }

    def on_schedule_finished(self, schedule_id: int, channel_id: int, log_func=None):
        """
        Khi 1 lịch trình đăng xong:
        - Nếu cả 5 kênh trong đợt đã hoàn tất:
          + Lập tức OFF PROXY khỏi 5 kênh đó.
          + Giải phóng Proxy để gán ngay cho 5 kênh tiếp theo!
        """
        with self._lock:
            for proxy, info in list(self._active_batches.items()):
                if schedule_id in info["pending_schedules"]:
                    info["pending_schedules"].discard(schedule_id)

                if len(info["pending_schedules"]) == 0:
                    batch_channels = list(info["channel_ids"])
                    b_id = info["batch_id"]

                    # 1. LẬP TỨC OFF PROXY CỦA 5 KÊNH ĐỢT NÀY!
                    self.off_proxy_from_channels(batch_channels)
                    for cid in batch_channels:
                        self._completed_channels.add(cid)

                    # 2. Giải phóng batch khỏi danh sách active
                    del self._active_batches[proxy]

                    # 3. Tự động gán sẵn Proxy vừa giải phóng sang 5 kênh tiếp theo trong danh sách tích chọn (nếu còn)
                    cfg = self.get_config()
                    target_cids = sorted(cfg.get("target_channel_ids") or [])
                    remaining_cids = [c for c in target_cids if c not in self._completed_channels]
                    next_preview_cids = remaining_cids[:cfg["batch_size"]]
                    if next_preview_cids:
                        self.assign_proxy_to_channels(next_preview_cids, proxy)

                    msg = (
                        f"🛡️ [Xoay Tua Proxy] ĐỢT #{b_id} ({len(batch_channels)} KÊNH) ĐÃ ĐĂNG XONG! "
                        f"➔ ĐÃ OFF PROXY 5 KÊNH CŨ & CHUYỂN PROXY [{proxy.split('@')[-1]}] SANG 5 KÊNH TIẾP THEO!"
                    )
                    if log_func:
                        log_func(msg)
                    else:
                        print(msg)
                    break

    def reset_cycle(self):
        """Làm mới phiên xoay tua"""
        with self._lock:
            for proxy, info in self._active_batches.items():
                self.off_proxy_from_channels(list(info["channel_ids"]))
            self._active_batches.clear()
            self._completed_channels.clear()

rotating_proxy_mgr = RotatingProxyManager()
