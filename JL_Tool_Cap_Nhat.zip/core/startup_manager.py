# -*- coding: utf-8 -*-
"""
STARTUP & BACKGROUND SERVICE MANAGER
Quản lý chế độ tự khởi động cùng Windows khi bật máy tính (Startup)
và cơ chế giữ luồng hệ thống hoạt động ngầm (Prevent Sleep) để tự động đăng video.
"""

import sys
import os
import ctypes
from pathlib import Path

REG_RUN_KEY = r"Software\Microsoft\Windows\CurrentVersion\Run"
APP_NAME = "JL Tool"

# Windows Execution States
ES_CONTINUOUS = 0x80000000
ES_SYSTEM_REQUIRED = 0x00000001
ES_AWAYMODE_REQUIRED = 0x00000040

_wake_timer_handle = None

def get_launch_command() -> str:
    """Trả về câu lệnh chính xác để Windows khởi động Tool ở chế độ chạy ngầm"""
    base_dir = Path(__file__).resolve().parent.parent
    exe_path = base_dir / "JL Tool.exe"
    if exe_path.exists():
        return f'"{exe_path}" --minimized'
    
    # Nếu chạy mã nguồn Python trực tiếp
    py_exe = sys.executable
    if "python.exe" in py_exe.lower() and os.path.exists(py_exe.lower().replace("python.exe", "pythonw.exe")):
        py_exe = py_exe.lower().replace("python.exe", "pythonw.exe")
    
    main_py = base_dir / "main.py"
    return f'"{py_exe}" "{main_py}" --minimized'

def is_windows_startup_enabled() -> bool:
    """Kiểm tra xem Tool đã được đăng ký tự khởi động cùng Windows chưa"""
    if sys.platform != "win32":
        return False
    try:
        import winreg
        key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, REG_RUN_KEY, 0, winreg.KEY_READ)
        try:
            val, _ = winreg.QueryValueEx(key, APP_NAME)
            return bool(val)
        finally:
            winreg.CloseKey(key)
    except Exception:
        return False

def enable_windows_startup(enable: bool = True) -> bool:
    """Bật/tắt tự động khởi động cùng Windows khi người dùng bật máy tính"""
    if sys.platform != "win32":
        return False
    try:
        import winreg
        key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, REG_RUN_KEY, 0, winreg.KEY_SET_VALUE)
        try:
            # Luôn xóa các khóa trùng lặp cũ (ví dụ 'JL_Tool') để Windows không bao giờ gọi chạy 2 lần cùng lúc!
            for legacy_name in ("JL_Tool", "JLTool", "JL_Tool_Auto"):
                try:
                    winreg.DeleteValue(key, legacy_name)
                except FileNotFoundError:
                    pass
            if enable:
                cmd = get_launch_command()
                winreg.SetValueEx(key, APP_NAME, 0, winreg.REG_SZ, cmd)
            else:
                try:
                    winreg.DeleteValue(key, APP_NAME)
                except FileNotFoundError:
                    pass
            return True
        finally:
            winreg.CloseKey(key)
    except Exception as e:
        print(f"[StartupManager] Lỗi cài đặt Windows Startup: {e}")
        return False

def keep_system_awake(enable: bool = True):
    """
    Giữ cho CPU Windows hoạt động ngầm ngay cả khi người dùng tắt màn hình hoặc bấm Sleep (Away Mode),
    đồng thời kích hoạt đồng hồ đánh thức phần cứng BIOS/RTC.
    """
    if sys.platform != "win32":
        return
    try:
        if enable:
            ctypes.windll.kernel32.SetThreadExecutionState(
                ES_CONTINUOUS | ES_SYSTEM_REQUIRED | ES_AWAYMODE_REQUIRED
            )
        else:
            ctypes.windll.kernel32.SetThreadExecutionState(ES_CONTINUOUS)
    except Exception:
        pass

def enable_hardware_wake_timers():
    """
    Kích hoạt quyền đánh thức máy tính bằng đồng hồ phần cứng (BIOS/RTC Wake Timers)
    và chế độ Away Mode trong cấu hình nguồn Windows (Chạy ngầm không hiện cửa sổ).
    """
    if sys.platform != "win32":
        return
    try:
        import subprocess
        cmds = [
            ["powercfg", "/SETACVALUEINDEX", "SCHEME_CURRENT", "SUB_SLEEP", "RTCWAKE", "1"],
            ["powercfg", "/SETDCVALUEINDEX", "SCHEME_CURRENT", "SUB_SLEEP", "RTCWAKE", "1"],
            ["powercfg", "/SETACVALUEINDEX", "SCHEME_CURRENT", "SUB_SLEEP", "AWAYMODE", "1"],
            ["powercfg", "/SETACTIVE", "SCHEME_CURRENT"]
        ]
        for c in cmds:
            subprocess.run(c, capture_output=True, timeout=3, creationflags=0x08000000)
    except Exception:
        pass

def set_hardware_wake_timer(target_dt) -> bool:
    """
    Đặt đồng hồ phần cứng (Kernel Waitable Timer với fResume=True) để tự động đánh thức
    máy tính từ trạng thái Sleep / Hibernate / Modern Standby trước giờ đăng 90 giây.
    """
    global _wake_timer_handle
    if sys.platform != "win32" or not target_dt:
        return False
    try:
        from datetime import datetime
        import ctypes.wintypes
        now = datetime.now()
        delta_sec = (target_dt - now).total_seconds() - 90.0
        if delta_sec <= 5:
            return False

        kernel32 = ctypes.windll.kernel32
        if not _wake_timer_handle:
            _wake_timer_handle = kernel32.CreateWaitableTimerW(None, True, "Local\JLTool_Hardware_RTC_WakeTimer")
        if not _wake_timer_handle:
            return False

        # Âm (negative) = thời gian tương đối tính bằng đơn vị 100-nanoseconds (1 giây = 10,000,000 ticks)
        due_time = ctypes.c_longlong(int(-delta_sec * 10_000_000))
        ok = kernel32.SetWaitableTimer(
            _wake_timer_handle,
            ctypes.byref(due_time),
            0,
            None,
            None,
            True  # fResume = True -> Đánh thức phần cứng BIOS/ACPI từ chế độ tắt tạm/ngủ đông!
        )
        return bool(ok)
    except Exception:
        return False

