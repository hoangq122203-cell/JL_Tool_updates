import sys
import winsound
import subprocess
import urllib.request
import urllib.parse
import json
import threading
import time
from typing import Optional, Dict, Any, Tuple
from PySide6.QtWidgets import QSystemTrayIcon, QApplication
from PySide6.QtCore import QObject, Signal, Qt
from PySide6.QtGui import QIcon
import config
from database.db_manager import db

def clean_telegram_inputs(bot_token: str, chat_id: str) -> Tuple[str, str]:
    """Làm sạch token và chat ID tự động, chống mọi lỗi copy-paste từ người dùng"""
    token = bot_token.strip().strip('"').strip("'")
    if "telegram.org/bot" in token:
        token = token.split("telegram.org/bot")[-1].split("/")[0].strip()
    if token.lower().startswith("bot") and ":" in token[:15]:
        token = token[3:].strip()
    
    cid = chat_id.strip().strip('"').strip("'")
    if "t.me/" in cid:
        cid = cid.split("t.me/")[-1].strip()
        if not cid.startswith("@") and not cid.lstrip("-").isdigit():
            cid = "@" + cid
            
    return token, cid

def send_telegram_message(text: str, bot_token: str = "", chat_id: str = "") -> Tuple[bool, str]:
    """
    Gửi tin nhắn thông báo đến Telegram qua Telegram Bot API chính thức.
    Hỗ trợ cơ chế đa tuyến (Multi-Route Resilient):
    1. Tuyến chính: api.telegram.org với requests có Session & Keep-Alive
    2. Tuyến dự phòng: Kết nối thẳng qua dãy IP máy chủ Telegram (149.154.166.110, 149.154.167.220)
       giúp vượt qua hoàn toàn việc các nhà mạng VN (FPT, VNPT, Viettel) chặn tên miền api.telegram.org.
    """
    import requests
    import urllib3
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

    if not bot_token:
        bot_token = db.get_setting("telegram_bot_token", "").strip()
    if not chat_id:
        chat_id = db.get_setting("telegram_chat_id", "").strip()

    bot_token, chat_id = clean_telegram_inputs(bot_token, chat_id)

    if not bot_token or not chat_id:
        return False, "Chưa điền Bot Token hoặc Chat ID Telegram."

    payload = {
        "chat_id": chat_id,
        "text": text,
        "parse_mode": "HTML",
        "disable_web_page_preview": True
    }

    # Danh sách các tuyến kết nối (ưu tiên tên miền chính, dự phòng IP máy chủ Telegram)
    routes = [
        ("https://api.telegram.org", True),
        ("https://149.154.166.110", False),
        ("https://149.154.167.220", False),
    ]

    session = requests.Session()
    session.headers.update({
        "User-Agent": "JLTool-Bot/2.0 (Windows NT 10.0; Win64; x64)"
    })

    last_error = ""
    for base_url, verify_ssl in routes:
        url = f"{base_url}/bot{bot_token}/sendMessage"
        req_headers = {"Content-Type": "application/json"}
        if not verify_ssl:
            req_headers["Host"] = "api.telegram.org"

        try:
            resp = session.post(
                url,
                json=payload,
                headers=req_headers,
                verify=verify_ssl,
                timeout=(5, 12)  # Connect timeout 5s, Read timeout 12s
            )

            try:
                res_json = resp.json()
            except Exception:
                res_json = {}

            if res_json.get("ok"):
                return True, "Gửi tin nhắn Telegram thành công!"

            # Nếu máy chủ Telegram trả về lỗi logic (sai token, chưa bấm start, v.v.)
            desc = res_json.get("description", "")
            err_code = res_json.get("error_code", resp.status_code)

            if err_code == 401 or "Unauthorized" in desc:
                return False, "❌ Mã Bot Token không chính xác (401 Unauthorized). Vui lòng kiểm tra lại token copy từ @BotFather."
            elif "chat not found" in desc.lower():
                return False, f"❌ Không tìm thấy người nhận (chat_id: {chat_id}). Hãy đảm bảo bạn đã mở Telegram, tìm bot và bấm nút START!"
            elif "bot was blocked" in desc.lower():
                return False, "❌ Bot đã bị bạn chặn trên Telegram. Vui lòng mở khóa cho bot trên Telegram."
            elif desc:
                return False, f"Telegram API ({err_code}): {desc}"

        except requests.exceptions.Timeout as te:
            last_error = "Hết thời gian chờ phản hồi từ máy chủ Telegram (Timeout)."
            continue
        except requests.exceptions.ConnectionError as ce:
            last_error = f"Lỗi kết nối mạng: {str(ce)}"
            continue
        except Exception as e:
            last_error = f"Lỗi gửi tin: {str(e)}"
            continue

    msg = last_error + "\n\n💡 Gợi ý xử lý: Nhà mạng (FPT/VNPT/Viettel) có thể đang tạm chặn kết nối trực tiếp đến Telegram. Bạn hãy mở ứng dụng VPN (PIA / HMA / WARP 1.1.1.1) hoặc bấm nút 'Mở App VPN' ở góc trên màn hình rồi thử lại nhé!"
    return False, msg

class DesktopNotifier(QObject):
    """
    Quản lý thông báo âm thanh, pop-up Windows và gửi thông báo Telegram khi video đăng tải xong.
    Hỗ trợ Thread-Safe 100%: Có thể gọi từ bất kỳ luồng chạy ngầm nào (Scheduler Thread).
    """
    _notify_signal = Signal(str, str, bool)

    def __init__(self):
        super().__init__()
        self._tray_icon: Optional[QSystemTrayIcon] = None
        self._last_notified: Dict[str, float] = {}
        try:
            self._notify_signal.connect(self._show_toast_slot, Qt.QueuedConnection)
        except Exception:
            pass

    def set_tray_icon(self, tray: QSystemTrayIcon):
        self._tray_icon = tray

    def notify_login_success(self, channel_name: str):
        title = "🎉 JL Tool - Đăng Nhập Kênh Thành Công!"
        msg = f"Kênh '{channel_name}' đã đăng nhập TikTok thành công trên Web!\n✅ Hệ thống đã tự động nhận diện và đồng bộ trạng thái."
        self.notify(title, msg, is_success=True)

    def notify_upload_success(self, channel_name: str, video_title: str, extra_info: Optional[Dict[str, Any]] = None):
        # Chỉ hiện thông báo và phát chuông trên máy tính nếu bật tùy chọn (mặc định tắt, chỉ báo Telegram)
        if db.get_setting("desktop_notify_success", "0") == "1":
            title = "🎉 JL Tool - Đăng Video Thành Công!"
            msg = f"Kênh '{channel_name}' đã hoàn tất đăng video:\n🎬 {video_title}"
            rem = extra_info.get("remaining_count") if extra_info else None
            if rem is not None:
                msg += f"\n📊 Lịch đăng còn lại: {rem} video"
            self.notify(title, msg, is_success=True)

        # Chống gửi trùng lặp thông báo Telegram trong vòng 30 giây cho cùng 1 video
        key = f"{channel_name}_{video_title}"
        now_ts = time.time()
        if now_ts - self._last_notified.get(key, 0) < 30:
            return
        self._last_notified[key] = now_ts

        # Tự động gửi thông báo Telegram nếu tính năng được bật
        try:
            if db.get_setting("telegram_notify_enabled", "0") == "1":
                self.send_telegram_upload_success(channel_name, video_title, extra_info)
        except Exception:
            pass

    def send_telegram_upload_success(self, channel_name: str, video_title: str, extra_info: Optional[Dict[str, Any]] = None):
        """Gửi thông báo video đăng tải thành công về Telegram qua luồng ngầm (non-blocking)"""
        from datetime import datetime
        now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        clean_ch = channel_name.strip()
        if not clean_ch.startswith("@"):
            display_ch = f"@{clean_ch}"
        else:
            display_ch = clean_ch

        info = extra_info or {}
        region = info.get("region") or info.get("target_country") or ""
        duration = info.get("duration", "")
        rem = info.get("remaining_count")

        msg = (
            f"🎉 <b>JL TOOL - ĐĂNG VIDEO THÀNH CÔNG!</b>\n\n"
            f"📺 <b>Kênh TikTok:</b> <code>{display_ch}</code>\n"
            f"🎬 <b>Tên Video:</b> {video_title}\n"
            f"⏰ <b>Thời gian:</b> <code>{now_str}</code>\n"
        )
        if region:
            msg += f"🌐 <b>Khu vực / IP:</b> {region}\n"
        if duration:
            msg += f"⚡ <b>Tốc độ xử lý:</b> {duration}\n"
        
        # Báo cáo số video còn lại trong lịch đăng
        if rem is not None:
            if rem > 2:
                msg += f"📊 <b>Lịch đăng còn lại:</b> <code>{rem} video</code>\n"
            elif rem > 0:
                msg += f"🟠 <b>Lịch đăng còn lại:</b> <code>{rem} video (SẮP HẾT)</code> ⚠️\n"
            else:
                msg += f"🔴 <b>Lịch đăng còn lại:</b> <code>0 video (ĐÃ HẾT VIDEO)</code> ⚠️\n"

        msg += f"✅ <b>Trạng thái:</b> Đã xuất bản và đồng bộ lên TikTok Studio!"

        def _do_send():
            ok, err = send_telegram_message(msg)
            if not ok:
                try:
                    print(f"[Telegram Notifier] ⚠️ {err}")
                except Exception:
                    pass

        threading.Thread(target=_do_send, daemon=True).start()

    def notify_upload_failed(self, channel_name: str, video_title: str, error_msg: str):
        title = "⚠️ JL Tool - Đăng Video Chưa Thành Công!"
        msg = f"Kênh '{channel_name}' ({video_title}):\n{error_msg}\n👉 Hệ thống đang tự động đăng lại ngầm liên tục!"
        self.notify(title, msg, is_success=False)

    def notify(self, title: str, message: str, is_success: bool = True):
        # 1. Phát âm thanh chuông Windows thông báo
        try:
            sound_type = winsound.MB_ICONASTERISK if is_success else winsound.MB_ICONHAND
            winsound.MessageBeep(sound_type)
        except Exception:
            pass

        # 2. Đưa yêu cầu hiển thị toast về luồng giao diện chính (Main GUI Thread)
        try:
            if QApplication.instance():
                self._notify_signal.emit(title, message, is_success)
            else:
                self._show_toast_slot(title, message, is_success)
        except Exception:
            self._show_toast_slot(title, message, is_success)

    def _show_toast_slot(self, title: str, message: str, is_success: bool):
        try:
            if self._tray_icon:
                if not self._tray_icon.isVisible():
                    self._tray_icon.show()
                icon_type = QSystemTrayIcon.Information if is_success else QSystemTrayIcon.Warning
                self._tray_icon.showMessage(title, message, icon_type, 6000)
            else:
                self._native_windows_toast(title, message)
        except Exception:
            try:
                self._native_windows_toast(title, message)
            except Exception:
                pass

    def _native_windows_toast(self, title: str, message: str):
        """Fallback: Sử dụng Windows PowerShell Toast nếu Tray Icon chưa sẵn sàng"""
        try:
            safe_title = title.replace("'", " ")
            safe_msg = message.replace("'", " ").replace("\n", " ")
            ps_cmd = f"""
            [Windows.UI.Notifications.ToastNotificationManager, Windows.UI.Notifications, ContentType = WindowsRuntime] | Out-Null
            $template = [Windows.UI.Notifications.ToastNotificationManager]::GetTemplateContent([Windows.UI.Notifications.ToastTemplateType]::ToastText02)
            $textNodes = $template.GetElementsByTagName("text")
            $textNodes.Item(0).AppendChild($template.CreateTextNode('{safe_title}')) | Out-Null
            $textNodes.Item(1).AppendChild($template.CreateTextNode('{safe_msg}')) | Out-Null
            $toast = [Windows.UI.Notifications.ToastNotification]::new($template)
            [Windows.UI.Notifications.ToastNotificationManager]::CreateToastNotifier("JL Tool").Show($toast)
            """
            subprocess.Popen(["powershell", "-NoProfile", "-WindowStyle", "Hidden", "-Command", ps_cmd], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except Exception:
            pass

notifier = DesktopNotifier()
