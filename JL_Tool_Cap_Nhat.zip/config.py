import os
import sys
from pathlib import Path

# Thư mục gốc của dự án
BASE_DIR = Path(__file__).resolve().parent

# Thư mục dữ liệu
DATA_DIR = BASE_DIR / "data"
DATA_DIR.mkdir(parents=True, exist_ok=True)

# Thư mục lưu Chrome Profiles
PROFILES_DIR = DATA_DIR / "profiles"
PROFILES_DIR.mkdir(parents=True, exist_ok=True)

# Thư mục cơ sở dữ liệu SQLite
DB_PATH = DATA_DIR / "tiktok_manager.db"

# Thư mục video mặc định
DEFAULT_VIDEOS_DIR = DATA_DIR / "videos"
DEFAULT_VIDEOS_DIR.mkdir(parents=True, exist_ok=True)

# Tự động tìm đường dẫn Chrome trên Windows
def find_chrome_path() -> str:
    candidates = [
        r"C:\Program Files\Google\Chrome\Application\chrome.exe",
        r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
        os.path.expandvars(r"%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe"),
        r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
        r"C:\Program Files\Microsoft\Edge\Application\msedge.exe"
    ]
    for path in candidates:
        if os.path.isfile(path):
            return path
    return ""

DEFAULT_CHROME_PATH = find_chrome_path()

# Thông tin ứng dụng
APP_NAME = "JL Tool"
APP_VERSION = "2.4.5"
APP_AUTHOR = "JL Studio"

# Đường dẫn máy chủ kiểm tra cập nhật tự động (GitHub Releases / Web Server)
UPDATE_API_URL = "https://raw.githubusercontent.com/hoangq122203-cell/JL_Tool_updates/main/version.json"

ICON_PATH = BASE_DIR / "assets" / "icon.png"
SPLASH_PATH = BASE_DIR / "assets" / "splash.png"

