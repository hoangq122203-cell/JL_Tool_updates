import sys
import os
import datetime
from PySide6.QtWidgets import (
    QMainWindow, QWidget, QHBoxLayout, QVBoxLayout, QPushButton,
    QLabel, QStackedWidget, QButtonGroup, QFrame, QApplication, QComboBox,
    QSystemTrayIcon, QLayout, QSizePolicy, QProgressDialog, QMessageBox
)
from PySide6.QtGui import QIcon, QPixmap
from PySide6.QtCore import Qt, QTimer, QObject, Signal, QThread
from ui.pages.dashboard_page import DashboardPage
from ui.pages.channels_page import ChannelsPage
from ui.pages.upload_page import UploadPage
from ui.pages.schedule_page import SchedulePage
from ui.pages.history_page import HistoryPage
from ui.pages.settings_page import SettingsPage
from core.network_manager import network_mgr, exec_pia_cmd
from core.vpn_regions import ALL_VPN_COUNTRIES
from database.db_manager import db
from core.chrome_manager import chrome_mgr
from core.notifier import notifier
import config

class IpUpdateWorker(QObject):
    ip_ready = Signal(dict)

    def fetch(self):
        try:
            info = network_mgr.get_detailed_ip_info()
            self.ip_ready.emit(info)
        except Exception:
            pass

class CheckUpdateWorker(QThread):
    finished_check = Signal(bool, dict, str)

    def run(self):
        try:
            from core.auto_updater import auto_updater
            has_update, data, msg = auto_updater.check_for_updates(timeout=8.0)
            self.finished_check.emit(has_update, data, msg)
        except Exception as e:
            self.finished_check.emit(False, {}, f"Không thể kiểm tra cập nhật: {e}")

class ApplyUpdateWorker(QThread):
    progress_val = Signal(int, str)
    finished_apply = Signal(bool, str)

    def __init__(self, download_url: str):
        super().__init__()
        self.download_url = download_url

    def run(self):
        try:
            from core.auto_updater import auto_updater
            success, msg = auto_updater.download_and_apply_update(
                self.download_url,
                progress_callback=lambda p, m: self.progress_val.emit(p, m)
            )
            self.finished_apply.emit(success, msg)
        except Exception as e:
            self.finished_apply.emit(False, str(e))

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle(f"{config.APP_NAME} v{config.APP_VERSION} - Hệ Thống Quản Lý Kênh TikTok Đa Tài Khoản")
        self.resize(1260, 840)
        self.setMinimumSize(1080, 720)
        if os.path.exists(str(config.ICON_PATH)):
            self.setWindowIcon(QIcon(str(config.ICON_PATH)))

        # Khởi tạo thông báo desktop Windows (Tray Notification)
        self.tray_icon = None
        if QSystemTrayIcon.isSystemTrayAvailable():
            self.tray_icon = QSystemTrayIcon(QApplication.instance())
            if os.path.exists(str(config.ICON_PATH)):
                self.tray_icon.setIcon(QIcon(str(config.ICON_PATH)))
            self.tray_icon.setToolTip("JL Tool - Đang Chạy Ngầm Hẹn Giờ Đăng TikTok")

            # Tạo menu chuột phải cho Khay hệ thống (System Tray Menu)
            from PySide6.QtWidgets import QMenu
            tray_menu = QMenu()
            tray_menu.setStyleSheet("""
                QMenu {
                    background-color: #141A29;
                    border: 1px solid #2B3654;
                    color: #FFFFFF;
                    font-size: 12px;
                    padding: 6px;
                }
                QMenu::item {
                    padding: 6px 20px;
                    border-radius: 4px;
                }
                QMenu::item:selected {
                    background-color: #2563EB;
                }
            """)

            act_show = tray_menu.addAction("🖥️ Mở Giao Diện JL Tool")
            act_show.triggered.connect(self.restore_window)

            tray_menu.addSeparator()

            from core.startup_manager import is_windows_startup_enabled
            self.act_autostart = tray_menu.addAction("🚀 Tự Động Chạy Cùng Windows")
            self.act_autostart.setCheckable(True)
            self.act_autostart.setChecked(is_windows_startup_enabled())
            self.act_autostart.triggered.connect(self.toggle_windows_startup)

            tray_menu.addSeparator()

            act_quit = tray_menu.addAction("⏹️ Thoát Hoàn Toàn Tool")
            act_quit.triggered.connect(self.force_quit_app)

            self.tray_icon.setContextMenu(tray_menu)
            self.tray_icon.activated.connect(self.on_tray_activated)
            self.tray_icon.show()
            from core.notifier import notifier
            notifier.set_tray_icon(self.tray_icon)

        self.ip_worker = IpUpdateWorker()
        self.ip_worker.ip_ready.connect(self._on_ip_info_received)

        self.init_ui()

        # Tự động kiểm tra bản cập nhật mới chạy ngầm sau 2.5 giây khi mở app
        QTimer.singleShot(2500, self.start_check_update_async)

    def init_ui(self):
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        main_layout = QHBoxLayout(central_widget)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)

        # ==================== 1. SIDEBAR BÊN TRÁI ====================
        sidebar = QFrame()
        sidebar.setObjectName("sidebar")
        sidebar_layout = QVBoxLayout(sidebar)
        sidebar_layout.setContentsMargins(16, 20, 16, 20)
        sidebar_layout.setSpacing(8)

        # Logo JL TOOL phong cách nổi bật, thương hiệu đẳng cấp
        logo_container = QFrame()
        logo_container.setObjectName("brandCard")
        logo_container.setStyleSheet("""
            QFrame#brandCard {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #18233C, stop:1 #0E1424);
                border: 1.5px solid #2B3D66;
                border-radius: 12px;
                padding: 6px 8px;
            }
        """)
        logo_box = QHBoxLayout(logo_container)
        logo_box.setContentsMargins(6, 6, 6, 6)
        logo_box.setSpacing(10)
        
        lbl_logo_icon = QLabel()
        logo_img_path = str(config.BASE_DIR / "assets" / "logo.png")
        if os.path.exists(logo_img_path):
            pix = QPixmap(logo_img_path)
            scaled_pix = pix.scaled(52, 52, Qt.KeepAspectRatio, Qt.SmoothTransformation)
            lbl_logo_icon.setPixmap(scaled_pix)
            lbl_logo_icon.setFixedSize(52, 52)
            lbl_logo_icon.setStyleSheet("""
                border-radius: 10px;
                border: 2px solid #38BDF8;
                background: transparent;
            """)
        else:
            lbl_logo_icon.setText("🟢")
            lbl_logo_icon.setStyleSheet("font-size: 26px;")
        
        title_box = QVBoxLayout()
        title_box.setSpacing(2)
        title_box.setAlignment(Qt.AlignVCenter)
        lbl_title = QLabel("JL TOOL")
        lbl_title.setObjectName("logoTitle")
        lbl_title.setStyleSheet("""
            font-weight: 900;
            color: #FFFFFF;
            font-size: 19px;
            letter-spacing: 1.2px;
            font-family: 'Segoe UI', Arial, sans-serif;
            border: none;
            background: transparent;
        """)
        lbl_sub = QLabel("TikTok Multi-Profile & VPN")
        lbl_sub.setStyleSheet("""
            color: #38BDF8;
            font-size: 10px;
            font-weight: 700;
            letter-spacing: 0.4px;
            border: none;
            background: transparent;
        """)
        title_box.addWidget(lbl_title)
        title_box.addWidget(lbl_sub)
        
        logo_box.addWidget(lbl_logo_icon)
        logo_box.addLayout(title_box)
        logo_box.addStretch()
        sidebar_layout.addWidget(logo_container)

        sidebar_layout.addSpacing(10)

        # Navigation Buttons Group - GIỮ ĐẦY ĐỦ CÁC CÔNG NĂNG GỐC CỦA TOOL
        self.nav_group = QButtonGroup(self)
        self.nav_group.setExclusive(True)

        nav_items = [
            ("📊  Tổng quan", 0),
            ("📱  Quản lý kênh & Proxy", 1),
            ("📅  Lịch trình đăng bài", 2),
            ("📜  Lịch sử đăng tải", 3),
            ("⚙️  Cấu hình hệ thống", 4),
        ]

        self.nav_buttons = []
        for text, index in nav_items:
            btn = QPushButton(text)
            btn.setProperty("class", "nav-btn")
            btn.setCheckable(True)
            btn.setCursor(Qt.PointingHandCursor)
            btn.clicked.connect(lambda checked=False, idx=index: self.switch_page(idx))
            self.nav_group.addButton(btn, index)
            sidebar_layout.addWidget(btn)
            self.nav_buttons.append(btn)

        sidebar_layout.addStretch()

        # Trạng thái dịch vụ góc dưới giống hệt ảnh
        sys_info_box = QFrame()
        sys_info_box.setStyleSheet("background-color: transparent; border-top: 1px solid #1B2234; padding-top: 10px;")
        sys_layout = QVBoxLayout(sys_info_box)
        sys_layout.setContentsMargins(4, 4, 4, 4)
        sys_layout.setSpacing(6)
        
        row_gemini = QHBoxLayout()
        lbl_g = QLabel("Gemini")
        lbl_g.setStyleSheet("color: #8C9BB0; font-size: 11px;")
        lbl_g_st = QLabel("🟢 online")
        lbl_g_st.setStyleSheet("color: #22C55E; font-size: 11px; font-weight: 600;")
        row_gemini.addWidget(lbl_g)
        row_gemini.addStretch()
        row_gemini.addWidget(lbl_g_st)
        sys_layout.addLayout(row_gemini)

        row_tt = QHBoxLayout()
        lbl_t = QLabel("TikTok")
        lbl_t.setStyleSheet("color: #8C9BB0; font-size: 11px;")
        lbl_t_st = QLabel("🟢 online")
        lbl_t_st.setStyleSheet("color: #22C55E; font-size: 11px; font-weight: 600;")
        row_tt.addWidget(lbl_t)
        row_tt.addStretch()
        row_tt.addWidget(lbl_t_st)
        sys_layout.addLayout(row_tt)

        row_vpn = QHBoxLayout()
        lbl_v = QLabel("PIA VPN")
        lbl_v.setStyleSheet("color: #8C9BB0; font-size: 11px;")
        self.lbl_sidebar_vpn_st = QLabel("🟢 online")
        self.lbl_sidebar_vpn_st.setStyleSheet("color: #22C55E; font-size: 11px; font-weight: 600;")
        row_vpn.addWidget(lbl_v)
        row_vpn.addStretch()
        row_vpn.addWidget(self.lbl_sidebar_vpn_st)
        sys_layout.addLayout(row_vpn)

        # Trạng thái bản quyền theo mã máy HWID
        row_lic = QHBoxLayout()
        lbl_lic_t = QLabel("Bản quyền")
        lbl_lic_t.setStyleSheet("color: #8C9BB0; font-size: 11px;")
        self.btn_license_badge = QPushButton("💎 Active")
        self.btn_license_badge.setCursor(Qt.PointingHandCursor)
        self.btn_license_badge.setStyleSheet("""
            QPushButton {
                background-color: #0F2942;
                color: #38BDF8;
                border: 1px solid #0284C7;
                border-radius: 4px;
                font-weight: 700;
                font-size: 10px;
                padding: 2px 6px;
            }
            QPushButton:hover {
                background-color: #0284C7;
                color: #FFFFFF;
            }
        """)
        self.btn_license_badge.clicked.connect(self.show_license_dialog)
        row_lic.addWidget(lbl_lic_t)
        row_lic.addStretch()
        row_lic.addWidget(self.btn_license_badge)
        sys_layout.addLayout(row_lic)
        self.update_license_badge()

        # Nút kiểm tra & cập nhật phiên bản ngay tại Sidebar (luôn hiển thị ở mọi màn hình)
        row_upd = QHBoxLayout()
        lbl_upd_t = QLabel("Phiên bản")
        lbl_upd_t.setStyleSheet("color: #8C9BB0; font-size: 11px;")
        self.btn_sidebar_update = QPushButton(f"🔄 v{config.APP_VERSION}")
        self.btn_sidebar_update.setCursor(Qt.PointingHandCursor)
        self.btn_sidebar_update.setToolTip("Bấm để kiểm tra & cập nhật phiên bản mới ngay")
        self.btn_sidebar_update.setStyleSheet("""
            QPushButton {
                background-color: #0F2942;
                color: #34D399;
                border: 1px solid #10B981;
                border-radius: 4px;
                font-weight: 700;
                font-size: 10px;
                padding: 2px 6px;
            }
            QPushButton:hover {
                background-color: #059669;
                color: #FFFFFF;
            }
        """)
        self.btn_sidebar_update.clicked.connect(self.check_update_from_sidebar)
        row_upd.addWidget(lbl_upd_t)
        row_upd.addStretch()
        row_upd.addWidget(self.btn_sidebar_update)
        sys_layout.addLayout(row_upd)

        # Nút Mở Bộ Tạo Key Bản Quyền (Chỉ hiển thị trên máy Admin có sẵn file JL_Key_Generator.py)
        from pathlib import Path
        gen_file = Path(__file__).resolve().parent.parent / "JL_Key_Generator.py"
        if gen_file.is_file():
            self.btn_open_key_gen = QPushButton("🔑 BỘ TẠO KEY (ADMIN)")
            self.btn_open_key_gen.setCursor(Qt.PointingHandCursor)
            self.btn_open_key_gen.setStyleSheet("""
                QPushButton {
                    background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #8B5CF6, stop:1 #EC4899);
                    color: #FFFFFF;
                    border: 1px solid #C084FC;
                    border-radius: 6px;
                    font-weight: 800;
                    font-size: 11px;
                    padding: 7px 10px;
                    margin-top: 4px;
                }
                QPushButton:hover {
                    background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #7C3AED, stop:1 #DB2777);
                }
            """)
            self.btn_open_key_gen.setToolTip("Mở bộ tạo Key bản quyền và quản lý danh sách khách hàng dành cho Admin")
            self.btn_open_key_gen.clicked.connect(self.open_key_generator)
            sys_layout.addWidget(self.btn_open_key_gen)

        sidebar_layout.addWidget(sys_info_box)

        main_layout.addWidget(sidebar)

        # ==================== 2. KHU VỰC NỘI DUNG CHÍNH (HEADER + PAGES) ====================
        content_area = QWidget()
        content_layout = QVBoxLayout(content_area)
        content_layout.setContentsMargins(0, 0, 0, 0)
        content_layout.setSpacing(0)

        # BANNER THÔNG BÁO BẢN CẬP NHẬT TỰ ĐỘNG (Ẩn mặc định, tự động trượt ra khi có bản mới)
        self.update_banner = QFrame()
        self.update_banner.setStyleSheet("""
            QFrame {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #1E1B4B, stop:0.5 #0F2942, stop:1 #064E3B);
                border-bottom: 1.5px solid #10B981;
                padding: 6px 16px;
            }
            QLabel {
                border: none;
                background: transparent;
                padding: 0px;
            }
        """)
        b_layout = QHBoxLayout(self.update_banner)
        b_layout.setContentsMargins(14, 6, 14, 6)
        b_layout.setSpacing(12)

        self.lbl_update_banner = QLabel("✨ Đã có bản cập nhật mới!")
        self.lbl_update_banner.setStyleSheet("color: #F8FAFC; font-weight: 700; font-size: 12px;")
        b_layout.addWidget(self.lbl_update_banner, 1)

        self.btn_update_now = QPushButton("🚀 TỰ ĐỘNG CẬP NHẬT (5 GIÂY)")
        self.btn_update_now.setCursor(Qt.PointingHandCursor)
        self.btn_update_now.setFixedHeight(28)
        self.btn_update_now.setStyleSheet("""
            QPushButton {
                background-color: #10B981;
                color: #FFFFFF;
                border: 1px solid #34D399;
                border-radius: 4px;
                font-weight: 800;
                font-size: 11px;
                padding: 0 14px;
            }
            QPushButton:hover {
                background-color: #059669;
            }
        """)
        self.btn_update_now.clicked.connect(self.start_apply_update)
        b_layout.addWidget(self.btn_update_now)

        btn_close_banner = QPushButton("✕")
        btn_close_banner.setCursor(Qt.PointingHandCursor)
        btn_close_banner.setFixedSize(22, 22)
        btn_close_banner.setStyleSheet("background: transparent; color: #94A3B8; border: none; font-size: 12px; font-weight: bold;")
        btn_close_banner.clicked.connect(lambda: self.update_banner.setVisible(False))
        b_layout.addWidget(btn_close_banner)

        content_layout.addWidget(self.update_banner)
        self.update_banner.setVisible(False)
        self._pending_download_url = ""
        self._pending_version = ""

        # TOP BAR HEADER - THIẾT KẾ RỘNG RÃI, CHỮ RÕ RÀNG KHÔNG BỊ CẮT CHỮ
        top_bar = QFrame()
        top_bar.setStyleSheet("background-color: #0A0B10; border-bottom: 1px solid #1A1D28; padding: 6px 16px;")
        top_bar_layout = QHBoxLayout(top_bar)
        top_bar_layout.setContentsMargins(0, 0, 0, 0)
        top_bar_layout.setSpacing(12)

        # Giữ biến để tương thích gọi hàm chuyển trang
        self.lbl_page_header = QLabel("")
        self.lbl_page_header.setVisible(False)

        # ==================== BỘ ĐIỀU KHIỂN VPN TRUNG TÂM & MỞ APP MÁY TÍNH (BÊN TRÁI) ====================
        vpn_box = QFrame()
        vpn_box.setStyleSheet("background-color: #0E1017; border: 1px solid #1E2230; border-radius: 6px; padding: 3px 8px;")
        vpn_l = QHBoxLayout(vpn_box)
        vpn_l.setContentsMargins(0, 0, 0, 0)
        vpn_l.setSpacing(8)

        # Nút Mở thẳng App PIA / HMA trên máy tính
        self.btn_open_desktop_vpn = QPushButton("📱 Mở App VPN")
        self.btn_open_desktop_vpn.setProperty("class", "btn-primary")
        self.btn_open_desktop_vpn.setFixedHeight(28)
        self.btn_open_desktop_vpn.setStyleSheet("background-color: #16A34A; color: #FFFFFF; font-weight: 700; font-size: 11px; padding: 0 10px; border-radius: 5px;")
        self.btn_open_desktop_vpn.setCursor(Qt.PointingHandCursor)
        self.btn_open_desktop_vpn.setToolTip("Mở ứng dụng PIA VPN trên máy tính để đăng nhập hoặc chọn nước")
        self.btn_open_desktop_vpn.clicked.connect(self.handle_open_desktop_vpn)
        vpn_l.addWidget(self.btn_open_desktop_vpn)

        # Nút Hướng dẫn giữ nguyên IP máy tính (Split Tunneling / Proxy)
        self.btn_split_tunnel_guide = QPushButton("💡 Giữ IP Máy Tính")
        self.btn_split_tunnel_guide.setFixedHeight(28)
        self.btn_split_tunnel_guide.setMinimumWidth(115)
        self.btn_split_tunnel_guide.setStyleSheet("background-color: #1E293B; color: #38BDF8; font-weight: 700; font-size: 11px; padding: 0 6px; border-radius: 5px; border: 1px solid #0284C7;")
        self.btn_split_tunnel_guide.setCursor(Qt.PointingHandCursor)
        self.btn_split_tunnel_guide.setToolTip("Cách cài đặt để chỉ riêng Tool fake IP, máy tính vẫn dùng mạng thật không bị gián đoạn")
        self.btn_split_tunnel_guide.clicked.connect(self.show_split_tunnel_guide)
        vpn_l.addWidget(self.btn_split_tunnel_guide)

        # Chọn nhanh quốc gia fake tự động (CHỮ TO RÕ RÀNG, ĐỒNG BỘ GIAO DIỆN)
        self._is_populating_regions = True
        self.cmb_global_region = QComboBox()
        self.cmb_global_region.setMinimumWidth(150)
        self.cmb_global_region.setMaxVisibleItems(15)
        self.cmb_global_region.setCursor(Qt.PointingHandCursor)
        for item in ALL_VPN_COUNTRIES:
            self.cmb_global_region.addItem(item["name"], item["code"])
        self.cmb_global_region.setStyleSheet("""
            QComboBox {
                background-color: #1C2337;
                border: 1px solid #2B3654;
                border-radius: 5px;
                color: #FFFFFF;
                font-size: 12px;
                font-weight: 600;
                padding: 4px 10px;
            }
            QComboBox:hover {
                background-color: #242E48;
                border-color: #38476E;
            }
            QComboBox::drop-down {
                border: none;
                width: 22px;
            }
            QComboBox QAbstractItemView {
                background-color: #1C2337;
                border: 1px solid #2B3654;
                selection-background-color: #2563EB;
                selection-color: #FFFFFF;
                color: #FFFFFF;
                padding: 4px;
            }
        """)

        # Nhãn hiển thị trạng thái đang đổi VPN / Đã đổi VPN
        self.lbl_vpn_switch_stat = QLabel("")
        self.lbl_vpn_switch_stat.setStyleSheet("font-size: 11px; font-weight: 700; color: #22C55E;")

        # Đồng bộ vùng đã lưu nếu có
        saved_reg = db.get_setting("global_vpn_region", "")
        if saved_reg:
            idx = self.cmb_global_region.findData(saved_reg)
            if idx >= 0:
                self.cmb_global_region.setCurrentIndex(idx)
        self._is_populating_regions = False

        # SỰ KIỆN: TỰ ĐỘNG CHUYỂN VÙNG APP KHI CHỌN QUỐC GIA TRÊN TOOL (1-CLICK KÍCH HOẠT, 0 ĐỘ TRỄ)
        self.cmb_global_region.activated.connect(self.on_auto_region_selected)
        self.cmb_global_region.currentIndexChanged.connect(self.on_auto_region_selected)
        vpn_l.addWidget(self.cmb_global_region)
        vpn_l.addWidget(self.lbl_vpn_switch_stat)

        top_bar_layout.addWidget(vpn_box)

        # KHOẢNG TRỐNG CO GIÃN ĐẨY CÁC THÔNG TIN IP VÀ THỜI GIAN SANG PHẢI
        top_bar_layout.addStretch()

        # Badge hiển thị tiến trình tự động tải/cắt video ngầm ở thanh tiêu đề (nhìn thấy ở mọi trang)
        self.lbl_bg_cut_status = QLabel("")
        self.lbl_bg_cut_status.setVisible(False)
        self.lbl_bg_cut_status.setMaximumWidth(420)
        self.lbl_bg_cut_status.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Fixed)
        self.lbl_bg_cut_status.setStyleSheet("""
            QLabel {
                background-color: #0B2A4A;
                color: #38BDF8;
                border: 1px solid #0284C7;
                border-radius: 6px;
                padding: 4px 10px;
                font-size: 11px;
                font-weight: 700;
            }
        """)
        top_bar_layout.addWidget(self.lbl_bg_cut_status)

        # ==================== KHU VỰC HIỂN THỊ CẢ 2 IP: IP MÁY TÍNH GỐC & IP KHI FAKE ====================
        ip_box = QFrame()
        ip_box.setSizePolicy(QSizePolicy.Minimum, QSizePolicy.Fixed)
        ip_box.setStyleSheet("background-color: #0E1017; border: 1px solid #1E2230; border-radius: 6px; padding: 3px 8px;")
        ip_layout = QHBoxLayout(ip_box)
        ip_layout.setContentsMargins(6, 0, 6, 0)
        ip_layout.setSpacing(8)

        # 1. IP Gốc của máy tính
        lbl_real_title = QLabel("💻 IP:")
        lbl_real_title.setStyleSheet("color: #8C9BB0; font-size: 11px; font-weight: 700; border: none; background: transparent;")
        self.lbl_real_ip = QLabel("Đang quét...")
        self.lbl_real_ip.setStyleSheet("color: #FFFFFF; font-weight: 700; font-size: 11px; font-family: Consolas, monospace; border: none; background: transparent;")
        self.lbl_real_ip.setToolTip("Địa chỉ IP thật do nhà mạng Internet cấp cho máy tính của bạn")

        # Dấu phân cách
        lbl_sep = QLabel("|")
        lbl_sep.setStyleSheet("color: #2D3A58; font-size: 11px; border: none; background: transparent;")

        # 2. IP Quốc Gia (VPN / Proxy)
        lbl_fake_title = QLabel("🛡️ IP:")
        lbl_fake_title.setStyleSheet("color: #8C9BB0; font-size: 11px; font-weight: 700; border: none; background: transparent;")
        self.lbl_fake_ip = QLabel("Chưa kết nối")
        self.lbl_fake_ip.setStyleSheet("color: #38BDF8; font-weight: 700; font-size: 11px; font-family: Consolas, monospace; border: none; background: transparent;")
        self.lbl_fake_ip.setToolTip("Địa chỉ IP quốc gia đã kết nối (Các kênh TikTok có bật VPN sẽ chạy qua IP này)")

        # Giữ tương thích alias
        self.lbl_current_ip = self.lbl_fake_ip

        btn_refresh_ip = QPushButton("↻ Quét lại")
        btn_refresh_ip.setToolTip("Kiểm tra và quét lại địa chỉ IP ngay lập tức")
        btn_refresh_ip.setFixedHeight(28)
        btn_refresh_ip.setMinimumWidth(85)
        btn_refresh_ip.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        btn_refresh_ip.setCursor(Qt.PointingHandCursor)
        btn_refresh_ip.setStyleSheet("""
            QPushButton {
                background-color: #1E293B;
                color: #38BDF8;
                border: 1px solid #334155;
                border-radius: 4px;
                padding: 2px 10px;
                font-size: 11px;
                font-weight: 700;
            }
            QPushButton:hover {
                background-color: #2563EB;
                color: #FFFFFF;
                border-color: #60A5FA;
            }
            QPushButton:pressed {
                background-color: #1D4ED8;
            }
        """)
        btn_refresh_ip.clicked.connect(self.update_current_ip)

        ip_layout.addWidget(lbl_real_title)
        ip_layout.addWidget(self.lbl_real_ip)
        ip_layout.addWidget(lbl_sep)
        ip_layout.addWidget(lbl_fake_title)
        ip_layout.addWidget(self.lbl_fake_ip)
        ip_layout.addWidget(btn_refresh_ip)
        top_bar_layout.addWidget(ip_box)

        # Khoảng cách và Đồng hồ thời gian thực
        top_bar_layout.addSpacing(16)
        self.lbl_clock = QLabel()
        self.lbl_clock.setStyleSheet("color: #CBD5E1; font-size: 12px; font-weight: 600; font-family: Consolas, monospace; border: none; background: transparent; padding-left: 10px; border-left: 1px solid #1E2230;")
        top_bar_layout.addWidget(self.lbl_clock)

        content_layout.addWidget(top_bar)

        # STACKED WIDGET CHỨA NỘI DUNG CÁC TRANG
        self.stack = QStackedWidget()

        self.page_dashboard = DashboardPage()
        self.page_channels = ChannelsPage()
        self.page_schedule = SchedulePage()
        self.page_history = HistoryPage()
        self.page_settings = SettingsPage()

        # Kết nối signal (chỉ nạp lại Dashboard khi đang đứng ở trang Dashboard để tránh khựng)
        self.page_dashboard.request_page.connect(self.switch_page)
        self.page_channels.channel_updated.connect(
            lambda: self.page_dashboard.load_data() if self.stack.currentIndex() == 0 else None
        )

        # Kết nối theo dõi tiến trình tải/cắt video ngầm để hiển thị ngay trên thanh tiêu đề chính (gom nhịp 250ms chống nghẽn UI)
        from core.series_queue_manager import series_queue_mgr
        self._bg_cut_timer = QTimer(self)
        self._bg_cut_timer.setSingleShot(True)
        self._bg_cut_timer.setInterval(250)
        self._bg_cut_timer.timeout.connect(self._flush_bg_cut_status)
        series_queue_mgr.queue_updated.connect(self._refresh_bg_cut_status)
        series_queue_mgr.task_progress.connect(self._refresh_bg_cut_status)
        self._flush_bg_cut_status()

        self.stack.addWidget(self.page_dashboard)   # 0
        self.stack.addWidget(self.page_channels)    # 1
        self.stack.addWidget(self.page_schedule)    # 2
        self.stack.addWidget(self.page_history)     # 3
        self.stack.addWidget(self.page_settings)    # 4

        content_layout.addWidget(self.stack)
        main_layout.addWidget(content_area)

        # Timer cập nhật đồng hồ mỗi giây
        self.timer_clock = QTimer(self)
        self.timer_clock.timeout.connect(self.update_clock)
        self.timer_clock.start(1000)
        self.update_clock()

        # TỰ ĐỘNG ĐỒNG BỘ IP THỜI GIAN THỰC (THEO DÕI APP PIA / HMA MỖI 15 GIÂY)
        # Đảm bảo hiển thị IP trên Tool đồng bộ nhưng không tốn CPU / spawn process liên tục
        self.last_vpn_signature = None
        self._is_checking_vpn = False
        self.timer_vpn_sync = QTimer(self)
        self.timer_vpn_sync.timeout.connect(self.check_vpn_app_change_auto)
        self.timer_vpn_sync.start(15000)

        # ĐẢM BẢO KHI MỞ TOOL: Máy tính luôn ở 100% mạng gốc Việt Nam siêu tốc, không bị VPN làm chậm
        if db.get_setting("auto_disconnect_vpn_after_post", "0") == "1":
            try:
                network_mgr.pia_disconnect()
            except Exception:
                pass

        # Kiểm tra IP máy lần đầu trong background
        QTimer.singleShot(500, self.update_current_ip)

        # TỰ ĐỘNG THEO DÕI ĐĂNG NHẬP WEB THỜI GIAN THỰC & ĐỒNG BỘ TỨC THÌ
        chrome_mgr.register_login_listener(self.on_channel_login_detected)

        # Quét ngầm tự động đồng bộ tài khoản đã đăng nhập định kỳ mỗi 90 giây (giảm tải Disk I/O)
        self._is_syncing_login = False
        self.timer_login_sync = QTimer(self)
        self.timer_login_sync.timeout.connect(lambda: self.auto_sync_all_channels_login(show_notify=True))
        self.timer_login_sync.start(90000)

        # Quét lần đầu ngay khi mở phần mềm để đồng bộ ngay lập tức các kênh đã đăng nhập
        QTimer.singleShot(600, lambda: self.auto_sync_all_channels_login(show_notify=False))

        # BẢO VỆ BẢN QUYỀN THỜI GIAN THỰC (REAL-TIME LICENSE SECURITY - SIÊU NHẸ)
        # Giám sát định kỳ 20 giây (chỉ đọc RAM 0ms, không lag giao diện):
        # - Nếu bị xóa khỏi danh sách máy cấp key -> Tự động out, đóng tool ngay lập tức.
        # - Nếu hết hạn sử dụng -> Khóa toàn bộ phần mềm, chỉ cho phép gia hạn.
        self._is_enforcing_license = False
        self.timer_license_enforcer = QTimer(self)
        self.timer_license_enforcer.timeout.connect(self.enforce_license_security)
        self.timer_license_enforcer.start(20000)

        # Mặc định mở trang Tổng quan (không nạp lại trùng lặp lần 2 lúc khởi động)
        self.switch_page(0, force_reload=False)

    def on_channel_login_detected(self, channel_id: int, channel_name: str):
        """Xử lý đồng bộ ngay lập tức khi phát hiện kênh đăng nhập thành công trên Web"""
        def handle():
            # Đồng bộ toàn bộ các trang trên giao diện
            if hasattr(self, "page_dashboard") and hasattr(self.page_dashboard, "load_data"):
                self.page_dashboard.load_data()
            if hasattr(self, "page_channels") and hasattr(self.page_channels, "load_channels"):
                self.page_channels.load_channels()
            if hasattr(self, "page_upload") and hasattr(self.page_upload, "load_channels_list"):
                self.page_upload.load_channels_list()

            # Thông báo chuông và toast khay hệ thống Windows
            notifier.notify_login_success(channel_name)

            # Hiển thị thông báo nổi bật trên Tool
            from PySide6.QtWidgets import QMessageBox
            msg_box = QMessageBox(self)
            msg_box.setWindowTitle("🎉 Đăng Nhập Thành Công")
            msg_box.setText(
                f"🎉 Kênh <b>{channel_name}</b> đã hoàn tất đăng nhập TikTok trên Web!<br><br>"
                "✅ Hệ thống đã tự động nhận diện và đồng bộ trạng thái <b>SẴN SÀNG</b> trên Tool."
            )
            msg_box.setIcon(QMessageBox.Information)
            msg_box.setStandardButtons(QMessageBox.Ok)
            msg_box.show()

        QTimer.singleShot(0, handle)

    def auto_sync_all_channels_login(self, show_notify: bool = False):
        """Quét ngầm tất cả các kênh chưa login xem đã đăng nhập chưa để tự động đồng bộ (bảo vệ chống trùng lặp luồng)"""
        if getattr(self, "_is_syncing_login", False):
            return
        self._is_syncing_login = True
        import threading
        def worker():
            try:
                channels = db.get_all_channels()
                if not channels:
                    return

                detected = []
                lost_login = []
                for ch in channels:
                    p = ch.get("profile_dir", "")
                    if not p:
                        continue
                    has_cookie = chrome_mgr.check_login_status_by_cookies(p)
                    was_logged = bool(ch.get("is_logged_in"))
                    if not was_logged and has_cookie:
                        db.update_channel_login_status(ch["id"], True)
                        detected.append(ch)
                    elif was_logged and not has_cookie:
                        # Chỉ hạ trạng thái nếu thực sự đọc được profile / không có file cookie (tránh nhầm lúc mới tạo)
                        resolved = chrome_mgr.resolve_profile_path(p)
                        if resolved:
                            db.update_channel_login_status(ch["id"], False)
                            lost_login.append(ch)

                if detected or lost_login:
                    def finish():
                        if hasattr(self, "page_dashboard") and hasattr(self.page_dashboard, "load_data") and getattr(self, "stack", None) and self.stack.currentIndex() == 0:
                            self.page_dashboard.load_data()
                        if hasattr(self, "page_channels"):
                            if hasattr(self.page_channels, "_request_channels_reload"):
                                self.page_channels._request_channels_reload()
                            elif hasattr(self.page_channels, "load_channels"):
                                self.page_channels.load_channels()
                        if hasattr(self, "page_upload") and hasattr(self.page_upload, "load_channels_list"):
                            self.page_upload.load_channels_list()

                        if show_notify:
                            for c in detected:
                                notifier.notify_login_success(c.get("name", "Kênh"))
                    QTimer.singleShot(0, finish)
            except Exception:
                pass
            finally:
                self._is_syncing_login = False

        threading.Thread(target=worker, daemon=True).start()

    def _refresh_bg_cut_status(self, *args):
        """Gom nhịp cập nhật thanh trạng thái cắt video ngầm (tối đa 4 lần/giây) để không làm đơ giao diện."""
        if hasattr(self, "_bg_cut_timer"):
            if not self._bg_cut_timer.isActive():
                self._bg_cut_timer.start()
        else:
            self._flush_bg_cut_status()

    def _flush_bg_cut_status(self):
        """Hiển thị trạng thái tải/cắt video tự động ngay trên thanh tiêu đề chính của phần mềm."""
        try:
            from core.series_queue_manager import series_queue_mgr
            summary = series_queue_mgr.get_active_summary()
            if summary:
                short_txt = summary if len(summary) <= 68 else summary[:65] + "..."
                if self.lbl_bg_cut_status.text() != short_txt:
                    self.lbl_bg_cut_status.setText(short_txt)
                    self.lbl_bg_cut_status.setToolTip(summary)
                if not self.lbl_bg_cut_status.isVisible():
                    self.lbl_bg_cut_status.setVisible(True)
            else:
                if self.lbl_bg_cut_status.isVisible() or self.lbl_bg_cut_status.text():
                    self.lbl_bg_cut_status.clear()
                    self.lbl_bg_cut_status.setToolTip("")
                    self.lbl_bg_cut_status.setVisible(False)
        except Exception:
            pass

    def check_vpn_app_change_auto(self):
        """
        Theo dõi trạng thái App PIA / HMA trên máy tính định kỳ.
        Nếu người dùng đổi IP hoặc ngắt kết nối trên App máy tính, Tool tự động cập nhật ngay lập tức!
        """
        if getattr(self, "_is_checking_vpn", False):
            return
        self._is_checking_vpn = True
        import threading
        def watcher():
            try:
                pia_exe = network_mgr.get_pia_path()
                if not pia_exe or not os.path.isfile(pia_exe):
                    return
                st = exec_pia_cmd([pia_exe, "get", "connectionstate"], timeout=1).stdout.strip()
                vpnip = exec_pia_cmd([pia_exe, "get", "vpnip"], timeout=1).stdout.strip()
                sig = f"{st}|{vpnip}"
                if sig != self.last_vpn_signature:
                    self.last_vpn_signature = sig
                    self.ip_worker.fetch()
            except Exception:
                pass
            finally:
                self._is_checking_vpn = False
        threading.Thread(target=watcher, daemon=True).start()

    def handle_open_desktop_vpn(self):
        """Mở thẳng ứng dụng PIA VPN trên máy tính để đăng nhập tài khoản hoặc chọn nước"""
        ok, msg = network_mgr.open_vpn_desktop_app("pia")
        from PySide6.QtWidgets import QMessageBox
        if ok:
            QMessageBox.information(
                self, "Đã mở PIA VPN",
                "✅ Đã mở ứng dụng PIA VPN trên máy tính thành công!\n\n"
                "• Bạn có thể đăng nhập tài khoản hoặc kiểm tra trực tiếp trên app PIA.\n"
                "• Sau đó chỉ cần chọn Quốc gia ngay trên thanh công cụ của Tool, PIA sẽ tự động đổi IP cho toàn bộ kênh!"
            )
        else:
            QMessageBox.warning(self, "Thông báo", msg)

    def show_split_tunnel_guide(self):
        """Mở cửa sổ hướng dẫn giữ IP máy tính (Split Tunneling & Proxy)"""
        from ui.components.split_tunnel_dialog import SplitTunnelGuideDialog
        dlg = SplitTunnelGuideDialog(self)
        dlg.exec()

    def on_auto_region_selected(self, index: int):
        """
        TỰ ĐỘNG CHUYỂN VÙNG IP NGẦM KHI TÍCH CHỌN QUỐC GIA TRÊN TOOL.
        - Tự động kích hoạt đổi IP ngầm sang quốc gia đã chọn trong 0.05 giây.
        - Màn hình tự động nhảy sang IP quốc gia đó và hiển thị địa chỉ IP thực tế.
        - Mạng gốc máy tính vẫn được giữ nguyên độc lập.
        """
        if getattr(self, "_is_populating_regions", False):
            return
        if index < 0:
            return

        region_code = self.cmb_global_region.currentData()
        country_name = self.cmb_global_region.currentText()
        if not region_code:
            return

        import time
        now = time.time()
        if hasattr(self, "_last_switch_trigger"):
            last_code, last_time = self._last_switch_trigger
            if last_code == region_code and (now - last_time) < 0.25:
                return
        self._last_switch_trigger = (region_code, now)

        short_name = country_name.split("(")[0].strip()

        # Cập nhật phản hồi giao diện ngay lập tức
        if hasattr(self, "lbl_vpn_switch_stat"):
            self.lbl_vpn_switch_stat.setText(f"⏳ Đang nhảy sang {short_name}...")
            self.lbl_vpn_switch_stat.setStyleSheet("font-size: 11px; font-weight: 700; color: #F59E0B;")
        if hasattr(self, "lbl_fake_ip"):
            self.lbl_fake_ip.setText(f"Đang nhảy IP {short_name}...")
            self.lbl_fake_ip.setStyleSheet("color: #F59E0B; font-weight: 700; font-size: 11px; font-family: Consolas, monospace;")

        self.cmb_global_region.setEnabled(True)

        # Lưu cấu hình vào database
        db.set_setting("global_vpn_region", region_code)
        db.set_setting("global_vpn_country_name", country_name)
        db.set_setting("cached_fake_country", country_name)

        # Tự động kết nối PIA VPN sang quốc gia đã chọn ngay lập tức để Chrome dùng đúng 100%
        if hasattr(self, "lbl_vpn_switch_stat"):
            self.lbl_vpn_switch_stat.setText(f"⏳ Đang kết nối {short_name}...")
            self.lbl_vpn_switch_stat.setStyleSheet("font-size: 11px; font-weight: 700; color: #F59E0B;")
        if hasattr(self, "lbl_fake_ip"):
            self.lbl_fake_ip.setText(f"Đang kết nối {short_name}...")
            self.lbl_fake_ip.setStyleSheet("color: #F59E0B; font-weight: 700; font-size: 11px; font-family: Consolas, monospace;")

        import threading
        def _connect_bg():
            try:
                network_mgr.pia_connect(region=region_code)
                time.sleep(1.5)
                if hasattr(self, "ip_worker"):
                    self.ip_worker.fetch()
            except Exception:
                pass

        threading.Thread(target=_connect_bg, daemon=True).start()

        # CẬP NHẬT GIAO DIỆN CÁC TRANG (TỔNG QUAN, KÊNH)
        if hasattr(self, "page_dashboard") and hasattr(self.page_dashboard, "load_data"):
            self.page_dashboard.load_data()
        if hasattr(self, "page_channels") and hasattr(self.page_channels, "load_channels"):
            self.page_channels.load_channels()

    def handle_switch_global_vpn(self):
        """Đổi vùng PIA VPN hoặc xoay IP HMA cho toàn bộ máy tính và tất cả các kênh TikTok"""
        vpn_type = self.cmb_global_vpn_type.currentData()
        region = self.cmb_global_region.currentData()
        region_name = self.cmb_global_region.currentText()

        self.btn_switch_vpn.setEnabled(False)
        self.btn_switch_vpn.setText("⏳ Đang đổi vùng...")
        self.lbl_current_ip.setText("Đang đổi IP...")

        import threading
        def worker():
            ok, msg = network_mgr.switch_global_vpn(vpn_type, region)

            def finish():
                self.btn_switch_vpn.setEnabled(True)
                self.btn_switch_vpn.setText("⚡ ĐỔI VÙNG CHO TẤT CẢ KÊNH")
                self.update_current_ip()
                if ok:
                    from PySide6.QtWidgets import QMessageBox
                    QMessageBox.information(
                        self, "Đổi Vùng Thành Công",
                        f"Đã chuyển kết nối toàn hệ thống sang: <b>{region_name}</b>!<br><br>"
                        "Tất cả các kênh TikTok có tích chọn 'Bật VPN' đã sẵn sàng ở vùng này!"
                    )
                else:
                    from PySide6.QtWidgets import QMessageBox
                    QMessageBox.warning(self, "Thông báo VPN", msg)

            QTimer.singleShot(0, finish)

        threading.Thread(target=worker, daemon=True).start()

    def update_clock(self):
        now_str = datetime.datetime.now().strftime("%H:%M:%S  |  %d/%m/%Y")
        self.lbl_clock.setText(now_str)

    def update_current_ip(self):
        self.lbl_fake_ip.setText("Đang quét...")
        import threading
        threading.Thread(target=self.ip_worker.fetch, daemon=True).start()

    def _on_ip_info_received(self, info: dict):
        self.last_vpn_signature = f"{info.get('raw_state')}|{info.get('fake_ip')}"
        real_text = info.get("real_ip", "")
        if info.get("real_country"):
            short_c = info["real_country"].split("(")[-1].replace(")", "").strip()
            real_text = f"{info['real_ip']} ({short_c})"

        if info.get("is_faked"):
            fake_c_short = info["fake_country"].split("(")[0].strip()
            fake_text = f"{info['fake_ip']} ({fake_c_short})"
            fake_color = "#38BDF8"
            if hasattr(self, "lbl_sidebar_vpn_st"):
                self.lbl_sidebar_vpn_st.setText("🟢 online")
                self.lbl_sidebar_vpn_st.setStyleSheet("color: #22C55E; font-size: 11px; font-weight: 600;")
        else:
            fake_text = "Chưa kết nối (IP gốc)"
            fake_color = "#94A3B8"
            if hasattr(self, "lbl_sidebar_vpn_st"):
                self.lbl_sidebar_vpn_st.setText("⚪ offline")
                self.lbl_sidebar_vpn_st.setStyleSheet("color: #64748B; font-size: 11px; font-weight: 500;")

        self.lbl_real_ip.setText(real_text)
        self.lbl_fake_ip.setText(fake_text)
        self.lbl_fake_ip.setStyleSheet(f"color: {fake_color}; font-weight: 800; font-size: 12px; font-family: Consolas, monospace;")

        # Lưu IP vào cache ở luồng ngầm (tuyệt đối không ghi SQLite đồng bộ trên luồng giao diện)
        fake_ip_val = info.get("fake_ip", "")
        fake_cnt_val = info.get("fake_country", "")
        real_ip_val = info.get("real_ip", "")
        if fake_ip_val or fake_cnt_val or real_ip_val:
            import threading
            def _save_ip_cache():
                try:
                    if fake_ip_val:
                        db.set_setting("cached_fake_ip", fake_ip_val)
                    if fake_cnt_val:
                        db.set_setting("cached_fake_country", fake_cnt_val)
                    if real_ip_val:
                        db.set_setting("cached_real_machine_ip", real_ip_val)
                except Exception:
                    pass
            threading.Thread(target=_save_ip_cache, daemon=True).start()

        # Tự động cập nhật bảng Tổng quan và bảng Quản lý kênh (gom nhịp không gây khựng)
        if hasattr(self, "stack"):
            current_idx = self.stack.currentIndex()
            if current_idx == 0 and hasattr(self, "page_dashboard"):
                self.page_dashboard.load_data()
            elif current_idx == 1 and hasattr(self, "page_channels"):
                if hasattr(self.page_channels, "_request_channels_reload"):
                    self.page_channels._request_channels_reload()
                else:
                    self.page_channels.load_channels()

    def handle_videos_to_upload(self, video_paths: list):
        """Mở dialog đặt lịch hẹn đăng video trực tiếp với các video đã chọn"""
        from ui.components.schedule_dialog import ScheduleDialog
        dlg = ScheduleDialog(self, preselected_video_path=video_paths[0] if video_paths else None)
        if len(video_paths) > 1:
            dlg.set_videos(video_paths)
        dlg.exec()
        if hasattr(self, "page_schedule"):
            self.page_schedule.load_schedules()

    def switch_page(self, index: int, force_reload: bool = True):
        self.stack.setCurrentIndex(index)
        for btn in self.nav_buttons:
            if self.nav_group.id(btn) == index:
                btn.setChecked(True)
                break

        page_titles = [
            "TỔNG QUAN",
            "TÀI KHOẢN TIKTOK & PROXY / VPN",
            "LỊCH TRÌNH ĐĂNG BÀI",
            "NHẬT KÝ & LỊCH SỬ ĐĂNG",
            "CẤU HÌNH HỆ THỐNG"
        ]
        if 0 <= index < len(page_titles):
            self.lbl_page_header.setText(page_titles[index])

        if not force_reload:
            return

        # Tải lại dữ liệu trang tương ứng
        if index == 0:
            self.page_dashboard.load_data()
        elif index == 1:
            self.page_channels.load_channels()
        elif index == 2:
            self.page_schedule.load_schedules()
        elif index == 3:
            self.page_history.load_history()
        elif index == 4:
            self.page_settings.load_settings()

    def restore_window(self):
        """Khôi phục và hiển thị lại cửa sổ giao diện chính của Tool lên trước màn hình (Bypass giới hạn focus của Windows)"""
        try:
            import sys
            self.setWindowState(self.windowState() & ~Qt.WindowMinimized | Qt.WindowActive)
            self.setVisible(True)
            self.show()
            self.showNormal()
            self.raise_()
            self.activateWindow()
            if sys.platform == "win32":
                try:
                    import ctypes
                    hwnd = int(self.winId())
                    user32 = ctypes.windll.user32
                    kernel32 = ctypes.windll.kernel32

                    # Kỹ thuật AttachThreadInput: Buộc Windows trao quyền Foreground tuyệt đối cho Tool
                    fg_hwnd = user32.GetForegroundWindow()
                    fg_thread = user32.GetWindowThreadProcessId(fg_hwnd, None)
                    cur_thread = kernel32.GetCurrentThreadId()

                    if fg_thread != cur_thread and fg_thread != 0:
                        user32.AttachThreadInput(cur_thread, fg_thread, True)
                        user32.ShowWindow(hwnd, 9)  # 9 = SW_RESTORE
                        user32.SetForegroundWindow(hwnd)
                        user32.BringWindowToTop(hwnd)
                        user32.AttachThreadInput(cur_thread, fg_thread, False)
                    else:
                        user32.ShowWindow(hwnd, 9)
                        user32.SetForegroundWindow(hwnd)
                        user32.BringWindowToTop(hwnd)

                    user32.SwitchToThisWindow(hwnd, True)
                except Exception:
                    pass
        except Exception:
            pass

    def on_tray_activated(self, reason):
        """Nhấp chuột vào icon khay hệ thống sẽ mở lại cửa sổ Tool"""
        from PySide6.QtWidgets import QSystemTrayIcon
        if reason in (QSystemTrayIcon.Trigger, QSystemTrayIcon.DoubleClick):
            self.restore_window()

    def toggle_windows_startup(self, checked: bool):
        """Bật/tắt tự động khởi động cùng Windows khi người dùng mở máy tính"""
        from core.startup_manager import enable_windows_startup
        enable_windows_startup(checked)

    def force_quit_app(self):
        """Thoát hoàn toàn ứng dụng từ menu chuột phải khay hệ thống và dọn tiến trình con tránh treo máy"""
        import os
        try:
            from core.scheduler_service import scheduler_service
            if scheduler_service.is_running:
                scheduler_service.stop()
        except Exception:
            pass
        try:
            from core.startup_manager import keep_system_awake
            keep_system_awake(False)
        except Exception:
            pass
        try:
            import psutil
            prof_marker = os.path.normcase(str(config.DATA_DIR / "profiles"))
            for proc in psutil.process_iter(["pid", "name", "cmdline"]):
                try:
                    pname = (proc.info.get("name") or "").lower()
                    if pname == "ffmpeg.exe":
                        proc.kill()
                    elif pname == "chrome.exe":
                        cmd_str = os.path.normcase(" ".join(proc.info.get("cmdline") or []))
                        if prof_marker in cmd_str:
                            proc.kill()
                except Exception:
                    continue
        except Exception:
            pass
        if self.tray_icon:
            self.tray_icon.hide()
        try:
            from PySide6.QtNetwork import QLocalServer
            QLocalServer.removeServer("JLTool_SingleInstance_App_Server")
        except Exception:
            pass
        from PySide6.QtWidgets import QApplication
        QApplication.quit()
        os._exit(0)

    def closeEvent(self, event):
        """
        KHI BẤM DẤU [X] TẮT TOOL:
        Tool KHÔNG BỊ TẮT mà tự động ẩn xuống Khay hệ thống (System Tray).
        Dịch vụ hẹn giờ đăng video và chuông thông báo vẫn liên tục hoạt động bình thường!
        """
        from PySide6.QtWidgets import QSystemTrayIcon
        event.ignore()
        self.hide()

        # Đảm bảo dịch vụ hẹn giờ đăng ngầm đang chạy liên tục
        from core.scheduler_service import scheduler_service
        if not scheduler_service.is_running:
            scheduler_service.start()

        # Giữ cho máy tính không bị rơi vào chế độ Sleep làm ngắt luồng
        from core.startup_manager import keep_system_awake
        keep_system_awake(True)

        if self.tray_icon:
            if not self.tray_icon.isVisible():
                self.tray_icon.show()
            self.tray_icon.showMessage(
                "JL Tool vẫn đang chạy ngầm",
                "Hệ thống hẹn giờ đăng video và chuông thông báo vẫn hoạt động bình thường dưới khay hệ thống.\nNhấp chuột vào biểu tượng để mở lại cửa sổ bất cứ lúc nào.",
                QSystemTrayIcon.Information,
                5000
            )
        else:
            from core.notifier import notifier
            notifier.notify(
                "JL Tool vẫn đang chạy ngầm",
                "Hệ thống hẹn giờ đăng video vẫn hoạt động bình thường khi đóng cửa sổ!",
                is_success=True
            )

    def update_license_badge(self):
        """Cập nhật nhãn trạng thái bản quyền HWID ở góc dưới thanh Sidebar"""
        if not hasattr(self, 'btn_license_badge'):
            return
        from core.license_manager import license_mgr
        valid, msg, info = license_mgr.check_current_license()
        if valid:
            if info.get("is_lifetime"):
                txt = "🌟 Vĩnh Viễn"
                tip = "💎 Bản quyền Vĩnh Viễn theo máy tính này\n👉 Bấm vào để xem mã máy hoặc cập nhật key"
                st = "background-color: #064E3B; color: #34D399; border: 1px solid #10B981; border-radius: 4px; font-weight: 700; font-size: 10px; padding: 2px 6px;"
            else:
                days = info.get("days_left", 0)
                txt = f"💎 Còn {days} ngày"
                tip = f"💎 Bản quyền hết hạn ngày {info.get('exp_date_str', '')}\n👉 Bấm vào để xem mã máy hoặc gia hạn"
                st = "background-color: #0F2942; color: #38BDF8; border: 1px solid #0284C7; border-radius: 4px; font-weight: 700; font-size: 10px; padding: 2px 6px;"
        else:
            txt = "🔴 Hết hạn"
            tip = "⚠️ Bản quyền chưa kích hoạt hoặc đã hết hạn\n👉 Bấm vào để kích hoạt gia hạn ngay!"
            st = "background-color: #450A0A; color: #F87171; border: 1px solid #EF4444; border-radius: 4px; font-weight: 700; font-size: 10px; padding: 2px 6px;"
        sig = (txt, st)
        if getattr(self, "_last_license_badge_sig", None) == sig:
            return
        self._last_license_badge_sig = sig
        self.btn_license_badge.setText(txt)
        self.btn_license_badge.setToolTip(tip)
        self.btn_license_badge.setStyleSheet(st)

    def enforce_license_security(self):
        """
        Bảo vệ bản quyền thời gian thực (kiểm tra ở luồng ngầm để không bao giờ khóa luồng giao diện):
        1. Nếu máy tính bị xóa khỏi danh sách Admin -> Tự động out, đóng tool ngay lập tức.
        2. Nếu hết hạn sử dụng -> Khóa toàn bộ phần mềm, chỉ cho phép mở cửa sổ Gia hạn.
        """
        if getattr(self, '_is_enforcing_license', False) or getattr(self, '_is_checking_license', False):
            return
        self._is_checking_license = True

        import threading
        def _bg_check():
            try:
                from core.license_manager import license_mgr
                valid, msg, info = license_mgr.check_current_license()
            except Exception:
                self._is_checking_license = False
                return

            def _apply_result():
                self._is_checking_license = False
                self._handle_license_check_result(valid, msg, info)
            QTimer.singleShot(0, _apply_result)

        threading.Thread(target=_bg_check, daemon=True).start()

    def _handle_license_check_result(self, valid: bool, msg: str, info: dict):
        if getattr(self, '_is_enforcing_license', False):
            return
        if valid:
            self.update_license_badge()
            return

        from core.license_manager import license_mgr
        self._is_enforcing_license = True

        # Dừng toàn bộ tiến trình đăng ngầm ngay lập tức
        try:
            from core.scheduler_service import scheduler_service
            if scheduler_service.is_running:
                scheduler_service.stop()
        except Exception:
            pass

        # Trường hợp 1: Bị Admin xóa khỏi danh sách máy đã cấp key hoặc bị thu hồi
        if info.get("status") == "REVOKED" or info.get("is_revoked"):
            if hasattr(self, 'timer_license_enforcer'):
                self.timer_license_enforcer.stop()
            hwid = info.get("hwid", license_mgr.get_hardware_id())
            QMessageBox.critical(
                self,
                "❌ THU HỒI BẢN QUYỀN",
                f"<b>BẢN QUYỀN MÁY TÍNH ĐÃ BỊ THU HỒI!</b><br><br>"
                f"• Mã máy tính: <b>{hwid}</b><br>"
                f"• Lý do: Máy tính này đã bị Quản Trị Viên (Admin) xóa hoặc thu hồi khỏi danh sách cấp bản quyền.<br><br>"
                f"⚠️ <b>Phần mềm sẽ tự động đóng ngay bây giờ!</b>"
            )
            QApplication.quit()
            import sys
            sys.exit(0)

        # Trường hợp 2: Hết hạn sử dụng hoặc chưa kích hoạt
        # Khóa toàn bộ các chức năng, chỉ mở cửa sổ Gia Hạn
        if hasattr(self, 'timer_license_enforcer'):
            self.timer_license_enforcer.stop()

        from ui.components.license_dialog import LicenseDialog
        dlg = LicenseDialog(parent=self, is_mandatory=True)
        if dlg.exec() == LicenseDialog.Accepted:
            # Người dùng đã gia hạn thành công -> Tiếp tục sử dụng
            self._is_enforcing_license = False
            self.update_license_badge()
            if hasattr(self, 'timer_license_enforcer'):
                self.timer_license_enforcer.start(8000)
        else:
            # Người dùng đóng cửa sổ mà không gia hạn -> Tự động thoát phần mềm
            QApplication.quit()
            import sys
            sys.exit(0)

    def show_license_dialog(self):
        """Mở cửa sổ chi tiết bản quyền và gia hạn"""
        from ui.components.license_dialog import LicenseDialog
        from core.license_manager import license_mgr
        valid, _, _ = license_mgr.check_current_license()
        dlg = LicenseDialog(parent=self, is_mandatory=not valid)
        if dlg.exec() == LicenseDialog.Accepted:
            self.update_license_badge()
        elif not valid:
            QApplication.quit()
            import sys
            sys.exit(0)

    def open_key_generator(self):
        """Mở cửa sổ Bộ Tạo Key & Quản Lý Khách Hàng Admin ngay trong Tool"""
        from JL_Key_Generator import JLKeyGeneratorApp
        if not hasattr(self, '_admin_key_gen_win') or self._admin_key_gen_win is None:
            self._admin_key_gen_win = JLKeyGeneratorApp()
        self._admin_key_gen_win.show()
        self._admin_key_gen_win.showNormal()
        self._admin_key_gen_win.raise_()
        self._admin_key_gen_win.activateWindow()

    # ================= TỰ ĐỘNG CẬP NHẬT PHẦN MỀM (AUTO-UPDATE) =================
    def start_check_update_async(self):
        """Khởi động luồng kiểm tra cập nhật chạy ngầm (không bao giờ làm đơ giao diện)"""
        self._update_worker = CheckUpdateWorker()
        self._update_worker.finished_check.connect(self.on_update_check_finished)
        self._update_worker.start()

    def check_update_from_sidebar(self):
        """Kiểm tra và cập nhật phiên bản mới trực tiếp khi khách bấm nút ở Sidebar"""
        if hasattr(self, "btn_sidebar_update"):
            self.btn_sidebar_update.setEnabled(False)
            self.btn_sidebar_update.setText("⏳ Đang k.tra...")

        worker = CheckUpdateWorker()
        self._sidebar_update_worker = worker

        def on_checked(has_update: bool, data: dict, msg: str):
            if hasattr(self, "btn_sidebar_update"):
                self.btn_sidebar_update.setEnabled(True)
                self.btn_sidebar_update.setText(f"🔄 v{config.APP_VERSION}")
            if has_update:
                new_ver = data.get("version", "")
                cl = data.get("changelog", "Tối ưu hiệu năng và sửa lỗi.")
                d_url = data.get("download_url", "")
                self._pending_download_url = d_url
                self._pending_version = new_ver
                self.lbl_update_banner.setText(f"🚀 <b>Đã có bản cập nhật mới v{new_ver}:</b> {cl[:75]}...")
                self.update_banner.setVisible(True)
                reply = QMessageBox.question(
                    self,
                    "Phát Hiện Bản Cập Nhật Mới",
                    f"🎉 ĐÃ CÓ PHIÊN BẢN MỚI v{new_ver}!\n\n"
                    f"📝 Nội dung: {cl}\n\n"
                    f"Bạn có muốn tiến hành tải và tự động cập nhật ngay bây giờ không?",
                    QMessageBox.Yes | QMessageBox.No
                )
                if reply == QMessageBox.Yes and d_url:
                    self.start_apply_update()
            else:
                QMessageBox.information(self, "Kiểm Tra Cập Nhật", msg)

        worker.finished_check.connect(on_checked)
        worker.start()

    def on_update_check_finished(self, has_update: bool, data: dict, msg: str):
        """Xử lý khi có kết quả kiểm tra cập nhật từ máy chủ đám mây"""
        if has_update:
            new_ver = data.get("version", "")
            cl = data.get("changelog", "Tối ưu hiệu năng và sửa lỗi.")
            self._pending_download_url = data.get("download_url", "")
            self._pending_version = new_ver
            self.lbl_update_banner.setText(f"🚀 <b>Đã có bản cập nhật mới v{new_ver}:</b> {cl[:75]}...")
            self.update_banner.setVisible(True)
            if hasattr(self, "btn_sidebar_update"):
                self.btn_sidebar_update.setText(f"🔥 Lên v{new_ver}")
                self.btn_sidebar_update.setStyleSheet("""
                    QPushButton {
                        background-color: #78350F;
                        color: #FDE68A;
                        border: 1px solid #F59E0B;
                        border-radius: 4px;
                        font-weight: 800;
                        font-size: 10px;
                        padding: 2px 6px;
                    }
                    QPushButton:hover {
                        background-color: #D97706;
                        color: #FFFFFF;
                    }
                """)

    def start_apply_update(self):
        """Tiến hành tải và cài đặt bản cập nhật tự động"""
        if not self._pending_download_url:
            QMessageBox.warning(self, "Lỗi cập nhật", "Không tìm thấy đường link tải bản cập nhật!")
            return

        prog = QProgressDialog("Đang kết nối tới máy chủ cập nhật...", "Hủy", 0, 100, self)
        prog.setWindowTitle("🚀 Tự Động Cập Nhật JL Tool")
        prog.setWindowModality(Qt.WindowModal)
        prog.setMinimumDuration(0)
        prog.setAutoClose(False)
        prog.setAutoReset(False)
        prog.setCancelButton(None) # Không cho hủy giữa chừng khi đang ghi đè file
        prog.show()

        worker = ApplyUpdateWorker(self._pending_download_url)
        self._apply_worker = worker

        def on_prog(pct: int, txt: str):
            prog.setValue(pct)
            prog.setLabelText(txt)

        def on_done(success: bool, err_msg: str):
            prog.close()
            if success:
                QMessageBox.information(
                    self, "Cập Nhật Thành Công",
                    f"🎉 CHÚC MỪNG BẠN!\n\n"
                    f"Phần mềm JL Tool đã được tự động cập nhật lên phiên bản v{self._pending_version} thành công 100%!\n\n"
                    f"Toàn bộ danh sách kênh, tài khoản và bản quyền đều được bảo toàn nguyên vẹn.\n"
                    f"Phần mềm sẽ tự khởi động lại ngay bây giờ."
                )
                from core.auto_updater import auto_updater
                auto_updater.restart_app()
            else:
                QMessageBox.critical(self, "Cập nhật không thành công", f"Không thể cập nhật: {err_msg}")

        worker.progress_val.connect(on_prog)
        worker.finished_apply.connect(on_done)
        worker.start()
