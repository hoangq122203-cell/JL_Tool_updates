import os
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QProgressBar, QFrame,
    QGraphicsDropShadowEffect
)
from PySide6.QtGui import QPixmap, QColor, QFont
from PySide6.QtCore import Qt, QTimer, Signal
import config

class JLSplashScreen(QWidget):
    """
    Màn hình chào mừng khởi động chuyên nghiệp (Startup Splash Screen)
    Phong cách Dark Modern Slate Navy, mượt mà và sang trọng.
    """
    startup_finished = Signal()

    def __init__(self):
        super().__init__()
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint | Qt.SplashScreen)
        self.setAttribute(Qt.WA_TranslucentBackground, True)
        self.setFixedSize(540, 330)

        # Căn giữa màn hình
        self._center_on_screen()

        self.init_ui()
        self.current_step = 0

        # Timer chạy tiến trình mượt mà (tổng thời gian ~ 1.8 giây)
        self.timer = QTimer(self)
        self.timer.timeout.connect(self._on_tick)
        self.progress_val = 0

    def _center_on_screen(self):
        from PySide6.QtGui import QGuiApplication
        screen = QGuiApplication.primaryScreen()
        if screen:
            screen_geo = screen.availableGeometry()
            x = (screen_geo.width() - self.width()) // 2
            y = (screen_geo.height() - self.height()) // 2
            self.move(x, y)

    def init_ui(self):
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(15, 15, 15, 15)

        # Card chính nền thẫm, viền bo tròn có đổ bóng
        card = QFrame(self)
        card.setStyleSheet("""
            QFrame {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #0B0E17, stop:0.5 #0F1424, stop:1 #11172B);
                border: 1px solid #1E293B;
                border-radius: 16px;
            }
        """)

        # Hiệu ứng đổ bóng mờ xung quanh card
        shadow = QGraphicsDropShadowEffect(self)
        shadow.setBlurRadius(28)
        shadow.setColor(QColor(0, 0, 0, 180))
        shadow.setOffset(0, 6)
        card.setGraphicsEffect(shadow)

        card_layout = QVBoxLayout(card)
        card_layout.setContentsMargins(36, 28, 36, 24)
        card_layout.setSpacing(10)
        card_layout.setAlignment(Qt.AlignCenter)

        # 1. Logo ứng dụng
        lbl_logo = QLabel()
        logo_path = str(config.BASE_DIR / "assets" / "logo.png")
        if not os.path.exists(logo_path):
            logo_path = str(config.BASE_DIR / "assets" / "icon.png")

        if os.path.exists(logo_path):
            pix = QPixmap(logo_path)
            scaled = pix.scaled(84, 84, Qt.KeepAspectRatio, Qt.SmoothTransformation)
            lbl_logo.setPixmap(scaled)
        lbl_logo.setAlignment(Qt.AlignCenter)
        lbl_logo.setStyleSheet("border: none; background: transparent; padding: 4px;")
        card_layout.addWidget(lbl_logo)

        # 2. Tiêu đề ứng dụng & Badge phiên bản
        title_box = QHBoxLayout()
        title_box.setAlignment(Qt.AlignCenter)
        title_box.setSpacing(8)

        lbl_title = QLabel("JL TOOL")
        lbl_title.setStyleSheet("color: #FFFFFF; font-size: 20px; font-weight: 800; letter-spacing: 2px; border: none; background: transparent;")
        
        lbl_badge = QLabel("PRO v2.0")
        lbl_badge.setStyleSheet("""
            background-color: #1E3A8A;
            color: #60A5FA;
            border: 1px solid #2563EB;
            border-radius: 4px;
            padding: 2px 6px;
            font-size: 10px;
            font-weight: 700;
        """)
        title_box.addWidget(lbl_title)
        title_box.addWidget(lbl_badge)
        card_layout.addLayout(title_box)

        # 3. Phụ đề
        lbl_sub = QLabel("Hệ Thống Quản Lý Kênh & Tự Động Hóa TikTok")
        lbl_sub.setStyleSheet("color: #94A3B8; font-size: 11px; font-weight: 500; letter-spacing: 0.3px; border: none; background: transparent;")
        lbl_sub.setAlignment(Qt.AlignCenter)
        card_layout.addWidget(lbl_sub)

        card_layout.addSpacing(12)

        # 4. Trạng thái khởi tạo
        status_box = QHBoxLayout()
        self.lbl_status = QLabel("Đang khởi tạo nhân hệ thống...")
        self.lbl_status.setStyleSheet("color: #38BDF8; font-size: 11px; font-weight: 600; border: none; background: transparent;")
        self.lbl_status.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)
        
        self.lbl_percent = QLabel("0%")
        self.lbl_percent.setStyleSheet("color: #64748B; font-size: 11px; font-weight: 700; font-family: Consolas, monospace; border: none; background: transparent;")
        self.lbl_percent.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        
        status_box.addWidget(self.lbl_status)
        status_box.addStretch()
        status_box.addWidget(self.lbl_percent)
        card_layout.addLayout(status_box)

        # 5. Thanh tiến trình (Progress Bar) siêu đẹp
        self.progress_bar = QProgressBar()
        self.progress_bar.setRange(0, 100)
        self.progress_bar.setValue(0)
        self.progress_bar.setTextVisible(False)
        self.progress_bar.setFixedHeight(6)
        self.progress_bar.setStyleSheet("""
            QProgressBar {
                background-color: #161D2F;
                border: 1px solid #1E293B;
                border-radius: 3px;
            }
            QProgressBar::chunk {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #1D4ED8, stop:0.6 #2563EB, stop:1 #38BDF8);
                border-radius: 3px;
            }
        """)
        card_layout.addWidget(self.progress_bar)

        # 6. Footer thông tin
        card_layout.addSpacing(6)
        footer_box = QHBoxLayout()
        lbl_foot_left = QLabel("Đa luồng Profile • VPN • Proxy • Auto Scheduler")
        lbl_foot_left.setStyleSheet("color: #475569; font-size: 10px; font-weight: 500; border: none; background: transparent;")
        
        lbl_foot_right = QLabel("JL Studio © 2026")
        lbl_foot_right.setStyleSheet("color: #475569; font-size: 10px; font-weight: 500; border: none; background: transparent;")
        
        footer_box.addWidget(lbl_foot_left)
        footer_box.addStretch()
        footer_box.addWidget(lbl_foot_right)
        card_layout.addLayout(footer_box)

        main_layout.addWidget(card)

    def start_loading(self):
        self.show()
        self.timer.start(25) # 25ms mỗi tick

    def _on_tick(self):
        self.progress_val += 2
        if self.progress_val > 100:
            self.progress_val = 100

        self.progress_bar.setValue(self.progress_val)
        self.lbl_percent.setText(f"{self.progress_val}%")

        # Cập nhật thông điệp theo từng giai đoạn
        if self.progress_val < 25:
            self.lbl_status.setText("Đang khởi tạo nhân hệ thống...")
        elif self.progress_val < 50:
            self.lbl_status.setText("Đang nạp hồ sơ kênh & cơ sở dữ liệu...")
        elif self.progress_val < 75:
            self.lbl_status.setText("Đang kiểm tra kết nối mạng & IP...")
        elif self.progress_val < 95:
            self.lbl_status.setText("Đang kích hoạt dịch vụ hẹn giờ tự động...")
        else:
            self.lbl_status.setText("Sẵn sàng khởi chạy JL Tool!")

        if self.progress_val >= 100:
            self.timer.stop()
            # Đợi nhẹ 150ms để người dùng thấy 100% rồi chuyển tiếp mượt mà
            QTimer.singleShot(150, self._finish)

    def _finish(self):
        self.startup_finished.emit()
        self.close()
