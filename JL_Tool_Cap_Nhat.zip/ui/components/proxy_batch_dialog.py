import os
import time
import threading
from typing import List, Dict, Any, Optional
from PySide6.QtWidgets import (
    QLineEdit,
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QPlainTextEdit, QSpinBox, QRadioButton, QButtonGroup,
    QTableWidget, QTableWidgetItem, QHeaderView, QMessageBox,
    QFrame, QWidget, QProgressBar, QCheckBox, QTabWidget
)
from PySide6.QtCore import Qt, Signal, QTimer, QThread
from PySide6.QtGui import QColor, QFont
from database.db_manager import db
from core.network_manager import network_mgr
from core.rotating_proxy_manager import rotating_proxy_mgr
from core.chrome_manager import chrome_mgr

# =============================================================================
# WORKER & HỘP THOẠI KIỂM TRA PROXY TOÀN DIỆN & VỊ TRÍ ĐỊA LÝ (SIÊU TỐC ĐA LUỒNG)
# =============================================================================
class ProxyCheckWorker(QThread):
    progress_updated = Signal(int, int, dict)
    finished_all = Signal(list)

    def __init__(self, proxies: List[str], parent=None):
        super().__init__(parent)
        self.proxies = proxies

    def run(self):
        def cb(done, total, res):
            self.progress_updated.emit(done, total, res)

        results = network_mgr.test_proxies_batch(self.proxies, max_workers=15, timeout=3.5, callback=cb)
        self.finished_all.emit(results)


class ProxyInspectionDialog(QDialog):
    """Hộp thoại Hiển thị Kết quả Kiểm tra Trạng thái, Quốc gia & Thông tin Chi tiết Proxy"""
    def __init__(self, parent, proxies: List[str]):
        super().__init__(parent)
        self.proxies = proxies
        self.results = []
        self.setWindowTitle("⚡ Kiểm Tra Trạng Thái & Vị Trí Địa Lý Proxy Tĩnh")
        self.resize(1000, 580)
        self.setStyleSheet("""
            QDialog {
                background-color: #0B0E17;
                color: #FFFFFF;
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            }
            QLabel {
                color: #E2E8F0;
            }
            QTableWidget {
                background-color: #0F172A;
                border: 1px solid #1E293B;
                border-radius: 8px;
                gridline-color: #1E293B;
                color: #E2E8F0;
            }
            QHeaderView::section {
                background-color: #1E293B;
                color: #38BDF8;
                font-weight: 700;
                border: none;
                padding: 7px;
            }
        """)
        self.init_ui()
        self.start_checking()

    def init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(18, 18, 18, 18)
        layout.setSpacing(12)

        # Header Title
        title_box = QHBoxLayout()
        self.lbl_title = QLabel("⚡ ĐANG KIỂM TRA PROXY SIÊU TỐC ĐA LUỒNG...")
        self.lbl_title.setStyleSheet("font-size: 15px; font-weight: 800; color: #38BDF8;")
        title_box.addWidget(self.lbl_title)
        title_box.addStretch()

        self.lbl_stat_live = QLabel("🟢 Live: 0")
        self.lbl_stat_live.setStyleSheet("background-color: #064E3B; color: #34D399; font-weight: 800; padding: 4px 10px; border-radius: 4px;")
        title_box.addWidget(self.lbl_stat_live)

        self.lbl_stat_die = QLabel("🔴 Die: 0")
        self.lbl_stat_die.setStyleSheet("background-color: #7F1D1D; color: #F87171; font-weight: 800; padding: 4px 10px; border-radius: 4px;")
        title_box.addWidget(self.lbl_stat_die)

        self.lbl_stat_ping = QLabel("⏱️ Ping TB: -- ms")
        self.lbl_stat_ping.setStyleSheet("background-color: #1E293B; color: #38BDF8; font-weight: 700; padding: 4px 10px; border-radius: 4px;")
        title_box.addWidget(self.lbl_stat_ping)

        layout.addLayout(title_box)

        # Progress bar
        self.prog_bar = QProgressBar()
        self.prog_bar.setRange(0, len(self.proxies))
        self.prog_bar.setValue(0)
        self.prog_bar.setStyleSheet("""
            QProgressBar {
                background-color: #1E293B;
                border: 1px solid #334155;
                border-radius: 4px;
                height: 14px;
                text-align: center;
                color: #FFFFFF;
                font-weight: 700;
                font-size: 10px;
            }
            QProgressBar::chunk {
                background-color: #10B981;
                border-radius: 3px;
            }
        """)
        layout.addWidget(self.prog_bar)

        # Results Table
        self.table = QTableWidget()
        self.table.setColumnCount(8)
        self.table.setHorizontalHeaderLabels([
            "STT", "TRẠNG THÁI", "QUỐC GIA", "THÀNH PHỐ / VÙNG",
            "IP PHÁT RA", "TỐC ĐỘ (PING)", "NHÀ MẠNG (ISP)", "PROXY GỐC"
        ])
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(3, QHeaderView.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(4, QHeaderView.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(5, QHeaderView.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(6, QHeaderView.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(7, QHeaderView.Stretch)
        self.table.verticalHeader().setVisible(False)
        self.table.setEditTriggers(QTableWidget.NoEditTriggers)
        self.table.setSelectionBehavior(QTableWidget.SelectRows)
        layout.addWidget(self.table)

        # Bottom Buttons
        btn_bar = QHBoxLayout()
        btn_bar.setSpacing(12)

        self.btn_apply_live = QPushButton("✅ Giữ lại danh sách Proxy Live (Loại bỏ Proxy Die)")
        self.btn_apply_live.setStyleSheet("background-color: #10B981; color: #FFFFFF; font-weight: 800; padding: 10px 18px; border-radius: 6px;")
        self.btn_apply_live.setCursor(Qt.PointingHandCursor)
        self.btn_apply_live.setEnabled(False)
        self.btn_apply_live.clicked.connect(self.apply_live_proxies)
        btn_bar.addWidget(self.btn_apply_live)

        self.btn_copy_live = QPushButton("📋 Copy Proxy Live")
        self.btn_copy_live.setStyleSheet("background-color: #1E293B; color: #38BDF8; font-weight: 700; border: 1px solid #0284C7; padding: 10px 16px; border-radius: 6px;")
        self.btn_copy_live.setCursor(Qt.PointingHandCursor)
        self.btn_copy_live.setEnabled(False)
        self.btn_copy_live.clicked.connect(self.copy_live_proxies)
        btn_bar.addWidget(self.btn_copy_live)

        btn_bar.addStretch()

        btn_close = QPushButton("Đóng")
        btn_close.setStyleSheet("background-color: #1E293B; color: #E2E8F0; padding: 10px 20px; border-radius: 6px;")
        btn_close.clicked.connect(self.close)
        btn_bar.addWidget(btn_close)

        layout.addLayout(btn_bar)

    def start_checking(self):
        self.worker = ProxyCheckWorker(self.proxies, self)
        self.worker.progress_updated.connect(self.on_proxy_tested)
        self.worker.finished_all.connect(self.on_all_finished)
        self.worker.start()

    def on_proxy_tested(self, done_count: int, total_count: int, res: dict):
        self.prog_bar.setValue(done_count)
        row = self.table.rowCount()
        self.table.insertRow(row)

        is_live = res.get("success", False)
        ping = res.get("ping", 0)

        # 0. STT
        it_stt = QTableWidgetItem(str(row + 1))
        it_stt.setTextAlignment(Qt.AlignCenter)
        self.table.setItem(row, 0, it_stt)

        # 1. Trạng thái
        st_text = "🟢 LIVE" if is_live else "🔴 DIE"
        it_st = QTableWidgetItem(st_text)
        it_st.setTextAlignment(Qt.AlignCenter)
        it_st.setForeground(QColor("#10B981") if is_live else QColor("#EF4444"))
        it_st.setFont(QFont("Segoe UI", 10, QFont.Bold))
        self.table.setItem(row, 1, it_st)

        # 2. Quốc gia
        c_text = res.get("display_country", "Không xác định") if is_live else "---"
        it_c = QTableWidgetItem(c_text)
        it_c.setForeground(QColor("#38BDF8") if is_live else QColor("#64748B"))
        it_c.setFont(QFont("Segoe UI", 10, QFont.Bold))
        self.table.setItem(row, 2, it_c)

        # 3. Thành phố / Vùng
        loc_text = res.get("city", "")
        if res.get("region"):
            loc_text = f"{loc_text}, {res['region']}" if loc_text else res["region"]
        it_loc = QTableWidgetItem(loc_text or "---")
        self.table.setItem(row, 3, it_loc)

        # 4. IP phát ra
        ip_text = res.get("ip", "") if is_live else "---"
        it_ip = QTableWidgetItem(ip_text)
        it_ip.setForeground(QColor("#FFFFFF"))
        it_ip.setFont(QFont("Consolas", 10, QFont.Bold))
        self.table.setItem(row, 4, it_ip)

        # 5. Tốc độ Ping
        if is_live:
            ping_text = f"{ping} ms"
            ping_color = "#10B981" if ping < 1000 else ("#F59E0B" if ping < 2500 else "#EF4444")
        else:
            ping_text = "Timeout / Lỗi"
            ping_color = "#EF4444"
        it_ping = QTableWidgetItem(ping_text)
        it_ping.setTextAlignment(Qt.AlignCenter)
        it_ping.setForeground(QColor(ping_color))
        it_ping.setFont(QFont("Segoe UI", 10, QFont.Bold))
        self.table.setItem(row, 5, it_ping)

        # 6. Nhà mạng / ISP
        isp_text = res.get("isp", "") or "---"
        it_isp = QTableWidgetItem(isp_text)
        it_isp.setForeground(QColor("#94A3B8"))
        self.table.setItem(row, 6, it_isp)

        # 7. Proxy gốc
        it_proxy = QTableWidgetItem(res.get("proxy", ""))
        it_proxy.setForeground(QColor("#E2E8F0"))
        it_proxy.setFont(QFont("Consolas", 9))
        self.table.setItem(row, 7, it_proxy)

    def on_all_finished(self, results: list):
        self.results = results
        live_count = sum(1 for r in results if r.get("success"))
        die_count = len(results) - live_count
        pings = [r["ping"] for r in results if r.get("success") and r.get("ping", 0) > 0]
        avg_ping = round(sum(pings) / len(pings)) if pings else 0

        self.lbl_title.setText(f"✅ ĐÃ HOÀN TẤT KIỂM TRA ({len(results)}/{len(results)} PROXY)")
        self.lbl_title.setStyleSheet("font-size: 15px; font-weight: 800; color: #10B981;")
        self.lbl_stat_live.setText(f"🟢 Live: {live_count}")
        self.lbl_stat_die.setText(f"🔴 Die: {die_count}")
        self.lbl_stat_ping.setText(f"⏱️ Ping TB: {avg_ping} ms")

        self.btn_apply_live.setEnabled(live_count > 0)
        self.btn_copy_live.setEnabled(live_count > 0)

        # Lưu cache vị trí vào parent để render preview
        if hasattr(self.parent(), "proxy_inspection_cache"):
            for r in results:
                if r.get("success"):
                    self.parent().proxy_inspection_cache[r["proxy"]] = r
            self.parent().update_rotation_preview()

    def apply_live_proxies(self):
        live_list = [r["proxy"] for r in self.results if r.get("success")]
        if hasattr(self.parent(), "txt_rotating_proxies"):
            self.parent().txt_rotating_proxies.setPlainText("\n".join(live_list))
        self.accept()
        QMessageBox.information(self, "Đã Cập Nhật", f"✅ Đã lọc và chỉ giữ lại {len(live_list)} Proxy Live hoạt động tốt vào hệ thống!")

    def copy_live_proxies(self):
        from PySide6.QtWidgets import QApplication
        live_list = [r["proxy"] for r in self.results if r.get("success")]
        QApplication.clipboard().setText("\n".join(live_list))
        QMessageBox.information(self, "Đã Copy", f"📋 Đã copy {len(live_list)} Proxy Live vào bộ nhớ tạm (Clipboard)!")

class BatchProxyDialog(QDialog):
    """
    Hộp thoại Quản lý Proxy Tĩnh:
    =============================================================================
    1. Chế độ XOAY TUA THEO ĐỢT (5 Kênh / 1 Proxy trên 1 lần đăng):
       - 1 Proxy tĩnh chỉ cấp cho 5 kênh trong 1 lần đăng.
       - Khi 5 kênh này đăng xong ➔ Tự động OFF Proxy khỏi 5 kênh đó.
       - Lấy chính Proxy đó chuyển tiếp sang 5 kênh kế tiếp để đăng / sử dụng.
       - Tuần tự xoay tua cho tới khi hoàn tất toàn bộ danh sách 1000 kênh!
    2. Chế độ ĐĂNG NHẬP XOAY TUA (Login Batch):
       - Mở 5 kênh đợt 1 với Proxy ➔ Login xong ➔ Bấm nút tự động OFF Proxy & mở 5 kênh tiếp theo!
    3. Chế độ GÁN CỐ ĐỊNH: Phân bổ chia đều tĩnh vĩnh viễn.
    """
    proxies_assigned = Signal()

    def __init__(self, parent=None, selected_channel_ids: Optional[List[int]] = None):
        super().__init__(parent)
        self.selected_channel_ids = selected_channel_ids or []
        self.setWindowTitle("🛡️ Cấu Hình Proxy Tĩnh & Xoay Tua Theo Đợt (5 Kênh / Lần Đăng)")
        self.resize(1120, 730)
        self.setStyleSheet("""
            QDialog {
                background-color: #0B0E17;
                color: #FFFFFF;
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            }
            QLabel {
                color: #E2E8F0;
            }
            QTabWidget::pane {
                border: 1px solid #1E293B;
                border-radius: 8px;
                background-color: #0F172A;
                top: -1px;
            }
            QTabBar::tab {
                background: #1E293B;
                color: #94A3B8;
                padding: 10px 18px;
                font-weight: 700;
                font-size: 13px;
                border-top-left-radius: 6px;
                border-top-right-radius: 6px;
                margin-right: 4px;
            }
            QTabBar::tab:selected {
                background: #0284C7;
                color: #FFFFFF;
            }
            QGroupBox {
                border: 1px solid #1E293B;
                border-radius: 8px;
                margin-top: 10px;
                padding-top: 15px;
                font-weight: 700;
                color: #38BDF8;
            }
            QTableWidget {
                background-color: #0B0E17;
                border: 1px solid #1E293B;
                border-radius: 8px;
                gridline-color: #1E293B;
                color: #E2E8F0;
            }
            QHeaderView::section {
                background-color: #1E293B;
                color: #38BDF8;
                font-weight: 700;
                border: none;
                padding: 6px;
            }
        """)

        # Trạng thái đăng nhập xoay tua
        self.cur_login_batch_idx = 0
        self.prev_login_channel_ids = []
        self.proxy_inspection_cache = {}

        self.init_ui()
        self.load_saved_config()

    def init_ui(self):
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(20, 18, 20, 18)
        main_layout.setSpacing(14)

        # Header Title
        lbl_title = QLabel("🛡️ QUẢN LÝ PROXY TĨNH: XOAY TUA THEO ĐỢT (5 KÊNH / LẦN ĐĂNG)")
        lbl_title.setStyleSheet("font-size: 16px; font-weight: 800; color: #38BDF8;")
        main_layout.addWidget(lbl_title)

        lbl_desc = QLabel(
            "Cơ chế thông minh: <b>1 Proxy tĩnh chỉ gán cho 5 tài khoản trên 1 lần đăng</b>. "
            "Khi 5 kênh này đăng xong ➔ Hệ thống <b>tự động OFF Proxy</b> khỏi 5 kênh đó, "
            "rồi <b>tự động chuyển Proxy đó sang 5 kênh tiếp theo</b> để tiếp tục đăng video / login. "
            "Quy trình tự động lặp lại cho tới khi hoàn tất toàn bộ danh sách 1000 kênh!"
        )
        lbl_desc.setWordWrap(True)
        lbl_desc.setStyleSheet("color: #94A3B8; font-size: 12px; line-height: 1.4;")
        main_layout.addWidget(lbl_desc)

        # Tab Widget
        self.tabs = QTabWidget()
        main_layout.addWidget(self.tabs)

        # Tab 1: Xoay Tua Đăng Video Tự Động (Upload Batch Rotation)
        self.tab_rotation = QWidget()
        self.init_rotation_tab()
        self.tabs.addTab(self.tab_rotation, "🔄 1. Xoay Tua Tự Động Khi Đăng Video (5 Kênh/Đợt)")

        # Tab 2: Đăng Nhập Xoay Tua (Login Batch Runner)
        self.tab_login = QWidget()
        self.init_login_tab()
        self.tabs.addTab(self.tab_login, "🔑 2. Đăng Nhập Xoay Tua (Mở Từng 5 Kênh)")

        # Tab 3: Gán Cố Định Chia Đều
        self.tab_static = QWidget()
        self.init_static_tab()
        self.tabs.addTab(self.tab_static, "📌 3. Gán Cố Định Chia Đều (STT 1 ➔ 1000)")

    # =========================================================================
    # TAB 1: XOAY TUA TỰ ĐỘNG KHI ĐĂNG VIDEO
    # =========================================================================
    def init_rotation_tab(self):
        """Thiết kế giao diện 2 cột chuyên nghiệp: Trái cấu hình Proxy - Phải chọn kênh & xem trước đợt"""
        main_layout = QVBoxLayout(self.tab_rotation)
        main_layout.setContentsMargins(14, 12, 14, 12)
        main_layout.setSpacing(10)

        # Hàng 2 cột chính
        split_layout = QHBoxLayout()
        split_layout.setSpacing(16)

        # =====================================================================
        # CỘT TRÁI (WIDTH ~410px): NHẬP PROXY & CÀI ĐẶT
        # =====================================================================
        left_col = QFrame()
        left_col.setStyleSheet("background-color: #0F172A; border: 1.5px solid #1E293B; border-radius: 8px; padding: 12px;")
        left_col.setFixedWidth(410)
        left_layout = QVBoxLayout(left_col)
        left_layout.setContentsMargins(10, 10, 10, 10)
        left_layout.setSpacing(10)

        lbl_p = QLabel("📋 1. DANH SÁCH PROXY TĨNH CỦA BẠN:")
        lbl_p.setStyleSheet("font-weight: 800; color: #38BDF8; font-size: 13px;")
        left_layout.addWidget(lbl_p)

        lbl_p_sub = QLabel("Mỗi dòng 1 Proxy (ip:port, ip:port:user:pass, socks5/http):")
        lbl_p_sub.setStyleSheet("color: #94A3B8; font-size: 11px;")
        left_layout.addWidget(lbl_p_sub)

        self.txt_rotating_proxies = QPlainTextEdit()
        self.txt_rotating_proxies.setPlaceholderText(
            "Ví dụ:\n103.152.112.50:8080\n103.152.112.51:8080:user:pass\nuser:pass@103.152.112.52:8080\nsocks5://103.152.112.53:1080"
        )
        self.txt_rotating_proxies.setStyleSheet("""
            QPlainTextEdit {
                background-color: #0B0E17;
                border: 1px solid #334155;
                border-radius: 6px;
                padding: 8px;
                color: #38BDF8;
                font-family: 'Consolas', monospace;
                font-size: 12px;
            }
        """)
        self.txt_rotating_proxies.setMaximumHeight(130)
        self.txt_rotating_proxies.textChanged.connect(self.on_rotation_text_changed)
        left_layout.addWidget(self.txt_rotating_proxies)

        # Hàng đếm proxy & nút kiểm tra
        cnt_row = QHBoxLayout()
        self.lbl_rot_counter = QLabel("Số lượng: 0 proxy")
        self.lbl_rot_counter.setStyleSheet("color: #38BDF8; font-weight: 700; font-size: 12px;")
        cnt_row.addWidget(self.lbl_rot_counter)
        cnt_row.addStretch()

        self.btn_check_rot_live = QPushButton("⚡ Kiểm tra Proxy (Live/Die)")
        self.btn_check_rot_live.setStyleSheet("background-color: #1E293B; color: #F59E0B; font-weight: 800; padding: 6px 14px; border-radius: 6px; border: 1.5px solid #F59E0B;")
        self.btn_check_rot_live.setCursor(Qt.PointingHandCursor)
        self.btn_check_rot_live.clicked.connect(lambda: self.check_proxies_live(self.txt_rotating_proxies))
        cnt_row.addWidget(self.btn_check_rot_live)
        left_layout.addLayout(cnt_row)

        # Khung cài đặt phân bổ
        opt_panel = QFrame()
        opt_panel.setStyleSheet("background-color: #0B0E17; border: 1px solid #1E293B; border-radius: 6px; padding: 8px;")
        opt_layout = QVBoxLayout(opt_panel)
        opt_layout.setSpacing(8)

        lbl_opt_title = QLabel("⚙️ CẤU HÌNH XOAY TUA:")
        lbl_opt_title.setStyleSheet("font-weight: 800; color: #E2E8F0; font-size: 12px;")
        opt_layout.addWidget(lbl_opt_title)

        ratio_row = QHBoxLayout()
        ratio_row.addWidget(QLabel("Tỉ lệ phân bổ:"))
        self.spn_rot_batch_size = QSpinBox()
        self.spn_rot_batch_size.setRange(1, 50)
        self.spn_rot_batch_size.setValue(5)
        self.spn_rot_batch_size.setSuffix(" Kênh / 1 Proxy")
        self.spn_rot_batch_size.setStyleSheet("background-color: #1E293B; color: #FFFFFF; padding: 4px 8px; border-radius: 4px; font-weight: 700;")
        self.spn_rot_batch_size.valueChanged.connect(self.update_rotation_preview)
        ratio_row.addWidget(self.spn_rot_batch_size)
        ratio_row.addStretch()
        opt_layout.addLayout(ratio_row)

        self.chk_rot_auto_off = QCheckBox("✅ Tự động nạp Proxy & tự OFF khi đăng xong")
        self.chk_rot_auto_off.setChecked(True)
        self.chk_rot_auto_off.setStyleSheet("color: #34D399; font-weight: 700; font-size: 11px;")
        opt_layout.addWidget(self.chk_rot_auto_off)

        left_layout.addWidget(opt_panel)

        # Trạng thái
        self.lbl_rot_status = QLabel("Trạng thái: ⚪ ĐANG TẮT CHẾ ĐỘ XOAY TUA")
        self.lbl_rot_status.setStyleSheet("font-weight: 800; font-size: 12px; color: #94A3B8; padding: 2px 0;")
        left_layout.addWidget(self.lbl_rot_status)

        left_layout.addStretch()

        # Nút hành động bên trái
        self.btn_toggle_rotation = QPushButton("🚀 BẬT XOAY TUA PROXY ĐĂNG VIDEO")
        self.btn_toggle_rotation.setStyleSheet("background-color: #10B981; color: #FFFFFF; font-weight: 800; font-size: 13px; padding: 12px; border-radius: 6px;")
        self.btn_toggle_rotation.setCursor(Qt.PointingHandCursor)
        self.btn_toggle_rotation.clicked.connect(self.save_and_toggle_rotation)
        left_layout.addWidget(self.btn_toggle_rotation)

        self.btn_off_all_proxies = QPushButton("⏹️ Tắt / Gỡ Hết Proxy Khỏi Toàn Bộ Kênh")
        self.btn_off_all_proxies.setStyleSheet("background-color: #7F1D1D; color: #FCA5A5; font-weight: 700; padding: 8px; border-radius: 6px; border: 1px solid #EF4444;")
        self.btn_off_all_proxies.setCursor(Qt.PointingHandCursor)
        self.btn_off_all_proxies.clicked.connect(self.off_all_proxies)
        left_layout.addWidget(self.btn_off_all_proxies)

        split_layout.addWidget(left_col)

        # =====================================================================
        # CỘT PHẢI (FLEX): CHỌN KÊNH & XEM TRƯỚC ĐỢT ĐĂNG
        # =====================================================================
        right_col = QFrame()
        right_col.setStyleSheet("background-color: #0F172A; border: 1.5px solid #1E293B; border-radius: 8px; padding: 12px;")
        right_layout = QVBoxLayout(right_col)
        right_layout.setContentsMargins(10, 10, 10, 10)
        right_layout.setSpacing(10)

        # Header khu vực chọn kênh
        head_sel = QHBoxLayout()
        lbl_sel = QLabel("👥 2. TÍCH CHỌN KÊNH ÁP DỤNG PROXY:")
        lbl_sel.setStyleSheet("font-weight: 800; color: #38BDF8; font-size: 13px;")
        head_sel.addWidget(lbl_sel)
        head_sel.addStretch()

        self.txt_search_channel = QLineEdit()
        self.txt_search_channel.setPlaceholderText("🔍 Tìm tên kênh, username...")
        self.txt_search_channel.setStyleSheet("background-color: #0B0E17; color: #FFFFFF; border: 1px solid #334155; border-radius: 4px; padding: 4px 8px; font-size: 11px;")
        self.txt_search_channel.setFixedWidth(160)
        self.txt_search_channel.textChanged.connect(self.filter_channels_table)
        head_sel.addWidget(self.txt_search_channel)

        self.btn_sel_all_channels = QPushButton("✓ Chọn tất cả")
        self.btn_sel_all_channels.setStyleSheet("background-color: #1E293B; color: #38BDF8; font-weight: 700; padding: 4px 10px; border-radius: 4px; border: 1px solid #0284C7;")
        self.btn_sel_all_channels.setCursor(Qt.PointingHandCursor)
        self.btn_sel_all_channels.clicked.connect(self.select_all_channels)
        head_sel.addWidget(self.btn_sel_all_channels)

        self.btn_unsel_all_channels = QPushButton("✗ Bỏ chọn")
        self.btn_unsel_all_channels.setStyleSheet("background-color: #1E293B; color: #94A3B8; font-weight: 700; padding: 4px 10px; border-radius: 4px; border: 1px solid #334155;")
        self.btn_unsel_all_channels.setCursor(Qt.PointingHandCursor)
        self.btn_unsel_all_channels.clicked.connect(self.unselect_all_channels)
        head_sel.addWidget(self.btn_unsel_all_channels)

        self.lbl_selected_channels_stat = QLabel("Đã chọn: 0 / 0 kênh")
        self.lbl_selected_channels_stat.setStyleSheet("background-color: #065F46; color: #34D399; font-weight: 800; padding: 4px 10px; border-radius: 4px; font-size: 11px;")
        head_sel.addWidget(self.lbl_selected_channels_stat)

        right_layout.addLayout(head_sel)

        # Bảng danh sách kênh rộng rãi, cao 240px
        self.table_channels_select = QTableWidget()
        self.table_channels_select.setColumnCount(5)
        self.table_channels_select.setHorizontalHeaderLabels(["CHỌN", "STT", "TÊN KÊNH", "USERNAME", "MẠNG HIỆN TẠI"])
        self.table_channels_select.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeToContents)
        self.table_channels_select.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeToContents)
        self.table_channels_select.horizontalHeader().setSectionResizeMode(2, QHeaderView.Stretch)
        self.table_channels_select.horizontalHeader().setSectionResizeMode(3, QHeaderView.Stretch)
        self.table_channels_select.horizontalHeader().setSectionResizeMode(4, QHeaderView.ResizeToContents)
        self.table_channels_select.verticalHeader().setVisible(False)
        self.table_channels_select.setStyleSheet("""
            QTableWidget {
                background-color: #0B0E17;
                border: 1px solid #1E293B;
                border-radius: 6px;
                gridline-color: #1E293B;
                color: #FFFFFF;
                font-size: 12px;
            }
            QHeaderView::section {
                background-color: #1E293B;
                color: #38BDF8;
                font-weight: 800;
                font-size: 11px;
                padding: 7px 4px;
                border: none;
                border-bottom: 1px solid #334155;
            }
        """)
        self.table_channels_select.setMinimumHeight(220)
        self.table_channels_select.setMaximumHeight(250)
        self.table_channels_select.setEditTriggers(QTableWidget.NoEditTriggers)
        self.table_channels_select.setSelectionBehavior(QTableWidget.SelectRows)
        right_layout.addWidget(self.table_channels_select)

        # Phía dưới: Bảng mô phỏng các đợt 5 kênh
        lbl_prev_title = QLabel("📊 3. MÔ PHỎNG LUỒNG XOAY TUA THEO ĐỢT (TỪ CÁC KÊNH ĐÃ CHỌN):")
        lbl_prev_title.setStyleSheet("font-weight: 800; color: #F59E0B; font-size: 12px; margin-top: 4px;")
        right_layout.addWidget(lbl_prev_title)

        self.table_rot_preview = QTableWidget()
        self.table_rot_preview.setColumnCount(5)
        self.table_rot_preview.setHorizontalHeaderLabels(["ĐỢT", "KHOẢNG KÊNH", "SỐ KÊNH", "PROXY SỬ DỤNG", "HÀNH ĐỘNG TỰ ĐỘNG"])
        self.table_rot_preview.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeToContents)
        self.table_rot_preview.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeToContents)
        self.table_rot_preview.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeToContents)
        self.table_rot_preview.horizontalHeader().setSectionResizeMode(3, QHeaderView.Stretch)
        self.table_rot_preview.horizontalHeader().setSectionResizeMode(4, QHeaderView.Stretch)
        self.table_rot_preview.verticalHeader().setVisible(False)
        self.table_rot_preview.setStyleSheet("""
            QTableWidget {
                background-color: #0B0E17;
                border: 1px solid #1E293B;
                border-radius: 6px;
                gridline-color: #1E293B;
                color: #E2E8F0;
                font-size: 11px;
            }
            QHeaderView::section {
                background-color: #1E293B;
                color: #F59E0B;
                font-weight: 800;
                font-size: 11px;
                padding: 6px 4px;
                border: none;
                border-bottom: 1px solid #334155;
            }
        """)
        self.table_rot_preview.setMinimumHeight(160)
        self.table_rot_preview.setMaximumHeight(200)
        self.table_rot_preview.setEditTriggers(QTableWidget.NoEditTriggers)
        self.table_rot_preview.setSelectionBehavior(QTableWidget.SelectRows)
        right_layout.addWidget(self.table_rot_preview)

        split_layout.addWidget(right_col, stretch=1)
        main_layout.addLayout(split_layout)

        # Hàng nút đóng dưới cùng
        foot_bar = QHBoxLayout()
        foot_bar.addStretch()
        btn_close = QPushButton("Đóng")
        btn_close.setStyleSheet("background-color: #1E293B; color: #E2E8F0; padding: 8px 24px; border-radius: 6px; font-weight: 700;")
        btn_close.clicked.connect(self.close)
        foot_bar.addWidget(btn_close)
        main_layout.addLayout(foot_bar)

    # =========================================================================
    # TAB 2: ĐĂNG NHẬP XOAY TUA (LOGIN BATCH RUNNER)
    # =========================================================================
    def init_login_tab(self):
        layout = QVBoxLayout(self.tab_login)
        layout.setContentsMargins(16, 16, 16, 16)
        layout.setSpacing(12)

        info = QLabel(
            "🔑 <b>Tính Năng Đăng Nhập Xoay Tua</b>: Mở đồng thời 5 kênh cho mỗi đợt với Proxy tĩnh. "
            "Khi bạn đăng nhập xong 5 kênh đó, chỉ cần bấm nút <b>'Xong Đợt Này ➔ Chuyển Sang 5 Kênh Tiếp Theo'</b>, "
            "hệ thống sẽ <b>tự động OFF Proxy của 5 kênh vừa xong</b>, chuyển Proxy sang 5 kênh kế tiếp và mở Chrome cho bạn đăng nhập!"
        )
        info.setWordWrap(True)
        info.setStyleSheet("color: #38BDF8; font-size: 12px; background-color: #0B0E17; border: 1px solid #1E293B; border-radius: 8px; padding: 10px;")
        layout.addWidget(info)

        # Batch progress display
        prog_panel = QFrame()
        prog_panel.setStyleSheet("background-color: #0B0E17; border: 1px solid #1E293B; border-radius: 8px; padding: 12px;")
        prog_layout = QVBoxLayout(prog_panel)

        self.lbl_login_batch_title = QLabel("📍 ĐỢT HIỆN TẠI: ĐỢT 1 (Kênh 1 ➜ 5)")
        self.lbl_login_batch_title.setStyleSheet("font-size: 15px; font-weight: 800; color: #34D399;")
        prog_layout.addWidget(self.lbl_login_batch_title)

        self.lbl_login_proxy_display = QLabel("Proxy sử dụng: Chưa chọn Proxy")
        self.lbl_login_proxy_display.setStyleSheet("font-size: 13px; color: #38BDF8; font-family: 'Consolas';")
        prog_layout.addWidget(self.lbl_login_proxy_display)

        layout.addWidget(prog_panel)

        # Table showing current 5 channels
        lbl_tbl = QLabel("Danh sách 5 kênh của đợt này:")
        lbl_tbl.setStyleSheet("font-weight: 700; color: #94A3B8;")
        layout.addWidget(lbl_tbl)

        self.table_login_current = QTableWidget()
        self.table_login_current.setColumnCount(4)
        self.table_login_current.setHorizontalHeaderLabels(["STT", "TÊN KÊNH", "USERNAME", "TRẠNG THÁI LOGIN"])
        self.table_login_current.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeToContents)
        self.table_login_current.horizontalHeader().setSectionResizeMode(1, QHeaderView.Stretch)
        self.table_login_current.horizontalHeader().setSectionResizeMode(2, QHeaderView.Stretch)
        self.table_login_current.horizontalHeader().setSectionResizeMode(3, QHeaderView.ResizeToContents)
        self.table_login_current.verticalHeader().setVisible(False)
        self.table_login_current.setEditTriggers(QTableWidget.NoEditTriggers)
        layout.addWidget(self.table_login_current)

        # Login Action Buttons
        act_row = QHBoxLayout()
        act_row.setSpacing(12)

        self.btn_open_login_batch = QPushButton("🌐 MỞ 5 KÊNH ĐỢT NÀY ĐỂ ĐĂNG NHẬP")
        self.btn_open_login_batch.setStyleSheet("background-color: #0284C7; color: #FFFFFF; font-weight: 800; font-size: 13px; padding: 12px 20px; border-radius: 6px;")
        self.btn_open_login_batch.setCursor(Qt.PointingHandCursor)
        self.btn_open_login_batch.clicked.connect(self.execute_open_login_batch)
        act_row.addWidget(self.btn_open_login_batch)

        self.btn_advance_login_batch = QPushButton("➡️ ĐÃ XONG 5 KÊNH NÀY ➔ TỰ TẮT PROXY & MỞ 5 KÊNH TIẾP THEO ➔")
        self.btn_advance_login_batch.setStyleSheet("background-color: #10B981; color: #FFFFFF; font-weight: 800; font-size: 13px; padding: 12px 20px; border-radius: 6px;")
        self.btn_advance_login_batch.setCursor(Qt.PointingHandCursor)
        self.btn_advance_login_batch.clicked.connect(self.execute_advance_login_batch)
        act_row.addWidget(self.btn_advance_login_batch)

        self.btn_reset_login_batch = QPushButton("🔄 Về Đợt 1")
        self.btn_reset_login_batch.setStyleSheet("background-color: #1E293B; color: #94A3B8; padding: 12px 14px; border-radius: 6px;")
        self.btn_reset_login_batch.clicked.connect(self.reset_login_batches)
        act_row.addWidget(self.btn_reset_login_batch)

        layout.addLayout(act_row)

    # =========================================================================
    # TAB 3: GÁN CỐ ĐỊNH CHIA ĐỀU (STATIC ALLOCATION)
    # =========================================================================
    def init_static_tab(self):
        layout = QVBoxLayout(self.tab_static)
        layout.setContentsMargins(16, 16, 16, 16)
        layout.setSpacing(12)

        info = QLabel(
            "📌 Chế độ Gán Cố Định: Gán chia đều danh sách Proxy tĩnh vĩnh viễn cho các kênh (ví dụ: Kênh 1-5 dùng Proxy 1 cố định, Kênh 6-10 dùng Proxy 2 cố định...). "
            "Nếu bạn muốn 1 Proxy dùng xoay tua cho nhiều đợt, vui lòng sử dụng <b>Tab 1 (Xoay Tua Tự Động)</b>."
        )
        info.setWordWrap(True)
        info.setStyleSheet("color: #94A3B8; font-size: 12px;")
        layout.addWidget(info)

        btn_apply_static = QPushButton("🚀 THỰC HIỆN GÁN CỐ ĐỊNH CHIA ĐỀU (5 KÊNH / 1 PROXY)")
        btn_apply_static.setStyleSheet("background-color: #0284C7; color: #FFFFFF; font-weight: 800; padding: 10px 18px; border-radius: 6px;")
        btn_apply_static.clicked.connect(self.execute_static_allocation)
        layout.addWidget(btn_apply_static)

        layout.addStretch()

    # =========================================================================
    # LOGIC FUNCTIONS
    # =========================================================================
    def get_checked_channel_ids(self) -> List[int]:
        checked_ids = []
        for r in range(self.table_channels_select.rowCount()):
            chk_widget = self.table_channels_select.cellWidget(r, 0)
            if chk_widget:
                chk = chk_widget.findChild(QCheckBox)
                if chk and chk.isChecked():
                    cid = chk.property("channel_id")
                    if cid is not None:
                        checked_ids.append(int(cid))
        return checked_ids

    def populate_channels_selection_table(self, saved_target_ids: Optional[List[int]] = None):
        channels = db.get_all_channels()
        self.table_channels_select.setRowCount(len(channels))
        
        # Mặc định: nếu đã có saved_target_ids thì dùng, nếu không thì dùng selected_channel_ids, nếu không nữa thì chọn tất cả
        if saved_target_ids is not None and len(saved_target_ids) > 0:
            active_set = set(saved_target_ids)
        elif self.selected_channel_ids and len(self.selected_channel_ids) > 0:
            active_set = set(self.selected_channel_ids)
        else:
            active_set = set(c["id"] for c in channels)

        for r, ch in enumerate(channels):
            # Cột 0: Checkbox
            w = QWidget()
            l = QHBoxLayout(w)
            l.setContentsMargins(0, 0, 0, 0)
            l.setAlignment(Qt.AlignCenter)
            chk = QCheckBox()
            chk.setProperty("channel_id", ch["id"])
            chk.setChecked(ch["id"] in active_set)
            chk.stateChanged.connect(self.on_channel_checkbox_changed)
            l.addWidget(chk)
            self.table_channels_select.setCellWidget(r, 0, w)

            # Cột 1: STT
            it_stt = QTableWidgetItem(str(r + 1))
            it_stt.setTextAlignment(Qt.AlignCenter)
            self.table_channels_select.setItem(r, 1, it_stt)

            # Cột 2: Tên kênh
            it_name = QTableWidgetItem(f"🎬 {ch['name']}")
            it_name.setForeground(QColor("#FFFFFF"))
            it_name.setFont(QFont("Segoe UI", 10, QFont.Bold))
            self.table_channels_select.setItem(r, 2, it_name)

            # Cột 3: Username (Chuẩn hóa không bị lặp @@)
            raw_u = str(ch.get('username') or '').strip().lstrip('@')
            disp_u = f"@{raw_u}" if raw_u else "chưa có"
            it_u = QTableWidgetItem(disp_u)
            it_u.setForeground(QColor("#94A3B8"))
            self.table_channels_select.setItem(r, 3, it_u)

            # Cột 4: Chế độ Mạng áp dụng (Ưu tiên Proxy hoặc Mặc định VPN PIA)
            is_checked = (ch["id"] in active_set)
            if is_checked:
                net_str = "🛡️ Ưu tiên Proxy Tĩnh"
                net_color = "#38BDF8"
            else:
                net_str = "🛡️ Mặc định: VPN của PIA"
                net_color = "#34D399"
            it_net = QTableWidgetItem(net_str)
            it_net.setTextAlignment(Qt.AlignCenter)
            it_net.setForeground(QColor(net_color))
            it_net.setFont(QFont("Segoe UI", 9, QFont.Bold))
            self.table_channels_select.setItem(r, 4, it_net)

        self.on_channel_checkbox_changed()

    def filter_channels_table(self, query: str):
        """Lọc nhanh danh sách kênh theo tên kênh hoặc username"""
        q = (query or "").strip().lower()
        for r in range(self.table_channels_select.rowCount()):
            name_item = self.table_channels_select.item(r, 2)
            user_item = self.table_channels_select.item(r, 3)
            name_text = name_item.text().lower() if name_item else ""
            user_text = user_item.text().lower() if user_item else ""
            match = not q or q in name_text or q in user_text
            self.table_channels_select.setRowHidden(r, not match)

    def select_all_channels(self):
        for r in range(self.table_channels_select.rowCount()):
            w = self.table_channels_select.cellWidget(r, 0)
            if w:
                chk = w.findChild(QCheckBox)
                if chk:
                    chk.setChecked(True)

    def unselect_all_channels(self):
        for r in range(self.table_channels_select.rowCount()):
            w = self.table_channels_select.cellWidget(r, 0)
            if w:
                chk = w.findChild(QCheckBox)
                if chk:
                    chk.setChecked(False)

    def on_channel_checkbox_changed(self):
        checked_ids = self.get_checked_channel_ids()
        checked_set = set(checked_ids)
        total = self.table_channels_select.rowCount()
        batch_size = self.spn_rot_batch_size.value()
        num_batches = (len(checked_ids) + batch_size - 1) // batch_size if checked_ids else 0

        # Cập nhật trực tiếp nhãn Cột 4 cho từng kênh khi người dùng tích/bỏ tích:
        # - Kênh tích chọn -> Ưu tiên Proxy Tĩnh (Đợt X) - Không chèn IP VPN
        # - Kênh không tích chọn -> Mặc định thực hiện VPN của PIA
        checked_rank = {cid: idx for idx, cid in enumerate(checked_ids)}
        for r in range(total):
            w = self.table_channels_select.cellWidget(r, 0)
            it_net = self.table_channels_select.item(r, 4)
            if w and it_net:
                chk = w.findChild(QCheckBox)
                if chk:
                    cid = int(chk.property("channel_id"))
                    if cid in checked_set:
                        b_num = (checked_rank[cid] // batch_size) + 1
                        it_net.setText(f"🛡️ Ưu tiên Proxy (Đợt {b_num})")
                        it_net.setForeground(QColor("#38BDF8"))
                        it_net.setToolTip("Kênh này sẽ ưu tiên chạy bằng Proxy Tĩnh (Bỏ qua VPN PIA, không chèn IP VPN)")
                    else:
                        it_net.setText("🛡️ Mặc định: VPN của PIA")
                        it_net.setForeground(QColor("#34D399"))
                        it_net.setToolTip("Kênh không gắn Proxy ➔ Mặc định chạy bằng VPN của PIA")

        self.lbl_selected_channels_stat.setText(
            f"Đã chọn Proxy: {len(checked_ids)} / {total} kênh ({num_batches} đợt) | Còn lại {total - len(checked_ids)} kênh chạy VPN PIA"
        )
        self.update_rotation_preview()
        self.update_login_batch_view()

    def load_saved_config(self):
        cfg = rotating_proxy_mgr.get_config()
        self.txt_rotating_proxies.setPlainText(cfg.get("raw_pool", ""))
        self.spn_rot_batch_size.setValue(cfg.get("batch_size", 5))
        self.chk_rot_auto_off.setChecked(cfg.get("auto_off", True))
        
        # Nạp bảng tích chọn kênh
        self.populate_channels_selection_table(cfg.get("target_channel_ids"))

        if cfg.get("enabled"):
            self.lbl_rot_status.setText("Trạng thái: 🟢 ĐANG BẬT XOAY TUA PROXY (ƯU TIÊN PROXY > VPN PIA)")
            self.lbl_rot_status.setStyleSheet("font-weight: 800; font-size: 13px; color: #34D399; padding: 4px 0;")
            self.btn_toggle_rotation.setText("💾 LƯU & CẬP NHẬT DANH SÁCH KÊNH CHẠY PROXY")
            self.btn_toggle_rotation.setStyleSheet("background-color: #10B981; color: #FFFFFF; font-weight: 800; font-size: 12px; padding: 10px 16px; border-radius: 6px;")
        else:
            self.lbl_rot_status.setText("Trạng thái: ⚪ ĐANG TẮT XOAY TUA PROXY (TẤT CẢ KÊNH CHẠY MẶC ĐỊNH VPN PIA)")
            self.lbl_rot_status.setStyleSheet("font-weight: 800; font-size: 13px; color: #94A3B8; padding: 4px 0;")
            self.btn_toggle_rotation.setText("🚀 BẬT & LƯU XOAY TUA PROXY CHO KÊNH ĐÃ CHỌN")
            self.btn_toggle_rotation.setStyleSheet("background-color: #10B981; color: #FFFFFF; font-weight: 800; font-size: 12px; padding: 10px 16px; border-radius: 6px;")

        self.update_rotation_preview()
        self.update_login_batch_view()

    def on_rotation_text_changed(self):
        lines = [l.strip() for l in self.txt_rotating_proxies.toPlainText().splitlines() if l.strip() and not l.strip().startswith("#")]
        self.lbl_rot_counter.setText(f"Số lượng Proxy: {len(lines)} proxy")
        self.update_rotation_preview()
        self.update_login_batch_view()

    def update_rotation_preview(self):
        lines = [l.strip() for l in self.txt_rotating_proxies.toPlainText().splitlines() if l.strip() and not l.strip().startswith("#")]
        batch_size = self.spn_rot_batch_size.value()
        checked_ids = self.get_checked_channel_ids() if hasattr(self, "table_channels_select") else None
        batches = rotating_proxy_mgr.get_batches(channel_ids=checked_ids, batch_size=batch_size)

        self.table_rot_preview.setRowCount(len(batches))
        num_proxies = len(lines)

        for r, b in enumerate(batches):
            p_str = "Chưa nhập proxy"
            if num_proxies > 0:
                p_str = lines[r % num_proxies]
                p_disp = p_str.split("@")[-1] if "@" in p_str else p_str

            item_batch = QTableWidgetItem(f"Đợt {b['batch_number']}")
            item_batch.setTextAlignment(Qt.AlignCenter)
            item_batch.setForeground(QColor("#38BDF8"))
            item_batch.setFont(QFont("Segoe UI", 10, QFont.Bold))
            self.table_rot_preview.setItem(r, 0, item_batch)

            item_range = QTableWidgetItem(f"Kênh {b['start_stt']} ➜ {b['end_stt']}")
            item_range.setTextAlignment(Qt.AlignCenter)
            item_range.setForeground(QColor("#FFFFFF"))
            self.table_rot_preview.setItem(r, 1, item_range)

            item_count = QTableWidgetItem(f"{len(b['channels'])} kênh")
            item_count.setTextAlignment(Qt.AlignCenter)
            self.table_rot_preview.setItem(r, 2, item_count)

            # Nếu proxy này đã được kiểm tra, hiển thị ngay Quốc Gia & Ping
            c_info = getattr(self, "proxy_inspection_cache", {}).get(p_str)
            if c_info and c_info.get("success"):
                flag = c_info.get("flag", "🛡️")
                c_name = c_info.get("country_name", "Quốc Tế")
                ping = c_info.get("ping", 0)
                disp_str = f"{flag} [{c_name}] {c_info.get('ip', p_disp)} ({ping} ms)"
                item_p = QTableWidgetItem(disp_str)
                item_p.setForeground(QColor("#34D399"))
                item_p.setFont(QFont("Segoe UI", 10, QFont.Bold))
                item_p.setToolTip(f"Quốc gia: {c_info.get('display_country')}\nThành phố: {c_info.get('city')}\nISP: {c_info.get('isp')}\nProxy gốc: {p_str}")
            else:
                item_p = QTableWidgetItem(f"🛡️ {p_disp if num_proxies > 0 else 'Chưa có'}")
                item_p.setForeground(QColor("#38BDF8") if num_proxies > 0 else QColor("#94A3B8"))
            self.table_rot_preview.setItem(r, 3, item_p)

            action_desc = "Tự động OFF Proxy ➔ Chuyển Proxy sang đợt tiếp theo" if self.chk_rot_auto_off.isChecked() else "Giữ nguyên"
            item_act = QTableWidgetItem(f"⚡ {action_desc}")
            item_act.setForeground(QColor("#34D399"))
            self.table_rot_preview.setItem(r, 4, item_act)

    def save_and_toggle_rotation(self):
        lines = [l.strip() for l in self.txt_rotating_proxies.toPlainText().splitlines() if l.strip() and not l.strip().startswith("#")]
        if not lines:
            QMessageBox.warning(self, "Chưa nhập Proxy", "Vui lòng dán ít nhất 1 Proxy tĩnh để kích hoạt chế độ xoay tua!")
            return

        checked_cids = self.get_checked_channel_ids()
        if not checked_cids:
            QMessageBox.warning(self, "Chưa chọn kênh", "Vui lòng tích chọn ít nhất 1 kênh trong bảng danh sách kênh để áp dụng proxy!")
            return

        rotating_proxy_mgr.save_config(
            enabled=True,
            proxies=lines,
            batch_size=self.spn_rot_batch_size.value(),
            auto_off=self.chk_rot_auto_off.isChecked(),
            target_channel_ids=checked_cids
        )

        self.load_saved_config()
        self.proxies_assigned.emit()

        c_count = len(checked_cids)
        total_ch = self.table_channels_select.rowCount()
        vpn_count = max(0, total_ch - c_count)
        b_size = self.spn_rot_batch_size.value()
        n_batches = (c_count + b_size - 1) // b_size if c_count else 0
        QMessageBox.information(
            self, "Đã Kích Hoạt & Ưu Tiên Proxy Tĩnh",
            f"🎉 <b>ĐÃ LƯU & BẬT CHẾ ĐỘ XOAY TUA PROXY THÀNH CÔNG!</b><br><br>"
            f"• <b>Kênh ưu tiên chạy Proxy Tĩnh:</b> <font color='#38BDF8'><b>{c_count} kênh</b></font> ({n_batches} đợt, {b_size} kênh/đợt)<br>"
            f"• <b>Kênh mặc định chạy VPN của PIA:</b> <font color='#34D399'><b>{vpn_count} kênh</b></font><br><br>"
            "🛡️ <b>Quy tắc Ưu Tiên Mạng đã áp dụng:</b><br>"
            "1. Các kênh đã tích chọn Proxy sẽ <b>ưu tiên tuyệt đối dùng Proxy Tĩnh</b> (tuyệt đối không chèn IP của VPN PIA kể cả khi VPN đang bật).<br>"
            "2. Khi 5 kênh đăng xong ➔ Tự động <b>OFF Proxy</b> ở 5 kênh đó (trả về mặc định VPN PIA) và <b>chuyển Proxy sang 5 kênh tiếp theo</b>.<br>"
            "3. Các kênh không gắn Proxy sẽ <b>mặc định thực hiện qua VPN của PIA</b>."
        )

    def off_all_proxies(self):
        reply = QMessageBox.question(
            self, "Xác nhận Tắt Proxy",
            "Bạn có chắc muốn <b>Tắt & Gỡ bỏ toàn bộ Proxy tĩnh</b> khỏi tất cả các kênh TikTok trong hệ thống?",
            QMessageBox.Yes | QMessageBox.No
        )
        if reply == QMessageBox.Yes:
            lines = [l.strip() for l in self.txt_rotating_proxies.toPlainText().splitlines() if l.strip() and not l.strip().startswith("#")]
            rotating_proxy_mgr.save_config(
                enabled=False,
                proxies=lines,
                batch_size=self.spn_rot_batch_size.value(),
                auto_off=self.chk_rot_auto_off.isChecked(),
                target_channel_ids=[]
            )
            db.batch_clear_proxies()
            rotating_proxy_mgr.reset_cycle()
            self.load_saved_config()
            self.proxies_assigned.emit()
            QMessageBox.information(self, "Đã Tắt Proxy", "✅ Đã gỡ bỏ Proxy khỏi toàn bộ các kênh!\nTất cả kênh đã được chuyển về mặc định chạy VPN của PIA.")

    # =========================================================================
    # LOGIN BATCH LOGIC
    # =========================================================================
    def update_login_batch_view(self):
        lines = [l.strip() for l in self.txt_rotating_proxies.toPlainText().splitlines() if l.strip() and not l.strip().startswith("#")]
        batch_size = self.spn_rot_batch_size.value()
        checked_ids = self.get_checked_channel_ids() if hasattr(self, "table_channels_select") else None
        batches = rotating_proxy_mgr.get_batches(channel_ids=checked_ids, batch_size=batch_size)

        if not batches:
            self.lbl_login_batch_title.setText("Không có kênh nào trong hệ thống!")
            self.table_login_current.setRowCount(0)
            return

        if self.cur_login_batch_idx >= len(batches):
            self.cur_login_batch_idx = 0

        b = batches[self.cur_login_batch_idx]
        total_b = len(batches)
        self.lbl_login_batch_title.setText(f"📍 ĐỢT HIỆN TẠI: ĐỢT {b['batch_number']} / {total_b} (Kênh {b['start_stt']} ➜ {b['end_stt']})")

        p_str = lines[self.cur_login_batch_idx % len(lines)] if lines else "Chưa nhập proxy"
        p_disp = p_str.split("@")[-1] if "@" in p_str else p_str
        self.lbl_login_proxy_display.setText(f"🛡️ Proxy sử dụng cho đợt này: {p_disp}")

        # Render 5 channels in table
        channels = b["channels"]
        self.table_login_current.setRowCount(len(channels))
        for r, ch in enumerate(channels):
            item_stt = QTableWidgetItem(str(b["start_stt"] + r))
            item_stt.setTextAlignment(Qt.AlignCenter)
            self.table_login_current.setItem(r, 0, item_stt)

            item_name = QTableWidgetItem(f"🎬 {ch['name']}")
            item_name.setForeground(QColor("#FFFFFF"))
            item_name.setFont(QFont("Segoe UI", 10, QFont.Bold))
            self.table_login_current.setItem(r, 1, item_name)

            item_user = QTableWidgetItem(f"@{ch.get('username') or 'chưa có'}")
            item_user.setForeground(QColor("#94A3B8"))
            self.table_login_current.setItem(r, 2, item_user)

            is_log = bool(ch.get("is_logged_in", 0))
            st_text = "✅ ĐÃ LOGIN" if is_log else "⚠️ CHƯA LOGIN"
            item_st = QTableWidgetItem(st_text)
            item_st.setTextAlignment(Qt.AlignCenter)
            item_st.setForeground(QColor("#10B981") if is_log else QColor("#F59E0B"))
            self.table_login_current.setItem(r, 3, item_st)

    def execute_open_login_batch(self):
        lines = [l.strip() for l in self.txt_rotating_proxies.toPlainText().splitlines() if l.strip() and not l.strip().startswith("#")]
        if not lines:
            QMessageBox.warning(self, "Chưa có Proxy", "Vui lòng nhập ít nhất 1 Proxy tĩnh ở Tab 1 trước khi mở đăng nhập!")
            return

        batch_size = self.spn_rot_batch_size.value()
        batches = rotating_proxy_mgr.get_batches(batch_size=batch_size)
        if not batches or self.cur_login_batch_idx >= len(batches):
            return

        cur_b = batches[self.cur_login_batch_idx]
        p_str = lines[self.cur_login_batch_idx % len(lines)]

        # Gán Proxy cho 5 kênh của đợt này
        rotating_proxy_mgr.assign_proxy_to_channels(cur_b["channel_ids"], p_str)
        self.prev_login_channel_ids = cur_b["channel_ids"]

        # Mở Chrome cho 5 kênh
        chrome_mgr.launch_batch_profiles(cur_b["channels"], delay_seconds=1.5)
        self.proxies_assigned.emit()

        QMessageBox.information(
            self, "Đã Mở Đăng Nhập",
            f"🌐 Đã gán Proxy <b>{p_str.split('@')[-1]}</b> và mở {len(cur_b['channels'])} Profile Chrome cho Đợt {cur_b['batch_number']}!<br><br>"
            "Bạn hãy thực hiện đăng nhập vào TikTok trên các cửa sổ trình duyệt vừa mở.<br>"
            "Sau khi đăng nhập xong, hãy bấm nút <b>'ĐÃ XONG 5 KÊNH NÀY ➔ TỰ TẮT PROXY & MỞ 5 KÊNH TIẾP THEO'</b>."
        )

    def execute_advance_login_batch(self):
        lines = [l.strip() for l in self.txt_rotating_proxies.toPlainText().splitlines() if l.strip() and not l.strip().startswith("#")]
        batch_size = self.spn_rot_batch_size.value()
        batches = rotating_proxy_mgr.get_batches(batch_size=batch_size)

        if self.cur_login_batch_idx >= len(batches) - 1:
            # Đã xong đợt cuối cùng
            if self.prev_login_channel_ids:
                rotating_proxy_mgr.off_proxy_from_channels(self.prev_login_channel_ids)
                self.prev_login_channel_ids = []
            self.proxies_assigned.emit()
            QMessageBox.information(self, "Hoàn tất", "🎉 Chúc mừng! Bạn đã hoàn thành đăng nhập toàn bộ các kênh trong hệ thống!")
            return

        # 1. TỰ ĐỘNG OFF PROXY CỦA ĐỢT VỪA XONG!
        if self.prev_login_channel_ids:
            rotating_proxy_mgr.off_proxy_from_channels(self.prev_login_channel_ids)

        # 2. CHUYỂN SANG ĐỢT TIẾP THEO
        self.cur_login_batch_idx += 1
        next_b = batches[self.cur_login_batch_idx]
        next_proxy = lines[self.cur_login_batch_idx % len(lines)] if lines else ""

        # 3. GÁN PROXY ĐÓ CHO 5 KÊNH TIẾP THEO
        if next_proxy:
            rotating_proxy_mgr.assign_proxy_to_channels(next_b["channel_ids"], next_proxy)
            self.prev_login_channel_ids = next_b["channel_ids"]

        # 4. MỞ 5 KÊNH TIẾP THEO LÊN
        self.update_login_batch_view()
        self.proxies_assigned.emit()

        reply = QMessageBox.question(
            self, "Chuyển Đợt Thành Công",
            f"✅ <b>ĐÃ TỰ ĐỘNG OFF PROXY 5 KÊNH VỪA XONG!</b><br><br>"
            f"👉 Đã chuyển sang <b>Đợt {next_b['batch_number']} (Kênh {next_b['start_stt']} ➜ {next_b['end_stt']})</b>.<br>"
            f"Bạn có muốn mở ngay đồng thời 5 Profile Chrome của đợt này để đăng nhập tiếp?",
            QMessageBox.Yes | QMessageBox.No
        )
        if reply == QMessageBox.Yes:
            chrome_mgr.launch_batch_profiles(next_b["channels"], delay_seconds=1.5)

    def reset_login_batches(self):
        if self.prev_login_channel_ids:
            rotating_proxy_mgr.off_proxy_from_channels(self.prev_login_channel_ids)
            self.prev_login_channel_ids = []
        self.cur_login_batch_idx = 0
        self.update_login_batch_view()
        self.proxies_assigned.emit()

    # =========================================================================
    # STATIC ALLOCATION
    # =========================================================================
    def execute_static_allocation(self):
        lines = [l.strip() for l in self.txt_rotating_proxies.toPlainText().splitlines() if l.strip() and not l.strip().startswith("#")]
        if not lines:
            QMessageBox.warning(self, "Chưa có Proxy", "Vui lòng dán danh sách Proxy ở Tab 1 trước!")
            return

        res = db.batch_assign_proxies(
            proxy_list=lines,
            ratio=self.spn_rot_batch_size.value(),
            channel_ids=self.selected_channel_ids if self.selected_channel_ids else None,
            sort_order="id_asc",
            loop_proxies=True
        )
        self.proxies_assigned.emit()
        QMessageBox.information(self, "Gán Cố Định Thành Công", res.get("message", "Đã gán proxy thành công!"))

    def closeEvent(self, event):
        """Khi đóng hộp thoại: Nếu đã nhập Proxy trong ô và có tích chọn kênh, tự động lưu & gắn Proxy cho các kênh đã chọn!"""
        try:
            lines = [l.strip() for l in self.txt_rotating_proxies.toPlainText().splitlines() if l.strip() and not l.strip().startswith("#")]
            checked_cids = self.get_checked_channel_ids()
            if lines and checked_cids:
                rotating_proxy_mgr.save_config(
                    enabled=True,
                    proxies=lines,
                    batch_size=self.spn_rot_batch_size.value(),
                    auto_off=self.chk_rot_auto_off.isChecked(),
                    target_channel_ids=checked_cids
                )
                self.proxies_assigned.emit()
        except Exception:
            pass
        super().closeEvent(event)

    def check_proxies_live(self, text_widget: QPlainTextEdit):
        lines = [l.strip() for l in text_widget.toPlainText().splitlines() if l.strip() and not l.strip().startswith("#")]
        if not lines:
            QMessageBox.warning(self, "Chưa có proxy", "Vui lòng nhập ít nhất 1 proxy để kiểm tra!")
            return

        if not hasattr(self, "proxy_inspection_cache"):
            self.proxy_inspection_cache = {}

        dlg = ProxyInspectionDialog(self, lines)
        dlg.exec()
