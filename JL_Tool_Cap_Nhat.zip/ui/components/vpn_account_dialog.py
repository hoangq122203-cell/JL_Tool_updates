import os
import time
from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QComboBox, QMessageBox, QGroupBox, QFormLayout, QFrame
)
from PySide6.QtCore import Qt, QObject, Signal
from database.db_manager import db
from core.network_manager import network_mgr
from core.vpn_regions import ALL_VPN_COUNTRIES

class VpnIpWorker(QObject):
    info_ready = Signal(dict)

    def fetch(self):
        try:
            info = network_mgr.get_detailed_ip_info()
            self.info_ready.emit(info)
        except Exception:
            pass

class VpnAccountDialog(QDialog):
    """
    Hộp thoại Đăng nhập tài khoản VPN & Tự động kết nối với App PIA / HMA trên máy tính
    """
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Kết Nối App PIA VPN / HMA VPN Trên Máy Tính")
        self.setFixedWidth(580)

        self.ip_worker = VpnIpWorker()
        self.ip_worker.info_ready.connect(self._on_ip_ready)

        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 20, 24, 20)
        layout.setSpacing(14)

        # Header Title
        title_box = QVBoxLayout()
        title_box.setSpacing(3)
        lbl_title = QLabel("KẾT NỐI APP PIA VPN & HMA VPN TRÊN MÁY TÍNH")
        lbl_title.setStyleSheet("font-size: 15px; font-weight: 800; color: #FFFFFF;")
        lbl_sub = QLabel("Chỉ cần App máy tính đổi IP sang nước nào, TOÀN BỘ các kênh trong Tool sẽ tự động chuyển sang nước đó")
        lbl_sub.setStyleSheet("font-size: 11px; color: #25F4EE; font-weight: 600;")
        title_box.addWidget(lbl_title)
        title_box.addWidget(lbl_sub)
        layout.addLayout(title_box)

        # ==================== KHU VỰC 1: MỞ THẲNG APP TRÊN MÁY TÍNH ====================
        grp_app = QGroupBox("1. Mở Trực Tiếp Ứng Dụng Trên Máy Tính Để Đăng Nhập / Chọn Nước")
        grp_app.setStyleSheet("QGroupBox { font-weight: 700; color: #FFFFFF; border: 1px solid #2B2D3D; border-radius: 8px; margin-top: 10px; padding: 14px; } QGroupBox::title { subcontrol-origin: margin; left: 10px; padding: 0 5px; }")
        app_layout = QVBoxLayout(grp_app)
        app_layout.setSpacing(10)

        lbl_app_desc = QLabel("Bấm nút bên dưới để mở giao diện chính thức của App PIA VPN hoặc HMA trên màn hình máy tính:")
        lbl_app_desc.setStyleSheet("color: #94A3B8; font-size: 11px;")
        app_layout.addWidget(lbl_app_desc)

        btn_app_row = QHBoxLayout()
        btn_app_row.setSpacing(12)

        self.btn_open_pia_app = QPushButton("📱 MỞ APP PIA VPN TRÊN MÁY TÍNH")
        self.btn_open_pia_app.setProperty("class", "btn-primary")
        self.btn_open_pia_app.setFixedHeight(40)
        self.btn_open_pia_app.setStyleSheet("background-color: #22C55E; color: #FFFFFF; font-weight: 800; font-size: 12px; border-radius: 8px;")
        self.btn_open_pia_app.setCursor(Qt.PointingHandCursor)
        self.btn_open_pia_app.clicked.connect(lambda: self.launch_desktop_app("pia"))
        btn_app_row.addWidget(self.btn_open_pia_app)

        self.btn_open_hma_app = QPushButton("📱 MỞ APP HMA VPN")
        self.btn_open_hma_app.setProperty("class", "btn-secondary")
        self.btn_open_hma_app.setFixedHeight(40)
        self.btn_open_hma_app.setStyleSheet("font-weight: 700; font-size: 12px; border-radius: 8px;")
        self.btn_open_hma_app.setCursor(Qt.PointingHandCursor)
        self.btn_open_hma_app.clicked.connect(lambda: self.launch_desktop_app("hma"))
        btn_app_row.addWidget(self.btn_open_hma_app)

        app_layout.addLayout(btn_app_row)
        layout.addWidget(grp_app)

        # ==================== KHU VỰC 2: PHÂN BIỆT RÕ RÀNG IP MÁY TÍNH & IP QUỐC GIA ====================
        grp_sync = QGroupBox("2. Kiểm Tra Rõ Ràng: IP Gốc Của Máy Tính & IP Quốc Gia")
        grp_sync.setStyleSheet("QGroupBox { font-weight: 700; color: #FFFFFF; border: 1px solid #2B2D3D; border-radius: 8px; margin-top: 10px; padding: 14px; } QGroupBox::title { subcontrol-origin: margin; left: 10px; padding: 0 5px; }")
        sync_layout = QVBoxLayout(grp_sync)
        sync_layout.setSpacing(12)

        # Hàng 2 Khung So Sánh Cạnh Nhau
        cards_row = QHBoxLayout()
        cards_row.setSpacing(12)

        # Khung 1: IP Thật Gốc của Máy Tính
        card_real = QFrame()
        card_real.setStyleSheet("background-color: #12131D; border: 1px solid #26273B; border-radius: 8px; padding: 10px;")
        l_real = QVBoxLayout(card_real)
        l_real.setSpacing(4)
        lbl_r_title = QLabel("💻 1. IP GỐC CỦA MÁY TÍNH (THẬT)")
        lbl_r_title.setStyleSheet("color: #94A3B8; font-size: 11px; font-weight: 700;")
        self.lbl_real_ip_val = QLabel("Đang kiểm tra...")
        self.lbl_real_ip_val.setStyleSheet("color: #FFFFFF; font-size: 14px; font-weight: 800; font-family: Consolas, monospace;")
        self.lbl_real_country_val = QLabel("Quốc gia: Đang xác định...")
        self.lbl_real_country_val.setStyleSheet("color: #64748B; font-size: 11px;")
        lbl_r_desc = QLabel("Địa chỉ Internet nhà mạng cung cấp cho máy tính.")
        lbl_r_desc.setStyleSheet("color: #475569; font-size: 10px; font-style: italic;")
        l_real.addWidget(lbl_r_title)
        l_real.addWidget(self.lbl_real_ip_val)
        l_real.addWidget(self.lbl_real_country_val)
        l_real.addWidget(lbl_r_desc)
        cards_row.addWidget(card_real)

        # Khung 2: IP Quốc Gia (VPN)
        card_fake = QFrame()
        card_fake.setStyleSheet("background-color: #101924; border: 1px solid #1E3A5F; border-radius: 8px; padding: 10px;")
        l_fake = QVBoxLayout(card_fake)
        l_fake.setSpacing(4)
        lbl_f_title = QLabel("🛡️ 2. IP QUỐC GIA (VPN / ĐÃ ĐỔI)")
        lbl_f_title.setStyleSheet("color: #38BDF8; font-size: 11px; font-weight: 700;")
        self.lbl_fake_ip_val = QLabel("Đang kiểm tra...")
        self.lbl_fake_ip_val.setStyleSheet("color: #25F4EE; font-size: 14px; font-weight: 800; font-family: Consolas, monospace;")
        self.lbl_fake_country_val = QLabel("Quốc gia: Đang xác định...")
        self.lbl_fake_country_val.setStyleSheet("color: #38BDF8; font-size: 11px; font-weight: 600;")
        self.lbl_vpn_status_badge = QLabel("Đang quét trạng thái...")
        self.lbl_vpn_status_badge.setStyleSheet("color: #22C55E; font-size: 10px; font-weight: 700;")
        l_fake.addWidget(lbl_f_title)
        l_fake.addWidget(self.lbl_fake_ip_val)
        l_fake.addWidget(self.lbl_fake_country_val)
        l_fake.addWidget(self.lbl_vpn_status_badge)
        cards_row.addWidget(card_fake)

        sync_layout.addLayout(cards_row)

        # Hàng nút Quét lại IP
        refresh_row = QHBoxLayout()
        self.btn_sync_ip = QPushButton("🔄 Quét & Xác Minh Lại Cả 2 IP Ngay Lập Tức")
        self.btn_sync_ip.setProperty("class", "btn-secondary")
        self.btn_sync_ip.setFixedHeight(34)
        self.btn_sync_ip.setCursor(Qt.PointingHandCursor)
        self.btn_sync_ip.clicked.connect(self.sync_current_ip)
        refresh_row.addWidget(self.btn_sync_ip)
        sync_layout.addLayout(refresh_row)

        lbl_rule_info = QLabel("💡 <b>Quy tắc hoạt động:</b> Sau khi bạn bấm kết nối sang nước nào trên App PIA/HMA, hãy bấm <b>'Đồng Bộ & Đóng'</b>. Tất cả các kênh TikTok có bật VPN sẽ tự động chạy qua <b>IP Quốc Gia</b> ở trên!")
        lbl_rule_info.setStyleSheet("color: #94A3B8; font-size: 11px; background-color: #1A1D2E; border-radius: 6px; padding: 8px;")
        sync_layout.addWidget(lbl_rule_info)

        layout.addWidget(grp_sync)

        # ==================== NÚT BẤM ====================
        btn_box = QHBoxLayout()
        btn_box.setSpacing(10)

        self.btn_cancel = QPushButton("Đóng")
        self.btn_cancel.setProperty("class", "btn-secondary")
        self.btn_cancel.clicked.connect(self.reject)
        btn_box.addWidget(self.btn_cancel)

        btn_box.addStretch()

        self.btn_confirm = QPushButton("✅ ĐỒNG BỘ IP NÀY CHO TẤT CẢ KÊNH & ĐÓNG")
        self.btn_confirm.setProperty("class", "btn-primary")
        self.btn_confirm.setFixedHeight(40)
        self.btn_confirm.setStyleSheet("background-color: #FE2C55; color: #FFFFFF; font-weight: 800; font-size: 12px; padding: 0 16px; border-radius: 8px;")
        self.btn_confirm.setCursor(Qt.PointingHandCursor)
        self.btn_confirm.clicked.connect(self.confirm_and_close)
        btn_box.addWidget(self.btn_confirm)

        layout.addLayout(btn_box)

        self.sync_current_ip()

    def launch_desktop_app(self, vpn_type: str):
        ok, msg = network_mgr.open_vpn_desktop_app(vpn_type)
        if ok:
            QMessageBox.information(
                self, "Đã mở App",
                f"{msg}<br><br>"
                "1. Bạn hãy đăng nhập tài khoản trên cửa sổ App vừa mở.<br>"
                "2. Chọn quốc gia mong muốn và bấm Kết Nối (Connect).<br>"
                "3. Quay lại Tool bấm <b>'Quét Lại IP Mới'</b> để cập nhật cho toàn bộ kênh!"
            )
        else:
            QMessageBox.warning(self, "Thông báo", msg)

    def sync_current_ip(self):
        self.lbl_real_ip_val.setText("Đang kiểm tra...")
        self.lbl_fake_ip_val.setText("Đang quét siêu tốc...")
        self.lbl_vpn_status_badge.setText("⚡ Đang quét trực tiếp từ App PIA...")
        self.lbl_vpn_status_badge.setStyleSheet("color: #F59E0B; font-size: 10px; font-weight: 700;")

        import threading
        threading.Thread(target=self.ip_worker.fetch, daemon=True).start()

    def _on_ip_ready(self, info: dict):
        # 1. IP Gốc Máy tính
        self.lbl_real_ip_val.setText(info.get("real_ip", ""))
        self.lbl_real_country_val.setText(f"Quốc gia: {info.get('real_country', '')}")

        # 2. IP Khi Fake - TRÙNG KHỚP 100% VỚI APP PIA
        fake_ip = info.get("fake_ip", "")
        self.lbl_fake_ip_val.setText(fake_ip)
        if info.get("is_faked"):
            self.lbl_fake_country_val.setText(f"Vùng: {info.get('fake_country', '')}")
            self.lbl_vpn_status_badge.setText(f"🟢 ĐÃ ĐỔI IP THÀNH CÔNG (Trùng khớp App {info['vpn_type']})")
            self.lbl_vpn_status_badge.setStyleSheet("color: #22C55E; font-size: 10px; font-weight: 700;")
            self.lbl_fake_ip_val.setStyleSheet("color: #25F4EE; font-size: 15px; font-weight: 800; font-family: Consolas, monospace;")
        else:
            self.lbl_fake_country_val.setText("Chưa chọn vùng VPN")
            self.lbl_vpn_status_badge.setText("⚪ Chưa kết nối VPN (Đang dùng IP Gốc Máy)")
            self.lbl_vpn_status_badge.setStyleSheet("color: #94A3B8; font-size: 10px; font-weight: 700;")
            self.lbl_fake_ip_val.setStyleSheet("color: #94A3B8; font-size: 14px; font-weight: 800; font-family: Consolas, monospace;")

    def confirm_and_close(self):
        # Lưu cấu hình vào setting để hiển thị Header
        fake_ip = self.lbl_fake_ip_val.text()
        fake_country = self.lbl_fake_country_val.text().replace("Vùng:", "").strip()
        real_ip = self.lbl_real_ip_val.text()

        db.set_setting("global_vpn_country_name", f"{fake_ip} ({fake_country})")
        QMessageBox.information(
            self, "Đã Đồng Bộ IP Thành Công",
            f"<b>💻 IP Máy Tính Gốc:</b> {real_ip}<br>"
            f"<b>🛡️ IP Quốc Gia (VPN):</b> {fake_ip} ({fake_country})<br><br>"
            "Toàn bộ các kênh TikTok có bật VPN đã sẵn sàng hoạt động qua IP này!"
        )
        self.accept()
