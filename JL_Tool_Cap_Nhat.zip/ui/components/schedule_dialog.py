import sys
import os
import random
from pathlib import Path
from datetime import datetime, timedelta
from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit,
    QPushButton, QFileDialog, QComboBox, QMessageBox,
    QGroupBox, QFormLayout, QDateTimeEdit, QTextEdit, QCheckBox,
    QSpinBox, QWidget, QScrollArea, QFrame, QSizePolicy
)
from PySide6.QtCore import Qt, QDateTime, QDate, QTime
from database.db_manager import db
from core.scheduler_service import scheduler_service
from core.video_vault import video_vault
import config

class ScheduleDialog(QDialog):
    """
    Cửa sổ tạo lịch hẹn giờ đăng video chi tiết theo Ngày & Giờ như lịch thông thường
    Hỗ trợ đăng 1 hoặc nhiều video với khoảng cách tùy chọn (mặc định 1 video cách nhau 1 phút)
    """
    def __init__(self, parent=None, preselected_channel_id=None, preselected_video_path=None):
        super().__init__(parent)
        self.preselected_channel_id = preselected_channel_id
        self.selected_video_paths = [preselected_video_path] if preselected_video_path else []
        self.setWindowTitle("📅 Hẹn Lịch Đăng Video Cho Kênh TikTok")
        self.resize(760, 840)
        self.setMinimumWidth(720)
        self.setStyleSheet("background-color: #0F121C; color: #FFFFFF;")
        self.init_ui()

    def init_ui(self):
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(16, 16, 16, 16)
        main_layout.setSpacing(10)

        # Tiêu đề
        lbl_header = QLabel("📅 HẸN LỊCH ĐĂNG VIDEO THEO NGÀY & GIỜ")
        lbl_header.setStyleSheet("font-size: 16px; font-weight: 800; color: #FFFFFF;")
        main_layout.addWidget(lbl_header)

        lbl_desc = QLabel("Chọn kênh, video và ngày giờ mong muốn. Hệ thống sẽ tự động đăng ngầm và đảm bảo chuẩn 1080p, tối ưu thuật toán lên xu hướng TikTok.")
        lbl_desc.setStyleSheet("color: #94A3B8; font-size: 12px;")
        lbl_desc.setWordWrap(True)
        main_layout.addWidget(lbl_desc)

        # Khung cuộn mượt mà bảo vệ hiển thị toàn bộ nội dung trên mọi màn hình
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setStyleSheet("""
            QScrollArea {
                border: none;
                background-color: transparent;
            }
            QScrollBar:vertical {
                border: none;
                background: #0B0E14;
                width: 8px;
                border-radius: 4px;
            }
            QScrollBar::handle:vertical {
                background: #2B3654;
                border-radius: 4px;
                min-height: 25px;
            }
            QScrollBar::handle:vertical:hover {
                background: #38BDF8;
            }
            QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {
                height: 0px;
            }
        """)

        scroll_widget = QWidget()
        scroll_widget.setStyleSheet("background-color: transparent;")
        layout = QVBoxLayout(scroll_widget)
        layout.setContentsMargins(0, 0, 8, 4)
        layout.setSpacing(12)

        # ==================== NHÓM 1: CHỌN KÊNH & VIDEO ====================
        grp_target = QGroupBox("1. Kênh TikTok & Video Nguồn")
        grp_target.setStyleSheet("QGroupBox { font-weight: 600; color: #E1E1E6; border: 1px solid #2B2D3D; border-radius: 8px; margin-top: 10px; padding-top: 15px; } QGroupBox::title { subcontrol-origin: margin; left: 10px; padding: 0 5px; }")
        t_layout = QFormLayout(grp_target)
        t_layout.setSpacing(10)

        # Dropdown Kênh (HIỂN THỊ RÕ RÀNG TRẠNG THÁI FAKE IP PHILIPPINES HOẶC CHƯA FAKE)
        self.cmb_channel = QComboBox()
        self.cmb_channel.setMinimumWidth(320)
        self.cmb_channel.setStyleSheet("""
            QComboBox {
                background-color: #0A0B10;
                color: #FFFFFF;
                border: 1px solid #2B3654;
                border-radius: 6px;
                padding: 6px 10px;
                font-size: 12px;
                font-weight: 600;
            }
            QComboBox:hover {
                border-color: #38BDF8;
            }
            QComboBox QAbstractItemView {
                background-color: #101424;
                color: #FFFFFF;
                selection-background-color: #2563EB;
                selection-color: #FFFFFF;
                border: 1px solid #2B3654;
                padding: 4px;
            }
        """)

        saved_country = db.get_setting("global_vpn_country_name", "Philippines")
        c_clean = saved_country
        for p in ["🇻🇳", "🇯🇵", "🇰🇷", "🇸🇬", "🇹🇼", "🇭🇰", "🇹🇭", "🇲🇾", "🇮🇩", "🇵🇭", "🇮🇳", "🇦🇺", "🇺🇸", "🇨🇦", "🇬🇧", "🇩🇪", "🇫🇷", "🇳🇱"]:
            c_clean = c_clean.replace(p, "").strip()
        if "(" in c_clean:
            c_clean = c_clean.split("(")[0].strip()
        if not c_clean or c_clean == "VPN":
            c_clean = "Philippines"

        cached_fake_ip = db.get_setting("cached_fake_ip", "")

        channels = db.get_all_channels()
        for ch in channels:
            use_vpn = bool(ch.get("use_vpn", 1))
            net_type = ch.get("network_type", "vpn")

            if net_type == "proxy" and ch.get("proxy_string"):
                vpn_stat = "🛡️ Proxy Riêng"
            elif use_vpn:
                if cached_fake_ip and cached_fake_ip not in ["Chưa fake", "Đang quét...", ""]:
                    vpn_stat = f"🛡️ IP: {c_clean} ({cached_fake_ip})"
                else:
                    vpn_stat = f"🛡️ IP: {c_clean}"
            else:
                vpn_stat = "🌐 IP Gốc"

            name = ch.get("name", "Kênh")
            raw_user = ch.get("username", "").strip()
            handle = raw_user if raw_user else f"@{name}"
            if not handle.startswith("@"):
                handle = f"@{handle}"

            clean_name = name.lstrip("@")
            clean_handle = handle.lstrip("@")
            if clean_name.lower() == clean_handle.lower():
                display_title = f"🎬 @{clean_name}"
            else:
                display_title = f"🎬 {name}  ({handle})"

            self.cmb_channel.addItem(f"{display_title} — [{vpn_stat}]", ch["id"])

        if self.preselected_channel_id:
            idx = self.cmb_channel.findData(self.preselected_channel_id)
            if idx >= 0:
                self.cmb_channel.setCurrentIndex(idx)

        self.cmb_channel.currentIndexChanged.connect(self.on_channel_selected_auto_load_videos)
        t_layout.addRow("Kênh đăng:", self.cmb_channel)

        # Chọn Video
        v_row = QHBoxLayout()
        self.lbl_video_info = QLabel("Chưa chọn video")
        self.lbl_video_info.setStyleSheet("color: #CBD5E1; font-size: 12px; font-style: italic;")
        self.btn_browse_video = QPushButton("📁 Chọn Video (1 hoặc nhiều)...")
        self.btn_browse_video.setProperty("class", "btn-secondary")
        self.btn_browse_video.setCursor(Qt.PointingHandCursor)
        self.btn_browse_video.clicked.connect(self.browse_video)
        v_row.addWidget(self.btn_browse_video)
        v_row.addWidget(self.lbl_video_info, 1)
        t_layout.addRow("File Video:", v_row)

        layout.addWidget(grp_target)

        # ==================== KHỐI PHÂN TÍCH KHUNG GIỜ VÀNG & CHIẾN LƯỢC XU HƯỚNG ====================
        grp_trend = QGroupBox("🔥 Phân Tích Khung Giờ & Chiến Lược Đăng Lên Xu Hướng TikTok (FYP)")
        grp_trend.setStyleSheet("""
            QGroupBox {
                font-weight: 700;
                color: #F59E0B;
                border: 1px solid #D97706;
                border-radius: 8px;
                margin-top: 10px;
                padding-top: 15px;
                background-color: rgba(217, 119, 6, 0.04);
            }
            QGroupBox::title {
                subcontrol-origin: margin;
                left: 10px;
                padding: 0 5px;
            }
        """)
        trend_layout = QVBoxLayout(grp_trend)
        trend_layout.setSpacing(8)

        # Label phân tích thời gian thực động
        self.lbl_trend_analysis = QLabel()
        self.lbl_trend_analysis.setStyleSheet("color: #FCD34D; font-size: 11px; font-weight: 600; line-height: 1.4;")
        self.lbl_trend_analysis.setWordWrap(True)
        trend_layout.addWidget(self.lbl_trend_analysis)

        # Dòng 1: Nút tự động chọn khung giờ vàng sắp tới nổi bật
        row_rec = QHBoxLayout()
        btn_auto_golden = QPushButton("⭐ Khung Giờ Vàng Sắp Tới Gần Nhất (Hệ Thống Tự Động Tính)")
        btn_auto_golden.setStyleSheet("""
            QPushButton {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #D97706, stop:1 #B45309);
                color: #FFFFFF;
                font-weight: 700;
                font-size: 12px;
                border-radius: 6px;
                padding: 7px 14px;
                border: 1px solid #F59E0B;
            }
            QPushButton:hover {
                background: #F59E0B;
            }
        """)
        btn_auto_golden.setCursor(Qt.PointingHandCursor)
        btn_auto_golden.clicked.connect(self.set_next_best_golden_hour)
        row_rec.addWidget(btn_auto_golden)
        trend_layout.addLayout(row_rec)

        # Dòng 2: 5 nút khung giờ vàng đỉnh điểm trong ngày
        row_quick_golden = QHBoxLayout()
        row_quick_golden.setSpacing(6)

        btn_golden_2030 = QPushButton("🔥 20:30 (Siêu Hot Tối)")
        btn_golden_2030.setStyleSheet("background-color: #1E284A; color: #FCD34D; font-weight: 700; font-size: 11px; border-radius: 5px; padding: 6px 10px; border: 1px solid #3B82F6;")
        btn_golden_2030.setCursor(Qt.PointingHandCursor)
        btn_golden_2030.clicked.connect(lambda: self.set_quick_time(20, 30))

        btn_golden_1130 = QPushButton("☀️ 11:30 (Nghỉ Trưa)")
        btn_golden_1130.setStyleSheet("background-color: #1E284A; color: #93C5FD; font-weight: 600; font-size: 11px; border-radius: 5px; padding: 6px 10px; border: 1px solid #2B3654;")
        btn_golden_1130.setCursor(Qt.PointingHandCursor)
        btn_golden_1130.clicked.connect(lambda: self.set_quick_time(11, 30))

        btn_golden_1800 = QPushButton("🌇 18:00 (Tan Tầm)")
        btn_golden_1800.setStyleSheet("background-color: #1E284A; color: #93C5FD; font-weight: 600; font-size: 11px; border-radius: 5px; padding: 6px 10px; border: 1px solid #2B3654;")
        btn_golden_1800.setCursor(Qt.PointingHandCursor)
        btn_golden_1800.clicked.connect(lambda: self.set_quick_time(18, 0))

        btn_golden_0730 = QPushButton("🌅 07:30 (Sáng Sớm)")
        btn_golden_0730.setStyleSheet("background-color: #1E284A; color: #93C5FD; font-weight: 600; font-size: 11px; border-radius: 5px; padding: 6px 10px; border: 1px solid #2B3654;")
        btn_golden_0730.setCursor(Qt.PointingHandCursor)
        btn_golden_0730.clicked.connect(lambda: self.set_quick_time(7, 30))

        btn_golden_2215 = QPushButton("🌙 22:15 (Đêm Khuya)")
        btn_golden_2215.setStyleSheet("background-color: #1E284A; color: #93C5FD; font-weight: 600; font-size: 11px; border-radius: 5px; padding: 6px 10px; border: 1px solid #2B3654;")
        btn_golden_2215.setCursor(Qt.PointingHandCursor)
        btn_golden_2215.clicked.connect(lambda: self.set_quick_time(22, 15))

        row_quick_golden.addWidget(btn_golden_2030)
        row_quick_golden.addWidget(btn_golden_1130)
        row_quick_golden.addWidget(btn_golden_1800)
        row_quick_golden.addWidget(btn_golden_0730)
        row_quick_golden.addWidget(btn_golden_2215)
        trend_layout.addLayout(row_quick_golden)

        layout.addWidget(grp_trend)
        self.update_trend_analysis_text()

        # ==================== NHÓM 2: HẸN NGÀY VÀ GIỜ ĐĂNG ====================
        grp_time = QGroupBox("2. Hẹn Ngày & Giờ Đăng (Lịch Thông Thường)")
        grp_time.setStyleSheet("QGroupBox { font-weight: 600; color: #E1E1E6; border: 1px solid #2B2D3D; border-radius: 8px; margin-top: 10px; padding-top: 15px; } QGroupBox::title { subcontrol-origin: margin; left: 10px; padding: 0 5px; }")
        time_layout = QFormLayout(grp_time)
        time_layout.setSpacing(10)

        # Bộ chọn Ngày & Giờ tích hợp Calendar Popup
        self.dt_schedule = QDateTimeEdit()
        self.dt_schedule.setCalendarPopup(True)
        self.dt_schedule.setDisplayFormat("dd/MM/yyyy  HH:mm")
        
        # Mặc định: Giờ hiện tại + 2 phút để người dùng kịp lưu lịch
        default_time = QDateTime.currentDateTime().addSecs(120)
        self.dt_schedule.setDateTime(default_time)
        self.dt_schedule.setMinimumDateTime(QDateTime.currentDateTime())
        self.dt_schedule.setStyleSheet("""
            QDateTimeEdit {
                background-color: #0A0B10;
                color: #FFFFFF;
                border: 1px solid #2B3654;
                border-radius: 6px;
                padding: 6px 10px;
                font-size: 13px;
                font-weight: 600;
            }
            QDateTimeEdit:focus {
                border-color: #38BDF8;
            }
        """)
        time_layout.addRow("Giờ bắt đầu đăng:", self.dt_schedule)

        self.lbl_target_time_preview = QLabel()
        self.lbl_target_time_preview.setStyleSheet("color: #38BDF8; font-size: 11px; font-weight: 600; padding: 2px 0;")
        self.lbl_target_time_preview.setWordWrap(True)
        time_layout.addRow("", self.lbl_target_time_preview)
        self.dt_schedule.dateTimeChanged.connect(self.on_schedule_datetime_changed)

        # --- LỰA CHỌN CÁCH THỨC ĐĂNG VIDEO TIẾP THEO (TÍCH CHỌN NHIỀU CÁCH THỨC) ---
        self.cmb_post_mode = QComboBox()
        self.cmb_post_mode.setStyleSheet("""
            QComboBox {
                background-color: #0A0B10;
                color: #38BDF8;
                border: 1px solid #2B3654;
                border-radius: 6px;
                padding: 6px 10px;
                font-size: 12px;
                font-weight: 700;
            }
            QComboBox:hover {
                border-color: #38BDF8;
            }
            QComboBox QAbstractItemView {
                background-color: #101424;
                color: #FFFFFF;
                selection-background-color: #2563EB;
                selection-color: #FFFFFF;
                border: 1px solid #2B3654;
                padding: 4px;
            }
        """)
        self.cmb_post_mode.addItem("🌟 1. Theo Khung Giờ Vàng TikTok (07:30, 11:30, 18:00, 20:30 - Dễ cắn đề xuất nhất)", "golden_hours")
        self.cmb_post_mode.addItem("🛡️ 2. Giãn cách chống spam thuật toán (Giãn 30 - 60 phút - Khuyên dùng xây kênh)", "anti_spam")
        self.cmb_post_mode.addItem("🎬 3. Đăng liên hoàn giữ chân người xem (Series / Part 1, 2, 3... cách nhau 5 - 10 phút)", "series")
        self.cmb_post_mode.addItem("📅 4. Chia đều theo ngày (Mỗi ngày X video vào cùng khung giờ)", "daily")
        self.cmb_post_mode.addItem("⚡ 5. Khoảng cách cố định (1 phút, 5p, 15p, 30p, 60p...)", "fixed")
        self.cmb_post_mode.addItem("🎲 6. Giãn cách ngẫu nhiên (10 - 30 phút tùy chỉnh)", "random")
        self.cmb_post_mode.addItem("🚀 7. Đăng liên tục nối tiếp ngay lập tức (0 phút chờ)", "immediate")
        
        self.cmb_post_mode.currentIndexChanged.connect(self.on_post_mode_changed)
        time_layout.addRow("Cách thức đăng:", self.cmb_post_mode)

        # Khung chứa tùy chọn chi tiết ứng với từng cách thức đăng
        self.mode_container = QWidget()
        self.mode_container.setStyleSheet("background: transparent; border: none;")
        self.mode_layout = QVBoxLayout(self.mode_container)
        self.mode_layout.setContentsMargins(0, 0, 0, 0)
        self.mode_layout.setSpacing(8)

        # --- TÙY CHỌN 1: CỐ ĐỊNH (INTERVAL) ---
        self.box_fixed = QWidget()
        bf_layout = QVBoxLayout(self.box_fixed)
        bf_layout.setContentsMargins(0, 0, 0, 0)
        bf_layout.setSpacing(6)

        bf_row = QHBoxLayout()
        self.spn_interval = QSpinBox()
        self.spn_interval.setRange(1, 1440)
        self.spn_interval.setValue(1) # Mặc định đúng 1 phút
        self.spn_interval.setSuffix(" phút / video")
        self.spn_interval.setFixedWidth(130)
        self.spn_interval.setStyleSheet("""
            QSpinBox {
                background-color: #0A0B10;
                color: #38BDF8;
                border: 1px solid #2B3654;
                border-radius: 6px;
                padding: 6px 10px;
                font-size: 13px;
                font-weight: 700;
            }
        """)
        bf_row.addWidget(self.spn_interval)

        # Các nút bấm chọn nhanh thời gian
        btn_quick_1 = QPushButton("1 phút")
        btn_quick_5 = QPushButton("5 phút")
        btn_quick_15 = QPushButton("15 phút")
        btn_quick_30 = QPushButton("30 phút")
        btn_quick_60 = QPushButton("1 giờ")
        for b in [btn_quick_1, btn_quick_5, btn_quick_15, btn_quick_30, btn_quick_60]:
            b.setStyleSheet("background-color: #1E284A; color: #93C5FD; border: 1px solid #2B3654; border-radius: 4px; padding: 4px 8px; font-size: 11px; font-weight: 600;")
            b.setCursor(Qt.PointingHandCursor)
        btn_quick_1.clicked.connect(lambda: self.spn_interval.setValue(1))
        btn_quick_5.clicked.connect(lambda: self.spn_interval.setValue(5))
        btn_quick_15.clicked.connect(lambda: self.spn_interval.setValue(15))
        btn_quick_30.clicked.connect(lambda: self.spn_interval.setValue(30))
        btn_quick_60.clicked.connect(lambda: self.spn_interval.setValue(60))
        bf_row.addWidget(btn_quick_1)
        bf_row.addWidget(btn_quick_5)
        bf_row.addWidget(btn_quick_15)
        bf_row.addWidget(btn_quick_30)
        bf_row.addWidget(btn_quick_60)
        bf_row.addStretch()
        bf_layout.addLayout(bf_row)

        self.lbl_fixed_hint = QLabel("⚡ Video tiếp theo sẽ tự động đăng cách nhau đúng số phút bạn chọn ở trên.")
        self.lbl_fixed_hint.setStyleSheet("color: #38BDF8; font-size: 11px; font-weight: 600;")
        bf_layout.addWidget(self.lbl_fixed_hint)
        self.mode_layout.addWidget(self.box_fixed)

        # --- TÙY CHỌN 2: GIÃN CÁCH NGẪU NHIÊN (RANDOM) ---
        self.box_random = QWidget()
        br_layout = QVBoxLayout(self.box_random)
        br_layout.setContentsMargins(0, 0, 0, 0)
        br_layout.setSpacing(6)
        br_row = QHBoxLayout()
        br_lbl1 = QLabel("Giãn cách từ:")
        br_lbl1.setStyleSheet("color: #FFFFFF; font-size: 12px; font-weight: 600;")
        self.spn_rand_min = QSpinBox()
        self.spn_rand_min.setRange(1, 720)
        self.spn_rand_min.setValue(10)
        self.spn_rand_min.setSuffix(" phút")
        self.spn_rand_min.setStyleSheet("background-color: #0A0B10; color: #F59E0B; border: 1px solid #D97706; border-radius: 6px; padding: 5px; font-weight: 700;")
        
        br_lbl2 = QLabel("đến:")
        br_lbl2.setStyleSheet("color: #FFFFFF; font-size: 12px; font-weight: 600;")
        self.spn_rand_max = QSpinBox()
        self.spn_rand_max.setRange(2, 1440)
        self.spn_rand_max.setValue(30)
        self.spn_rand_max.setSuffix(" phút")
        self.spn_rand_max.setStyleSheet("background-color: #0A0B10; color: #F59E0B; border: 1px solid #D97706; border-radius: 6px; padding: 5px; font-weight: 700;")

        br_row.addWidget(br_lbl1)
        br_row.addWidget(self.spn_rand_min)
        br_row.addWidget(br_lbl2)
        br_row.addWidget(self.spn_rand_max)
        br_row.addStretch()
        br_layout.addLayout(br_row)
        lbl_rand_hint = QLabel("🎲 Mỗi video tiếp theo sẽ được giãn cách ngẫu nhiên trong khoảng này để hành vi như người thật.")
        lbl_rand_hint.setStyleSheet("color: #F59E0B; font-size: 11px; font-weight: 600;")
        br_layout.addWidget(lbl_rand_hint)
        self.mode_layout.addWidget(self.box_random)

        # --- TÙY CHỌN 3: CHIA THEO NGÀY (DAILY BATCH) ---
        self.box_daily = QWidget()
        bd_layout = QVBoxLayout(self.box_daily)
        bd_layout.setContentsMargins(0, 0, 0, 0)
        bd_layout.setSpacing(6)
        bd_row = QHBoxLayout()
        bd_lbl1 = QLabel("Mỗi ngày đăng:")
        bd_lbl1.setStyleSheet("color: #FFFFFF; font-size: 12px; font-weight: 600;")
        self.spn_daily_vids = QSpinBox()
        self.spn_daily_vids.setRange(1, 50)
        self.spn_daily_vids.setValue(2)
        self.spn_daily_vids.setSuffix(" video / ngày")
        self.spn_daily_vids.setStyleSheet("background-color: #0A0B10; color: #10B981; border: 1px solid #059669; border-radius: 6px; padding: 5px; font-weight: 700;")
        
        bd_lbl2 = QLabel("Cách nhau:")
        bd_lbl2.setStyleSheet("color: #FFFFFF; font-size: 12px; font-weight: 600;")
        self.spn_daily_int = QSpinBox()
        self.spn_daily_int.setRange(1, 720)
        self.spn_daily_int.setValue(30)
        self.spn_daily_int.setSuffix(" phút")
        self.spn_daily_int.setStyleSheet("background-color: #0A0B10; color: #10B981; border: 1px solid #059669; border-radius: 6px; padding: 5px; font-weight: 700;")

        bd_row.addWidget(bd_lbl1)
        bd_row.addWidget(self.spn_daily_vids)
        bd_row.addWidget(bd_lbl2)
        bd_row.addWidget(self.spn_daily_int)
        bd_row.addStretch()
        bd_layout.addLayout(bd_row)
        lbl_daily_hint = QLabel("📅 Tự động chia đều số video sang các ngày kế tiếp (bắt đầu cùng khung giờ mỗi ngày).")
        lbl_daily_hint.setStyleSheet("color: #10B981; font-size: 11px; font-weight: 600;")
        bd_layout.addWidget(lbl_daily_hint)
        self.mode_layout.addWidget(self.box_daily)

        # --- TÙY CHỌN 4: KHUNG GIỜ VÀNG (GOLDEN HOURS) ---
        self.box_golden = QWidget()
        bg_layout = QVBoxLayout(self.box_golden)
        bg_layout.setContentsMargins(0, 0, 0, 0)
        bg_layout.setSpacing(6)
        bg_row = QHBoxLayout()
        self.chk_gold_morning = QCheckBox("07:00 (Sáng)")
        self.chk_gold_morning.setChecked(True)
        self.chk_gold_noon = QCheckBox("11:30 (Trưa)")
        self.chk_gold_noon.setChecked(True)
        self.chk_gold_afternoon = QCheckBox("18:00 (Chiều)")
        self.chk_gold_afternoon.setChecked(True)
        self.chk_gold_night = QCheckBox("20:30 (Tối)")
        self.chk_gold_night.setChecked(True)
        for c in [self.chk_gold_morning, self.chk_gold_noon, self.chk_gold_afternoon, self.chk_gold_night]:
            c.setStyleSheet("color: #FCD34D; font-weight: 600; font-size: 11px;")
            bg_row.addWidget(c)
        bg_row.addStretch()
        bg_layout.addLayout(bg_row)
        lbl_gold_hint = QLabel("🌟 Tự động xếp lần lượt từng video vào các khung giờ vàng được tích chọn ở trên.")
        lbl_gold_hint.setStyleSheet("color: #FCD34D; font-size: 11px; font-weight: 600;")
        bg_layout.addWidget(lbl_gold_hint)
        self.mode_layout.addWidget(self.box_golden)

        # --- TÙY CHỌN 2: GIÃN CÁCH CHỐNG SPAM (ANTI-SPAM) ---
        self.box_antispam = QWidget()
        ba_layout = QVBoxLayout(self.box_antispam)
        ba_layout.setContentsMargins(0, 0, 0, 0)
        lbl_as_hint = QLabel("🛡️ <b>Chiến lược chống bóp tương tác:</b> Tự động giãn cách <b>30 - 60 phút / video</b> kèm độ lệch ngẫu nhiên. Giúp thuật toán TikTok phân phối trọn vẹn từng video và bảo vệ kênh không bị đánh giá là bot/spam.")
        lbl_as_hint.setStyleSheet("color: #38BDF8; font-size: 11px; font-weight: 600; line-height: 1.4;")
        lbl_as_hint.setWordWrap(True)
        ba_layout.addWidget(lbl_as_hint)
        self.mode_layout.addWidget(self.box_antispam)

        # --- TÙY CHỌN 3: SERIES BINGE-WATCH (PART 1, 2, 3...) ---
        self.box_series = QWidget()
        bs_layout = QVBoxLayout(self.box_series)
        bs_layout.setContentsMargins(0, 0, 0, 0)
        lbl_sr_hint = QLabel("🎬 <b>Chiến lược xem liền mạch (Series Binge-Watch):</b> Dành riêng cho chuỗi video cắt ngắn (Part 1, Part 2, Part 3...). Đăng cách nhau <b>5 - 10 phút</b>, người xem vừa xem xong phần 1 sẽ bấm ngay vào trang cá nhân để xem tiếp phần 2, kéo lượt Follow kênh tăng vọt!")
        lbl_sr_hint.setStyleSheet("color: #C084FC; font-size: 11px; font-weight: 600; line-height: 1.4;")
        lbl_sr_hint.setWordWrap(True)
        bs_layout.addWidget(lbl_sr_hint)
        self.mode_layout.addWidget(self.box_series)

        # --- TÙY CHỌN 7: LIÊN TỤC NGAY LẬP TỨC (IMMEDIATE) ---
        self.box_immediate = QWidget()
        bi_layout = QVBoxLayout(self.box_immediate)
        bi_layout.setContentsMargins(0, 0, 0, 0)
        lbl_immed_hint = QLabel("🚀 Toàn bộ video sẽ được xếp hàng và tự động tải lên liên tiếp ngay sau khi video trước hoàn tất.")
        lbl_immed_hint.setStyleSheet("color: #EC4899; font-size: 11px; font-weight: 600;")
        bi_layout.addWidget(lbl_immed_hint)
        self.mode_layout.addWidget(self.box_immediate)

        time_layout.addRow("Cấu hình chi tiết:", self.mode_container)

        lbl_hint_time = QLabel("💡 Bạn có thể nhấp vào mũi tên để mở bảng Lịch xem cả tháng, và chọn giờ/phút tùy ý.")
        lbl_hint_time.setStyleSheet("color: #94A3B8; font-size: 11px;")
        time_layout.addRow("", lbl_hint_time)

        layout.addWidget(grp_time)

        # ==================== NHÓM 3: CAPTION & HASHTAGS ====================
        grp_content = QGroupBox("3. Nội Dung Bài Đăng")
        grp_content.setStyleSheet("QGroupBox { font-weight: 600; color: #E1E1E6; border: 1px solid #2B2D3D; border-radius: 8px; margin-top: 10px; padding-top: 15px; } QGroupBox::title { subcontrol-origin: margin; left: 10px; padding: 0 5px; }")
        c_layout = QFormLayout(grp_content)
        c_layout.setSpacing(10)

        self.txt_caption = QLineEdit()
        self.txt_caption.setPlaceholderText("Tiêu đề video (mặc định lấy theo tên file từng video)...")
        c_layout.addRow("Caption:", self.txt_caption)

        self.txt_hashtags = QLineEdit()
        self.txt_hashtags.setPlaceholderText("#fyp #trending #xuhuong (tùy chọn)")
        c_layout.addRow("Hashtags:", self.txt_hashtags)

        # Gợi ý hashtag xu hướng thịnh hành 1-click
        v_tags = QVBoxLayout()
        v_tags.setSpacing(6)
        lbl_quick_tag = QLabel("Gợi ý tag xu hướng thịnh hành (nhấp để thêm nhanh):")
        lbl_quick_tag.setStyleSheet("color: #94A3B8; font-size: 11px; font-weight: 600;")
        v_tags.addWidget(lbl_quick_tag)

        row_tags = QHBoxLayout()
        row_tags.setSpacing(8)

        tag_sets = [
            ("🔥 Xu Hướng VN", "#fyp #xuhuong #trending #viral"),
            ("🌍 Xu Hướng Ngoại", "#fyp #foryou #viral #trending"),
            ("🎬 Phim & Giải Trí", "#storytime #entertainment #funny #film"),
            ("💡 Đời Sống / Mẹo", "#learnontiktok #meohay #lifehacks")
        ]
        for title, tags in tag_sets:
            btn_tag = QPushButton(f"{title}")
            btn_tag.setStyleSheet("""
                QPushButton {
                    background-color: #10162A;
                    color: #38BDF8;
                    border: 1px solid #2B3654;
                    border-radius: 5px;
                    padding: 5px 10px;
                    font-size: 11px;
                    font-weight: 600;
                }
                QPushButton:hover {
                    background-color: #1E284A;
                    border-color: #38BDF8;
                }
            """)
            btn_tag.setCursor(Qt.PointingHandCursor)
            btn_tag.clicked.connect(lambda checked=False, t=tags: self.append_hashtags(t))
            row_tags.addWidget(btn_tag)
        row_tags.addStretch()
        v_tags.addLayout(row_tags)
        c_layout.addRow("", v_tags)

        # Checkbox tùy chọn
        self.chk_headless = QCheckBox("Tự động đăng ngầm (Không mở cửa sổ web lên màn hình)")
        self.chk_headless.setChecked(True)
        self.chk_headless.setStyleSheet("color: #FFFFFF; font-weight: 500;")
        c_layout.addRow("", self.chk_headless)

        self.chk_notify = QCheckBox("Gửi thông báo và phát chuông về máy tính khi đăng xong")
        self.chk_notify.setChecked(True)
        self.chk_notify.setStyleSheet("color: #FFFFFF; font-weight: 500;")
        c_layout.addRow("", self.chk_notify)

        self.chk_autostart = QCheckBox("🛡️ Giữ đồng nhất IP quốc gia & Tự chạy ngầm cùng Windows khi mở máy")
        self.chk_autostart.setChecked(True)
        self.chk_autostart.setStyleSheet("color: #38BDF8; font-weight: 600;")
        self.chk_autostart.setToolTip("Dù tắt máy tính, khi bạn bật máy lên lại, Tool sẽ tự động quét các video đã đến giờ, tự chuyển đúng IP nước đó và đăng tải bình thường.")
        c_layout.addRow("", self.chk_autostart)

        layout.addWidget(grp_content)

        scroll.setWidget(scroll_widget)
        main_layout.addWidget(scroll, 1)

        # ==================== NÚT HÀNH ĐỘNG CỐ ĐỊNH Ở DƯỚI (ALWAYS VISIBLE) ====================
        btn_box = QFrame()
        btn_box.setStyleSheet("border-top: 1px solid #1E293B; padding-top: 10px; background: transparent;")
        btn_layout = QHBoxLayout(btn_box)
        btn_layout.setContentsMargins(0, 4, 0, 0)
        btn_layout.addStretch()

        self.btn_cancel = QPushButton("Hủy bỏ")
        self.btn_cancel.setProperty("class", "btn-secondary")
        self.btn_cancel.setFixedWidth(120)
        self.btn_cancel.setFixedHeight(38)
        self.btn_cancel.clicked.connect(self.reject)
        btn_layout.addWidget(self.btn_cancel)

        self.btn_save = QPushButton("💾 Lưu Lịch Hẹn Đăng")
        self.btn_save.setProperty("class", "btn-primary")
        self.btn_save.setFixedWidth(200)
        self.btn_save.setFixedHeight(38)
        self.btn_save.setCursor(Qt.PointingHandCursor)
        self.btn_save.clicked.connect(self.save_schedule)
        btn_layout.addWidget(self.btn_save)

        main_layout.addWidget(btn_box)

        self.on_post_mode_changed()

        # Nếu có video truyền vào trước
        if self.selected_video_paths and os.path.isfile(self.selected_video_paths[0]):
            self.set_videos(self.selected_video_paths)
        else:
            self.on_channel_selected_auto_load_videos()

    def get_current_target_profile(self) -> dict:
        cid = self.cmb_channel.currentData()
        if cid:
            ch = db.get_channel(cid)
            if ch:
                from core.vpn_regions import get_channel_region_profile
                return get_channel_region_profile(ch)
        from core.vpn_regions import get_region_profile, get_country_display_name
        reg = db.get_setting("global_vpn_region", "philippines")
        prof = dict(get_region_profile(reg))
        prof["country_name"] = get_country_display_name(reg)
        return prof

    def on_schedule_datetime_changed(self):
        dt_val = self.dt_schedule.dateTime()
        local_py_dt = datetime(
            dt_val.date().year(), dt_val.date().month(), dt_val.date().day(),
            dt_val.time().hour(), dt_val.time().minute(), 0
        )
        prof = self.get_current_target_profile()
        from core.vpn_regions import convert_local_to_target_time
        try:
            tgt_dt = convert_local_to_target_time(local_py_dt, prof["timezone_id"])
            tz_abbr = tgt_dt.strftime("%Z")
            cnt_name = prof.get("country_name") or prof.get("country", "Nước fake IP")
            if hasattr(self, "lbl_target_time_preview"):
                self.lbl_target_time_preview.setText(
                    f"🌍 <b>Giờ tại nước mục tiêu ({cnt_name}):</b> "
                    f"<span style='color: #FCD34D;'><b>{tgt_dt.strftime('%H:%M - %d/%m/%Y')} ({tz_abbr})</b></span> "
                    f"➔ <i>(Giờ máy tính VN: {local_py_dt.strftime('%H:%M - %d/%m')})</i>"
                )
        except Exception:
            pass

    def on_channel_selected_auto_load_videos(self):
        cid = self.cmb_channel.currentData()
        if not cid:
            return
        ch = db.get_channel(cid)
        if not ch:
            return
        self.update_trend_analysis_text()
        self.on_schedule_datetime_changed()

        vid_cfg = ch.get("video_folder", "")
        if vid_cfg and not self.selected_video_paths:
            v_exts = ('.mp4', '.mov', '.mkv', '.webm', '.avi', '.flv', '.wmv', '.m4v', '.ts', '.3gp')
            loaded_files = []
            if ";" in vid_cfg:
                loaded_files = [p for p in vid_cfg.split(";") if os.path.isfile(p)]
            elif os.path.isdir(vid_cfg):
                for root, _, fnames in os.walk(vid_cfg):
                    for f in sorted(fnames):
                        if f.lower().endswith(v_exts):
                            loaded_files.append(os.path.join(root, f))
            elif os.path.isfile(vid_cfg):
                loaded_files = [vid_cfg]

            if loaded_files:
                self.set_videos(loaded_files)

    def on_post_mode_changed(self):
        mode = self.cmb_post_mode.currentData()
        self.box_fixed.setVisible(mode == "fixed")
        self.box_random.setVisible(mode == "random")
        self.box_daily.setVisible(mode == "daily")
        self.box_golden.setVisible(mode == "golden_hours")
        self.box_immediate.setVisible(mode == "immediate")
        self.box_antispam.setVisible(mode == "anti_spam")
        self.box_series.setVisible(mode == "series")
        if self.selected_video_paths and hasattr(self, "txt_caption"):
            self.set_videos(self.selected_video_paths)

    def append_hashtags(self, tags: str):
        cur = self.txt_hashtags.text().strip()
        if cur:
            self.txt_hashtags.setText(f"{cur} {tags}")
        else:
            self.txt_hashtags.setText(tags)

    def update_trend_analysis_text(self):
        prof = self.get_current_target_profile()
        tz_id = prof["timezone_id"]
        from core.vpn_regions import convert_target_golden_to_local, convert_local_to_target_time, get_safe_tzinfo
        target_tz = get_safe_tzinfo(tz_id)

        now_target = datetime.now(target_tz)
        now_vn = datetime.now()
        th = now_target.hour
        tm = now_target.minute

        if th < 7 or (th == 7 and tm < 30):
            next_gold = "07:30 (Sáng đầu ngày)"
            target_h, target_m = 7, 30
            reason = "Khán giả nước sở tại vừa thức dậy, bắt đầu lướt tin tức. Cạnh tranh vừa phải, video dễ cắn đề xuất sớm."
        elif th < 11 or (th == 11 and tm < 30):
            next_gold = "11:30 (Giờ nghỉ trưa)"
            target_h, target_m = 11, 30
            reason = "Giờ nghỉ trưa của dân văn phòng & học sinh sinh viên tại nước sở tại. Tỷ lệ xem hết video (Watch Time) cao."
        elif th < 18:
            next_gold = "18:00 (Chiều tan tầm)"
            target_h, target_m = 18, 0
            reason = "Mọi người tan làm, tan trường, nhu cầu giải trí tăng mạnh. Lượng tương tác like & bình luận bùng nổ."
        elif th < 20 or (th == 20 and tm < 30):
            next_gold = "20:30 (SIÊU GIỜ VÀNG TỐI - HOT NHẤT 24H ⭐)"
            target_h, target_m = 20, 30
            reason = "Lưu lượng truy cập toàn mạng tại nước sở tại đạt đỉnh điểm (Peak Traffic). Thuật toán FYP mở rộng mạnh nhất."
        elif th < 22 or (th == 22 and tm < 15):
            next_gold = "22:15 (Đêm khuya viral)"
            target_h, target_m = 22, 15
            reason = "Khung giờ vàng của cú đêm tại nước sở tại. Đặc biệt hiệu quả với clip kể chuyện, giải trí, kịch tính."
        else:
            next_gold = "07:30 sáng mai"
            target_h, target_m = 7, 30
            reason = "Bắt đầu ngày mới tại nước sở tại. Thuật toán sẽ tiếp tục đẩy luồng phân phối vào buổi trưa."

        tgt_dt, local_vn_dt = convert_target_golden_to_local(target_h, target_m, tz_id)
        tz_abbr = now_target.strftime("%Z")
        country_title = prof.get("country_name") or prof.get("country", "Quốc tế")

        self.lbl_trend_analysis.setText(
            f"📊 <b>Phân tích thuật toán TikTok ({country_title} — Múi giờ {tz_id}):</b><br>"
            f"• Giờ hiện tại ở nước đó: <span style='color: #38BDF8;'><b>{now_target.strftime('%H:%M')} ({tz_abbr})</b></span> "
            f"<i>(Giờ máy tính VN: {now_vn.strftime('%H:%M')})</i><br>"
            f"• Khung giờ vàng sắp tới đề xuất: <span style='color: #F59E0B;'><b>{next_gold}</b></span> "
            f"➔ Tương ứng máy tính VN: <span style='color: #10B981;'><b>{local_vn_dt.strftime('%H:%M ngày %d/%m')}</b></span><br>"
            f"💡 <i>{reason}</i>"
        )
        self._next_gold_target = (target_h, target_m)

    def set_next_best_golden_hour(self):
        self.update_trend_analysis_text()
        th, tm = getattr(self, "_next_gold_target", (20, 30))
        self.set_quick_time(th, tm)

    def set_quick_time(self, hour: int, minute: int):
        prof = self.get_current_target_profile()
        from core.vpn_regions import convert_target_golden_to_local
        tgt_dt, local_vn_dt = convert_target_golden_to_local(hour, minute, prof["timezone_id"])
        qdt = QDateTime(
            QDate(local_vn_dt.year, local_vn_dt.month, local_vn_dt.day),
            QTime(local_vn_dt.hour, local_vn_dt.minute, 0)
        )
        self.dt_schedule.setDateTime(qdt)
        self.on_schedule_datetime_changed()

    def browse_video(self):
        files, _ = QFileDialog.getOpenFileNames(
            self, "Chọn Video Đăng (Có thể chọn 1 hoặc nhiều video cùng lúc)", "", "Video Files (*.mp4 *.mov *.avi *.mkv *.webm);;All Files (*)"
        )
        if files:
            self.set_videos(files)

    def set_videos(self, file_paths: list):
        self.selected_video_paths = [p for p in file_paths if os.path.isfile(p)]
        if not self.selected_video_paths:
            return

        if len(self.selected_video_paths) == 1:
            p = self.selected_video_paths[0]
            filename = os.path.basename(p)
            self.lbl_video_info.setText(f"🎬 {filename}")
            self.lbl_video_info.setStyleSheet("color: #38BDF8; font-weight: 600; font-size: 12px;")
            if hasattr(self, "txt_caption") and not self.txt_caption.text().strip():
                base_name = os.path.splitext(filename)[0]
                self.txt_caption.setText(base_name)
        else:
            count = len(self.selected_video_paths)
            mode_raw = self.cmb_post_mode.currentText()
            mode_text = mode_raw.split(".")[1].split("(")[0].strip() if "." in mode_raw else "Theo cấu hình đã chọn"
            self.lbl_video_info.setText(f"🎬 Đã chọn {count} video (Cách thức: {mode_text})")
            self.lbl_video_info.setStyleSheet("color: #22C55E; font-weight: 700; font-size: 12px;")
            if hasattr(self, "txt_caption") and not self.txt_caption.text().strip():
                self.txt_caption.setPlaceholderText(f"Tự động lấy theo tên file từng video cho {count} video")

    def save_schedule(self):
        channel_id = self.cmb_channel.currentData()
        if not channel_id:
            QMessageBox.warning(self, "Chưa chọn kênh", "Vui lòng chọn kênh TikTok bạn muốn đăng video!")
            return

        if not self.selected_video_paths:
            QMessageBox.warning(self, "Chưa chọn video", "Vui lòng chọn ít nhất 1 file video cần hẹn giờ đăng!")
            return

        # Thời gian bắt đầu
        dt_val = self.dt_schedule.dateTime()
        start_py_dt = datetime(
            dt_val.date().year(), dt_val.date().month(), dt_val.date().day(),
            dt_val.time().hour(), dt_val.time().minute(), 0
        )
        user_caption = self.txt_caption.text().strip()
        hashtags = self.txt_hashtags.text().strip()
        mode = self.cmb_post_mode.currentData()
        total_vids = len(self.selected_video_paths)

        # Tính toán danh sách thời gian đăng cho từng video theo cách thức người dùng chọn
        scheduled_times = []
        mode_desc = ""

        if mode == "fixed":
            interval_mins = self.spn_interval.value()
            for idx in range(total_vids):
                post_dt = start_py_dt + timedelta(minutes=idx * interval_mins)
                scheduled_times.append(post_dt)
            mode_desc = f"Khoảng cách cố định: <b>{interval_mins} phút / video</b>"

        elif mode == "random":
            r_min = min(self.spn_rand_min.value(), self.spn_rand_max.value())
            r_max = max(self.spn_rand_min.value(), self.spn_rand_max.value())
            curr_dt = start_py_dt
            for idx in range(total_vids):
                if idx == 0:
                    scheduled_times.append(curr_dt)
                else:
                    curr_dt += timedelta(minutes=random.randint(r_min, r_max))
                    scheduled_times.append(curr_dt)
            mode_desc = f"Giãn cách ngẫu nhiên từ <b>{r_min} đến {r_max} phút / video</b>"

        elif mode == "daily":
            vids_per_day = self.spn_daily_vids.value()
            d_int = self.spn_daily_int.value()
            for idx in range(total_vids):
                day_offset = idx // vids_per_day
                slot = idx % vids_per_day
                post_dt = start_py_dt + timedelta(days=day_offset, minutes=slot * d_int)
                scheduled_times.append(post_dt)
            mode_desc = f"Chia theo ngày: <b>{vids_per_day} video/ngày</b> (cách nhau <b>{d_int} phút</b>)"

        elif mode == "anti_spam":
            curr_dt = start_py_dt
            for idx in range(total_vids):
                if idx == 0:
                    scheduled_times.append(curr_dt)
                else:
                    curr_dt += timedelta(minutes=random.randint(35, 60))
                    scheduled_times.append(curr_dt)
            mode_desc = "Giãn cách chống spam (35 - 60 phút / video)"

        elif mode == "series":
            for idx in range(total_vids):
                post_dt = start_py_dt + timedelta(minutes=idx * 7)
                scheduled_times.append(post_dt)
            mode_desc = "Đăng liên hoàn giữ chân người xem (7 phút / phần)"

        elif mode == "golden_hours":
            prof = self.get_current_target_profile()
            target_tz_id = prof["timezone_id"]
            from core.vpn_regions import convert_local_to_target_time
            
            try:
                from zoneinfo import ZoneInfo
                target_tz = ZoneInfo(target_tz_id)
            except Exception:
                import pytz
                target_tz = pytz.timezone(target_tz_id)

            start_in_target = convert_local_to_target_time(start_py_dt, target_tz_id)
            curr_target_date = start_in_target.date()

            golden_slots = []
            if self.chk_gold_morning.isChecked(): golden_slots.append((7, 30))
            if self.chk_gold_noon.isChecked(): golden_slots.append((11, 30))
            if self.chk_gold_afternoon.isChecked(): golden_slots.append((18, 0))
            if self.chk_gold_night.isChecked(): golden_slots.append((20, 30))
            if not golden_slots:
                golden_slots = [(7, 30), (11, 30), (18, 0), (20, 30)]

            found_slot = 0
            for s_idx, (gh, gm) in enumerate(golden_slots):
                cand = datetime(curr_target_date.year, curr_target_date.month, curr_target_date.day, gh, gm, 0, tzinfo=target_tz)
                if cand >= start_in_target:
                    found_slot = s_idx
                    break
            else:
                curr_target_date += timedelta(days=1)
                found_slot = 0

            local_tz = datetime.now().astimezone().tzinfo
            for idx in range(total_vids):
                gh, gm = golden_slots[found_slot]
                slot_target_dt = datetime(curr_target_date.year, curr_target_date.month, curr_target_date.day, gh, gm, 0, tzinfo=target_tz)
                post_loc = slot_target_dt.astimezone(local_tz).replace(tzinfo=None)
                scheduled_times.append(post_loc)
                found_slot += 1
                if found_slot >= len(golden_slots):
                    found_slot = 0
                    curr_target_date += timedelta(days=1)

            slot_names = [f"{h:02d}:{m:02d}" for h, m in golden_slots]
            cnt_name = prof.get("country_name") or prof.get("country", "Nước mục tiêu")
            mode_desc = f"Khung giờ vàng ({cnt_name}): <b>{', '.join(slot_names)}</b>"

        elif mode == "immediate":
            for idx in range(total_vids):
                post_dt = start_py_dt + timedelta(seconds=idx * 20)
                scheduled_times.append(post_dt)
            mode_desc = "Đăng liên tục nối đuôi ngay lập tức"

        else:
            for idx in range(total_vids):
                scheduled_times.append(start_py_dt + timedelta(minutes=idx))
            mode_desc = "Mặc định"

        # Lấy vùng VPN của kênh (hoặc vùng toàn cục) để ghim vĩnh viễn cho từng video trong lịch này (ĐỒNG NHẤT IP 100%)
        ch_info = db.get_channel(channel_id) or {}
        current_vpn_region = (ch_info.get("vpn_region") or "").strip() or db.get_setting("global_vpn_region", "philippines")
        current_country_name = (ch_info.get("target_country") or "").strip() or db.get_setting("global_vpn_country_name", "Philippines")

        # Lưu từng lịch vào cơ sở dữ liệu (Tự động lọc trùng lặp tiêu đề đã đăng thành công)
        saved_count = 0
        skipped_duplicate_titles = []

        for idx, v_path in enumerate(self.selected_video_paths):
            post_dt = scheduled_times[idx]
            scheduled_str = post_dt.strftime("%Y-%m-%d %H:%M:%S")

            filename = os.path.basename(v_path)
            if total_vids == 1 and user_caption:
                caption = user_caption
            else:
                caption = user_caption if user_caption else os.path.splitext(filename)[0]

            # KIỂM TRA QUY TẮC: 1 video 1 tiêu đề chỉ đăng 1 lần thành công trên mỗi kênh
            if db.is_video_already_posted(channel_id=channel_id, video_title=caption, video_path=v_path):
                skipped_duplicate_titles.append(caption)
                continue

            saved_count += 1
            # TỰ ĐỘNG CHUYỂN VIDEO VÀO KHO CỦA TOOL ĐỂ KHI XÓA FILE GỐC TRÊN MÁY TÍNH KHÔNG BỊ ẢNH HƯỞNG
            vault_path = video_vault.import_video_to_vault(v_path, title=caption)
            file_sz = os.path.getsize(vault_path) if os.path.exists(vault_path) else 0
            video_id = db.add_video(
                title=caption,
                file_path=vault_path,
                file_size=file_sz,
                channel_id=channel_id,
                description=hashtags
            )

            db.add_schedule(
                channel_id=channel_id,
                video_id=video_id,
                scheduled_time=scheduled_str,
                caption=caption,
                hashtags=hashtags,
                vpn_region=current_vpn_region,
                target_country=current_country_name,
                upload_mode="local"
            )

        if saved_count == 0 and skipped_duplicate_titles:
            dup_list = "<br>• ".join(skipped_duplicate_titles[:4])
            QMessageBox.warning(
                self,
                "Bỏ Qua Vì Đã Đăng Thành Công",
                f"⚠️ Kênh này đã từng đăng thành công các video có tiêu đề dưới đây trước đó:<br><br>"
                f"• {dup_list}<br><br>"
                f"👉 <b>Quy tắc hệ thống:</b> 1 video 1 tiêu đề chỉ đăng 1 lần thành công duy nhất trên mỗi kênh để tránh spam tài khoản!"
            )
            return

        if hasattr(self, "chk_autostart") and self.chk_autostart.isChecked():
            try:
                from core.startup_manager import enable_windows_startup
                enable_windows_startup(True)
            except Exception:
                pass

        # Đảm bảo dịch vụ hẹn giờ chạy ngầm
        if not scheduler_service.is_running:
            scheduler_service.start()

        display_start = scheduled_times[0].strftime("%d/%m/%Y %H:%M")
        display_end = scheduled_times[-1].strftime("%d/%m/%Y %H:%M")

        if total_vids == 1:
            QMessageBox.information(
                self,
                "Hẹn Lịch Thành Công",
                f"✅ Đã lưu lịch hẹn đăng video thành công!<br><br>"
                f"🎬 <b>Kênh:</b> {self.cmb_channel.currentText()}<br>"
                f"📅 <b>Thời gian đăng:</b> {display_start}<br>"
                f"📝 <b>Caption:</b> {user_caption or os.path.splitext(os.path.basename(self.selected_video_paths[0]))[0]}<br><br>"
                f"<i>Tool sẽ tự động đăng ngầm vào đúng thời điểm trên và gửi thông báo về máy tính khi hoàn tất.</i>"
            )
        else:
            QMessageBox.information(
                self,
                "Hẹn Lịch Hàng Loạt Thành Công",
                f"✅ Đã lưu thành công <b>{total_vids}</b> lịch hẹn đăng video!<br><br>"
                f"🎬 <b>Kênh:</b> {self.cmb_channel.currentText()}<br>"
                f"🎯 <b>Cách thức đăng:</b> {mode_desc}<br>"
                f"⏰ <b>Bắt đầu từ:</b> {display_start}<br>"
                f"🏁 <b>Dự kiến hoàn thành:</b> {display_end}<br><br>"
                f"<i>Tool sẽ tự động đăng ngầm theo đúng lịch trình bạn chọn và gửi thông báo về máy tính.</i>"
            )

        self.accept()

