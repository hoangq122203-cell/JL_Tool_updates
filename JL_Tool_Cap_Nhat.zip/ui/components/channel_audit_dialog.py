# -*- coding: utf-8 -*-
"""
CHANNEL HEALTH & AI AUDIT DIALOG
Hộp thoại chi tiết khám sức khỏe kênh, thống kê view/follower và đưa ra chiến lược AI.
"""

from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QFrame, QProgressBar, QTextBrowser, QApplication, QCheckBox
)
from PySide6.QtCore import Qt, QThread, Signal
from PySide6.QtGui import QColor, QFont
from typing import Dict, Any

class AuditWorker(QThread):
    finished = Signal(dict)
    log_msg = Signal(str)

    def __init__(self, channel_data: Dict[str, Any]):
        super().__init__()
        self.channel_data = channel_data

    def run(self):
        from core.channel_auditor import analyze_channel_health
        res = analyze_channel_health(self.channel_data, headless=True, log_func=self.log_msg.emit)
        self.finished.emit(res)

class ChannelAuditDialog(QDialog):
    def __init__(self, channel_data: Dict[str, Any], parent=None):
        super().__init__(parent)
        self.channel_data = channel_data
        self.setWindowTitle(f"🩺 Bác Sĩ Kênh & Chiến Lược 10K Follow — @{channel_data.get('name', '')}")
        self.resize(780, 690)
        self.setMinimumSize(740, 650)
        self.setStyleSheet("QDialog { background-color: #0B1120; color: #F8FAFC; }")
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 20, 24, 20)
        layout.setSpacing(14)

        # Header Title
        title_box = QHBoxLayout()
        lbl_icon = QLabel("🩺")
        lbl_icon.setStyleSheet("font-size: 32px;")
        title_box.addWidget(lbl_icon)

        t_sub = QVBoxLayout()
        lbl_t = QLabel(f"Bác Sĩ Kênh AI & Lộ Trình 10K Follow: @{self.channel_data.get('name', '')}")
        lbl_t.setStyleSheet("color: #FFFFFF; font-size: 18px; font-weight: 800;")
        lbl_s = QLabel("Chẩn đoán sức khỏe, cơ chế nuôi chuẩn Mobile và chiến lược đưa kênh lên 10.000 Follower bật kiếm tiền")
        lbl_s.setStyleSheet("color: #38BDF8; font-size: 12px; font-weight: 500;")
        t_sub.addWidget(lbl_t)
        t_sub.addWidget(lbl_s)
        title_box.addLayout(t_sub)
        title_box.addStretch()

        layout.addLayout(title_box)

        # Thanh điểm sức khỏe (Health Score Gauge)
        gauge_frame = QFrame()
        gauge_frame.setObjectName("gauge_frame")
        gauge_frame.setStyleSheet("""
            QFrame#gauge_frame {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #1E293B, stop:1 #0F172A);
                border: 1px solid #334155;
                border-radius: 12px;
            }
        """)
        gauge_layout = QVBoxLayout(gauge_frame)
        gauge_layout.setContentsMargins(14, 14, 14, 14)
        gauge_layout.setSpacing(10)

        row_score = QHBoxLayout()
        self.lbl_score_title = QLabel("ĐIỂM SỨC KHỎE KÊNH:")
        self.lbl_score_title.setStyleSheet("color: #94A3B8; font-weight: 700; font-size: 13px;")
        self.lbl_score_val = QLabel("Đang phân tích...")
        self.lbl_score_val.setStyleSheet("color: #22C55E; font-size: 20px; font-weight: 900;")
        row_score.addWidget(self.lbl_score_title)
        row_score.addStretch()
        row_score.addWidget(self.lbl_score_val)
        gauge_layout.addLayout(row_score)

        self.progress_score = QProgressBar()
        self.progress_score.setRange(0, 100)
        self.progress_score.setValue(0)
        self.progress_score.setTextVisible(False)
        self.progress_score.setFixedHeight(10)
        self.progress_score.setStyleSheet("""
            QProgressBar {
                background-color: #0F172A;
                border-radius: 5px;
            }
            QProgressBar::chunk {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #EAB308, stop:1 #22C55E);
                border-radius: 5px;
            }
        """)
        gauge_layout.addWidget(self.progress_score)

        # 3 Thẻ thống kê nhanh
        row_cards = QHBoxLayout()
        row_cards.setSpacing(10)

        self.card_views = self._create_stat_card("👀 View Trung Bình", "--", "#38BDF8")
        self.card_status = self._create_stat_card("🛡️ Trạng Thái Kênh", "Đang kiểm tra", "#F59E0B")
        self.card_zero = self._create_stat_card("❌ Số Video 0 View", "--", "#EF4444")

        row_cards.addWidget(self.card_views["frame"])
        row_cards.addWidget(self.card_status["frame"])
        row_cards.addWidget(self.card_zero["frame"])

        gauge_layout.addLayout(row_cards)
        layout.addWidget(gauge_frame)

        # Khung Đề Xuất Chiến Lược AI & 10K Follow
        lbl_ai_title = QLabel("🤖 LỘ TRÌNH 10K FOLLOW & CHIẾN LƯỢC NUÔI CHUẨN MOBILE TỪ AI:")
        lbl_ai_title.setStyleSheet("color: #FCD34D; font-weight: 800; font-size: 13px;")
        layout.addWidget(lbl_ai_title)

        self.txt_recommendation = QTextBrowser()
        self.txt_recommendation.setStyleSheet("""
            QTextBrowser {
                background-color: #131A2B;
                border: 1.5px solid #2B3D66;
                border-radius: 8px;
                color: #F8FAFC;
                padding: 12px;
                font-size: 13px;
                line-height: 1.6;
            }
        """)
        self.txt_recommendation.setHtml("<i>Đang kết nối AI và đọc dữ liệu phân tích của kênh, vui lòng đợi trong giây lát...</i>")
        layout.addWidget(self.txt_recommendation, 1)

        # KHỐI TÍCH CHỌN TỰ ĐỘNG THỰC THI THEO ĐỀ XUẤT AI (AUTO-PILOT)
        pilot_frame = QFrame()
        pilot_frame.setStyleSheet("""
            QFrame {
                background-color: #111D33;
                border: 1.5px solid #1E40AF;
                border-radius: 8px;
                padding: 10px;
            }
        """)
        pilot_layout = QVBoxLayout(pilot_frame)
        pilot_layout.setContentsMargins(10, 8, 10, 8)
        pilot_layout.setSpacing(4)

        from database.db_manager import db
        is_auto = db.is_channel_autopilot(self.channel_data["id"])

        self.chk_autopilot = QCheckBox("🤖 Bật tự động thực thi theo chiến lược AI (AI Auto-Pilot)")
        self.chk_autopilot.setStyleSheet("color: #38BDF8; font-weight: 800; font-size: 13px;")
        self.chk_autopilot.setChecked(is_auto)
        self.chk_autopilot.toggled.connect(self._on_autopilot_toggled)
        pilot_layout.addWidget(self.chk_autopilot)

        lbl_pilot_desc = QLabel(
            "✓ Tự động hoãn đăng khi kênh dính 0 view/shadowban để bảo vệ nick.<br>"
            "✓ Tự động đẩy mạnh đăng vào khung giờ vàng khi kênh đang cắn đề xuất.<br>"
            "✓ Tự động lách sâu video & tối ưu hashtag theo đề xuất AI."
        )
        lbl_pilot_desc.setStyleSheet("color: #94A3B8; font-size: 11px; line-height: 1.4;")
        pilot_layout.addWidget(lbl_pilot_desc)

        layout.addWidget(pilot_frame)

        # Nút Hành động
        btn_layout = QHBoxLayout()
        self.btn_recheck = QPushButton("🔄 Khám Lại Ngay")
        self.btn_recheck.setCursor(Qt.PointingHandCursor)
        self.btn_recheck.setStyleSheet("""
            QPushButton {
                background-color: #0284C7;
                color: #FFFFFF;
                border: 1px solid #38BDF8;
                border-radius: 6px;
                padding: 8px 18px;
                font-weight: 700;
                font-size: 12px;
            }
            QPushButton:hover {
                background-color: #0369A1;
            }
        """)
        self.btn_recheck.clicked.connect(self.start_audit)
        btn_layout.addWidget(self.btn_recheck)

        btn_layout.addStretch()

        btn_close = QPushButton("Đóng")
        btn_close.setCursor(Qt.PointingHandCursor)
        btn_close.setStyleSheet("""
            QPushButton {
                background-color: #334155;
                color: #FFFFFF;
                border-radius: 6px;
                padding: 8px 24px;
                font-weight: 600;
            }
            QPushButton:hover {
                background-color: #475569;
            }
        """)
        btn_close.clicked.connect(self.accept)
        btn_layout.addWidget(btn_close)

        layout.addLayout(btn_layout)

        # Kiểm tra xem đã có dữ liệu trước đó chưa
        from database.db_manager import db
        cached = db.get_channel_analytics(self.channel_data["id"])
        # Nếu có cache hợp lệ (không phải dummy 0 view mà 90 điểm), hiển thị cache, ngược lại tự động khám ngay
        if cached and not (cached.get("avg_views", 0) == 0 and cached.get("zero_view_count", 0) == 0 and cached.get("health_score", 0) >= 80):
            self._render_result(cached)
        else:
            self.start_audit()

    def _create_stat_card(self, title: str, init_val: str, color: str) -> Dict[str, Any]:
        frame = QFrame()
        frame.setObjectName("stat_card")
        frame.setFixedHeight(62)
        frame.setStyleSheet("""
            QFrame#stat_card {
                background-color: #0F172A;
                border: 1px solid #334155;
                border-radius: 8px;
            }
        """)
        box = QVBoxLayout(frame)
        box.setContentsMargins(8, 6, 8, 6)
        box.setSpacing(2)
        box.setAlignment(Qt.AlignCenter)

        lbl_t = QLabel(title)
        lbl_t.setAlignment(Qt.AlignCenter)
        lbl_t.setStyleSheet("color: #94A3B8; font-size: 11px; font-weight: 700; background: transparent; border: none;")
        
        lbl_v = QLabel(init_val)
        lbl_v.setAlignment(Qt.AlignCenter)
        lbl_v.setStyleSheet(f"color: {color}; font-size: 15px; font-weight: 900; background: transparent; border: none;")

        box.addWidget(lbl_t)
        box.addWidget(lbl_v)
        return {"frame": frame, "lbl_title": lbl_t, "lbl_val": lbl_v}

    def start_audit(self):
        self.btn_recheck.setEnabled(False)
        self.btn_recheck.setText("⏳ Đang phân tích...")
        self.txt_recommendation.setHtml("<i>Hệ thống đang mở profile Chrome ngầm để đo lường view thực tế và quét lỗi shadowban...</i>")

        self.worker = AuditWorker(self.channel_data)
        self.worker.log_msg.connect(lambda msg: self.txt_recommendation.append(f"<span style='color:#94A3B8;'>• {msg}</span>"))
        self.worker.finished.connect(self._on_audit_finished)
        self.worker.start()

    def _on_audit_finished(self, res: dict):
        self.btn_recheck.setEnabled(True)
        self.btn_recheck.setText("🔄 Khám Lại Ngay")
        self._render_result(res)

    def _render_result(self, res: dict):
        score = res.get("health_score", 85)
        self.progress_score.setValue(score)

        status = res.get("health_status", "healthy")
        videos_cnt = res.get("videos_count", 0)
        avg_views = res.get("avg_views", 0)
        zero_cnt = res.get("zero_view_count", 0)

        if status == "shadowban" or score < 50:
            color = "#EF4444"
            status_text = "🔴 Shadowban (Bóp view)"
            chunk_color = "qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #991B1B, stop:1 #EF4444)"
        elif status == "warning" or score < 75:
            color = "#F59E0B"
            status_text = "🟡 Cảnh báo (Cần tối ưu)"
            chunk_color = "qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #F59E0B, stop:1 #EAB308)"
        elif videos_cnt == 0:
            color = "#38BDF8"
            status_text = "🔵 Kênh mới (Chưa có video)"
            chunk_color = "qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #0284C7, stop:1 #38BDF8)"
        else:
            color = "#22C55E"
            status_text = "🟢 Khỏe mạnh (Bình thường)"
            chunk_color = "qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #10B981, stop:1 #22C55E)"

        self.progress_score.setStyleSheet(f"""
            QProgressBar {{
                background-color: #0F172A;
                border-radius: 5px;
            }}
            QProgressBar::chunk {{
                background: {chunk_color};
                border-radius: 5px;
            }}
        """)

        self.lbl_score_val.setText(f"{score} / 100")
        self.lbl_score_val.setStyleSheet(f"color: {color}; font-size: 20px; font-weight: 900;")

        # Nếu kênh có video mà view TB là 0 và zero view là 0 (chưa tải được Studio)
        if videos_cnt > 0 and avg_views == 0 and zero_cnt == 0:
            self.card_views["lbl_val"].setText("Chưa tải")
            self.card_status["lbl_val"].setText("🟡 Cần khám lại")
            self.card_status["lbl_val"].setStyleSheet("color: #F59E0B; font-size: 12px; font-weight: 800;")
            self.card_zero["lbl_val"].setText("Chưa rõ")
            self.card_zero["lbl_val"].setStyleSheet("color: #F59E0B; font-size: 15px; font-weight: 800;")
        else:
            self.card_views["lbl_val"].setText(f"{avg_views:,} view")
            self.card_status["lbl_val"].setText(status_text)
            self.card_status["lbl_val"].setStyleSheet(f"color: {color}; font-size: 12px; font-weight: 800;")
            self.card_zero["lbl_val"].setText(f"{zero_cnt} video")
            if zero_cnt > 0:
                self.card_zero["lbl_val"].setStyleSheet("color: #EF4444; font-size: 15px; font-weight: 900;")
            else:
                self.card_zero["lbl_val"].setStyleSheet("color: #22C55E; font-size: 15px; font-weight: 800;")

        rec_html = res.get("ai_recommendation", "")
        if not rec_html:
            rec_html = "✅ Kênh đang hoạt động ổn định. Tiếp tục duy trì đăng đều 2 video/ngày theo khung giờ vàng."
        self.txt_recommendation.setHtml(rec_html)

    def _on_autopilot_toggled(self, checked: bool):
        from database.db_manager import db
        db.set_channel_autopilot(self.channel_data["id"], checked)

