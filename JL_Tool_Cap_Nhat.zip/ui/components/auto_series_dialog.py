# -*- coding: utf-8 -*-
"""
AUTO SERIES YOUTUBE TO TIKTOK DIALOG
Giao diện Tự động hóa: 1 Kênh - 1 Nguồn YouTube - Lấy video phổ biến nhất - Cắt 9:16 - Rải lịch theo ngày.
"""

from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit,
    QPushButton, QComboBox, QSpinBox, QDoubleSpinBox, QCheckBox, QTextBrowser,
    QProgressBar, QFrame, QMessageBox, QApplication
)
from PySide6.QtCore import Qt, QThread, Signal
from typing import Dict, Any, Optional, List
from database.db_manager import db
from core.series_queue_manager import series_queue_mgr
import config
import os

class SeriesWorker(QThread):
    log_msg = Signal(str)
    progress_val = Signal(int)
    finished_series = Signal(bool, str)

    def __init__(
        self,
        channel_id: int,
        source_url: str,
        sort_mode: str = "popular",
        part_duration: int = 35,
        min_duration_min: float = 0.5,
        max_duration_min: float = 1.0,
        videos_per_day: int = 2,
        golden_hours: Optional[List[str]] = None,
        schedule_mode: str = "golden",
        interval_minutes: int = 180,
        start_time_str: str = "08:00",
        use_jitter: bool = True,
        crop_mode: str = "blur_9_16"
    ):
        super().__init__()
        self.channel_id = channel_id
        self.source_url = source_url
        self.sort_mode = sort_mode
        self.part_duration = part_duration
        self.min_duration_min = min_duration_min
        self.max_duration_min = max_duration_min
        self.videos_per_day = videos_per_day
        self.golden_hours = golden_hours or ["11:30", "19:30"]
        self.schedule_mode = schedule_mode
        self.interval_minutes = interval_minutes
        self.start_time_str = start_time_str
        self.use_jitter = use_jitter
        self.crop_mode = crop_mode

    def run(self):
        from core.youtube_pipeline import (
            fetch_best_youtube_video,
            download_youtube_video,
            auto_slice_and_edit_shorts,
            schedule_series_for_channel
        )
        import os

        try:
            self.progress_val.emit(5)
            # NGUYÊN TẮC: Chỉ có 1 video duy nhất hoạt động trong hàng chờ của kênh, không nạp chồng chéo nhiều video
            old_rem = db.get_channel_remaining_schedules_count(self.channel_id)
            if old_rem > 0:
                self.log_msg.emit(f"🧹 Phát hiện kênh đang có {old_rem} tập chưa đăng từ trước. Đang dọn sạch hàng chờ để chỉ xử lý duy nhất 1 video mới này...")
                db.clear_channel_pending_schedules(self.channel_id)

            self.progress_val.emit(10)
            # 1. Tìm video theo tiêu chí (phổ biến, mới nhất, cũ nhất) chưa từng xử lý
            sort_text = {
                "popular": "phổ biến nhất (nhiều view nhất)",
                "latest": "mới nhất (vừa tải lên)",
                "oldest": "cũ nhất (từ tập đầu tiên)"
            }.get(self.sort_mode, "phù hợp")
            self.log_msg.emit(f"🔎 Bước 1/4: Đang phân tích nguồn YouTube và tìm video {sort_text}...")
            # Vòng lặp tự động lấy video công khai theo thứ tự (tự động bỏ qua video Hội viên / bị chặn)
            ch = db.get_channel(self.channel_id)
            ch_name = ch.get("name", f"channel_{self.channel_id}") if ch else f"channel_{self.channel_id}"
            raw_dir = os.path.join(str(config.DATA_DIR / "videos" / "youtube_raw"), ch_name)
            
            download_res = None
            best_vid = None
            max_attempts = 10
            session_excluded = set()
            for attempt in range(max_attempts):
                best_vid = fetch_best_youtube_video(
                    source_url=self.source_url,
                    channel_id=self.channel_id,
                    sort_mode=self.sort_mode,
                    log_func=self.log_msg.emit,
                    exclude_ids=session_excluded
                )
                if not best_vid:
                    break

                yt_channel_name = best_vid.get("uploader_name", "")
                self.log_msg.emit(f"📥 Bước 2/4: Đang tải video từ nguồn '@{yt_channel_name}': '{best_vid['title'][:45]}...' về máy tính...")
                download_res = download_youtube_video(best_vid["url"], raw_dir, log_func=self.log_msg.emit)
                if download_res:
                    # Cập nhật nguồn video YouTube & khung tự cắt vào thông tin kênh TikTok
                    db.update_channel_youtube_source(self.channel_id, self.source_url, yt_channel_name)
                    db.update_channel_crop_frame(self.channel_id, self.crop_mode)
                    break

                # Nếu video bị giới hạn hội viên/bản quyền -> Bỏ qua và chuyển sang video công khai tiếp theo theo thứ tự
                self.log_msg.emit(f"⚠️ Video '{best_vid['title'][:35]}' không tải được hoặc bị giới hạn. Tự động chuyển sang video tiếp theo...")
                session_excluded.add(best_vid["id"])

            if not download_res or not best_vid:
                self.finished_series.emit(False, "Không tìm thấy video công khai phù hợp trên nguồn YouTube này. Vui lòng kiểm tra lại đường link!")
                return

            self.progress_val.emit(25)

            raw_file, original_title = download_res
            self.progress_val.emit(50)

            # 3. Phân tích, cắt tập và edit dọc 9:16
            min_sec = max(10.0, self.min_duration_min * 60.0)
            max_sec = max(min_sec, self.max_duration_min * 60.0)
            shorts_dir = os.path.join(str(config.DATA_DIR / "videos"), ch_name)
            crop_label = {
                "blur_9_16": "Dọc 9:16 (Nền Mờ)",
                "crop_9_16": "Dọc 9:16 (Cắt Giữa)",
                "crop_1_1": "Khung Vuông 1:1",
                "crop_16_9": "Khung Ngang 16:9",
                "original": "Giữ nguyên gốc"
            }.get(self.crop_mode, self.crop_mode)
            self.log_msg.emit(f"✂️ Bước 3/4: Đang phân tích video, tự động cắt theo khung [{crop_label}], chia tập ({self.min_duration_min:.1f} - {self.max_duration_min:.1f} phút/tập) & chèn CTA follow...")
            created_parts = auto_slice_and_edit_shorts(
                src_video_path=raw_file,
                output_dir=shorts_dir,
                target_parts=None,
                segment_duration=int((min_sec + max_sec) / 2),
                min_duration_sec=min_sec,
                max_duration_sec=max_sec,
                show_title=original_title,
                crop_mode=self.crop_mode,
                channel_id=self.channel_id,
                log_func=self.log_msg.emit
            )

            if not created_parts:
                self.finished_series.emit(False, "Không thể cắt và biên tập video. Vui lòng kiểm tra lại công cụ FFmpeg.")
                return

            self.progress_val.emit(85)
            # 4. Rải lịch độc quyền cho kênh theo ngày (Tự động nối tiếp lịch cũ & Lưu lên Đám Mây TikTok)
            strat_label = {
                "golden": "Khung Giờ Vàng",
                "interval": f"Cách đều {self.interval_minutes} phút",
                "custom": "Tùy chỉnh"
            }.get(self.schedule_mode, "Đã chọn")

            self.log_msg.emit(f"📅 Bước 4/4: Đang tự động rải {len(created_parts)} tập vào Đám Mây TikTok kênh '@{ch_name}' ({self.videos_per_day} video/ngày - {strat_label})...")
            summary = schedule_series_for_channel(
                channel_id=self.channel_id,
                parts=created_parts,
                videos_per_day=self.videos_per_day,
                golden_hours=self.golden_hours,
                schedule_mode=self.schedule_mode,
                interval_minutes=self.interval_minutes,
                start_time_str=self.start_time_str,
                use_jitter=self.use_jitter,
                upload_mode="cloud",
                log_func=self.log_msg.emit
            )

            count = summary.get("schedules_added", len(created_parts))
            total_pending = summary.get("total_pending", count)
            today_cnt = summary.get("today_count", 0)
            end_date = summary.get("end_date_str", "")

            # 5. Lưu vết video YouTube đã xử lý để không bao giờ lấy trùng
            db.save_youtube_processed_video(
                channel_id=self.channel_id,
                youtube_video_id=best_vid["id"],
                title=original_title,
                view_count=best_vid.get("view_count", 0),
                duration=best_vid.get("duration", 0),
                parts_created=len(created_parts),
                source_url=self.source_url
            )

            report_msg = (
                f"🎉 HOÀN THÀNH TỰ ĐỘNG HÓA SERIES CHO KÊNH '@{ch_name}'!\n\n"
                f"📺 Kênh Nguồn YouTube: @{yt_channel_name}\n"
                f"✂️ Đã cắt và biên tập: {count} tập ({self.min_duration_min:.1f} – {self.max_duration_min:.1f} phút/tập) chuẩn dọc 9:16\n"
                f"📅 Tần suất: {self.videos_per_day} video / ngày ({strat_label})\n"
                f"📊 Hôm nay đăng: {today_cnt} video\n"
                f"📦 Tổng video trong lịch: {total_pending} video\n"
                f"⏳ Lịch đăng đảm bảo liên tục đến ngày: {end_date}\n"
                f"☁️ Trạng thái: Đã lưu trữ và lên lịch trên Đám Mây TikTok an toàn!"
            )

            try:
                from core.notifier import notifier
                tg_msg = (
                    f"🎬 <b>[TỰ ĐỘNG SERIES YOUTUBE HOÀN TẤT]</b>\n\n"
                    f"📺 <b>Kênh TikTok:</b> <code>@{ch_name}</code>\n"
                    f"🔗 <b>Kênh Nguồn YouTube:</b> <code>@{yt_channel_name}</code>\n"
                    f"✂️ <b>Đã cắt thành công:</b> <b>{count} tập (9:16)</b>\n"
                    f"📅 <b>Tần suất:</b> {self.videos_per_day} video/ngày ({strat_label})\n"
                    f"📊 <b>Hôm nay:</b> {today_cnt} video\n"
                    f"📦 <b>Tổng video trong lịch:</b> <b>{total_pending} video</b>\n"
                    f"⏳ <b>Lịch đăng liên tục đến:</b> <code>{end_date}</code>\n"
                    f"☁️ <b>Trạng thái:</b> <i>Đã lưu vào Đám Mây TikTok!</i>"
                )
                notifier.send_telegram_msg(tg_msg)
            except Exception:
                pass

            self.progress_val.emit(100)
            self.finished_series.emit(True, report_msg)

        except Exception as e:
            self.log_msg.emit(f"❌ Sự cố ngoài dự kiến: {e}")
            self.finished_series.emit(False, str(e))

class AutoSeriesDialog(QDialog):
    def __init__(self, preselected_channel_id: Optional[int] = None, parent=None):
        super().__init__(parent)
        self.preselected_channel_id = preselected_channel_id
        self._loading_config = False
        self._active_cid = None
        self.setWindowTitle("🎬 Tự Động Series YouTube ➔ TikTok (1 Kênh - Rải Theo Ngày)")
        self.resize(720, 640)
        self.setStyleSheet("QDialog { background-color: #0B1120; color: #F8FAFC; }")
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 20, 24, 20)
        layout.setSpacing(12)

        # Header Title
        title_box = QHBoxLayout()
        lbl_icon = QLabel("🎬")
        lbl_icon.setStyleSheet("font-size: 32px;")
        title_box.addWidget(lbl_icon)

        t_sub = QVBoxLayout()
        lbl_t = QLabel("Tự Động Series: YouTube ➔ TikTok Shorts Chuẩn Mobile")
        lbl_t.setStyleSheet("color: #FFFFFF; font-size: 17px; font-weight: 800;")
        lbl_s = QLabel("Lấy video phổ biến nhất, cắt chuẩn giữ chân 9:16 và tự rải lịch theo ngày độc quyền cho 1 kênh")
        lbl_s.setStyleSheet("color: #38BDF8; font-size: 12px; font-weight: 500;")
        t_sub.addWidget(lbl_t)
        t_sub.addWidget(lbl_s)
        title_box.addLayout(t_sub)
        title_box.addStretch()
        layout.addLayout(title_box)

        # Form Cấu hình
        form_frame = QFrame()
        form_frame.setStyleSheet("""
            QFrame {
                background-color: #111D33;
                border: 1px solid #1E3A8A;
                border-radius: 10px;
                padding: 12px;
            }
            QLabel {
                color: #CBD5E1;
                font-size: 12px;
                font-weight: 700;
            }
            QLineEdit, QComboBox, QSpinBox {
                background-color: #0F172A;
                border: 1px solid #334155;
                border-radius: 6px;
                color: #FFFFFF;
                padding: 6px 10px;
                font-size: 12px;
            }
            QLineEdit:focus, QComboBox:focus, QSpinBox:focus {
                border-color: #38BDF8;
            }
        """)
        form_layout = QVBoxLayout(form_frame)
        form_layout.setSpacing(10)

        # 1. Chọn Kênh TikTok nhận video
        row_ch = QHBoxLayout()
        lbl_ch = QLabel("1. Kênh TikTok nhận video:")
        lbl_ch.setFixedWidth(180)
        self.cmb_channel = QComboBox()
        channels = db.get_all_channels()
        for c in channels:
            self.cmb_channel.addItem(f"@{c.get('name', '')} (ID: {c['id']})", c["id"])

        if self.preselected_channel_id:
            for idx in range(self.cmb_channel.count()):
                if self.cmb_channel.itemData(idx) == self.preselected_channel_id:
                    self.cmb_channel.setCurrentIndex(idx)
                    break

        row_ch.addWidget(lbl_ch)
        row_ch.addWidget(self.cmb_channel, 1)
        form_layout.addLayout(row_ch)

        # 2. Link Nguồn YouTube
        row_url = QHBoxLayout()
        lbl_url = QLabel("2. Link YouTube (Kênh/Video):")
        lbl_url.setFixedWidth(180)
        self.txt_url = QLineEdit()
        self.txt_url.setPlaceholderText("Dán link kênh YouTube (ví dụ: https://www.youtube.com/@ToniTalks) hoặc link video...")

        self.btn_clear_url = QPushButton("🗑️ Xóa Nguồn")
        self.btn_clear_url.setCursor(Qt.PointingHandCursor)
        self.btn_clear_url.setStyleSheet("""
            QPushButton {
                background-color: #7F1D1D;
                color: #FCA5A5;
                border: 1px solid #DC2626;
                border-radius: 6px;
                padding: 6px 14px;
                font-weight: 700;
                font-size: 12px;
            }
            QPushButton:hover {
                background-color: #991B1B;
                color: #FFFFFF;
            }
        """)
        self.btn_clear_url.setToolTip("Xóa đường link nguồn YouTube và tắt tự động lấy video cho kênh này")
        self.btn_clear_url.clicked.connect(self._clear_and_disable_source)

        row_url.addWidget(lbl_url)
        row_url.addWidget(self.txt_url, 1)
        row_url.addWidget(self.btn_clear_url)
        form_layout.addLayout(row_url)

        # Nhãn hiển thị Tên kênh YouTube tự động nhận diện từ link
        row_detected = QHBoxLayout()
        row_detected.addSpacing(185)
        self.lbl_channel_detected = QLabel("")
        self.lbl_channel_detected.setStyleSheet("color: #38BDF8; font-size: 11px; font-weight: 700; margin-top: -4px; margin-bottom: 2px;")
        self.lbl_channel_detected.setVisible(False)
        row_detected.addWidget(self.lbl_channel_detected)
        row_detected.addStretch()
        form_layout.addLayout(row_detected)
        self.txt_url.editingFinished.connect(self._on_url_editing_finished)

        # 3. Tiêu chí chọn video YouTube
        row_sort = QHBoxLayout()
        lbl_sort = QLabel("3. Tiêu chí chọn video:")
        lbl_sort.setFixedWidth(180)
        self.cmb_sort = QComboBox()
        self.cmb_sort.addItem("🔥 Phổ Biến Nhất (Nhiều View Nhất) [Khuyên dùng]", "popular")
        self.cmb_sort.addItem("✨ Mới Nhất (Video Vừa Tải Lên Gần Đây)", "latest")
        self.cmb_sort.addItem("⏳ Cũ Nhất (Từ Video Đầu Tiên / Series Từ Tập 1)", "oldest")
        self.cmb_sort.setToolTip("Chọn cách Tool tự động tìm và lấy video từ nguồn YouTube cho kênh TikTok này")
        row_sort.addWidget(lbl_sort)
        row_sort.addWidget(self.cmb_sort, 1)
        form_layout.addLayout(row_sort)

        # 4. CẤU HÌNH THỜI LƯỢNG MỖI TẬP (TỪ ... PHÚT ĐẾN ... PHÚT) & TẦN SUẤT
        row_dur_top = QHBoxLayout()

        lbl_dur = QLabel("4. Thời lượng mỗi tập:")
        lbl_dur.setFixedWidth(180)
        self.cmb_dur = QComboBox()
        self.cmb_dur.addItem("⚡ Shorts nhanh (0.5 – 1.0 phút / 30s – 60s) [Chuẩn giữ chân]", (0.5, 1.0))
        self.cmb_dur.addItem("🎬 Tập ngắn (1.0 – 2.0 phút) [Review, Tin tức]", (1.0, 2.0))
        self.cmb_dur.addItem("🎬 Tập vừa (2.0 – 3.0 phút) [Kể chuyện, Tóm tắt]", (2.0, 3.0))
        self.cmb_dur.addItem("🎬 Tập dài (3.0 – 5.0 phút) [Podcast, Phân tích]", (3.0, 5.0))
        self.cmb_dur.addItem("🎬 Tập chuyên sâu (5.0 – 10.0 phút) [Series dài]", (5.0, 10.0))
        self.cmb_dur.addItem("⚙️ Tự điều chỉnh khoảng thời gian (Từ ... đến ...)", "custom")

        row_dur_top.addWidget(lbl_dur)
        row_dur_top.addWidget(self.cmb_dur, 1)

        lbl_per_day = QLabel("Số video / ngày:")
        self.cmb_per_day = QComboBox()
        self.cmb_per_day.addItem("2 video / ngày (Khuyên dùng)", 2)
        self.cmb_per_day.addItem("1 video / ngày", 1)
        self.cmb_per_day.addItem("3 video / ngày", 3)
        self.cmb_per_day.addItem("4 video / ngày", 4)
        self.cmb_per_day.addItem("5 video / ngày", 5)
        self.cmb_per_day.addItem("6 video / ngày", 6)

        row_dur_top.addSpacing(15)
        row_dur_top.addWidget(lbl_per_day)
        row_dur_top.addWidget(self.cmb_per_day)
        form_layout.addLayout(row_dur_top)

        # Hộp nhập khoảng thời lượng trực tiếp: Từ ... phút đến ... phút
        box_range = QFrame()
        box_range.setObjectName("box_range")
        box_range.setStyleSheet("""
            #box_range {
                background-color: #0F172A;
                border: 1px solid #1E293B;
                border-radius: 6px;
            }
            #box_range QLabel {
                border: none;
                background: transparent;
                padding: 0px;
            }
        """)
        l_range = QVBoxLayout(box_range)
        l_range.setContentsMargins(12, 8, 12, 8)

        row_spin_range = QHBoxLayout()
        lbl_range_title = QLabel("⏱️ Khoảng thời lượng mỗi tập:")
        lbl_range_title.setStyleSheet("font-weight: 700; color: #38BDF8; font-size: 11px;")
        lbl_from = QLabel("Từ:")
        lbl_from.setStyleSheet("color: #E2E8F0; font-weight: 600;")
        
        self.spn_min_dur = QDoubleSpinBox()
        self.spn_min_dur.setRange(0.2, 60.0)
        self.spn_min_dur.setSingleStep(0.5)
        self.spn_min_dur.setValue(0.5)
        self.spn_min_dur.setSuffix(" phút")
        self.spn_min_dur.setFixedWidth(95)

        lbl_to = QLabel("đến:")
        lbl_to.setStyleSheet("color: #E2E8F0; font-weight: 600;")

        self.spn_max_dur = QDoubleSpinBox()
        self.spn_max_dur.setRange(0.2, 60.0)
        self.spn_max_dur.setSingleStep(0.5)
        self.spn_max_dur.setValue(1.0)
        self.spn_max_dur.setSuffix(" phút")
        self.spn_max_dur.setFixedWidth(95)

        row_spin_range.addWidget(lbl_range_title)
        row_spin_range.addSpacing(10)
        row_spin_range.addWidget(lbl_from)
        row_spin_range.addWidget(self.spn_min_dur)
        row_spin_range.addWidget(lbl_to)
        row_spin_range.addWidget(self.spn_max_dur)

        # Nút chọn nhanh khoảng thời gian
        for min_v, max_v, label_btn in [
            (0.5, 1.0, "30s-1p"),
            (1.0, 2.0, "1-2p"),
            (2.0, 3.0, "2-3p"),
            (3.0, 5.0, "3-5p"),
            (5.0, 10.0, "5-10p")
        ]:
            btn_dur_chip = QPushButton(label_btn)
            btn_dur_chip.setCursor(Qt.PointingHandCursor)
            btn_dur_chip.setStyleSheet("""
                QPushButton {
                    background-color: #1E293B;
                    color: #94A3B8;
                    border: 1px solid #334155;
                    border-radius: 4px;
                    padding: 2px 7px;
                    font-size: 10px;
                    font-weight: 600;
                }
                QPushButton:hover {
                    background-color: #0284C7;
                    color: #FFFFFF;
                    border-color: #38BDF8;
                }
            """)
            btn_dur_chip.clicked.connect(lambda ch=False, mi=min_v, ma=max_v: self._set_custom_range(mi, ma))
            row_spin_range.addWidget(btn_dur_chip)

        row_spin_range.addStretch()
        l_range.addLayout(row_spin_range)

        self.lbl_smart_dur_info = QLabel("💡 <b>AI Smart Slice:</b> Tool tự động chia tập trong khoảng <b>30s – 60s</b>. Tập cuối sẽ không bị cắt vụn!")
        self.lbl_smart_dur_info.setStyleSheet("color: #38BDF8; font-size: 11px;")
        l_range.addWidget(self.lbl_smart_dur_info)

        form_layout.addWidget(box_range)

        # Kết nối sự kiện thay đổi thời lượng
        self.cmb_dur.currentIndexChanged.connect(self._on_dur_preset_changed)
        self.spn_min_dur.valueChanged.connect(self._on_dur_spin_changed)
        self.spn_max_dur.valueChanged.connect(self._on_dur_spin_changed)

        # 5. LỰA CHỌN KHUNG HÌNH ĐỂ TOOL TỰ CẮT
        row_crop = QHBoxLayout()
        lbl_crop = QLabel("5. Tùy chọn khung tự cắt:")
        lbl_crop.setFixedWidth(180)
        self.cmb_crop_frame = QComboBox()
        self.cmb_crop_frame.setStyleSheet("""
            QComboBox {
                background-color: #0F172A;
                color: #FFFFFF;
                border: 1px solid #334155;
                border-radius: 6px;
                padding: 6px 10px;
                font-size: 12px;
                font-weight: 600;
            }
            QComboBox QAbstractItemView {
                background-color: #0F172A;
                color: #FFFFFF;
                selection-background-color: #0284C7;
            }
        """)
        from core.video_cropper import CROP_OPTIONS
        for val, label in CROP_OPTIONS:
            self.cmb_crop_frame.addItem(label, val)
        # Mặc định chọn blur_9_16 cho nguồn YouTube
        idx_b = self.cmb_crop_frame.findData("blur_9_16")
        if idx_b >= 0:
            self.cmb_crop_frame.setCurrentIndex(idx_b)

        row_crop.addWidget(lbl_crop)
        row_crop.addWidget(self.cmb_crop_frame, 1)
        form_layout.addLayout(row_crop)

        # 6. CHIẾN LƯỢC HẸN GIỜ ĐĂNG VIDEO
        row_mode = QHBoxLayout()
        lbl_mode = QLabel("6. Chiến lược giờ đăng:")
        lbl_mode.setFixedWidth(180)
        self.cmb_sched_mode = QComboBox()
        self.cmb_sched_mode.addItem("🔥 Khung Giờ Vàng TikTok (Tối ưu đề xuất triệu view)", "golden")
        self.cmb_sched_mode.addItem("⏱️ Cách đều nhau theo số phút (Cách X phút/video)", "interval")
        self.cmb_sched_mode.addItem("✏️ Khung giờ tùy chỉnh thủ công", "custom")
        row_mode.addWidget(lbl_mode)
        row_mode.addWidget(self.cmb_sched_mode, 1)
        form_layout.addLayout(row_mode)

        # Container A: Giờ vàng Preview
        self.box_golden = QFrame()
        self.box_golden.setObjectName("box_golden")
        self.box_golden.setStyleSheet("""
            #box_golden { background-color: #0F172A; border-radius: 6px; }
            #box_golden QLabel { border: none; background: transparent; padding: 0px; }
        """)
        l_golden = QVBoxLayout(self.box_golden)
        l_golden.setContentsMargins(10, 6, 10, 6)
        self.lbl_golden_preview = QLabel("🎯 <b>Khung Giờ Vàng áp dụng:</b> 11:30 (Trưa) & 19:30 (Tối cao điểm)")
        self.lbl_golden_preview.setStyleSheet("color: #34D399; font-size: 11px;")
        l_golden.addWidget(self.lbl_golden_preview)
        form_layout.addWidget(self.box_golden)

        # Container B: Khoảng cách đều nhau theo phút
        self.box_interval = QFrame()
        self.box_interval.setObjectName("box_interval")
        self.box_interval.setStyleSheet("""
            #box_interval { background-color: #0F172A; border-radius: 6px; }
            #box_interval QLabel { border: none; background: transparent; padding: 0px; }
        """)
        l_interval = QVBoxLayout(self.box_interval)
        l_interval.setContentsMargins(10, 8, 10, 8)

        row_int_inputs = QHBoxLayout()
        lbl_start_t = QLabel("Bắt đầu video 1 lúc:")
        self.cmb_start_time = QComboBox()
        for h in range(0, 24):
            self.cmb_start_time.addItem(f"{h:02d}:00", f"{h:02d}:00")
            self.cmb_start_time.addItem(f"{h:02d}:30", f"{h:02d}:30")
        # Chọn mặc định 08:00
        idx_8 = self.cmb_start_time.findData("08:00")
        if idx_8 >= 0:
            self.cmb_start_time.setCurrentIndex(idx_8)

        lbl_spacing = QLabel("Cách nhau:")
        self.spn_interval = QSpinBox()
        self.spn_interval.setRange(1, 1440)
        self.spn_interval.setSingleStep(5)
        self.spn_interval.setValue(180)
        self.spn_interval.setSuffix(" phút")

        row_int_inputs.addWidget(lbl_start_t)
        row_int_inputs.addWidget(self.cmb_start_time)
        row_int_inputs.addSpacing(15)
        row_int_inputs.addWidget(lbl_spacing)
        row_int_inputs.addWidget(self.spn_interval)
        row_int_inputs.addStretch()
        l_interval.addLayout(row_int_inputs)

        # Nút chọn nhanh số phút
        row_chips = QHBoxLayout()
        lbl_chip_hint = QLabel("Chọn nhanh:")
        lbl_chip_hint.setStyleSheet("color: #94A3B8; font-size: 10px;")
        row_chips.addWidget(lbl_chip_hint)
        for mins, txt in [
            (10, "10p"),
            (15, "15p"),
            (30, "30p"),
            (60, "60p (1h)"),
            (90, "90p (1.5h)"),
            (120, "120p (2h)"),
            (180, "180p (3h)"),
            (240, "240p (4h)")
        ]:
            btn_chip = QPushButton(txt)
            btn_chip.setCursor(Qt.PointingHandCursor)
            btn_chip.setStyleSheet("""
                QPushButton {
                    background-color: #1E293B;
                    color: #38BDF8;
                    border: 1px solid #334155;
                    border-radius: 4px;
                    padding: 2px 8px;
                    font-size: 10px;
                }
                QPushButton:hover {
                    background-color: #0284C7;
                    color: #FFFFFF;
                }
            """)
            btn_chip.clicked.connect(lambda ch=False, m=mins: self.spn_interval.setValue(m))
            row_chips.addWidget(btn_chip)
        row_chips.addStretch()
        l_interval.addLayout(row_chips)

        self.lbl_interval_preview = QLabel("⏱️ <i>Dự kiến giờ đăng: 08:00, 11:00</i>")
        self.lbl_interval_preview.setStyleSheet("color: #38BDF8; font-size: 11px;")
        l_interval.addWidget(self.lbl_interval_preview)

        form_layout.addWidget(self.box_interval)
        self.box_interval.setVisible(False)

        # Container C: Khung giờ tùy chỉnh
        self.box_custom = QFrame()
        self.box_custom.setObjectName("box_custom")
        self.box_custom.setStyleSheet("""
            #box_custom { background-color: #0F172A; border-radius: 6px; }
            #box_custom QLabel { border: none; background: transparent; padding: 0px; }
        """)
        l_custom = QVBoxLayout(self.box_custom)
        l_custom.setContentsMargins(10, 6, 10, 6)

        row_custom = QHBoxLayout()
        lbl_custom = QLabel("Nhập các khung giờ:")
        self.txt_hours = QLineEdit("11:30, 19:30")
        self.txt_hours.setToolTip("Các khung giờ đăng mỗi ngày, cách nhau bằng dấu phẩy (ví dụ: 07:15, 11:45, 20:00)")
        row_custom.addWidget(lbl_custom)
        row_custom.addWidget(self.txt_hours, 1)
        l_custom.addLayout(row_custom)

        lbl_custom_hint = QLabel("💡 Nhập các giờ cách nhau bằng dấu phẩy (Ví dụ: <code>07:00, 11:30, 17:30, 20:30</code>)")
        lbl_custom_hint.setStyleSheet("color: #94A3B8; font-size: 10px;")
        l_custom.addWidget(lbl_custom_hint)

        form_layout.addWidget(self.box_custom)
        self.box_custom.setVisible(False)

        # 6. Tùy chọn Jitter Người thật (Chống quét bot)
        self.chk_jitter = QCheckBox("🎲 Lệch ngẫu nhiên ± 3–7 phút (Mô phỏng 100% người thật đăng tay, chống quét Bot TikTok)")
        self.chk_jitter.setChecked(True)
        self.chk_jitter.setCursor(Qt.PointingHandCursor)
        self.chk_jitter.setStyleSheet("color: #38BDF8; font-weight: 700; font-size: 11px; margin-top: 4px;")
        form_layout.addWidget(self.chk_jitter)

        # Lắng nghe thay đổi chế độ và cập nhật preview
        self.cmb_sched_mode.currentIndexChanged.connect(self._on_sched_mode_changed)
        self.cmb_per_day.currentIndexChanged.connect(self._update_sched_previews)
        self.cmb_start_time.currentIndexChanged.connect(self._update_sched_previews)
        self.spn_interval.valueChanged.connect(self._update_sched_previews)
        self._update_sched_previews()

        # Tự động lưu cấu hình kênh khi người dùng thay đổi bất kỳ ô cài đặt nào
        self.spn_interval.valueChanged.connect(self._on_auto_save_trigger)
        self.cmb_start_time.currentIndexChanged.connect(self._on_auto_save_trigger)
        self.cmb_sched_mode.currentIndexChanged.connect(self._on_auto_save_trigger)
        self.cmb_per_day.currentIndexChanged.connect(self._on_auto_save_trigger)
        self.cmb_sort.currentIndexChanged.connect(self._on_auto_save_trigger)
        self.spn_min_dur.valueChanged.connect(self._on_auto_save_trigger)
        self.spn_max_dur.valueChanged.connect(self._on_auto_save_trigger)
        self.chk_jitter.stateChanged.connect(self._on_auto_save_trigger)
        self.txt_hours.editingFinished.connect(self._on_auto_save_trigger)
        self.txt_url.editingFinished.connect(self._on_auto_save_trigger)
        if hasattr(self, "cmb_crop_frame"):
            self.cmb_crop_frame.currentIndexChanged.connect(self._on_auto_save_trigger)

        # Checklist Tự động hóa
        lbl_features = QLabel(
            "✓ <b>Tùy chọn đa dạng:</b> Tự động lấy Phổ biến nhất / Mới nhất / Cũ nhất từ tập 1.<br>"
            "✓ <b>Chống trùng lặp 100%:</b> Video đã xử lý sẽ không bao giờ bị lấy lại.<br>"
            "✓ <b>AI Smart Slice:</b> Tự động chia tập 30s-45s tỷ lệ 9:16 + Tiêu đề Tập + CTA hút Follow.<br>"
            "✓ <b>Báo cáo tồn kho:</b> Khi đăng bài, luôn tự động báo số video còn lại trong lịch hẹn."
        )
        lbl_features.setStyleSheet("color: #38BDF8; font-size: 11px; line-height: 1.5; padding-top: 4px;")
        form_layout.addWidget(lbl_features)

        layout.addWidget(form_frame)

        # Tiến trình & Log Output
        self.progress_bar = QProgressBar()
        self.progress_bar.setRange(0, 100)
        self.progress_bar.setValue(0)
        self.progress_bar.setFixedHeight(20)
        self.progress_bar.setAlignment(Qt.AlignCenter)
        self.progress_bar.setFormat("%p%")
        self.progress_bar.setStyleSheet("""
            QProgressBar {
                background-color: #0F172A;
                border: 1px solid #1E293B;
                border-radius: 6px;
                text-align: center;
                color: #FFFFFF;
                font-size: 11px;
                font-weight: 800;
            }
            QProgressBar::chunk {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #0284C7, stop:1 #38BDF8);
                border-radius: 5px;
            }
        """)
        layout.addWidget(self.progress_bar)

        self.txt_log = QTextBrowser()
        self.txt_log.setStyleSheet("""
            QTextBrowser {
                background-color: #0F172A;
                border: 1px solid #1E293B;
                border-radius: 8px;
                color: #94A3B8;
                padding: 10px;
                font-family: Consolas, monospace;
                font-size: 12px;
            }
        """)
        self.txt_log.setHtml("<i>Sẵn sàng. Hãy dán link YouTube và bấm 'Bắt Đầu Tự Động Hóa Series'...</i>")
        layout.addWidget(self.txt_log, 1)

        # Buttons
        btn_box = QHBoxLayout()
        btn_box.setSpacing(12)

        self.btn_save = QPushButton("💾 LƯU CÀI ĐẶT")
        self.btn_save.setCursor(Qt.PointingHandCursor)
        self.btn_save.setStyleSheet("""
            QPushButton {
                background-color: #059669;
                color: #FFFFFF;
                border: 1px solid #10B981;
                border-radius: 6px;
                padding: 10px 20px;
                font-weight: 800;
                font-size: 13px;
            }
            QPushButton:hover {
                background-color: #047857;
            }
        """)
        self.btn_save.setToolTip("Chỉ lưu cấu hình kênh và nguồn YouTube vào hệ thống, KHÔNG chạy ngầm video")
        self.btn_save.clicked.connect(self.save_settings_only)
        btn_box.addWidget(self.btn_save)

        self.btn_start = QPushButton("🚀 BẮT ĐẦU CHẠY")
        self.btn_start.setCursor(Qt.PointingHandCursor)
        self.btn_start.setStyleSheet("""
            QPushButton {
                background-color: #0284C7;
                color: #FFFFFF;
                border: 1px solid #38BDF8;
                border-radius: 6px;
                padding: 10px 20px;
                font-weight: 800;
                font-size: 13px;
            }
            QPushButton:hover {
                background-color: #0369A1;
            }
        """)
        self.btn_start.setToolTip("Lưu cài đặt và bắt đầu tự động tải & cắt video ngay. Kể cả khi bấm [Đóng], video vẫn tự động chạy ngầm an toàn 100%!")
        self.btn_start.clicked.connect(self.start_pipeline)
        btn_box.addWidget(self.btn_start)

        self.btn_disable_source = QPushButton("🛑 TẮT TỰ ĐỘNG NGUỒN")
        self.btn_disable_source.setCursor(Qt.PointingHandCursor)
        self.btn_disable_source.setStyleSheet("""
            QPushButton {
                background-color: #7F1D1D;
                color: #FCA5A5;
                border: 1px solid #DC2626;
                border-radius: 6px;
                padding: 10px 18px;
                font-weight: 800;
                font-size: 13px;
            }
            QPushButton:hover {
                background-color: #991B1B;
                color: #FFFFFF;
            }
        """)
        self.btn_disable_source.setToolTip("Xóa liên kết nguồn YouTube và tắt hoàn toàn tính năng tự động lấy video cho kênh này")
        self.btn_disable_source.clicked.connect(self._clear_and_disable_source)
        btn_box.addWidget(self.btn_disable_source)

        btn_box.addStretch()

        btn_close = QPushButton("Đóng")
        btn_close.setCursor(Qt.PointingHandCursor)
        btn_close.setStyleSheet("""
            QPushButton {
                background-color: #334155;
                color: #FFFFFF;
                border-radius: 6px;
                padding: 10px 24px;
                font-weight: 600;
            }
            QPushButton:hover {
                background-color: #475569;
            }
        """)
        btn_close.clicked.connect(self._on_btn_close_clicked)
        btn_box.addWidget(btn_close)

        layout.addLayout(btn_box)

        # Lắng nghe đổi kênh & Khởi tạo cấu hình ban đầu
        self.cmb_channel.currentIndexChanged.connect(self._on_channel_changed)
        self._on_channel_changed(self.cmb_channel.currentIndex())

    def _on_dur_preset_changed(self, idx: int):
        data = self.cmb_dur.itemData(idx)
        if isinstance(data, (tuple, list)):
            self.spn_min_dur.blockSignals(True)
            self.spn_max_dur.blockSignals(True)
            self.spn_min_dur.setValue(data[0])
            self.spn_max_dur.setValue(data[1])
            self.spn_min_dur.blockSignals(False)
            self.spn_max_dur.blockSignals(False)
            self._update_dur_info()

    def _on_dur_spin_changed(self):
        min_v = self.spn_min_dur.value()
        max_v = self.spn_max_dur.value()
        if min_v > max_v:
            self.spn_max_dur.setValue(min_v)
            max_v = min_v

        matched = False
        for idx in range(self.cmb_dur.count()):
            d = self.cmb_dur.itemData(idx)
            if isinstance(d, (tuple, list)) and abs(d[0] - min_v) < 0.01 and abs(d[1] - max_v) < 0.01:
                self.cmb_dur.blockSignals(True)
                self.cmb_dur.setCurrentIndex(idx)
                self.cmb_dur.blockSignals(False)
                matched = True
                break
        if not matched:
            custom_idx = self.cmb_dur.findData("custom")
            if custom_idx >= 0:
                self.cmb_dur.blockSignals(True)
                self.cmb_dur.setCurrentIndex(custom_idx)
                self.cmb_dur.blockSignals(False)

        self._update_dur_info()

    def _set_custom_range(self, min_v: float, max_v: float):
        self.spn_min_dur.setValue(min_v)
        self.spn_max_dur.setValue(max_v)
        self._on_dur_spin_changed()

    def _update_dur_info(self):
        min_v = self.spn_min_dur.value()
        max_v = self.spn_max_dur.value()
        min_s = int(min_v * 60)
        max_s = int(max_v * 60)
        min_desc = f"{int(min_v)} phút" if min_v == int(min_v) else f"{min_v:.1f} phút"
        max_desc = f"{int(max_v)} phút" if max_v == int(max_v) else f"{max_v:.1f} phút"
        if min_s < 60:
            min_desc += f" ({min_s}s)"
        if max_s < 60:
            max_desc += f" ({max_s}s)"
        self.lbl_smart_dur_info.setText(
            f"💡 <b>AI Smart Slice:</b> Tool tự động chia tập trong khoảng <b>{min_desc} – {max_desc}</b>. Tập cuối sẽ không bị cắt vụn!"
        )

    def _on_url_editing_finished(self):
        url = self.txt_url.text().strip()
        if not url:
            self.lbl_channel_detected.setVisible(False)
            return
        cid = self.cmb_channel.currentData()
        try:
            from core.youtube_pipeline import resolve_youtube_channel_title
            resolved = resolve_youtube_channel_title(url)
            if resolved and not resolved.startswith("UC"):
                self.lbl_channel_detected.setText(f"📺 Tên Kênh YouTube: <b><font color='#34D399'>@{resolved}</font></b>")
                self.lbl_channel_detected.setVisible(True)
                if cid:
                    db.update_channel_youtube_source(cid, url, resolved)
        except Exception:
            pass

    def _on_channel_changed(self, idx: int):
        # 0. Nếu đang chuyển từ kênh khác sang, lưu cấu hình kênh cũ trước
        old_cid = getattr(self, "_active_cid", None)
        if old_cid and not getattr(self, "_loading_config", False):
            self._auto_save_current_config(target_cid=old_cid, reschedule=True)

        cid = self.cmb_channel.itemData(idx)
        if not cid:
            return
        self._active_cid = cid

        self._loading_config = True
        try:
            # 1. Tự động nạp toàn bộ cấu hình đã lưu trước đó của kênh
            saved_cfg = db.get_channel_auto_series_config(cid)
            ch = db.get_channel(cid)

            # Luôn luôn đảm bảo Link nguồn YouTube được hiển thị đầy đủ (ưu tiên config lưu hoặc nguồn của kênh)
            source_url = ""
            if saved_cfg and saved_cfg.get("source_url"):
                source_url = str(saved_cfg["source_url"]).strip()
            elif ch and ch.get("youtube_source_url"):
                source_url = str(ch["youtube_source_url"]).strip()

            if source_url:
                self.txt_url.setText(source_url)
            else:
                self.txt_url.clear()

            yt_name = str(ch.get("youtube_channel_name") or "").strip() if ch else ""
            if (not yt_name or yt_name.startswith("UC")) and source_url:
                try:
                    from core.youtube_pipeline import resolve_youtube_channel_title
                    resolved = resolve_youtube_channel_title(source_url)
                    if resolved and not resolved.startswith("UC"):
                        yt_name = resolved
                        db.update_channel_youtube_source(cid, source_url, yt_name)
                except Exception:
                    pass

            if yt_name and not yt_name.startswith("UC"):
                self.lbl_channel_detected.setText(f"📺 Tên Kênh YouTube: <b><font color='#34D399'>@{yt_name}</font></b>")
                self.lbl_channel_detected.setVisible(True)
            else:
                self.lbl_channel_detected.setText("")
                self.lbl_channel_detected.setVisible(False)

            if saved_cfg:
                sort_mode = saved_cfg.get("sort_mode", "popular")
                s_idx = self.cmb_sort.findData(sort_mode)
                if s_idx >= 0:
                    self.cmb_sort.setCurrentIndex(s_idx)

                min_dur = float(saved_cfg.get("min_duration_min", 0.5))
                max_dur = float(saved_cfg.get("max_duration_min", 1.0))
                self.spn_min_dur.setValue(min_dur)
                self.spn_max_dur.setValue(max_dur)
                self._on_dur_spin_changed()

                crop_mode = saved_cfg.get("crop_mode") or (ch.get("crop_frame") if ch else "") or "blur_9_16"
                if hasattr(self, "cmb_crop_frame"):
                    c_idx = self.cmb_crop_frame.findData(crop_mode)
                    if c_idx >= 0:
                        self.cmb_crop_frame.setCurrentIndex(c_idx)

                per_day = int(saved_cfg.get("videos_per_day", 2))
                p_idx = self.cmb_per_day.findData(per_day)
                if p_idx >= 0:
                    self.cmb_per_day.setCurrentIndex(p_idx)

                sched_mode = saved_cfg.get("schedule_mode", "golden")
                sm_idx = self.cmb_sched_mode.findData(sched_mode)
                if sm_idx >= 0:
                    self.cmb_sched_mode.setCurrentIndex(sm_idx)

                interval_m = int(saved_cfg.get("interval_minutes", 180))
                self.spn_interval.setValue(interval_m)

                start_t = saved_cfg.get("start_time_str", "08:00")
                st_idx = self.cmb_start_time.findData(start_t)
                if st_idx >= 0:
                    self.cmb_start_time.setCurrentIndex(st_idx)

                gh = saved_cfg.get("golden_hours")
                if gh and isinstance(gh, list):
                    self.txt_hours.setText(", ".join(gh))

                use_jitter = bool(saved_cfg.get("use_jitter", True))
                self.chk_jitter.setChecked(use_jitter)
            elif ch:
                if hasattr(self, "cmb_crop_frame"):
                    saved_crop = ch.get("crop_frame", "blur_9_16")
                    c_idx = self.cmb_crop_frame.findData(saved_crop)
                    if c_idx >= 0:
                        self.cmb_crop_frame.setCurrentIndex(c_idx)

            self._update_sched_previews()
        finally:
            self._loading_config = False

        # 2. Kiểm tra xem kênh này có đang chạy ngầm trong hàng đợi không
        st = series_queue_mgr.get_channel_status(cid)
        if st:
            status_type = st.get("status", "queued")
            progress = st.get("progress", 0)
            step_text = st.get("step", "")
            if status_type == "processing":
                self.txt_log.setHtml(
                    f"⚡ <b>Kênh này đang được xử lý ngầm:</b><br>"
                    f"<font color='#38BDF8'>{step_text}</font> (Tiến trình: <b>{progress}%</b>)<br><br>"
                    f"<i>Tiến trình đang chạy ngầm an toàn. Bạn có thể đóng cửa sổ hoặc chờ hoàn tất.</i>"
                )
            else:
                pos = st.get("position", 1)
                self.txt_log.setHtml(
                    f"⏳ <b>Kênh đang xếp hàng đợi (Vị trí #{pos}):</b><br>"
                    f"<font color='#FCD34D'>{step_text}</font><br><br>"
                    f"<i>Tool sẽ tự động cắt video cho kênh này ngay sau khi kênh trước hoàn tất!</i>"
                )
            self.progress_bar.setValue(progress)
            self.btn_start.setEnabled(False)
            self.btn_start.setText("⏳ Đang xử lý trong hàng đợi...")
        else:
            self.btn_start.setEnabled(True)
            self.btn_start.setText("🚀 BẮT ĐẦU CHẠY")

    def _on_sched_mode_changed(self, idx: int):
        mode = self.cmb_sched_mode.currentData()
        self.box_golden.setVisible(mode == "golden")
        self.box_interval.setVisible(mode == "interval")
        self.box_custom.setVisible(mode == "custom")
        self._update_sched_previews()

    def _update_sched_previews(self):
        mode = self.cmb_sched_mode.currentData()
        per_day = self.cmb_per_day.currentData() or 2

        # 1. Preview Giờ vàng
        golden_hints = {
            1: "19:30 (Tối thư giãn cao điểm triệu view)",
            2: "11:30 (Nghỉ trưa) & 19:30 (Tối cao điểm)",
            3: "07:15 (Sáng đi làm), 11:45 (Trưa), 20:00 (Tối bùng nổ)",
            4: "07:00, 11:30, 17:30 (Tan làm), 20:30 (Cao điểm)",
            5: "07:00, 11:15, 14:00, 17:30, 20:45",
            6: "07:00, 09:30, 11:45, 14:30, 18:00, 21:00"
        }
        gh_text = golden_hints.get(per_day, "Rải đều từ 07:00 đến 22:00")
        self.lbl_golden_preview.setText(f"🎯 <b>Khung Giờ Vàng áp dụng ({per_day} video/ngày):</b> <font color='#34D399'>{gh_text}</font>")

        # 2. Preview Khoảng cách
        start_t = self.cmb_start_time.currentData() or "08:00"
        interval_m = self.spn_interval.value()
        try:
            sh, sm = [int(x) for x in start_t.split(':')]
        except Exception:
            sh, sm = 8, 0
        start_min = sh * 60 + sm
        calc_times = []
        for i in range(per_day):
            cur = (start_min + i * interval_m) % 1440
            calc_times.append(f"{cur // 60:02d}:{cur % 60:02d}")
        
        times_str = ", ".join(calc_times)
        self.lbl_interval_preview.setText(f"⏱️ <b>Dự kiến giờ đăng ({per_day} video/ngày, cách {interval_m}p):</b> <font color='#38BDF8'>{times_str}</font>")

    def _get_current_form_config(self, require_url: bool = False, silent: bool = False) -> Optional[dict]:
        cid = self.cmb_channel.currentData()
        if not cid:
            return None

        url = self.txt_url.text().strip()
        if require_url and not url:
            if not silent:
                QMessageBox.warning(self, "Chưa nhập link", "Vui lòng nhập Link Kênh hoặc Link Video YouTube!")
            return None

        sort_mode = self.cmb_sort.currentData() or "popular"
        min_dur = self.spn_min_dur.value()
        max_dur = self.spn_max_dur.value()
        if min_dur > max_dur:
            min_dur, max_dur = max_dur, min_dur

        per_day = self.cmb_per_day.currentData() or 2
        sched_mode = self.cmb_sched_mode.currentData() or "golden"
        interval_mins = max(1, self.spn_interval.value())
        start_time_val = self.cmb_start_time.currentData() or "08:00"
        use_jitter_val = self.chk_jitter.isChecked()

        raw_hours = self.txt_hours.text().strip()
        golden_hours = [h.strip() for h in raw_hours.split(',') if h.strip()]
        if not golden_hours:
            golden_hours = ["11:30", "19:30"]

        crop_mode_val = "blur_9_16"
        if hasattr(self, "cmb_crop_frame"):
            crop_mode_val = self.cmb_crop_frame.currentData() or "blur_9_16"

        return {
            "channel_id": cid,
            "source_url": url,
            "sort_mode": sort_mode,
            "min_duration_min": min_dur,
            "max_duration_min": max_dur,
            "videos_per_day": per_day,
            "golden_hours": golden_hours,
            "schedule_mode": sched_mode,
            "interval_minutes": interval_mins,
            "start_time_str": start_time_val,
            "use_jitter": use_jitter_val,
            "crop_mode": crop_mode_val
        }

    def _on_auto_save_trigger(self):
        """Kích hoạt tự động lưu cài đặt ngầm khi người dùng thay đổi dữ liệu trên giao diện"""
        if getattr(self, "_loading_config", False):
            return
        self._auto_save_current_config(reschedule=True)

    def _auto_save_current_config(self, target_cid: Optional[int] = None, reschedule: bool = True):
        """Tự động lưu ngầm toàn bộ cài đặt của kênh vào Database SQLite, chống mất dữ liệu khi thoát ra"""
        if getattr(self, "_loading_config", False):
            return
        try:
            cid = target_cid or self.cmb_channel.currentData()
            if not cid:
                return
            cfg = self._get_current_form_config(require_url=False, silent=True)
            if not cfg:
                return
            cfg["channel_id"] = cid
            db.save_channel_auto_series_config(cid, cfg)
            if cfg.get("source_url"):
                db.update_channel_youtube_source(cid, cfg["source_url"])
            if cfg.get("crop_mode"):
                db.update_channel_crop_frame(cid, cfg["crop_mode"])
            if reschedule:
                db.reschedule_channel_pending_schedules(cid, cfg)
        except Exception:
            pass

    def _on_btn_close_clicked(self):
        """Bấm nút Đóng: Tự động lưu cấu hình kênh và đóng cửa sổ"""
        self._auto_save_current_config(reschedule=True)
        self.accept()

    def save_settings_only(self):
        """Chỉ lưu cài đặt cấu hình vào Database, tự động giãn cách lại lịch đăng cho các video chưa đăng nếu có"""
        from core.license_manager import license_mgr
        is_lic, _, _ = license_mgr.check_current_license()
        if not is_lic:
            QMessageBox.warning(self, "Bản Quyền Hết Hạn", "⚠️ Bản quyền phần mềm đã hết hạn hoặc bị thu hồi! Vui lòng gia hạn để tiếp tục sử dụng.")
            return

        cfg = self._get_current_form_config(require_url=False, silent=False)
        if not cfg:
            return

        cid = cfg["channel_id"]
        # 1. Lưu cấu hình vào Database
        db.save_channel_auto_series_config(cid, cfg)
        if cfg.get("source_url"):
            db.update_channel_youtube_source(cid, cfg["source_url"])
        if cfg.get("crop_mode"):
            db.update_channel_crop_frame(cid, cfg["crop_mode"])

        # 2. Tự động quét chỉ giữ 1 video gốc duy nhất, loại bỏ video thừa
        db.clean_duplicate_pending_schedules(cid)

        # 3. Tự động tính toán & cập nhật lại thời gian đăng giãn cách cho các video chưa đăng theo cấu hình mới
        rescheduled_count = db.reschedule_channel_pending_schedules(cid, cfg)

        ch = db.get_channel(cid)
        cname = ch.get("name", f"ID {cid}") if ch else f"ID {cid}"

        sched_info = ""
        if rescheduled_count > 0:
            summary = db.get_channel_schedule_summary(cid)
            sched_mode_desc = {
                "golden": "Khung Giờ Vàng TikTok",
                "interval": f"Cách đều nhau {cfg.get('interval_minutes', 180)} phút (Bắt đầu từ {cfg.get('start_time_str', '11:00')})",
                "custom": "Khung giờ tùy chỉnh"
            }.get(cfg.get("schedule_mode", "golden"), "Cài đặt mới")
            sched_info = (
                f"<br><br>⚡ <b>Đã tự động cập nhật lại thời gian giãn cách cho {rescheduled_count} video chưa đăng:</b><br>"
                f"• Chiến lược giờ đăng: <b>{sched_mode_desc}</b> ({cfg.get('videos_per_day', 2)} video/ngày)<br>"
                f"• Lịch đăng dự kiến kéo dài đến ngày: <b>{summary.get('end_date_str', '')}</b>"
            )

        QMessageBox.information(
            self,
            "Đã Lưu Cài Đặt",
            f"✅ <b>Đã lưu cài đặt cho kênh '@{cname}' thành công!</b>{sched_info}<br><br>"
            "• Kênh <b>chưa kích hoạt chạy ngầm lấy thêm video mới</b>.<br>"
            "• Khi nào bạn muốn lấy tiếp video mới từ YouTube, chỉ cần bấm nút <b>'🚀 BẮT ĐẦU CHẠY'</b>!"
        )
        self.accept()

    def start_pipeline(self):
        """Lưu cài đặt và BẮT ĐẦU CHẠY TỰ ĐỘNG (Kể cả khi ấn [Đóng], video vẫn tự động chạy ngầm)"""
        from core.license_manager import license_mgr
        is_lic, _, _ = license_mgr.check_current_license()
        if not is_lic:
            QMessageBox.warning(self, "Bản Quyền Hết Hạn", "⚠️ Bản quyền phần mềm đã hết hạn hoặc bị thu hồi! Vui lòng gia hạn để tiếp tục sử dụng.")
            return

        cfg = self._get_current_form_config(require_url=True, silent=False)
        if not cfg:
            return

        cid = cfg["channel_id"]
        ch = db.get_channel(cid)
        cname = ch.get("name", f"ID {cid}") if ch else f"ID {cid}"

        # 1. Tự động quét dọn video trùng lặp nội bộ (nếu có)
        db.clean_duplicate_pending_schedules(cid)

        # 2. Kiểm tra nếu kênh đang có video chờ đăng dở dang
        rem = db.get_channel_remaining_schedules_count(cid)
        if rem > 0:
            msg_box = QMessageBox(self)
            msg_box.setWindowTitle("Kênh Đang Có Lịch Hẹn Chờ Đăng")
            msg_box.setText(
                f"<b>Kênh '@{cname}' hiện đang có {rem} video trong lịch chờ đăng.</b><br><br>"
                "Bạn muốn hệ thống xử lý video mới cắt từ nguồn YouTube này như thế nào?"
            )
            btn_append = msg_box.addButton("🔗 Nối Tiếp Vào Sau (Khuyên dùng)", QMessageBox.AcceptRole)
            btn_replace = msg_box.addButton("🧹 Xóa Hết Cũ & Thay Mới", QMessageBox.DestructiveRole)
            btn_cancel = msg_box.addButton("Hủy Bỏ", QMessageBox.RejectRole)
            msg_box.setDefaultButton(btn_append)
            msg_box.exec()

            clicked = msg_box.clickedButton()
            if clicked == btn_cancel:
                return
            elif clicked == btn_replace:
                db.clear_channel_pending_schedules(cid)
            # Nếu chọn Nối Tiếp: Giữ nguyên lịch cũ, tool sẽ tự động xếp các tập mới sau video cuối!

        # Lưu vào Database
        db.save_channel_auto_series_config(cid, cfg)
        db.update_channel_youtube_source(cid, cfg["source_url"])
        db.update_channel_crop_frame(cid, cfg["crop_mode"])

        self.btn_start.setEnabled(False)
        self.btn_start.setText("⏳ Đang Tự Động Chạy...")
        self.btn_save.setEnabled(False)

        self.txt_log.clear()
        self.txt_log.append(f"<span>🚀 <b>Đã bắt đầu tự động hóa Series cho kênh '@{cname}'!</b></span>")
        self.txt_log.append("<span>⚡ <b>Hệ thống đang tự động tải, cắt và rải lịch video ngầm theo thứ tự...</b></span>")
        self.txt_log.append("<span>💡 <i><b>ĐẶC BIỆT:</b> Bạn có thể bấm nút <b>[Đóng]</b> cửa sổ này bất cứ lúc nào, kênh vẫn sẽ <b>tự động chạy ngầm 100%</b> cho đến khi hoàn tất!</i></span><br>")

        self._active_cid = cid
        if getattr(self, "_is_queue_connected", False):
            try:
                series_queue_mgr.task_progress.disconnect(self._on_queue_progress)
            except Exception:
                pass
            try:
                series_queue_mgr.task_finished.disconnect(self._on_queue_finished)
            except Exception:
                pass
            self._is_queue_connected = False

        series_queue_mgr.task_progress.connect(self._on_queue_progress)
        series_queue_mgr.task_finished.connect(self._on_queue_finished)
        self._is_queue_connected = True

        # Nạp vào Hàng đợi ngầm tự động
        series_queue_mgr.add_task(cid, cfg)

    def _on_queue_progress(self, cid: int, percent: int, msg: str):
        if hasattr(self, "_active_cid") and self._active_cid == cid:
            self.progress_bar.setValue(percent)
            self.txt_log.append(f"<span>{msg}</span>")

    def _on_queue_finished(self, cid: int, success: bool, message: str):
        if hasattr(self, "_active_cid") and self._active_cid == cid:
            self.btn_start.setEnabled(True)
            self.btn_start.setText("🚀 BẮT ĐẦU CHẠY")
            self.btn_save.setEnabled(True)
            if success:
                QMessageBox.information(self, "Thành công", message)
            else:
                QMessageBox.warning(self, "Chưa hoàn tất", message)

    def closeEvent(self, event):
        """Khi người dùng bấm Đóng cửa sổ (hoặc nút X), tự động lưu cấu hình kênh và giữ tiến trình ngầm"""
        try:
            self._auto_save_current_config(reschedule=True)
        except Exception:
            pass
        if getattr(self, "_is_queue_connected", False):
            try:
                series_queue_mgr.task_progress.disconnect(self._on_queue_progress)
            except Exception:
                pass
            try:
                series_queue_mgr.task_finished.disconnect(self._on_queue_finished)
            except Exception:
                pass
            self._is_queue_connected = False
        event.accept()

    def _clear_and_disable_source(self):
        """Xóa nguồn YouTube và tắt hoàn toàn tính năng tự động lấy video cho kênh hiện tại"""
        cid = self.cmb_channel.currentData()
        if not cid:
            return

        ch = db.get_channel(cid)
        ch_name = ch.get("name", f"channel_{cid}") if ch else f"channel_{cid}"

        # Kiểm tra nếu ô link đang trống và kênh chưa có link
        current_url = self.txt_url.text().strip()
        has_db_url = bool(ch and ch.get("youtube_source_url"))
        if not current_url and not has_db_url:
            QMessageBox.information(self, "Thông báo", f"Kênh '@{ch_name}' hiện tại chưa gắn link nguồn nào!")
            return

        reply = QMessageBox.question(
            self,
            "Xác nhận tắt nguồn tự động",
            f"Bạn có chắc chắn muốn XÓA NGUỒN YouTube và TẮT TỰ ĐỘNG LẤY VIDEO cho kênh '@{ch_name}' không?\n\n"
            "Sau khi tắt:\n"
            "• Link nguồn YouTube của kênh sẽ được xóa sạch.\n"
            "• Tool sẽ ngừng hoàn toàn việc tự động tải và cắt video từ YouTube cho kênh này.",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No
        )
        if reply != QMessageBox.Yes:
            return

        # 1. Xóa nội dung trong ô nhập Link
        self.txt_url.clear()

        # 2. Xóa trong database channels (youtube_source_url, youtube_channel_name, auto_series_config)
        db.clear_channel_youtube_source(cid)

        # 3. Hủy hàng chờ nếu kênh đang được xếp lịch xử lý
        try:
            series_queue_mgr.cancel_channel(cid)
        except Exception:
            pass

        # 4. Cập nhật giao diện tiến trình và log
        self.progress_bar.setValue(0)
        self.txt_log.setHtml(
            f"<div style='color:#34D399; font-size:13px; line-height:1.6;'>"
            f"<b>✅ ĐÃ TẮT NGUỒN TỰ ĐỘNG THÀNH CÔNG!</b><br>"
            f"• Kênh áp dụng: <b>@{ch_name} (ID: {cid})</b><br>"
            f"• Trạng thái: Đã xóa link nguồn YouTube và hủy chế độ tự động nạp video.<br>"
            f"• Từ bây giờ, Tool sẽ <b>KHÔNG tự động lấy video</b> từ YouTube cho kênh này nữa."
            f"</div>"
        )

        QMessageBox.information(
            self,
            "Đã tắt nguồn thành công",
            f"Đã xóa link nguồn YouTube và tắt tự động lấy video cho kênh '@{ch_name}' thành công!"
        )

