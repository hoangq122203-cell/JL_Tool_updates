from PySide6.QtWidgets import QFrame, QVBoxLayout, QLabel
from PySide6.QtCore import Qt

class StatCard(QFrame):
    """
    Thẻ chỉ số Dashboard chuẩn xác theo giao diện mẫu:
    - Nền Dark Slate Navy (#141A2D)
    - Viền mỏng tinh tế (#222B42)
    - Chữ tiêu đề hoa nhỏ, giá trị số to màu trắng, dòng chú thích chân thẻ
    """
    def __init__(self, title: str, value: str = "0", description: str = "",
                 icon: str = "", color: str = "#3B82F6", badge_text: str = ""):
        super().__init__()
        self.init_ui(title, value, description)

    def init_ui(self, title: str, value: str, description: str):
        self.setStyleSheet("""
            QFrame {
                background-color: #141A2D;
                border: 1px solid #222B42;
                border-radius: 8px;
            }
            QFrame:hover {
                background-color: #161D32;
                border: 1px solid #2D3A58;
            }
        """)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(16, 14, 16, 14)
        layout.setSpacing(4)

        # 1. Tiêu đề hoa nhỏ
        self.lbl_title = QLabel(title.upper())
        self.lbl_title.setStyleSheet("color: #8C9BB0; font-size: 11px; font-weight: 700; letter-spacing: 0.5px; border: none; background: transparent;")
        layout.addWidget(self.lbl_title)

        # 2. Số liệu lớn nổi bật
        self.lbl_value = QLabel(str(value))
        self.lbl_value.setStyleSheet("color: #FFFFFF; font-size: 26px; font-weight: 800; border: none; background: transparent;")
        layout.addWidget(self.lbl_value)

        # 3. Dòng phụ chú giải
        self.lbl_desc = QLabel(description)
        self.lbl_desc.setStyleSheet("color: #64748B; font-size: 11px; font-weight: 500; border: none; background: transparent;")
        layout.addWidget(self.lbl_desc)

    def update_value(self, value: str, description: str = "", badge_text: str = ""):
        self.lbl_value.setText(str(value))
        if description:
            self.lbl_desc.setText(description)
