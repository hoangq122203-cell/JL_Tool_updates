import os
from pathlib import Path
from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QProgressBar, QMessageBox, QFrame
)
from PySide6.QtCore import Qt, QUrl
from PySide6.QtWebEngineWidgets import QWebEngineView
from PySide6.QtWebEngineCore import QWebEngineProfile, QWebEnginePage
from database.db_manager import db
from core.chrome_manager import chrome_mgr

class WebLoginDialog(QDialog):
    """
    Cửa sổ trình duyệt web tích hợp trực tiếp trong JL Tool để người dùng đăng nhập thủ công
    """
    def __init__(self, parent=None, channel_data=None):
        super().__init__(parent)
        self.channel_data = channel_data or {}
        channel_name = self.channel_data.get("name", "Kênh TikTok")
        self.setWindowTitle(f"JL Browser - Đăng Nhập Thủ Công: {channel_name}")
        self.resize(1080, 750)
        self.setMinimumSize(900, 600)
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        # ==================== THANH CÔNG CỤ TRÌNH DUYỆT (BROWSER TOOLBAR) ====================
        toolbar = QFrame()
        toolbar.setStyleSheet("background-color: #141520; border-bottom: 1px solid #282A3E; padding: 8px 16px;")
        t_layout = QHBoxLayout(toolbar)
        t_layout.setContentsMargins(0, 0, 0, 0)
        t_layout.setSpacing(10)

        self.btn_back = QPushButton("⬅")
        self.btn_back.setToolTip("Quay lại")
        self.btn_back.setProperty("class", "btn-secondary")
        self.btn_back.setFixedSize(32, 32)
        t_layout.addWidget(self.btn_back)

        self.btn_reload = QPushButton("↻ Tải lại")
        self.btn_reload.setToolTip("Tải lại trang")
        self.btn_reload.setProperty("class", "btn-secondary")
        self.btn_reload.setFixedHeight(32)
        self.btn_reload.setStyleSheet("padding: 2px 10px; font-weight: 700; font-size: 11px;")
        t_layout.addWidget(self.btn_reload)

        lbl_info = QLabel(f"Đang đăng nhập cho: <b>{self.channel_data.get('name', '')}</b>")
        lbl_info.setStyleSheet("color: #FFFFFF; font-size: 13px; margin-left: 8px;")
        t_layout.addWidget(lbl_info)

        t_layout.addStretch()

        lbl_tip = QLabel("💡 Bạn hãy quét mã QR hoặc đăng nhập bằng tài khoản TikTok tại đây:")
        lbl_tip.setStyleSheet("color: #25F4EE; font-size: 11px;")
        t_layout.addWidget(lbl_tip)

        # NÚT XÁC NHẬN ĐÃ ĐĂNG NHẬP XONG
        self.btn_confirm_done = QPushButton("✅ ĐÃ ĐĂNG NHẬP XONG (LƯU PHIÊN)")
        self.btn_confirm_done.setProperty("class", "btn-primary")
        self.btn_confirm_done.setFixedHeight(34)
        self.btn_confirm_done.setStyleSheet("background-color: #22C55E; color: #FFFFFF; font-weight: 700; border-radius: 6px; padding: 0 16px;")
        self.btn_confirm_done.setCursor(Qt.PointingHandCursor)
        self.btn_confirm_done.clicked.connect(self.on_login_completed)
        t_layout.addWidget(self.btn_confirm_done)

        layout.addWidget(toolbar)

        # Thanh tiến độ tải trang
        self.progress_bar = QProgressBar()
        self.progress_bar.setFixedHeight(2)
        self.progress_bar.setTextVisible(False)
        self.progress_bar.setStyleSheet("background-color: transparent; border: none;")
        layout.addWidget(self.progress_bar)

        # ==================== TRÌNH DUYỆT WEB TÍCH HỢP (QWebEngineView) ====================
        profile_dir = self.channel_data.get("profile_dir", "")
        if not profile_dir:
            profile_dir = chrome_mgr.get_profile_dir(self.channel_data.get("id", 0))

        storage_path = os.path.join(profile_dir, "webengine_storage")
        os.makedirs(storage_path, exist_ok=True)

        # Tạo Profile lưu trữ Persistent độc lập cho kênh này
        self.web_profile = QWebEngineProfile(f"channel_{self.channel_data.get('id', 0)}", self)
        self.web_profile.setPersistentStoragePath(storage_path)
        self.web_profile.setPersistentCookiesPolicy(QWebEngineProfile.ForcePersistentCookies)
        
        # User-Agent chuẩn desktop
        self.web_profile.setHttpUserAgent(
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
        )

        self.web_page = QWebEnginePage(self.web_profile, self)
        self.browser = QWebEngineView()
        self.browser.setPage(self.web_page)

        # Kết nối sự kiện nút
        self.btn_back.clicked.connect(self.browser.back)
        self.btn_reload.clicked.connect(self.browser.reload)
        self.browser.loadProgress.connect(self.on_load_progress)
        self.browser.urlChanged.connect(self.on_url_changed)

        layout.addWidget(self.browser)

        # Nạp trang đăng nhập TikTok
        login_url = "https://www.tiktok.com/login"
        self.browser.load(QUrl(login_url))

    def on_load_progress(self, progress: int):
        self.progress_bar.setValue(progress)
        if progress >= 100:
            self.progress_bar.setVisible(False)
        else:
            self.progress_bar.setVisible(True)

    def on_url_changed(self, url: QUrl):
        url_str = url.toString()
        # Nếu đã thoát khỏi trang login và vào trang chủ tiktok.com
        if "tiktok.com" in url_str and "login" not in url_str:
            self.btn_confirm_done.setText("🎉 ĐÃ ĐĂNG NHẬP! BẤM ĐỂ LƯU")
            self.btn_confirm_done.setStyleSheet("background-color: #10B981; color: #FFFFFF; font-weight: 800; padding: 0 18px;")

    def on_login_completed(self):
        # Lưu trạng thái vào database
        channel_id = self.channel_data.get("id")
        if channel_id:
            db.update_channel_login_status(channel_id, True)

        QMessageBox.information(
            self, "Thành công",
            f"Đã lưu thành công phiên đăng nhập cho kênh: <b>{self.channel_data.get('name', '')}</b>!<br>"
            "Trạng thái kênh đã chuyển sang ĐÃ ĐĂNG NHẬP."
        )
        self.accept()

