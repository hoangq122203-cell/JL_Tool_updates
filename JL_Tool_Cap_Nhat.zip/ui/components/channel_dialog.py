import os
from pathlib import Path
from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit,
    QPushButton, QFileDialog, QComboBox, QMessageBox,
    QGroupBox, QFormLayout, QCheckBox, QFrame, QScrollArea, QWidget,
    QProgressDialog, QSpinBox
)
from PySide6.QtCore import Qt, QThread, Signal
import config
from database.db_manager import db
from core.chrome_manager import chrome_mgr
from core.network_manager import network_mgr
from core.video_cropper import CROP_OPTIONS, batch_crop_folder

class BatchCropWorker(QThread):
    progress = Signal(int, int, str)
    finished_signal = Signal(int, int, str)

    def __init__(self, folder_or_files: str, crop_mode: str):
        super().__init__()
        self.folder_or_files = folder_or_files
        self.crop_mode = crop_mode

    def run(self):
        def cb(cur, tot, fn):
            self.progress.emit(cur, tot, fn)
        s, t, d = batch_crop_folder(self.folder_or_files, self.crop_mode, progress_callback=cb)
        self.finished_signal.emit(s, t, d)

class ChannelDialog(QDialog):
    def __init__(self, parent=None, channel_data=None):
        super().__init__(parent)
        self.channel_data = channel_data
        self.setWindowTitle("Chỉnh sửa kênh TikTok" if channel_data else "Thêm kênh TikTok mới")
        self.resize(640, 740)
        self.setMinimumWidth(620)
        self.setMinimumHeight(580)
        self.init_ui()

    def init_ui(self):
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(18, 16, 18, 16)
        main_layout.setSpacing(12)

        # Tiêu đề form
        title_text = "CẬP NHẬT KÊNH TIKTOK" if self.channel_data else "THÊM KÊNH TIKTOK MỚI"
        lbl_header = QLabel(title_text)
        lbl_header.setStyleSheet("font-size: 16px; font-weight: 800; color: #FFFFFF;")
        main_layout.addWidget(lbl_header)

        # Khung cuộn mượt mà bảo vệ hiển thị không bao giờ bị nén ép trên mọi màn hình
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        scroll.setStyleSheet("""
            QScrollArea {
                border: none;
                background-color: transparent;
            }
            QScrollBar:vertical {
                border: none;
                background: #0B0E17;
                width: 6px;
                margin: 0px;
                border-radius: 3px;
            }
            QScrollBar::handle:vertical {
                background: #253352;
                border-radius: 3px;
                min-height: 30px;
            }
            QScrollBar::handle:vertical:hover {
                background: #38BDF8;
            }
            QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {
                height: 0px;
            }
            QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical {
                background: none;
            }
            QScrollBar::corner {
                background: transparent;
            }
        """)

        container = QWidget()
        layout = QVBoxLayout(container)
        layout.setContentsMargins(4, 4, 10, 4)
        layout.setSpacing(14)

        # Nhóm 1: Thông tin tài khoản TikTok
        grp_info = QGroupBox("1. Thông tin kênh TikTok")
        grp_info.setStyleSheet("QGroupBox { font-weight: 600; color: #E1E1E6; border: 1px solid #2B2D3D; border-radius: 8px; margin-top: 10px; padding-top: 15px; } QGroupBox::title { subcontrol-origin: margin; left: 10px; padding: 0 5px; }")
        info_layout = QFormLayout(grp_info)
        info_layout.setSpacing(10)

        self.txt_name = QLineEdit()
        self.txt_name.setPlaceholderText("VD: 5, Kênh Review Phim...")
        self.txt_name.textChanged.connect(self.on_name_changed)
        info_layout.addRow("Tên kênh:", self.txt_name)

        self.txt_username = QLineEdit()
        self.txt_username.setPlaceholderText("Tự động đồng nhất: @tên_kênh (VD: @5)")
        info_layout.addRow("TikTok Username:", self.txt_username)

        stat_row = QHBoxLayout()
        self.spin_followers = QSpinBox()
        self.spin_followers.setRange(0, 100_000_000)
        self.spin_followers.setSingleStep(100)
        self.spin_followers.setPrefix("👥 ")
        self.spin_followers.setSuffix(" Follow")
        self.spin_followers.setStyleSheet("background-color: #0E121E; color: #38BDF8; font-weight: 700; padding: 4px;")

        self.spin_views = QSpinBox()
        self.spin_views.setRange(0, 2_000_000_000)
        self.spin_views.setSingleStep(500)
        self.spin_views.setPrefix("👁️ ")
        self.spin_views.setSuffix(" Views")
        self.spin_views.setStyleSheet("background-color: #0E121E; color: #34D399; font-weight: 700; padding: 4px;")

        stat_row.addWidget(self.spin_followers, 1)
        stat_row.addWidget(self.spin_views, 1)
        info_layout.addRow("Chỉ số (Flow / View):", stat_row)

        layout.addWidget(grp_info)

        # Nhóm 2: Cấu hình Mạng & IP
        grp_network = QGroupBox("2. Cấu hình IP và Kết nối Mạng")
        grp_network.setStyleSheet("QGroupBox { font-weight: 700; color: #FFFFFF; border: 1px solid #2B2D3D; border-radius: 8px; margin-top: 10px; padding-top: 15px; } QGroupBox::title { subcontrol-origin: margin; left: 10px; padding: 0 5px; }")
        net_layout = QVBoxLayout(grp_network)
        net_layout.setSpacing(12)

        # Ô TÍCH CHỌN BẬT/TẮT VPN
        self.chk_use_vpn = QCheckBox("🛡️ BẬT VPN (Kênh này sẽ chạy qua địa chỉ IP quốc gia)")
        self.chk_use_vpn.setChecked(True)
        self.chk_use_vpn.setCursor(Qt.PointingHandCursor)
        self.chk_use_vpn.setStyleSheet("color: #38BDF8; font-size: 13px; font-weight: 700; padding: 4px 0;")
        self.chk_use_vpn.stateChanged.connect(self.update_ip_status_display)
        net_layout.addWidget(self.chk_use_vpn)

        # KHUNG HIỂN THỊ ĐỊA CHỈ IP RÕ RÀNG (KHÔNG ÁP DỤNG BORDER/PADDING CHO LABEL CON)
        self.ip_display_box = QFrame()
        self.ip_display_box.setObjectName("ipDisplayBox")
        self.ip_display_box.setStyleSheet("""
            QFrame#ipDisplayBox {
                background-color: #0E1424;
                border: 1px solid #2563EB;
                border-radius: 8px;
                padding: 12px 16px;
            }
            QFrame#ipDisplayBox QLabel {
                border: none;
                background: transparent;
                padding: 1px 0;
            }
        """)
        ip_disp_layout = QVBoxLayout(self.ip_display_box)
        ip_disp_layout.setContentsMargins(12, 10, 12, 10)
        ip_disp_layout.setSpacing(8)

        # Lấy thông tin IP hiện tại
        saved_country = db.get_setting("global_vpn_country_name", "Philippines")
        real_ip = db.get_setting("cached_real_machine_ip", "Đang kết nối...")
        fake_ip = db.get_setting("cached_fake_ip", "Theo VPN Tool")

        self.lbl_ip_real_text = QLabel(f"💻 <b>IP Thật của máy:</b> <span style='color: #FFFFFF; font-family: Consolas;'>{real_ip}</span> (Việt Nam)")
        self.lbl_ip_real_text.setStyleSheet("border: none; background: transparent; font-size: 13px; color: #CBD5E1;")
        self.lbl_ip_real_text.setMinimumHeight(22)

        self.lbl_ip_fake_text = QLabel(f"🛡️ <b>IP Quốc Gia:</b> <span style='color: #38BDF8; font-family: Consolas; font-weight: 700;'>{fake_ip}</span> | Vùng: <b style='color: #FFFFFF;'>{saved_country}</b>")
        self.lbl_ip_fake_text.setStyleSheet("border: none; background: transparent; font-size: 13px; color: #CBD5E1;")
        self.lbl_ip_fake_text.setMinimumHeight(22)

        self.lbl_ip_explain = QLabel("✅ Khi bật VPN: Mọi hành động đăng video và duyệt web của kênh này được bảo vệ bởi địa chỉ IP ở trên.")
        self.lbl_ip_explain.setStyleSheet("border: none; background: transparent; font-size: 12px; color: #38BDF8; font-weight: 600;")
        self.lbl_ip_explain.setWordWrap(True)
        self.lbl_ip_explain.setMinimumHeight(22)

        ip_disp_layout.addWidget(self.lbl_ip_real_text)
        ip_disp_layout.addWidget(self.lbl_ip_fake_text)
        ip_disp_layout.addWidget(self.lbl_ip_explain)
        net_layout.addWidget(self.ip_display_box)

        # Chế độ dùng Proxy riêng nếu có
        row_type = QHBoxLayout()
        row_type.addWidget(QLabel("Nguồn IP:"))
        self.cmb_net_type = QComboBox()
        self.cmb_net_type.addItem("🌐 Cấu hình Proxy Riêng Cho Kênh (Khuyên Dùng - Không đổi IP máy tính)", "proxy")
        self.cmb_net_type.addItem("🛡️ Dùng VPN Chung Toàn Tool (PIA / HMA)", "vpn")
        self.cmb_net_type.currentIndexChanged.connect(self.on_net_type_changed)
        row_type.addWidget(self.cmb_net_type, 1)
        net_layout.addLayout(row_type)

        # Nút xem hướng dẫn giữ IP máy tính
        btn_split_guide = QPushButton("💡 Xem hướng dẫn: Chỉ Tool Fake IP, máy tính giữ nguyên mạng thật")
        btn_split_guide.setStyleSheet("background: transparent; color: #38BDF8; font-size: 11px; font-weight: 600; text-align: left; padding: 2px 0; border: none;")
        btn_split_guide.setCursor(Qt.PointingHandCursor)
        btn_split_guide.clicked.connect(self.open_split_tunnel_guide)
        net_layout.addWidget(btn_split_guide)

        # Box Proxy riêng
        self.box_proxy = QVBoxLayout()
        lbl_p_desc = QLabel("Nhập định dạng: <code>ip:port</code> hoặc <code>ip:port:user:pass</code> (Ví dụ: <code>103.152.12.34:8080:user:pass</code>)<br><span style='color: #10B981; font-weight: 600;'>⭐ Dùng Proxy giúp máy tính vẫn giữ 100% mạng gốc, công việc cá nhân không bị gián đoạn!</span>")
        lbl_p_desc.setStyleSheet("color: #8E8E9F; font-size: 11px;")
        lbl_p_desc.setWordWrap(True)
        self.box_proxy.addWidget(lbl_p_desc)

        proxy_input_row = QHBoxLayout()
        self.txt_proxy = QLineEdit()
        self.txt_proxy.setPlaceholderText("103.152.12.34:8080:username:password")
        self.btn_check_proxy = QPushButton("🔍 Kiểm tra IP")
        self.btn_check_proxy.setProperty("class", "btn-secondary")
        self.btn_check_proxy.clicked.connect(self.check_proxy_connection)
        proxy_input_row.addWidget(self.txt_proxy, 1)
        proxy_input_row.addWidget(self.btn_check_proxy)
        self.box_proxy.addLayout(proxy_input_row)

        self.lbl_proxy_result = QLabel("")
        self.lbl_proxy_result.setStyleSheet("font-size: 11px;")
        self.box_proxy.addWidget(self.lbl_proxy_result)
        net_layout.addLayout(self.box_proxy)

        layout.addWidget(grp_network)

        # Nhóm 3: Chrome Profile & Thư mục video
        grp_storage = QGroupBox("3. Hồ sơ Chrome Profile Độc Lập")
        grp_storage.setStyleSheet("QGroupBox { font-weight: 600; color: #E1E1E6; border: 1px solid #2B2D3D; border-radius: 8px; margin-top: 10px; padding-top: 15px; } QGroupBox::title { subcontrol-origin: margin; left: 10px; padding: 0 5px; }")
        st_layout = QFormLayout(grp_storage)
        st_layout.setSpacing(10)

        p_row = QHBoxLayout()
        self.txt_profile = QLineEdit()
        self.txt_profile.setPlaceholderText("Tự động tạo profile độc lập riêng cho kênh...")
        self.btn_browse_profile = QPushButton("Duyệt...")
        self.btn_browse_profile.setProperty("class", "btn-secondary")
        self.btn_browse_profile.clicked.connect(self.browse_profile_folder)
        p_row.addWidget(self.txt_profile)
        p_row.addWidget(self.btn_browse_profile)
        st_layout.addRow("Thư mục Profile:", p_row)

        self.txt_note = QLineEdit()
        self.txt_note.setPlaceholderText("Ghi chú kênh (tùy chọn)...")
        st_layout.addRow("Ghi chú:", self.txt_note)

        layout.addWidget(grp_storage)

        # Nhóm 4: Chọn File & Thư mục Video cho kênh
        grp_video = QGroupBox("4. Chọn File / Thư Mục Video Cho Kênh")
        grp_video.setStyleSheet("QGroupBox { font-weight: 700; color: #FFFFFF; border: 1px solid #2B2D3D; border-radius: 8px; margin-top: 10px; padding-top: 15px; } QGroupBox::title { subcontrol-origin: margin; left: 10px; padding: 0 5px; }")
        vid_layout = QVBoxLayout(grp_video)
        vid_layout.setSpacing(8)

        v_row = QHBoxLayout()
        self.txt_video_folder = QLineEdit()
        self.txt_video_folder.setPlaceholderText("Chưa chọn file hoặc thư mục video cho kênh...")
        self.txt_video_folder.setStyleSheet("color: #FFFFFF; background-color: #0E121E; border: 1px solid #253352; border-radius: 6px; padding: 6px 10px; font-size: 12px;")
        self.txt_video_folder.textChanged.connect(self.on_video_path_changed)

        self.btn_browse_vid_files = QPushButton("🎬 Chọn File...")
        self.btn_browse_vid_files.setProperty("class", "btn-secondary")
        self.btn_browse_vid_files.setCursor(Qt.PointingHandCursor)
        self.btn_browse_vid_files.setToolTip("Chọn 1 hoặc nhiều file video cho kênh này (.mp4, .mov...)")
        self.btn_browse_vid_files.clicked.connect(self.browse_video_files)

        self.btn_browse_vid_folder = QPushButton("📁 Chọn Thư Mục...")
        self.btn_browse_vid_folder.setProperty("class", "btn-secondary")
        self.btn_browse_vid_folder.setCursor(Qt.PointingHandCursor)
        self.btn_browse_vid_folder.setToolTip("Chọn cả thư mục chứa video cho kênh này")
        self.btn_browse_vid_folder.clicked.connect(self.browse_video_folder)

        v_row.addWidget(self.txt_video_folder, 1)
        v_row.addWidget(self.btn_browse_vid_files)
        v_row.addWidget(self.btn_browse_vid_folder)
        vid_layout.addLayout(v_row)

        self.lbl_video_info = QLabel("Chưa chọn file video nào cho kênh này.")
        self.lbl_video_info.setStyleSheet("color: #94A3B8; font-size: 11px;")
        vid_layout.addWidget(self.lbl_video_info)

        # Mục lựa chọn khung để tool tự cắt
        crop_box = QFrame()
        crop_box.setObjectName("crop_box")
        crop_box.setStyleSheet("""
            #crop_box {
                background-color: #0E1322;
                border: 1px solid #1E293B;
                border-radius: 8px;
            }
            #crop_box QLabel {
                border: none;
                background: transparent;
                padding: 0px;
            }
        """)
        crop_vlayout = QVBoxLayout(crop_box)
        crop_vlayout.setContentsMargins(10, 10, 10, 10)
        crop_vlayout.setSpacing(6)

        crop_row1 = QHBoxLayout()
        crop_row1.setSpacing(8)

        lbl_crop = QLabel("📐 Tùy chọn khung hình tự cắt:")
        lbl_crop.setStyleSheet("color: #38BDF8; font-weight: 700; font-size: 12px;")
        crop_row1.addWidget(lbl_crop)

        self.cmb_crop_frame = QComboBox()
        self.cmb_crop_frame.setStyleSheet("""
            QComboBox {
                background-color: #1E293B;
                color: #FFFFFF;
                border: 1px solid #334155;
                border-radius: 6px;
                padding: 6px 12px;
                font-size: 12px;
                font-weight: 600;
            }
            QComboBox QAbstractItemView {
                background-color: #0F172A;
                color: #FFFFFF;
                selection-background-color: #0284C7;
            }
        """)
        for val, label in CROP_OPTIONS:
            self.cmb_crop_frame.addItem(label, val)
        crop_row1.addWidget(self.cmb_crop_frame, 1)
        crop_vlayout.addLayout(crop_row1)

        crop_row2 = QHBoxLayout()
        crop_row2.setSpacing(10)

        self.btn_batch_crop = QPushButton("✂️ Cắt Khung Ngay Cho Thư Mục Này")
        self.btn_batch_crop.setCursor(Qt.PointingHandCursor)
        self.btn_batch_crop.setFixedHeight(34)
        self.btn_batch_crop.setStyleSheet("""
            QPushButton {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #0284C7, stop:1 #2563EB);
                color: #FFFFFF;
                border: 1px solid #38BDF8;
                border-radius: 6px;
                padding: 0 16px;
                font-weight: 800;
                font-size: 12px;
            }
            QPushButton:hover {
                background: #0369A1;
            }
        """)
        self.btn_batch_crop.setToolTip("Quét toàn bộ video đã chọn và tự động cắt thành các file video chuẩn khung vào thư mục '_da_cat_khung'")
        self.btn_batch_crop.clicked.connect(self.start_batch_crop_now)
        crop_row2.addWidget(self.btn_batch_crop)

        lbl_crop_auto_tip = QLabel("<i>(Hoặc để Tool tự cắt tự động khi đến giờ đăng)</i>")
        lbl_crop_auto_tip.setStyleSheet("color: #94A3B8; font-size: 11px;")
        crop_row2.addWidget(lbl_crop_auto_tip)
        crop_row2.addStretch()

        crop_vlayout.addLayout(crop_row2)

        lbl_crop_hint = QLabel("💡 <i>Khuyên dùng <b>'Dọc 9:16 - Nền Mờ'</b> cho video ngang YouTube để tạo hiệu ứng nền mờ chuẩn TikTok không mất nội dung; hoặc <b>'Dọc 9:16 - Cắt Giữa'</b> để lấy trọng tâm.</i>")
        lbl_crop_hint.setStyleSheet("color: #CBD5E1; font-size: 11px; padding-top: 2px;")
        crop_vlayout.addWidget(lbl_crop_hint)

        vid_layout.addWidget(crop_box)

        layout.addWidget(grp_video)

        scroll.setWidget(container)
        main_layout.addWidget(scroll, 1)

        # Nút bấm Hành động (cố định phía dưới, luôn nhìn thấy rõ ràng)
        btn_layout = QHBoxLayout()
        btn_layout.addStretch()

        self.btn_cancel = QPushButton("Hủy bỏ")
        self.btn_cancel.setProperty("class", "btn-secondary")
        self.btn_cancel.clicked.connect(self.reject)
        btn_layout.addWidget(self.btn_cancel)

        self.btn_save = QPushButton("Lưu kênh TikTok")
        self.btn_save.setProperty("class", "btn-primary")
        self.btn_save.clicked.connect(self.save_channel)
        btn_layout.addWidget(self.btn_save)

        main_layout.addLayout(btn_layout)

        # Nạp dữ liệu cũ nếu là chỉnh sửa
        if self.channel_data:
            self.txt_name.setText(self.channel_data.get("name", ""))
            self.txt_username.setText(self.channel_data.get("username", ""))
            self.txt_profile.setText(self.channel_data.get("profile_dir", ""))
            self.txt_profile.setEnabled(False)
            self.btn_browse_profile.setEnabled(False)
            self.txt_note.setText(self.channel_data.get("note", ""))
            self.txt_video_folder.setText(self.channel_data.get("video_folder", ""))
            self.spin_followers.setValue(int(self.channel_data.get("followers_count") or 0))
            self.spin_views.setValue(int(self.channel_data.get("views_count") or 0))

            # Nạp trạng thái Fake VPN
            use_vpn = bool(self.channel_data.get("use_vpn", 1))
            self.chk_use_vpn.setChecked(use_vpn)

            net_type = self.channel_data.get("network_type", "vpn")
            if net_type == "proxy":
                self.cmb_net_type.setCurrentIndex(1)
                self.txt_proxy.setText(self.channel_data.get("proxy_string", ""))
            else:
                self.cmb_net_type.setCurrentIndex(0)

            # Nạp khung hình tự cắt
            old_crop = self.channel_data.get("crop_frame", "original")
            idx = self.cmb_crop_frame.findData(old_crop)
            if idx >= 0:
                self.cmb_crop_frame.setCurrentIndex(idx)

        self.on_net_type_changed()
        self.update_ip_status_display()

    def on_name_changed(self, text: str):
        # Tự động đồng nhất username sau chữ @ theo tên kênh
        clean = text.strip()
        if clean:
            handle = clean if clean.startswith("@") else f"@{clean}"
            self.txt_username.setText(handle)
        else:
            self.txt_username.clear()

    def update_ip_status_display(self):
        is_faked = self.chk_use_vpn.isChecked()
        if is_faked:
            self.lbl_ip_explain.setText("✅ ĐANG BẬT VPN: Mọi hành động đăng video của kênh này sẽ đi qua IP quốc gia.")
            self.lbl_ip_explain.setStyleSheet("border: none; background: transparent; font-size: 12px; color: #38BDF8; font-weight: 700;")
            self.ip_display_box.setStyleSheet("""
                QFrame#ipDisplayBox {
                    background-color: #0E1424;
                    border: 1px solid #2563EB;
                    border-radius: 8px;
                    padding: 12px 16px;
                }
                QFrame#ipDisplayBox QLabel {
                    border: none;
                    background: transparent;
                    padding: 1px 0;
                }
            """)
        else:
            self.lbl_ip_explain.setText("🌐 DÙNG IP GỐC: Kênh này sẽ kết nối trực tiếp bằng IP gốc của máy tính.")
            self.lbl_ip_explain.setStyleSheet("border: none; background: transparent; font-size: 12px; color: #10B981; font-weight: 700;")
            self.ip_display_box.setStyleSheet("""
                QFrame#ipDisplayBox {
                    background-color: #0E1424;
                    border: 1px solid #10B981;
                    border-radius: 8px;
                    padding: 12px 16px;
                }
                QFrame#ipDisplayBox QLabel {
                    border: none;
                    background: transparent;
                    padding: 1px 0;
                }
            """)

    def on_net_type_changed(self):
        is_proxy = (self.cmb_net_type.currentData() == "proxy")
        self.txt_proxy.setVisible(is_proxy)
        self.btn_check_proxy.setVisible(is_proxy)
        self.lbl_proxy_result.setVisible(is_proxy)

    def check_proxy_connection(self):
        p_str = self.txt_proxy.text().strip()
        if not p_str:
            QMessageBox.warning(self, "Chưa nhập Proxy", "Vui lòng nhập định dạng ip:port hoặc ip:port:user:pass trước khi kiểm tra.")
            return

        self.lbl_proxy_result.setText("⏳ Đang kiểm tra kết nối qua Proxy...")
        self.lbl_proxy_result.setStyleSheet("color: #F59E0B;")
        self.repaint()

        res = network_mgr.get_current_ip(p_str)
        if res.get("success"):
            self.lbl_proxy_result.setText(f"✅ Hoạt động tốt! IP: {res['text']}")
            self.lbl_proxy_result.setStyleSheet("color: #22C55E;")
        else:
            self.lbl_proxy_result.setText(f"❌ Kết nối thất bại: {res.get('error', 'Timeout')}")
            self.lbl_proxy_result.setStyleSheet("color: #EF4444;")

    def browse_profile_folder(self):
        dir_path = QFileDialog.getExistingDirectory(self, "Chọn thư mục Chrome Profile")
        if dir_path:
            self.txt_profile.setText(dir_path)

    def browse_video_files(self):
        files, _ = QFileDialog.getOpenFileNames(
            self, "Chọn các file video cho kênh", "",
            "Video Files (*.mp4 *.mov *.mkv *.webm *.avi *.flv *.wmv *.m4v *.ts *.3gp)"
        )
        if files:
            self.txt_video_folder.setText(";".join(files))
            self.lbl_video_info.setText(f"🎬 Đã chọn {len(files)} file video cho kênh này.")
            self.lbl_video_info.setStyleSheet("color: #38BDF8; font-size: 11px; font-weight: 700;")

    def browse_video_folder(self):
        folder = QFileDialog.getExistingDirectory(self, "Chọn thư mục video cho kênh")
        if folder:
            self.txt_video_folder.setText(folder)
            v_exts = ('.mp4', '.mov', '.mkv', '.webm', '.avi', '.flv', '.wmv', '.m4v', '.ts', '.3gp')
            count = 0
            for root, _, fnames in os.walk(folder):
                for f in fnames:
                    if f.lower().endswith(v_exts):
                        count += 1
            self.lbl_video_info.setText(f"📁 Thư mục video: Tìm thấy {count} video sẵn sàng.")
            self.lbl_video_info.setStyleSheet("color: #22C55E; font-size: 11px; font-weight: 700;")

    def on_video_path_changed(self, text: str):
        val = text.strip()
        if not val:
            self.lbl_video_info.setText("Chưa chọn file video nào cho kênh này.")
            self.lbl_video_info.setStyleSheet("color: #94A3B8; font-size: 11px;")
        elif ";" in val:
            cnt = len([p for p in val.split(";") if p.strip()])
            self.lbl_video_info.setText(f"🎬 Đã chọn {cnt} file video cho kênh.")
            self.lbl_video_info.setStyleSheet("color: #38BDF8; font-size: 11px; font-weight: 700;")
        elif os.path.isdir(val):
            v_exts = ('.mp4', '.mov', '.mkv', '.webm', '.avi', '.flv', '.wmv', '.m4v', '.ts', '.3gp')
            count = sum(1 for root, _, fnames in os.walk(val) for f in fnames if f.lower().endswith(v_exts))
            self.lbl_video_info.setText(f"📁 Thư mục video: Tìm thấy {count} video sẵn sàng.")
            self.lbl_video_info.setStyleSheet("color: #22C55E; font-size: 11px; font-weight: 700;")
        elif os.path.isfile(val):
            self.lbl_video_info.setText("🎬 Đã chọn 1 file video.")
            self.lbl_video_info.setStyleSheet("color: #38BDF8; font-size: 11px; font-weight: 700;")
        else:
            self.lbl_video_info.setText("📁 Đường dẫn video đã cấu hình.")
            self.lbl_video_info.setStyleSheet("color: #38BDF8; font-size: 11px;")

    def open_split_tunnel_guide(self):
        from ui.components.split_tunnel_dialog import SplitTunnelGuideDialog
        dlg = SplitTunnelGuideDialog(self)
        dlg.exec()

    def start_batch_crop_now(self):
        val = self.txt_video_folder.text().strip()
        if not val:
            QMessageBox.warning(self, "Chưa chọn video", "Vui lòng bấm 'Chọn Thư Mục' hoặc 'Chọn File' video cho kênh trước khi cắt khung!")
            return

        crop_mode = self.cmb_crop_frame.currentData()
        if crop_mode == "original":
            QMessageBox.information(self, "Thông báo", "Bạn đang chọn 'Giữ nguyên bản gốc (Không cắt)'.\nVui lòng chọn một khung cắt như 'Dọc 9:16' hoặc 'Khung Vuông 1:1' để bắt đầu cắt!")
            return

        prog = QProgressDialog("Đang chuẩn bị cắt video...", "Hủy bỏ", 0, 100, self)
        prog.setWindowTitle("✂️ Tự Động Cắt Khung Video Cho Kênh")
        prog.setWindowModality(Qt.WindowModal)
        prog.setMinimumDuration(0)
        prog.setValue(0)

        worker = BatchCropWorker(val, crop_mode)
        self._crop_worker = worker

        def on_prog(cur, tot, fn):
            if tot > 0:
                prog.setMaximum(tot)
                prog.setValue(cur)
                prog.setLabelText(f"Đang xử lý ({cur}/{tot}): {fn}")

        def on_finished(succ, tot, target_dir):
            prog.close()
            if succ > 0:
                QMessageBox.information(
                    self,
                    "Cắt Khung Thành Công",
                    f"🎉 Đã cắt thành công {succ}/{tot} video sang khung chuẩn!\n\n"
                    f"📁 Thư mục lưu: {target_dir}\n\n"
                    f"Tool đã tự động chuyển nguồn video của kênh sang thư mục video đã cắt này."
                )
                self.txt_video_folder.setText(target_dir)
            else:
                QMessageBox.warning(
                    self,
                    "Chưa hoàn tất",
                    f"Không có video nào được cắt mới (có thể các video đã đúng tỷ lệ hoặc đã tồn tại trong thư mục đã cắt)."
                )

        worker.progress.connect(on_prog)
        worker.finished_signal.connect(on_finished)
        prog.canceled.connect(worker.terminate)

        worker.start()
        prog.exec()

    def save_channel(self):
        name = self.txt_name.text().strip()
        username = self.txt_username.text().strip()
        profile_dir = self.txt_profile.text().strip()
        video_folder = self.txt_video_folder.text().strip()
        note = self.txt_note.text().strip()
        net_type = self.cmb_net_type.currentData()
        proxy_str = self.txt_proxy.text().strip() if net_type == "proxy" else ""
        crop_frame = self.cmb_crop_frame.currentData() or "original"

        if not name:
            QMessageBox.warning(self, "Thông báo", "Vui lòng nhập tên kênh!")
            return

        # Đảm bảo username luôn có @tên_kênh
        if not username:
            clean_name = name.replace(" ", "").lower()
            username = f"@{clean_name}"
        elif not username.startswith("@"):
            username = f"@{username}"

        followers_val = self.spin_followers.value()
        views_val = self.spin_views.value()

        if not self.channel_data:
            channel_id = db.add_channel(
                name=name,
                username=username,
                profile_dir=profile_dir,
                video_folder=video_folder,
                note=note,
                network_type=net_type,
                proxy_string=proxy_str,
                crop_frame=crop_frame
            )
            db.update_channel_stats(channel_id, followers_val, views_val)
            db.set_channel_vpn_status(channel_id, self.chk_use_vpn.isChecked())
            QMessageBox.information(self, "Thành công", f"Đã thêm kênh '{name}' thành công!")
        else:
            channel_id = self.channel_data["id"]
            db.update_channel(
                channel_id=channel_id,
                name=name,
                username=username,
                video_folder=video_folder,
                status=self.channel_data.get("status", "active"),
                note=note,
                network_type=net_type,
                proxy_string=proxy_str,
                crop_frame=crop_frame
            )
            db.update_channel_stats(channel_id, followers_val, views_val)
            db.set_channel_vpn_status(channel_id, self.chk_use_vpn.isChecked())
            QMessageBox.information(self, "Thành công", "Đã cập nhật thông tin kênh!")

        self.accept()
