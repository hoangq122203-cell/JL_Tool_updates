# -*- coding: utf-8 -*-
"""
Hộp thoại cập nhật chỉ số Kênh (Followers / Flow & Lượt Xem / View) cho từng kênh TikTok chuẩn xác.
Cho phép chỉnh sửa hàng loạt trực tiếp hoặc quét tự động từ TikTok Studio/Profile.
"""

from typing import List, Dict, Any, Optional
from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QTableWidget, QTableWidgetItem, QHeaderView, QMessageBox,
    QFrame, QWidget, QSpinBox, QProgressBar
)
from PySide6.QtCore import Qt, Signal, QThread
from PySide6.QtGui import QColor, QFont
from database.db_manager import db
from core.channel_auditor import analyze_channel_health


class BatchStatsWorker(QThread):
    progress_updated = Signal(int, int, str, dict)
    finished_all = Signal(list)

    def __init__(self, channels: List[Dict[str, Any]], parent=None):
        super().__init__(parent)
        self.channels = channels
        self.is_cancelled = False

    def run(self):
        results = []
        total = len(self.channels)
        for idx, ch in enumerate(self.channels):
            if self.is_cancelled:
                break
            ch_name = ch.get("name", "Kênh")
            def log_cb(msg):
                pass
            try:
                res = analyze_channel_health(ch, headless=True, log_func=log_cb)
                results.append((ch["id"], res))
                self.progress_updated.emit(idx + 1, total, ch_name, res)
            except Exception as e:
                self.progress_updated.emit(idx + 1, total, ch_name, {})
        self.finished_all.emit(results)


class BatchStatsDialog(QDialog):
    stats_updated = Signal()

    def __init__(self, parent=None, selected_channel_ids: Optional[List[int]] = None):
        super().__init__(parent)
        self.selected_channel_ids = selected_channel_ids or []
        self.setWindowTitle("📊 Quản Lý & Cập Nhật Chỉ Số Kênh (Followers & Views)")
        self.resize(780, 560)
        self.setStyleSheet("""
            QDialog {
                background-color: #0B0E17;
                color: #FFFFFF;
                font-family: 'Segoe UI', Arial, sans-serif;
            }
            QLabel {
                color: #CBD5E1;
            }
            QTableWidget {
                background-color: #0F172A;
                border: 1px solid #1E293B;
                border-radius: 8px;
                gridline-color: #1E293B;
                color: #E2E8F0;
                font-size: 12px;
            }
            QTableWidget::item {
                padding: 4px;
            }
            QHeaderView::section {
                background-color: #1E293B;
                color: #38BDF8;
                font-weight: 700;
                font-size: 11px;
                border: none;
                border-bottom: 2px solid #0284C7;
                padding: 6px;
            }
            QSpinBox {
                background-color: #1E293B;
                color: #FFFFFF;
                border: 1px solid #334155;
                border-radius: 4px;
                padding: 4px 6px;
                font-size: 12px;
                font-weight: 700;
            }
            QSpinBox:focus {
                border-color: #38BDF8;
            }
        """)

        self.spin_boxes: Dict[int, Dict[str, QSpinBox]] = {}
        self.worker: Optional[BatchStatsWorker] = None
        self.init_ui()
        self.load_data()

    def init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 16, 20, 16)
        layout.setSpacing(12)

        # Header Card
        header = QFrame()
        header.setStyleSheet("""
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #1E1B4B, stop:1 #0F2942);
            border: 1px solid #38BDF8;
            border-radius: 8px;
            padding: 10px;
        """)
        h_layout = QVBoxLayout(header)
        h_layout.setContentsMargins(10, 8, 10, 8)
        h_layout.setSpacing(4)

        lbl_t = QLabel("📊 ĐỒNG BỘ CHỈ SỐ FOLLOWERS (FLOW) VÀ LƯỢT XEM (VIEW) CHUẨN XÁC")
        lbl_t.setStyleSheet("font-size: 14px; font-weight: 800; color: #38BDF8; border: none; background: transparent;")
        lbl_d = QLabel("• Tự động hiển thị theo từng kênh TikTok. Bạn có thể sửa trực tiếp con số chính xác hoặc bấm quét tự động.")
        lbl_d.setStyleSheet("font-size: 11px; color: #94A3B8; border: none; background: transparent;")
        h_layout.addWidget(lbl_t)
        h_layout.addWidget(lbl_d)
        layout.addWidget(header)

        # Table
        self.table = QTableWidget()
        self.table.setColumnCount(4)
        self.table.setHorizontalHeaderLabels(["STT", "Kênh TikTok", "👥 Followers (Người theo dõi)", "👁️ Lượt Xem Video (Views)"])
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.Fixed)
        self.table.setColumnWidth(0, 50)
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.Stretch)
        self.table.horizontalHeader().setSectionResizeMode(2, QHeaderView.Fixed)
        self.table.setColumnWidth(2, 220)
        self.table.horizontalHeader().setSectionResizeMode(3, QHeaderView.Fixed)
        self.table.setColumnWidth(3, 220)
        self.table.verticalHeader().setVisible(False)
        self.table.verticalHeader().setDefaultSectionSize(44)
        layout.addWidget(self.table)

        # Progress bar
        self.prog_bar = QProgressBar()
        self.prog_bar.setStyleSheet("""
            QProgressBar {
                border: 1px solid #1E293B;
                border-radius: 4px;
                background-color: #0F172A;
                text-align: center;
                color: #FFFFFF;
                font-weight: 700;
                height: 18px;
            }
            QProgressBar::chunk {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #0284C7, stop:1 #38BDF8);
            }
        """)
        self.prog_bar.setVisible(False)
        layout.addWidget(self.prog_bar)

        # Action Buttons
        btn_box = QHBoxLayout()
        btn_box.setSpacing(10)

        self.btn_auto_scan = QPushButton("⚡ Quét Tự Động Từ TikTok (Auto Scan)")
        self.btn_auto_scan.setCursor(Qt.PointingHandCursor)
        self.btn_auto_scan.setFixedHeight(38)
        self.btn_auto_scan.setStyleSheet("""
            QPushButton {
                background-color: #0C2B35;
                color: #38BDF8;
                border: 1.5px solid #0891B2;
                border-radius: 6px;
                font-weight: 700;
                font-size: 12px;
                padding: 6px 14px;
            }
            QPushButton:hover {
                background-color: #0891B2;
                color: #FFFFFF;
                border-color: #38BDF8;
            }
        """)
        self.btn_auto_scan.clicked.connect(self.start_auto_scan)
        btn_box.addWidget(self.btn_auto_scan)

        btn_box.addStretch()

        btn_cancel = QPushButton("Đóng")
        btn_cancel.setCursor(Qt.PointingHandCursor)
        btn_cancel.setFixedHeight(38)
        btn_cancel.setStyleSheet("""
            QPushButton {
                background-color: #1E293B;
                color: #94A3B8;
                border: 1px solid #334155;
                border-radius: 6px;
                font-weight: 600;
                font-size: 12px;
                padding: 6px 16px;
            }
            QPushButton:hover {
                background-color: #334155;
                color: #FFFFFF;
            }
        """)
        btn_cancel.clicked.connect(self.reject)
        btn_box.addWidget(btn_cancel)

        self.btn_save = QPushButton("💾 LƯU CHỈ SỐ TẤT CẢ KÊNH")
        self.btn_save.setCursor(Qt.PointingHandCursor)
        self.btn_save.setFixedHeight(38)
        self.btn_save.setStyleSheet("""
            QPushButton {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #0284C7, stop:1 #2563EB);
                color: #FFFFFF;
                border: 1px solid #38BDF8;
                border-radius: 6px;
                font-weight: 800;
                font-size: 12px;
                padding: 6px 20px;
            }
            QPushButton:hover {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #0369A1, stop:1 #1D4ED8);
            }
        """)
        self.btn_save.clicked.connect(self.save_all)
        btn_box.addWidget(self.btn_save)

        layout.addLayout(btn_box)

    def load_data(self):
        all_channels = db.get_all_channels()
        if self.selected_channel_ids:
            channels = [c for c in all_channels if c["id"] in self.selected_channel_ids]
        else:
            channels = all_channels

        self.channels = channels
        self.table.setRowCount(len(channels))
        self.spin_boxes.clear()

        for row, ch in enumerate(channels):
            cid = ch["id"]
            cname = ch.get("name", "Kênh")
            handle = ch.get("username", "") or f"@{cname}"

            # Col 0: STT
            item_stt = QTableWidgetItem(str(row + 1))
            item_stt.setTextAlignment(Qt.AlignCenter)
            item_stt.setForeground(QColor("#94A3B8"))
            self.table.setItem(row, 0, item_stt)

            # Col 1: Kênh
            item_name = QTableWidgetItem(f"🎬 @{cname} ({handle})")
            item_name.setForeground(QColor("#FFFFFF"))
            font_b = QFont("Segoe UI", 10)
            font_b.setBold(True)
            item_name.setFont(font_b)
            self.table.setItem(row, 1, item_name)

            # Col 2: SpinBox Followers
            spin_f = QSpinBox()
            spin_f.setRange(0, 100_000_000)
            spin_f.setSingleStep(100)
            spin_f.setValue(int(ch.get("followers_count") or 0))
            spin_f.setPrefix("👥 ")
            spin_f.setSuffix(" Follow")
            self.table.setCellWidget(row, 2, spin_f)

            # Col 3: SpinBox Views
            spin_v = QSpinBox()
            spin_v.setRange(0, 2_000_000_000)
            spin_v.setSingleStep(500)
            spin_v.setValue(int(ch.get("views_count") or 0))
            spin_v.setPrefix("👁️ ")
            spin_v.setSuffix(" Views")
            self.table.setCellWidget(row, 3, spin_v)

            self.spin_boxes[cid] = {"followers": spin_f, "views": spin_v}

    def start_auto_scan(self):
        if not self.channels:
            return
        reply = QMessageBox.question(
            self, "Quét Tự Động Từ TikTok",
            f"Bạn có muốn quét tự động chỉ số Followers và Lượt xem qua trình duyệt ngầm cho {len(self.channels)} kênh?",
            QMessageBox.Yes | QMessageBox.No
        )
        if reply != QMessageBox.Yes:
            return

        self.btn_auto_scan.setEnabled(False)
        self.btn_save.setEnabled(False)
        self.prog_bar.setVisible(True)
        self.prog_bar.setMaximum(len(self.channels))
        self.prog_bar.setValue(0)

        self.worker = BatchStatsWorker(self.channels, self)
        self.worker.progress_updated.connect(self.on_scan_progress)
        self.worker.finished_all.connect(self.on_scan_finished)
        self.worker.start()

    def on_scan_progress(self, current: int, total: int, ch_name: str, res: dict):
        self.prog_bar.setValue(current)
        self.prog_bar.setFormat(f"Đang quét ({current}/{total}): @{ch_name}...")
        cid = None
        for ch in self.channels:
            if ch.get("name") == ch_name:
                cid = ch["id"]
                break
        if cid and cid in self.spin_boxes and res:
            f_val = res.get("followers_count", 0)
            v_val = res.get("avg_views", 0)
            if f_val > 0:
                self.spin_boxes[cid]["followers"].setValue(f_val)
            if v_val > 0:
                self.spin_boxes[cid]["views"].setValue(v_val)

    def on_scan_finished(self, results: list):
        self.btn_auto_scan.setEnabled(True)
        self.btn_save.setEnabled(True)
        self.prog_bar.setFormat("🎉 Quét hoàn tất! Hãy kiểm tra và bấm 'Lưu' bên dưới.")
        QMessageBox.information(self, "Quét Hoàn Tất", f"Đã quét xong dữ liệu từ TikTok cho {len(results)} kênh!\nCác chỉ số đã được điền tự động vào bảng.")

    def save_all(self):
        for cid, spins in self.spin_boxes.items():
            f_val = spins["followers"].value()
            v_val = spins["views"].value()
            db.update_channel_stats(cid, followers_count=f_val, views_count=v_val)

        self.stats_updated.emit()
        QMessageBox.information(
            self, "Lưu Thành Công",
            f"🎉 Đã lưu thành công số lượng Follower và Lượt Xem chuẩn xác cho {len(self.spin_boxes)} kênh!"
        )
        self.accept()
