# -*- coding: utf-8 -*-
import os
import sys
from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel,
    QPushButton, QFrame, QScrollArea, QWidget
)
from PySide6.QtCore import Qt
from core.network_manager import network_mgr

class SplitTunnelGuideDialog(QDialog):
    """
    Cửa sổ hướng dẫn chi tiết cách Fake IP chỉ riêng cho Tool / Kênh TikTok
    để Máy tính vẫn giữ nguyên IP gốc, không bị gián đoạn công việc cá nhân.
    """
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Hướng Dẫn: Giữ Nguyên IP Máy Tính (Không Gián Đoạn Công Việc)")
        self.resize(700, 680)
        self.setMinimumWidth(660)
        self.setStyleSheet("""
            QDialog {
                background-color: #0F121C;
                color: #FFFFFF;
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
            }
        """)
        self.init_ui()

    def init_ui(self):
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(20, 20, 20, 16)
        main_layout.setSpacing(12)

        # Tiêu đề
        lbl_title = QLabel("💡 GIẢI PHÁP: CHỈ TOOL FAKE IP - MÁY TÍNH VẪN DÙNG MẠNG THẬT")
        lbl_title.setStyleSheet("font-size: 15px; font-weight: 800; color: #38BDF8;")
        main_layout.addWidget(lbl_title)

        lbl_subtitle = QLabel(
            "Bạn muốn duyệt web, làm việc, xem YouTube, Zalo trên máy tính với <b>IP Việt Nam bình thường</b>, "
            "trong khi các kênh TikTok trên Tool vẫn đăng bài bằng <b>IP Nước Ngoài (Philippines, Mỹ...)?</b> "
            "Dưới đây là 2 cách thực hiện chuẩn nhất:"
        )
        lbl_subtitle.setWordWrap(True)
        lbl_subtitle.setStyleSheet("color: #94A3B8; font-size: 12px; line-height: 1.4;")
        main_layout.addWidget(lbl_subtitle)

        # Khung cuộn nội dung
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setStyleSheet("""
            QScrollArea { border: none; background: transparent; }
            QScrollBar:vertical { border: none; background: #0B0E14; width: 6px; border-radius: 3px; }
            QScrollBar::handle:vertical { background: #2B3654; border-radius: 3px; }
        """)

        content = QWidget()
        content.setStyleSheet("background: transparent;")
        c_layout = QVBoxLayout(content)
        c_layout.setContentsMargins(0, 0, 8, 0)
        c_layout.setSpacing(16)

        # ==================== PHƯƠNG ÁN 1: DÙNG PROXY (CHUẨN NHẤT) ====================
        card_proxy = QFrame()
        card_proxy.setStyleSheet("""
            QFrame {
                background-color: #141A29;
                border: 1px solid #10B981;
                border-radius: 10px;
                padding: 14px;
            }
        """)
        cp_layout = QVBoxLayout(card_proxy)
        cp_layout.setSpacing(8)

        lbl_cp_title = QLabel("⭐ CÁCH 1: DÙNG PROXY RIÊNG CHO TỪNG KÊNH (KHUYÊN DÙNG SỐ 1)")
        lbl_cp_title.setStyleSheet("font-size: 13px; font-weight: 800; color: #10B981;")
        cp_layout.addWidget(lbl_cp_title)

        lbl_cp_desc = QLabel(
            "• <b>Cơ chế hoạt động:</b> Proxy chỉ can thiệp vào trình duyệt của đúng kênh TikTok đó khi đăng bài.<br>"
            "• <b>Lợi ích:</b> Toàn bộ máy tính (Zalo, Facebook, YouTube, công việc cá nhân) <b>hoàn toàn không bị ảnh hưởng</b>, "
            "vẫn dùng 100% mạng thật Việt Nam siêu tốc.<br>"
            "• <b>Cách làm:</b> Vào <b>Quản lý kênh & Proxy</b> -> Bấm <b>Chỉnh sửa kênh</b> -> Mục 2 chọn <b>'Cấu hình Proxy Riêng (HTTP/SOCKS5)'</b> -> Nhập IP Proxy dạng <code>ip:port:user:pass</code>."
        )
        lbl_cp_desc.setWordWrap(True)
        lbl_cp_desc.setStyleSheet("color: #E2E8F0; font-size: 12px; line-height: 1.4;")
        cp_layout.addWidget(lbl_cp_desc)
        c_layout.addWidget(card_proxy)

        # ==================== PHƯƠNG ÁN 2: BẬT SPLIT TUNNELING TRONG PIA VPN ====================
        card_pia = QFrame()
        card_pia.setStyleSheet("""
            QFrame {
                background-color: #141A29;
                border: 1px solid #3B82F6;
                border-radius: 10px;
                padding: 14px;
            }
        """)
        pia_layout = QVBoxLayout(card_pia)
        pia_layout.setSpacing(8)

        lbl_pia_title = QLabel("🛡️ CÁCH 2: NẾU DÙNG PIA VPN - BẬT 'SPLIT TUNNELING' (TÁCH ĐƯỜNG TRUYỀN)")
        lbl_pia_title.setStyleSheet("font-size: 13px; font-weight: 800; color: #38BDF8;")
        pia_layout.addWidget(lbl_pia_title)

        lbl_pia_desc = QLabel(
            "Ứng dụng PIA VPN có sẵn tính năng <b>Split Tunneling</b>, cho phép bạn quy định: "
            "<i>Toàn bộ máy tính dùng mạng thật, chỉ riêng JL Tool chạy qua VPN nước ngoài!</i>"
        )
        lbl_pia_desc.setWordWrap(True)
        lbl_pia_desc.setStyleSheet("color: #CBD5E1; font-size: 12px; font-weight: 600;")
        pia_layout.addWidget(lbl_pia_desc)

        steps_box = QFrame()
        steps_box.setStyleSheet("background-color: #0E121E; border: 1px solid #232B3E; border-radius: 8px; padding: 10px;")
        sb_layout = QVBoxLayout(steps_box)
        sb_layout.setSpacing(6)

        steps_text = [
            "<b>Bước 1:</b> Mở ứng dụng <b>PIA VPN</b> trên máy tính (bấm nút màu xanh bên dưới).",
            "<b>Bước 2:</b> Trên giao diện PIA VPN, bấm vào icon <b>Cài đặt (⚙️ Settings)</b> ở góc trên bên phải.",
            "<b>Bước 3:</b> Chọn tab <b>Split Tunneling</b> ở danh mục bên trái.",
            "<b>Bước 4:</b> Tích bật công tắc <b>Split Tunneling</b>.",
            "<b>Bước 5 (Quan trọng):</b> Tại dòng <b>Default Rule (Mặc định)</b> -> Chọn <b>Bypass VPN</b> (Bỏ qua VPN). <i>(Bước này giúp toàn bộ máy tính chạy mạng gốc)</i>.",
            "<b>Bước 6:</b> Tại mục <b>App Rules</b> -> Bấm <b>Add Application</b> -> Chọn file <code>JL Tool.exe</code> (hoặc <code>python.exe</code>) -> Chọn chế độ <b>Only VPN</b>."
        ]
        for s in steps_text:
            l = QLabel(s)
            l.setWordWrap(True)
            l.setStyleSheet("color: #E2E8F0; font-size: 11px;")
            sb_layout.addWidget(l)

        pia_layout.addWidget(steps_box)

        # Nút mở nhanh PIA
        btn_open_pia_row = QHBoxLayout()
        self.btn_open_pia = QPushButton("📱 Mở Ngay Ứng Dụng PIA VPN Để Cài Đặt")
        self.btn_open_pia.setStyleSheet("""
            QPushButton {
                background-color: #16A34A;
                color: #FFFFFF;
                font-weight: 700;
                font-size: 12px;
                padding: 8px 16px;
                border-radius: 6px;
            }
            QPushButton:hover {
                background-color: #22C55E;
            }
        """)
        self.btn_open_pia.setCursor(Qt.PointingHandCursor)
        self.btn_open_pia.clicked.connect(self.handle_open_pia)
        btn_open_pia_row.addWidget(self.btn_open_pia)
        btn_open_pia_row.addStretch()
        pia_layout.addLayout(btn_open_pia_row)

        c_layout.addWidget(card_pia)

        # ==================== PHƯƠNG ÁN 3: SOCKS5 PROXY TỪ PIA ====================
        card_socks = QFrame()
        card_socks.setStyleSheet("""
            QFrame {
                background-color: #141A29;
                border: 1px solid #6366F1;
                border-radius: 10px;
                padding: 12px;
            }
        """)
        cs_layout = QVBoxLayout(card_socks)
        cs_layout.setSpacing(6)

        lbl_cs_title = QLabel("🌐 CÁCH 3: DÙNG SOCKS5 PROXY MIỄN PHÍ TRONG TÀI KHOẢN PIA")
        lbl_cs_title.setStyleSheet("font-size: 12px; font-weight: 800; color: #818CF8;")
        cs_layout.addWidget(lbl_cs_title)

        lbl_cs_desc = QLabel(
            "Tất cả tài khoản PIA đều được tặng kèm SOCKS5 Proxy miễn phí. Bạn chỉ cần đăng nhập web "
            "<b>privateinternetaccess.com</b>, lấy thông tin SOCKS5 (dạng <code>proxy-nl.privateinternetaccess.com:1080</code>) "
            "và điền vào ô Proxy của kênh trên Tool. Tool sẽ chạy qua PIA mà không cần bật VPN trên máy tính!"
        )
        lbl_cs_desc.setWordWrap(True)
        lbl_cs_desc.setStyleSheet("color: #94A3B8; font-size: 11px; line-height: 1.4;")
        cs_layout.addWidget(lbl_cs_desc)
        c_layout.addWidget(card_socks)

        scroll.setWidget(content)
        main_layout.addWidget(scroll, 1)

        # Footer
        btn_box = QHBoxLayout()
        btn_box.addStretch()
        btn_close = QPushButton("Đã hiểu & Đóng")
        btn_close.setStyleSheet("""
            QPushButton {
                background-color: #2563EB;
                color: #FFFFFF;
                font-weight: 700;
                font-size: 12px;
                padding: 8px 24px;
                border-radius: 6px;
            }
            QPushButton:hover {
                background-color: #3B82F6;
            }
        """)
        btn_close.setCursor(Qt.PointingHandCursor)
        btn_close.clicked.connect(self.accept)
        btn_box.addWidget(btn_close)
        main_layout.addLayout(btn_box)

    def handle_open_pia(self):
        ok, msg = network_mgr.open_vpn_desktop_app("pia")
        if not ok:
            from PySide6.QtWidgets import QMessageBox
            QMessageBox.warning(self, "Lỗi", msg)

