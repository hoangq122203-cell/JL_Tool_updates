# -*- coding: utf-8 -*-
"""
LICENSE ACTIVATION & RENEWAL DIALOG
Giao diện kích hoạt và gia hạn bản quyền theo mã máy (HWID).
"""

from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit,
    QPushButton, QFrame, QMessageBox, QApplication
)
from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QFont, QColor
from core.license_manager import license_mgr
import webbrowser
import os
from pathlib import Path

class LicenseDialog(QDialog):
    def __init__(self, parent=None, is_mandatory: bool = True):
        super().__init__(parent)
        self.is_mandatory = is_mandatory
        self.setWindowTitle("🛡️ Kích Hoạt & Bản Quyền Phần Mềm - JL TikTok Manager")
        self.setFixedSize(650, 600)
        self.setStyleSheet("""
            QDialog {
                background-color: #0B1120;
                color: #F8FAFC;
                font-family: 'Segoe UI', Arial, sans-serif;
            }
            #header_box {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #0F2942, stop:1 #1E1B4B);
                border: 1px solid #0284C7;
                border-radius: 8px;
            }
            #hwid_box {
                background-color: #0F172A;
                border: 1px solid #1E293B;
                border-radius: 8px;
            }
            #status_box {
                background-color: #0F172A;
                border: 1.5px solid #1E293B;
                border-radius: 8px;
            }
            #act_box {
                background-color: #0F172A;
                border: 1.5px solid #1E293B;
                border-radius: 8px;
            }
            QLabel {
                border: none;
                background: transparent;
                padding: 0px;
                margin: 0px;
            }
        """)
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 20, 24, 20)
        layout.setSpacing(14)

        # 1. Header Banner
        header_box = QFrame()
        header_box.setObjectName("header_box")
        h_layout = QVBoxLayout(header_box)
        h_layout.setContentsMargins(16, 14, 16, 14)
        h_layout.setSpacing(6)

        lbl_icon = QLabel("🛡️ HỆ THỐNG BẢO VỆ BẢN QUYỀN ĐỘC QUYỀN")
        lbl_icon.setStyleSheet("color: #38BDF8; font-weight: 800; font-size: 15px;")
        lbl_icon.setAlignment(Qt.AlignCenter)

        lbl_sub = QLabel("Phần mềm được bảo vệ theo Mã Máy Tính (HWID). Mỗi key kích hoạt dùng độc quyền cho 1 máy.")
        lbl_sub.setStyleSheet("color: #94A3B8; font-size: 12px;")
        lbl_sub.setAlignment(Qt.AlignCenter)
        lbl_sub.setWordWrap(True)

        h_layout.addWidget(lbl_icon)
        h_layout.addWidget(lbl_sub)
        layout.addWidget(header_box)

        # 2. Khung Hiển Thị Mã Máy (HWID)
        hwid_box = QFrame()
        hwid_box.setObjectName("hwid_box")
        hw_layout = QVBoxLayout(hwid_box)
        hw_layout.setContentsMargins(16, 14, 16, 14)
        hw_layout.setSpacing(10)

        lbl_hwid_title = QLabel("💻 MÃ MÁY TÍNH CỦA BẠN (HARDWARE ID):")
        lbl_hwid_title.setStyleSheet("color: #38BDF8; font-weight: 800; font-size: 13px;")
        hw_layout.addWidget(lbl_hwid_title)

        row_hwid = QHBoxLayout()
        row_hwid.setSpacing(10)
        self.txt_hwid = QLineEdit(license_mgr.get_hardware_id())
        self.txt_hwid.setReadOnly(True)
        self.txt_hwid.setAlignment(Qt.AlignCenter)
        self.txt_hwid.setFixedHeight(44)
        self.txt_hwid.setStyleSheet("""
            QLineEdit {
                background-color: #1E293B;
                color: #FACC15;
                border: 2px solid #F59E0B;
                border-radius: 6px;
                font-family: Consolas, monospace;
                font-size: 16px;
                font-weight: 900;
                padding: 0 12px;
            }
        """)
        row_hwid.addWidget(self.txt_hwid, 1)

        self.btn_copy_hwid = QPushButton("📋 COPY MÃ MÁY")
        self.btn_copy_hwid.setCursor(Qt.PointingHandCursor)
        self.btn_copy_hwid.setFixedHeight(44)
        self.btn_copy_hwid.setStyleSheet("""
            QPushButton {
                background-color: #0284C7;
                color: #FFFFFF;
                border: 1px solid #38BDF8;
                border-radius: 6px;
                padding: 0 20px;
                font-weight: 800;
                font-size: 13px;
            }
            QPushButton:hover {
                background-color: #0369A1;
            }
        """)
        self.btn_copy_hwid.clicked.connect(self.copy_hwid_to_clipboard)
        row_hwid.addWidget(self.btn_copy_hwid)
        hw_layout.addLayout(row_hwid)

        lbl_hwid_note = QLabel("👉 Hãy bấm <b>[Copy Mã Máy]</b> và gửi cho Admin để nhận Key kích hoạt hoặc gia hạn bản quyền.")
        lbl_hwid_note.setStyleSheet("color: #CBD5E1; font-size: 12px;")
        lbl_hwid_note.setWordWrap(True)
        hw_layout.addWidget(lbl_hwid_note)

        layout.addWidget(hwid_box)

        # 3. Trạng thái bản quyền hiện tại
        status_box = QFrame()
        status_box.setObjectName("status_box")
        st_layout = QHBoxLayout(status_box)
        st_layout.setContentsMargins(16, 14, 16, 14)

        lbl_st_title = QLabel("Trạng thái hiện tại:")
        lbl_st_title.setStyleSheet("color: #CBD5E1; font-weight: 700; font-size: 13px;")
        st_layout.addWidget(lbl_st_title)

        is_valid, msg, info = license_mgr.check_current_license()
        if is_valid:
            if info.get("is_lifetime"):
                st_text = "🌟 ĐANG HOẠT ĐỘNG (BẢN QUYỀN VĨNH VIỄN)"
                st_color = "#34D399"
            else:
                days = info.get("days_left", 0)
                exp_date = info.get("exp_date_str", "")
                st_text = f"🟢 ĐANG HOẠT ĐỘNG (Còn {days} ngày - Hết hạn {exp_date})"
                st_color = "#38BDF8"
        else:
            if info.get("is_expired"):
                st_text = f"⚠️ ĐÃ HẾT HẠN (Vào ngày {info.get('exp_date_str', '')})"
                st_color = "#F87171"
            else:
                st_text = "🔴 CHƯA KÍCH HOẠT BẢN QUYỀN"
                st_color = "#EF4444"

        self.lbl_current_status = QLabel(st_text)
        self.lbl_current_status.setStyleSheet(f"color: {st_color}; font-weight: 900; font-size: 13px;")
        st_layout.addWidget(self.lbl_current_status, 1)

        layout.addWidget(status_box)

        # 4. Nhập Key Kích Hoạt / Gia Hạn
        act_box = QFrame()
        act_box.setObjectName("act_box")
        act_layout = QVBoxLayout(act_box)
        act_layout.setContentsMargins(16, 14, 16, 14)
        act_layout.setSpacing(10)

        lbl_key_title = QLabel("🔑 NHẬP KEY KÍCH HOẠT / GIA HẠN:")
        lbl_key_title.setStyleSheet("color: #38BDF8; font-weight: 800; font-size: 13px;")
        act_layout.addWidget(lbl_key_title)

        self.txt_key = QLineEdit()
        self.txt_key.setPlaceholderText("Dán mã Key kích hoạt (JLKEY-XXXXX-XXXXX...) vào đây...")
        self.txt_key.setFixedHeight(42)
        self.txt_key.setStyleSheet("""
            QLineEdit {
                background-color: #1E293B;
                color: #FFFFFF;
                border: 1.5px solid #334155;
                border-radius: 6px;
                font-family: Consolas, monospace;
                font-size: 13px;
                font-weight: 600;
                padding: 0 12px;
            }
            QLineEdit:focus {
                border: 1.5px solid #38BDF8;
                background-color: #0F172A;
            }
        """)
        act_layout.addWidget(self.txt_key)

        self.btn_activate = QPushButton("🚀 KÍCH HOẠT / GIA HẠN BẢN QUYỀN")
        self.btn_activate.setCursor(Qt.PointingHandCursor)
        self.btn_activate.setFixedHeight(44)
        self.btn_activate.setStyleSheet("""
            QPushButton {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #0284C7, stop:1 #2563EB);
                color: #FFFFFF;
                border: 1px solid #38BDF8;
                border-radius: 6px;
                font-weight: 800;
                font-size: 14px;
            }
            QPushButton:hover {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #0369A1, stop:1 #1D4ED8);
            }
        """)
        self.btn_activate.clicked.connect(self.on_activate_clicked)
        act_layout.addWidget(self.btn_activate)

        layout.addWidget(act_box)

        # 5. Nút Thoát / Đóng & Nút Mở Tool Admin
        btn_row = QHBoxLayout()
        if not self.is_mandatory:
            btn_close = QPushButton("Đóng")
            btn_close.setCursor(Qt.PointingHandCursor)
            btn_close.setStyleSheet("background-color: #334155; color: #FFFFFF; border-radius: 6px; padding: 9px 22px; font-weight: 700; font-size: 13px;")
            btn_close.clicked.connect(self.reject)
            btn_row.addWidget(btn_close)
        else:
            btn_exit = QPushButton("Thoát Phần Mềm")
            btn_exit.setCursor(Qt.PointingHandCursor)
            btn_exit.setStyleSheet("background-color: #1E293B; color: #94A3B8; border: 1px solid #334155; border-radius: 6px; padding: 9px 22px; font-weight: 700; font-size: 13px;")
            btn_exit.clicked.connect(self.reject)
            btn_row.addWidget(btn_exit)

        btn_row.addStretch()

        gen_file = Path(__file__).resolve().parent.parent.parent / "JL_Key_Generator.py"
        if gen_file.is_file():
            btn_open_gen = QPushButton("🔑 Mở Bộ Tạo Key (Admin)")
            btn_open_gen.setCursor(Qt.PointingHandCursor)
            btn_open_gen.setStyleSheet("""
                QPushButton {
                    background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #8B5CF6, stop:1 #EC4899);
                    color: #FFFFFF;
                    border: 1px solid #C084FC;
                    border-radius: 6px;
                    padding: 8px 16px;
                    font-weight: 800;
                    font-size: 12px;
                }
                QPushButton:hover {
                    background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #7C3AED, stop:1 #DB2777);
                }
            """)
            btn_open_gen.clicked.connect(self.open_admin_generator)
            btn_row.addWidget(btn_open_gen)

        layout.addLayout(btn_row)

    def open_admin_generator(self):
        from JL_Key_Generator import JLKeyGeneratorApp
        self._gen_win = JLKeyGeneratorApp()
        self._gen_win.show()
        self._gen_win.showNormal()
        self._gen_win.raise_()
        self._gen_win.activateWindow()

    def copy_hwid_to_clipboard(self):
        hwid = self.txt_hwid.text().strip()
        QApplication.clipboard().setText(hwid)
        self.btn_copy_hwid.setText("✅ ĐÃ COPY!")
        self.btn_copy_hwid.setStyleSheet("background-color: #10B981; color: #FFFFFF; border: 1px solid #34D399; border-radius: 6px; font-weight: 800; font-size: 13px; padding: 0 16px;")
        QTimer.singleShot(2500, self._restore_copy_btn)

    def _restore_copy_btn(self):
        self.btn_copy_hwid.setText("📋 COPY MÃ MÁY")
        self.btn_copy_hwid.setStyleSheet("background-color: #0284C7; color: #FFFFFF; border: 1px solid #38BDF8; border-radius: 6px; padding: 0 20px; font-weight: 800; font-size: 13px;")

    def on_activate_clicked(self):
        key = self.txt_key.text().strip()
        if not key:
            QMessageBox.warning(self, "Chưa nhập Key", "Vui lòng dán mã Key kích hoạt do Admin cấp!")
            return

        is_valid, msg, info = license_mgr.verify_license_key(key)
        if not is_valid:
            QMessageBox.critical(self, "Kích hoạt thất bại", msg)
            return

        # Lưu bản quyền
        license_mgr.save_installed_license(key)

        plan = info.get("plan", "PRO")
        exp_date = info.get("exp_date_str", "")
        success_msg = (
            f"🎉 CHÚC MỪNG BẠN ĐÃ KÍCH HOẠT THÀNH CÔNG!\n\n"
            f"💎 Gói bản quyền: {plan}\n"
            f"⏳ Hạn sử dụng: {exp_date}\n"
            f"💻 Thiết bị: {info.get('hwid')}\n\n"
            f"Chúc bạn quản lý kênh TikTok hiệu quả và cắn view triệu view!"
        )
        QMessageBox.information(self, "Kích hoạt thành công", success_msg)
        self.accept()
