import os
from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit,
    QPushButton, QMessageBox, QGroupBox, QFormLayout, QCheckBox,
    QTableWidget, QTableWidgetItem, QHeaderView
)
from PySide6.QtCore import Qt
from database.db_manager import db

class QuickRenameDialog(QDialog):
    """
    Hộp thoại sửa đổi tên kênh TikTok và tự động đồng nhất username sau chữ @
    """
    def __init__(self, parent=None, channels=None):
        super().__init__(parent)
        self.channels = channels or []
        self.setWindowTitle("✏️ Sửa Đổi Tên Kênh TikTok")
        self.setFixedWidth(520)
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 20, 24, 20)
        layout.setSpacing(14)

        if len(self.channels) == 1:
            # Sửa 1 kênh đơn lẻ
            ch = self.channels[0]
            lbl_title = QLabel(f"✏️ SỬA ĐỔI TÊN KÊNH: {ch.get('name', '')}")
            lbl_title.setStyleSheet("font-size: 15px; font-weight: 800; color: #FFFFFF;")
            layout.addWidget(lbl_title)

            grp = QGroupBox("Thông tin tên kênh mới")
            grp.setStyleSheet("QGroupBox { font-weight: 700; color: #FFFFFF; border: 1px solid #2B2D3D; border-radius: 8px; margin-top: 10px; padding-top: 15px; } QGroupBox::title { subcontrol-origin: margin; left: 10px; padding: 0 5px; }")
            f_layout = QFormLayout(grp)
            f_layout.setSpacing(10)

            self.txt_name = QLineEdit()
            self.txt_name.setText(ch.get("name", ""))
            self.txt_name.setStyleSheet("background-color: #0A0B10; color: #FFFFFF; font-size: 13px; font-weight: 600; padding: 8px 10px; border: 1px solid #2B3654; border-radius: 6px;")
            self.txt_name.textChanged.connect(self.on_single_name_changed)
            f_layout.addRow("Tên kênh mới:", self.txt_name)

            self.txt_username = QLineEdit()
            cur_user = ch.get("username", "") or f"@{ch.get('name', '')}"
            if not cur_user.startswith("@"):
                cur_user = f"@{cur_user}"
            self.txt_username.setText(cur_user)
            self.txt_username.setStyleSheet("background-color: #0A0B10; color: #38BDF8; font-size: 13px; font-weight: 700; padding: 8px 10px; border: 1px solid #2B3654; border-radius: 6px;")
            f_layout.addRow("TikTok Username:", self.txt_username)

            self.chk_auto_sync = QCheckBox("Tự động đồng nhất Username sau chữ @ theo tên kênh mới")
            self.chk_auto_sync.setChecked(True)
            self.chk_auto_sync.setStyleSheet("color: #22C55E; font-weight: 600; font-size: 11px;")
            f_layout.addRow("", self.chk_auto_sync)

            layout.addWidget(grp)

        else:
            # Sửa hàng loạt nhiều kênh đã tích chọn
            lbl_title = QLabel(f"✏️ ĐỔI TÊN HÀNG LOẠT ({len(self.channels)} KÊNH ĐÃ TÍCH CHỌN)")
            lbl_title.setStyleSheet("font-size: 15px; font-weight: 800; color: #FFFFFF;")
            layout.addWidget(lbl_title)

            lbl_sub = QLabel("Bạn có thể đặt tên chung có số thứ tự tự động (ví dụ: Kênh 1, Kênh 2...) hoặc nhập trực tiếp tên từng kênh bên dưới.")
            lbl_sub.setStyleSheet("color: #94A3B8; font-size: 12px;")
            lbl_sub.setWordWrap(True)
            layout.addWidget(lbl_sub)

            # Khung đổi tên nhanh theo mẫu
            pattern_box = QHBoxLayout()
            pattern_box.addWidget(QLabel("Mẫu tên:"))
            self.txt_pattern = QLineEdit()
            self.txt_pattern.setPlaceholderText("VD: Kênh Phim, Kênh TikTok...")
            pattern_box.addWidget(self.txt_pattern, 1)

            btn_apply_pattern = QPushButton("Áp dụng mẫu")
            btn_apply_pattern.setProperty("class", "btn-secondary")
            btn_apply_pattern.clicked.connect(self.apply_pattern_to_table)
            pattern_box.addWidget(btn_apply_pattern)
            layout.addLayout(pattern_box)

            # Bảng danh sách kênh để sửa trực tiếp
            self.table_edit = QTableWidget()
            self.table_edit.setColumnCount(3)
            self.table_edit.setHorizontalHeaderLabels(["STT", "Tên Kênh Mới", "Username (@tên)"])
            self.table_edit.horizontalHeader().setSectionResizeMode(0, QHeaderView.Fixed)
            self.table_edit.setColumnWidth(0, 50)
            self.table_edit.horizontalHeader().setSectionResizeMode(1, QHeaderView.Stretch)
            self.table_edit.horizontalHeader().setSectionResizeMode(2, QHeaderView.Stretch)
            self.table_edit.verticalHeader().setVisible(False)
            self.table_edit.setMinimumHeight(220)

            self.table_inputs = []
            self.table_edit.setRowCount(len(self.channels))
            for r, ch in enumerate(self.channels):
                item_stt = QTableWidgetItem(str(r + 1))
                item_stt.setTextAlignment(Qt.AlignCenter)
                item_stt.setToolTip(f"STT: {r + 1} (ID Kênh: {ch['id']})")
                self.table_edit.setItem(r, 0, item_stt)

                txt_n = QLineEdit(ch.get("name", ""))
                txt_n.setStyleSheet("background-color: #0A0B10; color: #FFFFFF; font-weight: 600; padding: 4px;")
                txt_u = QLineEdit(ch.get("username", "") or f"@{ch.get('name', '')}")
                txt_u.setStyleSheet("background-color: #0A0B10; color: #38BDF8; font-weight: 700; padding: 4px;")

                def make_sync_callback(n_widget, u_widget):
                    def callback(new_text):
                        clean = new_text.strip()
                        u_widget.setText(clean if clean.startswith("@") else f"@{clean}")
                    return callback

                txt_n.textChanged.connect(make_sync_callback(txt_n, txt_u))

                self.table_edit.setCellWidget(r, 1, txt_n)
                self.table_edit.setCellWidget(r, 2, txt_u)
                self.table_inputs.append((ch, txt_n, txt_u))

            layout.addWidget(self.table_edit)

        # Nút bấm Hành động
        btn_layout = QHBoxLayout()
        btn_layout.addStretch()

        self.btn_cancel = QPushButton("Hủy bỏ")
        self.btn_cancel.setProperty("class", "btn-secondary")
        self.btn_cancel.clicked.connect(self.reject)
        btn_layout.addWidget(self.btn_cancel)

        self.btn_save = QPushButton("💾 Lưu Tên Kênh Mới")
        self.btn_save.setProperty("class", "btn-primary")
        self.btn_save.setStyleSheet("background-color: #2563EB; color: #FFFFFF; font-weight: 700; padding: 7px 18px; border-radius: 6px;")
        self.btn_save.setCursor(Qt.PointingHandCursor)
        self.btn_save.clicked.connect(self.save_renames)
        btn_layout.addWidget(self.btn_save)

        layout.addLayout(btn_layout)

    def on_single_name_changed(self, text: str):
        if hasattr(self, "chk_auto_sync") and self.chk_auto_sync.isChecked():
            clean = text.strip()
            handle = clean if clean.startswith("@") else f"@{clean}"
            self.txt_username.setText(handle)

    def apply_pattern_to_table(self):
        pat = self.txt_pattern.text().strip()
        if not pat:
            QMessageBox.warning(self, "Chưa nhập mẫu", "Vui lòng nhập tên mẫu, ví dụ: 'Kênh'")
            return

        for idx, (ch, txt_n, txt_u) in enumerate(self.table_inputs, 1):
            new_n = f"{pat} {idx}" if len(self.table_inputs) > 1 else pat
            txt_n.setText(new_n)

    def save_renames(self):
        if len(self.channels) == 1:
            ch = self.channels[0]
            new_name = self.txt_name.text().strip()
            new_user = self.txt_username.text().strip()
            if not new_name:
                QMessageBox.warning(self, "Thông báo", "Tên kênh không được để trống!")
                return

            if not new_user:
                new_user = new_name if new_name.startswith("@") else f"@{new_name}"
            elif not new_user.startswith("@"):
                new_user = f"@{new_user}"

            db.update_channel(
                channel_id=ch["id"],
                name=new_name,
                username=new_user,
                video_folder=ch.get("video_folder", ""),
                status=ch.get("status", "active"),
                note=ch.get("note", ""),
                network_type=ch.get("network_type", "vpn"),
                proxy_string=ch.get("proxy_string", ""),
                vpn_region=ch.get("vpn_region", ""),
                pia_username=ch.get("pia_username", ""),
                pia_password=ch.get("pia_password", "")
            )
            QMessageBox.information(self, "Thành công", f"Đã đổi tên kênh thành công thành: <b>🎬 @{new_name.lstrip('@')}</b>!")
        else:
            updated_count = 0
            for ch, txt_n, txt_u in self.table_inputs:
                new_name = txt_n.text().strip()
                new_user = txt_u.text().strip()
                if not new_name:
                    continue
                if not new_user:
                    new_user = new_name if new_name.startswith("@") else f"@{new_name}"
                elif not new_user.startswith("@"):
                    new_user = f"@{new_user}"

                db.update_channel(
                    channel_id=ch["id"],
                    name=new_name,
                    username=new_user,
                    video_folder=ch.get("video_folder", ""),
                    status=ch.get("status", "active"),
                    note=ch.get("note", ""),
                    network_type=ch.get("network_type", "vpn"),
                    proxy_string=ch.get("proxy_string", ""),
                    vpn_region=ch.get("vpn_region", ""),
                    pia_username=ch.get("pia_username", ""),
                    pia_password=ch.get("pia_password", "")
                )
                updated_count += 1

            QMessageBox.information(self, "Thành công", f"Đã cập nhật tên mới cho <b>{updated_count}</b> kênh thành công!")

        self.accept()

