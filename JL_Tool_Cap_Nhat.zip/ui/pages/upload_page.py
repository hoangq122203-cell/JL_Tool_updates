import os
from datetime import datetime, timedelta
from pathlib import Path
from typing import List, Dict, Any
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QLineEdit, QFileDialog, QComboBox, QDateEdit, QTimeEdit,
    QSpinBox, QFrame, QTableWidget, QTableWidgetItem, QHeaderView,
    QMessageBox, QScrollArea, QProgressBar, QApplication, QCheckBox,
    QProgressDialog
)
from PySide6.QtCore import Qt, QDate, QTime, Signal, QThread
from database.db_manager import db
from core.scheduler_service import scheduler_service
from core.video_vault import video_vault
from core.video_cropper import CROP_OPTIONS, crop_single_video, batch_crop_folder

SUPPORTED_VIDEO_EXTS = ('.mp4', '.mov', '.mkv', '.webm', '.avi', '.flv', '.wmv', '.m4v', '.ts', '.3gp')

class VideoDropZone(QFrame):
    files_dropped = Signal(list)
    clicked = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAcceptDrops(True)
        self.setCursor(Qt.PointingHandCursor)
        self.set_active_style(False)

    def set_active_style(self, is_active: bool):
        if is_active:
            self.setStyleSheet("""
                QFrame {
                    background-color: #1A2844;
                    border: 2px dashed #00F2FE;
                    border-radius: 16px;
                    padding: 24px;
                }
            """)
        else:
            self.setStyleSheet("""
                QFrame {
                    background-color: #141622;
                    border: 2px dashed #00F2FE;
                    border-radius: 16px;
                    padding: 24px;
                }
                QFrame:hover {
                    background-color: #1A1D2E;
                    border: 2px dashed #FE2C55;
                }
            """)

    def dragEnterEvent(self, event):
        if event.mimeData().hasUrls():
            event.acceptProposedAction()
            self.set_active_style(True)
        else:
            event.ignore()

    def dragMoveEvent(self, event):
        if event.mimeData().hasUrls():
            event.acceptProposedAction()
        else:
            event.ignore()

    def dragLeaveEvent(self, event):
        self.set_active_style(False)
        event.accept()

    def dropEvent(self, event):
        self.set_active_style(False)
        if event.mimeData().hasUrls():
            paths = []
            for url in event.mimeData().urls():
                p = url.toLocalFile()
                if not p:
                    p = url.toString()
                    if p.startswith("file:///"):
                        p = p[8:]
                p = os.path.normpath(p)
                if os.path.isfile(p):
                    if p.lower().endswith(SUPPORTED_VIDEO_EXTS):
                        paths.append(p)
                elif os.path.isdir(p):
                    for root, _, files in os.walk(p):
                        for f in files:
                            if f.lower().endswith(SUPPORTED_VIDEO_EXTS):
                                paths.append(os.path.normpath(os.path.join(root, f)))
            if paths:
                self.files_dropped.emit(paths)
                event.acceptProposedAction()
                return
        event.ignore()

    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            self.clicked.emit()
        super().mousePressEvent(event)

class UploadPage(QWidget):
    request_page = Signal(int)

    def __init__(self):
        super().__init__()
        self.selected_videos: List[str] = []
        self.preview_schedule_data: List[Dict[str, Any]] = []
        self.setAcceptDrops(True)
        self.init_ui()

    def init_ui(self):
        outer_layout = QVBoxLayout(self)
        outer_layout.setContentsMargins(0, 0, 0, 0)

        scroll_area = QScrollArea()
        scroll_area.setWidgetResizable(True)
        scroll_area.setAcceptDrops(True)
        if scroll_area.viewport():
            scroll_area.viewport().setAcceptDrops(True)
        scroll_area.setStyleSheet("QScrollArea { border: none; background-color: #0E0E12; }")

        container = QWidget()
        container.setAcceptDrops(True)
        container.setStyleSheet("background-color: #0E0E12;")
        layout = QVBoxLayout(container)
        layout.setContentsMargins(28, 20, 28, 24)
        layout.setSpacing(16)

        # Header Title
        title_box = QVBoxLayout()
        lbl_title = QLabel("Quản Lý & Chọn File Video Cho Kênh TikTok")
        lbl_title.setProperty("class", "page-title")
        lbl_subtitle = QLabel("📁 Chọn kênh TikTok, kéo thả hoặc chọn các file/thư mục video từ máy tính để phân phối vào kênh")
        lbl_subtitle.setStyleSheet("color: #38BDF8; font-size: 13px; font-weight: 600;")
        title_box.addWidget(lbl_title)
        title_box.addWidget(lbl_subtitle)
        layout.addLayout(title_box)

        # ==================== DROP ZONE KHÔNG GIỚI HẠN SỐ LƯỢNG ====================
        self.drop_zone = VideoDropZone()
        self.drop_zone.files_dropped.connect(self.add_videos_and_auto_schedule)
        self.drop_zone.clicked.connect(self.select_video_files)
        drop_layout = QVBoxLayout(self.drop_zone)
        drop_layout.setAlignment(Qt.AlignCenter)
        drop_layout.setSpacing(8)

        lbl_drop_icon = QLabel("⬆")
        lbl_drop_icon.setAttribute(Qt.WA_TransparentForMouseEvents, True)
        lbl_drop_icon.setStyleSheet("""
            font-size: 24px;
            font-weight: 800;
            color: #38BDF8;
            background-color: #1E293B;
            border: 1px solid #334155;
            border-radius: 24px;
            padding: 8px;
            min-width: 48px;
            max-width: 48px;
            min-height: 48px;
            max-height: 48px;
        """)
        lbl_drop_icon.setAlignment(Qt.AlignCenter)
        drop_layout.addWidget(lbl_drop_icon, alignment=Qt.AlignCenter)

        lbl_drop_main = QLabel("KÉO VÀ THẢ FILE VIDEO HOẶC THƯ MỤC VÀO ĐÂY CHO KÊNH")
        lbl_drop_main.setAttribute(Qt.WA_TransparentForMouseEvents, True)
        lbl_drop_main.setStyleSheet("font-size: 15px; font-weight: 800; color: #FFFFFF; letter-spacing: 0.5px; border: none; background: transparent;")
        lbl_drop_main.setAlignment(Qt.AlignCenter)
        drop_layout.addWidget(lbl_drop_main)

        lbl_drop_sub = QLabel("Tự động nhận diện danh sách video (.mp4, .mov...) và gán chính xác vào các kênh đã chọn")
        lbl_drop_sub.setAttribute(Qt.WA_TransparentForMouseEvents, True)
        lbl_drop_sub.setStyleSheet("font-size: 12px; color: #94A3B8; font-weight: 500; border: none; background: transparent;")
        lbl_drop_sub.setAlignment(Qt.AlignCenter)
        drop_layout.addWidget(lbl_drop_sub)

        # Nút phụ chọn thủ công
        btn_or_row = QHBoxLayout()
        btn_or_row.addStretch()
        self.btn_manual_select = QPushButton("Hoặc bấm để chọn danh sách video từ ổ cứng...")
        self.btn_manual_select.setProperty("class", "btn-secondary")
        self.btn_manual_select.clicked.connect(self.select_video_files)
        btn_or_row.addWidget(self.btn_manual_select)

        self.btn_folder_select = QPushButton("📁 Chọn cả thư mục video...")
        self.btn_folder_select.setProperty("class", "btn-secondary")
        self.btn_folder_select.clicked.connect(self.select_video_folder)
        btn_or_row.addWidget(self.btn_folder_select)

        btn_or_row.addStretch()
        drop_layout.addLayout(btn_or_row)

        layout.addWidget(self.drop_zone)

        # ==================== CẤU HÌNH PHÂN PHỐI KÊNH & LỊCH NGÀY ====================
        config_bar = QFrame()
        config_bar.setObjectName("config_bar")
        config_bar.setStyleSheet("""
            QFrame#config_bar {
                background-color: #14151D;
                border: 1px solid #242533;
                border-radius: 12px;
            }
        """)
        bar_layout = QVBoxLayout(config_bar)
        bar_layout.setContentsMargins(16, 14, 16, 14)
        bar_layout.setSpacing(12)

        cmb_style = """
            QComboBox {
                background-color: #0A0B10;
                color: #FFFFFF;
                border: 1px solid #2B3654;
                border-radius: 6px;
                padding: 5px 12px;
                font-size: 12px;
                font-weight: 600;
            }
            QComboBox:hover {
                border-color: #38476E;
                background-color: #111420;
            }
            QComboBox QAbstractItemView {
                background-color: #131826;
                color: #FFFFFF;
                selection-background-color: #2563EB;
                selection-color: #FFFFFF;
                border: 1px solid #2B3654;
                border-radius: 6px;
                padding: 4px;
            }
        """

        dt_style = """
            QDateEdit, QTimeEdit {
                background-color: #0A0B10;
                color: #FFFFFF;
                border: 1px solid #2B3654;
                border-radius: 6px;
                padding: 5px 8px;
                font-size: 12px;
                font-weight: 600;
            }
            QDateEdit:hover, QTimeEdit:hover {
                border-color: #38476E;
            }
        """

        # Hàng 1: Phân phối kênh & Kiểu hẹn giờ
        row1 = QHBoxLayout()
        row1.setSpacing(14)

        lbl_c_mode = QLabel("🎯 Phân phối kênh:")
        lbl_c_mode.setStyleSheet("color: #FFFFFF; font-weight: 600; font-size: 12px;")
        row1.addWidget(lbl_c_mode)

        self.cmb_channel_mode = QComboBox()
        self.cmb_channel_mode.setStyleSheet(cmb_style)
        self.cmb_channel_mode.addItem("🔄 Xoay vòng phân bổ đều cho các kênh đã tích chọn", "round_robin")
        self.cmb_channel_mode.addItem("🌐 Đăng đồng loạt lên TẤT CẢ các kênh đã tích chọn", "all_channels")
        self.cmb_channel_mode.currentIndexChanged.connect(self.on_config_changed)
        row1.addWidget(self.cmb_channel_mode)

        lbl_s_type = QLabel("⏱️ Kiểu hẹn lịch:")
        lbl_s_type.setStyleSheet("color: #FFFFFF; font-weight: 600; font-size: 12px;")
        row1.addWidget(lbl_s_type)

        self.cmb_schedule_type = QComboBox()
        self.cmb_schedule_type.setStyleSheet(cmb_style)
        self.cmb_schedule_type.addItem("📅 Đăng theo ngày (Cùng giờ bắt đầu mỗi ngày, cách nhau 30 phút)", "daily_batch")
        self.cmb_schedule_type.addItem("⚡ Đăng liên tục trong 1 ngày (Chọn số video đăng, cách nhau 30 phút)", "continuous_day")
        self.cmb_schedule_type.addItem("🚀 Đăng toàn bộ video liên tục (Cách nhau 30 phút)", "all_continuous")
        self.cmb_schedule_type.currentIndexChanged.connect(self.on_schedule_type_changed)
        row1.addWidget(self.cmb_schedule_type)

        row1.addStretch()
        bar_layout.addLayout(row1)

        # Hàng 2: Thời gian bắt đầu, Số video đăng mỗi ngày, Khoảng cách phút (Mặc định 30 phút) và Hashtags
        row2 = QHBoxLayout()
        row2.setSpacing(10)

        lbl_d_start = QLabel("📅 Ngày bắt đầu:")
        lbl_d_start.setStyleSheet("color: #FFFFFF; font-weight: 600; font-size: 12px;")
        row2.addWidget(lbl_d_start)

        self.date_start = QDateEdit()
        self.date_start.setStyleSheet(dt_style)
        self.date_start.setDate(QDate.currentDate())
        self.date_start.setCalendarPopup(True)
        self.date_start.setFixedWidth(115)
        self.date_start.dateChanged.connect(self.on_config_changed)
        row2.addWidget(self.date_start)

        lbl_t_start = QLabel("⏰ Giờ bắt đầu:")
        lbl_t_start.setStyleSheet("color: #FFFFFF; font-weight: 600; font-size: 12px;")
        row2.addWidget(lbl_t_start)

        self.time_start = QTimeEdit()
        self.time_start.setStyleSheet(dt_style)
        cur_time = QTime.currentTime().addSecs(60)
        self.time_start.setTime(cur_time)
        self.time_start.setDisplayFormat("HH:mm")
        self.time_start.setFixedWidth(85)
        self.time_start.timeChanged.connect(self.on_config_changed)
        row2.addWidget(self.time_start)

        # MỤC LỰA CHỌN: SỐ VIDEO ĐĂNG MỖI NGÀY
        self.lbl_num_videos = QLabel("🎬 Số video mỗi ngày:")
        self.lbl_num_videos.setStyleSheet("font-weight: 700; color: #F59E0B; font-size: 12px;")
        row2.addWidget(self.lbl_num_videos)

        self.spn_limit_videos = QSpinBox()
        self.spn_limit_videos.setRange(1, 1000)
        self.spn_limit_videos.setValue(2)  # Mặc định 2 video / ngày
        self.spn_limit_videos.setSuffix(" video / ngày")
        self.spn_limit_videos.setFixedWidth(120)
        self.spn_limit_videos.setStyleSheet("""
            QSpinBox {
                background-color: #0A0B10;
                color: #F59E0B;
                border: 1px solid #D97706;
                border-radius: 6px;
                padding: 5px 8px;
                font-size: 12px;
                font-weight: 700;
            }
        """)
        self.spn_limit_videos.setToolTip("Số lượng video tool sẽ đăng mỗi ngày (ví dụ: 1, 2, 3, 5 video...)")
        self.spn_limit_videos.valueChanged.connect(self.on_config_changed)
        row2.addWidget(self.spn_limit_videos)

        # Khoảng cách giữa các video: MẶC ĐỊNH 30 PHÚT THEO YÊU CẦU
        self.lbl_interval = QLabel("⏳ Khoảng cách:")
        self.lbl_interval.setStyleSheet("font-weight: 700; color: #38BDF8; font-size: 12px;")
        row2.addWidget(self.lbl_interval)

        self.spn_interval_minutes = QSpinBox()
        self.spn_interval_minutes.setRange(1, 1440)
        self.spn_interval_minutes.setValue(30)  # MẶC ĐỊNH 30 PHÚT
        self.spn_interval_minutes.setSuffix(" phút")
        self.spn_interval_minutes.setFixedWidth(105)
        self.spn_interval_minutes.setStyleSheet("""
            QSpinBox {
                background-color: #0A0B10;
                color: #38BDF8;
                border: 1px solid #2563EB;
                border-radius: 6px;
                padding: 5px 8px;
                font-size: 12px;
                font-weight: 700;
            }
        """)
        self.spn_interval_minutes.setToolTip("Khoảng cách thời gian giữa mỗi video (mặc định cách nhau 30 phút)")
        self.spn_interval_minutes.valueChanged.connect(self.on_config_changed)
        row2.addWidget(self.spn_interval_minutes)

        # Nút chọn nhanh khoảng cách 30 phút, 15 phút, 1 giờ, 1 phút
        btn_int_30 = QPushButton("30p")
        btn_int_30.setToolTip("Đặt khoảng cách cách nhau 30 phút")
        btn_int_30.setStyleSheet("background-color: #1E2838; color: #38BDF8; border: 1px solid #2B3A55; border-radius: 4px; padding: 4px 8px; font-weight: 700; font-size: 11px;")
        btn_int_30.setCursor(Qt.PointingHandCursor)
        btn_int_30.clicked.connect(lambda: self.spn_interval_minutes.setValue(30))
        row2.addWidget(btn_int_30)

        btn_int_15 = QPushButton("15p")
        btn_int_15.setToolTip("Đặt khoảng cách cách nhau 15 phút")
        btn_int_15.setStyleSheet("background-color: #1A1F2E; color: #94A3B8; border: 1px solid #283044; border-radius: 4px; padding: 4px 6px; font-size: 11px;")
        btn_int_15.setCursor(Qt.PointingHandCursor)
        btn_int_15.clicked.connect(lambda: self.spn_interval_minutes.setValue(15))
        row2.addWidget(btn_int_15)

        btn_int_60 = QPushButton("1h")
        btn_int_60.setToolTip("Đặt khoảng cách cách nhau 1 giờ (60 phút)")
        btn_int_60.setStyleSheet("background-color: #1A1F2E; color: #94A3B8; border: 1px solid #283044; border-radius: 4px; padding: 4px 6px; font-size: 11px;")
        btn_int_60.setCursor(Qt.PointingHandCursor)
        btn_int_60.clicked.connect(lambda: self.spn_interval_minutes.setValue(60))
        row2.addWidget(btn_int_60)

        lbl_htag = QLabel("Hashtags:")
        lbl_htag.setStyleSheet("color: #FFFFFF; font-weight: 600; font-size: 12px;")
        row2.addWidget(lbl_htag)

        self.txt_hashtags = QLineEdit()
        self.txt_hashtags.setPlaceholderText("#fyp #trending (tùy chọn)")
        self.txt_hashtags.setStyleSheet("""
            QLineEdit {
                background-color: #0A0B10;
                color: #FFFFFF;
                border: 1px solid #2B3654;
                border-radius: 6px;
                padding: 5px 10px;
                font-size: 12px;
            }
            QLineEdit:focus {
                border-color: #38BDF8;
            }
        """)
        self.txt_hashtags.textChanged.connect(self.on_config_changed)
        row2.addWidget(self.txt_hashtags, 1)

        bar_layout.addLayout(row2)

        # Hàng 3: PHẦN TÍCH CHỌN CÁC KÊNH NHẬN ĐĂNG VIDEO (YÊU CẦU TRỌNG TÂM)
        channel_box = QFrame()
        channel_box.setStyleSheet("background-color: #0E131F; border: 1px solid #1E293F; border-radius: 8px;")
        channel_vlayout = QVBoxLayout(channel_box)
        channel_vlayout.setContentsMargins(12, 10, 12, 10)
        channel_vlayout.setSpacing(8)

        ch_header = QHBoxLayout()
        lbl_ch_title = QLabel("🎯 Tích chọn kênh TikTok muốn nhận / gắn video (Tích kênh nào thì video sẽ gắn vào kênh đó):")
        lbl_ch_title.setStyleSheet("color: #FFFFFF; font-weight: 700; font-size: 12px; border: none; background: transparent;")
        ch_header.addWidget(lbl_ch_title)
        ch_header.addStretch()

        btn_select_all_ch = QPushButton("✓ Chọn tất cả kênh")
        btn_select_all_ch.setStyleSheet("background-color: #1E293B; color: #38BDF8; border: 1px solid #334155; border-radius: 4px; padding: 4px 10px; font-size: 11px; font-weight: 700;")
        btn_select_all_ch.setCursor(Qt.PointingHandCursor)
        btn_select_all_ch.clicked.connect(self.select_all_channels)
        ch_header.addWidget(btn_select_all_ch)

        btn_unselect_all_ch = QPushButton("Bỏ chọn")
        btn_unselect_all_ch.setStyleSheet("background-color: #1E293B; color: #94A3B8; border: 1px solid #334155; border-radius: 4px; padding: 4px 10px; font-size: 11px;")
        btn_unselect_all_ch.setCursor(Qt.PointingHandCursor)
        btn_unselect_all_ch.clicked.connect(self.unselect_all_channels)
        ch_header.addWidget(btn_unselect_all_ch)

        channel_vlayout.addLayout(ch_header)

        # Scrollable chứa danh sách các kênh để tích chọn
        ch_scroll = QScrollArea()
        ch_scroll.setWidgetResizable(True)
        ch_scroll.setFrameShape(QFrame.NoFrame)
        ch_scroll.setStyleSheet("background: transparent; border: none;")
        ch_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        ch_scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        ch_scroll.setFixedHeight(48)

        self.channel_chips_widget = QWidget()
        self.channel_chips_widget.setStyleSheet("background: transparent; border: none;")
        self.channel_chips_layout = QHBoxLayout(self.channel_chips_widget)
        self.channel_chips_layout.setContentsMargins(4, 2, 4, 2)
        self.channel_chips_layout.setSpacing(10)
        self.channel_checkboxes = []

        ch_scroll.setWidget(self.channel_chips_widget)
        channel_vlayout.addWidget(ch_scroll)
        bar_layout.addWidget(channel_box)
        layout.addWidget(config_bar)

        # ==================== BẢNG XEM TRƯỚC TIẾN ĐỘ HÀNG NGHÌN VIDEO ====================
        preview_box = QFrame()
        preview_box.setObjectName("preview_box")
        preview_box.setStyleSheet("""
            QFrame#preview_box {
                background-color: #14151D;
                border: 1px solid #242533;
                border-radius: 12px;
            }
        """)
        p_layout = QVBoxLayout(preview_box)
        p_layout.setContentsMargins(16, 14, 16, 16)
        p_layout.setSpacing(12)

        p_header_row = QHBoxLayout()
        self.lbl_schedule_title = QLabel("📁 DANH SÁCH FILE VIDEO ĐƯỢC CHỌN CHO CÁC KÊNH")
        self.lbl_schedule_title.setStyleSheet("font-weight: 800; color: #FFFFFF; font-size: 13px; border: none; background: transparent;")
        p_header_row.addWidget(self.lbl_schedule_title)
        p_header_row.addStretch()

        self.btn_clear = QPushButton("🗑️ Xóa danh sách")
        self.btn_clear.setMinimumHeight(40)
        self.btn_clear.setCursor(Qt.PointingHandCursor)
        self.btn_clear.setStyleSheet("""
            QPushButton {
                background-color: #1C2337;
                color: #E2E8F0;
                border: 1px solid #2B3654;
                border-radius: 6px;
                padding: 4px 14px;
                font-weight: 600;
                font-size: 12px;
            }
            QPushButton:hover {
                background-color: #242E48;
                border-color: #38476E;
                color: #FFFFFF;
            }
        """)
        self.btn_clear.clicked.connect(self.clear_all)
        p_header_row.addWidget(self.btn_clear)

        self.btn_confirm_schedule = QPushButton("💾 LƯU FILE & HẸN LỊCH ĐĂNG CHO KÊNH")
        self.btn_confirm_schedule.setMinimumHeight(40)
        self.btn_confirm_schedule.setMinimumWidth(270)
        self.btn_confirm_schedule.setCursor(Qt.PointingHandCursor)
        self.btn_confirm_schedule.setStyleSheet("""
            QPushButton {
                background-color: #2563EB;
                color: #FFFFFF;
                border: 1px solid #3B82F6;
                border-radius: 6px;
                padding: 4px 18px;
                font-weight: 700;
                font-size: 12px;
            }
            QPushButton:hover {
                background-color: #1D4ED8;
                border-color: #60A5FA;
            }
            QPushButton:pressed {
                background-color: #1E40AF;
            }
        """)
        self.btn_confirm_schedule.clicked.connect(self.save_and_activate_schedule)
        p_header_row.addWidget(self.btn_confirm_schedule)

        p_layout.addLayout(p_header_row)

        self.table_preview = QTableWidget()
        self.table_preview.setColumnCount(5)
        self.table_preview.setHorizontalHeaderLabels([
            "STT", "Tên Video Nguồn", "Caption Đăng (Tên File)", "Kênh TikTok Nhận Đăng", "Thời Gian Đăng (Ngày & Giờ)"
        ])
        p_header = self.table_preview.horizontalHeader()
        p_header.setSectionResizeMode(0, QHeaderView.Fixed)
        self.table_preview.setColumnWidth(0, 48)

        p_header.setSectionResizeMode(1, QHeaderView.Stretch)
        p_header.setSectionResizeMode(2, QHeaderView.Stretch)

        p_header.setSectionResizeMode(3, QHeaderView.Fixed)
        self.table_preview.setColumnWidth(3, 175)

        p_header.setSectionResizeMode(4, QHeaderView.Fixed)
        self.table_preview.setColumnWidth(4, 195)

        self.table_preview.verticalHeader().setDefaultSectionSize(40)
        self.table_preview.verticalHeader().setVisible(False)
        self.table_preview.setMinimumHeight(300)
        self.table_preview.setSelectionBehavior(QTableWidget.SelectRows)
        self.table_preview.setEditTriggers(QTableWidget.NoEditTriggers)
        p_layout.addWidget(self.table_preview)

        # Thanh hành động phía dưới bảng (Chữ to rõ, không bao giờ bị bẹp dính chữ)
        bottom_bar = QHBoxLayout()
        self.lbl_queue_stats = QLabel("⚡ Danh sách đang chờ nạp video...")
        self.lbl_queue_stats.setStyleSheet("color: #94A3B8; font-size: 12px; font-weight: 600; border: none; background: transparent;")
        bottom_bar.addWidget(self.lbl_queue_stats)
        bottom_bar.addStretch()

        self.btn_confirm_schedule_bottom = QPushButton("💾 LƯU FILE & HẸN LỊCH ĐĂNG CHO KÊNH")
        self.btn_confirm_schedule_bottom.setFixedHeight(40)
        self.btn_confirm_schedule_bottom.setMinimumWidth(300)
        self.btn_confirm_schedule_bottom.setCursor(Qt.PointingHandCursor)
        self.btn_confirm_schedule_bottom.setStyleSheet("""
            QPushButton {
                background-color: #2563EB;
                color: #FFFFFF;
                border: 1px solid #3B82F6;
                border-radius: 6px;
                padding: 8px 24px;
                font-weight: 700;
                font-size: 13px;
            }
            QPushButton:hover {
                background-color: #1D4ED8;
                border-color: #60A5FA;
            }
            QPushButton:pressed {
                background-color: #1E40AF;
            }
        """)
        self.btn_confirm_schedule_bottom.clicked.connect(self.save_and_activate_schedule)
        bottom_bar.addWidget(self.btn_confirm_schedule_bottom)
        p_layout.addLayout(bottom_bar)

        layout.addWidget(preview_box)

        scroll_area.setWidget(container)
        outer_layout.addWidget(scroll_area)

        self.load_channels_list()

    def load_channels_list(self):
        """Nạp danh sách các kênh TikTok vào phần tích chọn kênh đăng video"""
        # Xóa các checkbox kênh cũ nếu có
        while self.channel_chips_layout.count():
            item = self.channel_chips_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        self.channel_checkboxes.clear()

        channels = db.get_all_channels()
        status_map = db.get_channels_video_schedule_status()
        chk_ch_style = """
            QCheckBox {
                color: #FFFFFF;
                font-size: 12px;
                font-weight: 700;
                background-color: #141A2D;
                border: 1.5px solid #28344E;
                border-radius: 6px;
                padding: 6px 14px;
                spacing: 8px;
            }
            QCheckBox:hover {
                border-color: #38BDF8;
                background-color: #1A243E;
            }
            QCheckBox:checked {
                color: #38BDF8;
                border-color: #2563EB;
                background-color: #1E2E4E;
            }
        """

        if not channels:
            lbl_empty = QLabel("⚠️ Chưa có kênh TikTok nào trong tool. Vui lòng vào trang 'Quản lý kênh' để thêm!")
            lbl_empty.setStyleSheet("color: #F87171; font-size: 12px; font-weight: 600; border: none; background: transparent;")
            self.channel_chips_layout.addWidget(lbl_empty)
        else:
            saved_country = db.get_setting("global_vpn_country_name", "Philippines")
            c_clean = saved_country
            for p in ["🇻🇳", "🇯🇵", "🇰🇷", "🇸🇬", "🇹🇼", "🇭🇰", "🇹🇭", "🇲🇾", "🇮🇩", "🇵🇭", "🇮🇳", "🇦🇺", "🇺🇸", "🇨🇦", "🇬🇧", "🇩🇪", "🇫🇷", "🇳🇱"]:
                c_clean = c_clean.replace(p, "").strip()
            if "(" in c_clean:
                c_clean = c_clean.split("(")[0].strip()
            if not c_clean or c_clean == "VPN":
                c_clean = "Philippines"

            cached_fake_ip = db.get_setting("cached_fake_ip", "")

            for ch in channels:
                c_name = str(ch.get("name", "Kênh")).strip()
                c_user = str(ch.get("username", "") or "").strip()
                c_clean_name = c_name.lstrip("@")
                c_clean_user = c_user.lstrip("@")

                if c_clean_user and c_clean_name.lower() != c_clean_user.lower():
                    display_label = f"🎬 {c_name} (@{c_clean_user})"
                else:
                    display_label = f"🎬 @{c_clean_name}"

                use_vpn = bool(ch.get("use_vpn", 1))
                net_type = ch.get("network_type", "vpn")
                if net_type == "proxy" and ch.get("proxy_string"):
                    vpn_tag = "🛡️ Proxy"
                elif use_vpn:
                    if cached_fake_ip and cached_fake_ip not in ["Chưa fake", "Đang quét...", ""]:
                        vpn_tag = f"🛡️ IP: {c_clean} ({cached_fake_ip})"
                    else:
                        vpn_tag = f"🛡️ IP: {c_clean}"
                else:
                    vpn_tag = "🌐 IP Gốc"

                st = "🟢" if ch.get("is_logged_in") else "⚪"
                cid = ch["id"]
                sched_st = status_map.get(cid, {})
                sched_badge = sched_st.get("badge_short", "🔴 Hết video")

                chk = QCheckBox(f"{st} {display_label} — [{sched_badge}] [{vpn_tag}]")
                chk.setToolTip(f"{display_label}\n{sched_st.get('tooltip', '')}")
                chk.setStyleSheet(chk_ch_style)
                chk.setCursor(Qt.PointingHandCursor)
                chk.setChecked(True)  # Mặc định tích chọn tất cả kênh
                chk.stateChanged.connect(self.on_config_changed)
                self.channel_chips_layout.addWidget(chk)
                self.channel_checkboxes.append((chk, ch))

        self.channel_chips_layout.addStretch()

    def select_all_channels(self):
        """Tích chọn toàn bộ kênh"""
        for chk, _ in self.channel_checkboxes:
            chk.blockSignals(True)
            chk.setChecked(True)
            chk.blockSignals(False)
        self.on_config_changed()

    def unselect_all_channels(self):
        """Bỏ tích toàn bộ kênh"""
        for chk, _ in self.channel_checkboxes:
            chk.blockSignals(True)
            chk.setChecked(False)
            chk.blockSignals(False)
        self.on_config_changed()

    def get_selected_channels(self) -> List[dict]:
        """Lấy danh sách các kênh TikTok được người dùng tích chọn"""
        return [ch for chk, ch in self.channel_checkboxes if chk.isChecked()]

    def on_schedule_type_changed(self):
        st = self.cmb_schedule_type.currentData()
        if st == "continuous_day":
            self.lbl_num_videos.setText("🎬 Số video đăng hôm nay:")
            self.lbl_num_videos.setVisible(True)
            self.spn_limit_videos.setVisible(True)
        elif st == "daily_batch":
            self.lbl_num_videos.setText("🎬 Số video mỗi ngày:")
            self.lbl_num_videos.setVisible(True)
            self.spn_limit_videos.setVisible(True)
        else:  # all_continuous
            self.lbl_num_videos.setVisible(False)
            self.spn_limit_videos.setVisible(False)

        self.on_config_changed()

    def on_config_changed(self):
        if self.selected_videos:
            self.auto_generate_schedule()

    # ==================== KÉO THẢ TỰ ĐỘNG KHÔNG GIỚI HẠN ====================
    def dragEnterEvent(self, event):
        if event.mimeData().hasUrls():
            event.acceptProposedAction()
            if hasattr(self, 'drop_zone'):
                self.drop_zone.set_active_style(True)
        else:
            event.ignore()

    def dragMoveEvent(self, event):
        if event.mimeData().hasUrls():
            event.acceptProposedAction()
        else:
            event.ignore()

    def dragLeaveEvent(self, event):
        if hasattr(self, 'drop_zone'):
            self.drop_zone.set_active_style(False)
        event.accept()

    def dropEvent(self, event):
        if hasattr(self, 'drop_zone'):
            self.drop_zone.set_active_style(False)
        if event.mimeData().hasUrls():
            paths = []
            for url in event.mimeData().urls():
                p = url.toLocalFile()
                if not p:
                    p = url.toString()
                    if p.startswith("file:///"):
                        p = p[8:]
                p = os.path.normpath(p)
                if os.path.isfile(p):
                    if p.lower().endswith(SUPPORTED_VIDEO_EXTS):
                        paths.append(p)
                elif os.path.isdir(p):
                    for root, _, files in os.walk(p):
                        for f in files:
                            if f.lower().endswith(SUPPORTED_VIDEO_EXTS):
                                paths.append(os.path.normpath(os.path.join(root, f)))

            if paths:
                self.add_videos_and_auto_schedule(paths)
                event.acceptProposedAction()
                return
        event.ignore()

    def select_video_files(self):
        ext_str = " ".join([f"*{ext}" for ext in SUPPORTED_VIDEO_EXTS])
        files, _ = QFileDialog.getOpenFileNames(
            self, "Chọn danh sách file Video", "", f"Video Files ({ext_str});;All Files (*)"
        )
        if files:
            self.add_videos_and_auto_schedule(files)

    def select_video_folder(self):
        folder = QFileDialog.getExistingDirectory(self, "Chọn thư mục chứa Video")
        if folder:
            paths = []
            for root, _, files in os.walk(folder):
                for f in files:
                    if f.lower().endswith(SUPPORTED_VIDEO_EXTS):
                        paths.append(os.path.normpath(os.path.join(root, f)))
            if paths:
                self.add_videos_and_auto_schedule(paths)

    def add_videos_and_auto_schedule(self, new_paths: List[str]):
        # Bổ sung video mới không giới hạn số lượng
        added_count = 0
        for p in new_paths:
            norm_p = os.path.normpath(p)
            if norm_p not in self.selected_videos:
                self.selected_videos.append(norm_p)
                added_count += 1

        self.auto_generate_schedule()

    def clear_all(self):
        self.selected_videos.clear()
        self.preview_schedule_data.clear()
        self.table_preview.clearContents()
        self.table_preview.setRowCount(0)
        self.lbl_schedule_title.setText("📅 KẾ HOẠCH HẸN GIỜ ĐĂNG VIDEO")
        if hasattr(self, "lbl_queue_stats"):
            self.lbl_queue_stats.setText("⚡ Danh sách đang chờ nạp video...")

    # ==================== TỰ ĐỘNG PHÂN PHỔI KHÔNG GIỚI HẠN KÊNH & VIDEO ====================
    def auto_generate_schedule(self):
        if not self.selected_videos:
            self.preview_schedule_data = []
            self.render_preview_table()
            self.lbl_schedule_title.setText("📅 KẾ HOẠCH HẸN GIỜ ĐĂNG VIDEO (CHỜ THẢ VIDEO VÀO)")
            if hasattr(self, "lbl_queue_stats"):
                self.lbl_queue_stats.setText("⚡ Danh sách đang chờ nạp video...")
            return

        target_channels = self.get_selected_channels()
        hashtags_str = self.txt_hashtags.text().strip()

        if not target_channels:
            # VẪN HIỂN THỊ CÁC VIDEO ĐÃ KÉO THẢ VÀO BẢNG ĐỂ NGƯỜI DÙNG THẤY NGAY
            self.preview_schedule_data = []
            for video_path in self.selected_videos:
                video_name = os.path.splitext(os.path.basename(video_path))[0]
                full_caption = f"{video_name} {hashtags_str}".strip()
                self.preview_schedule_data.append({
                    "video_path": video_path,
                    "video_title": video_name,
                    "caption": full_caption,
                    "hashtags": hashtags_str,
                    "channel_id": 0,
                    "channel_name": "⚠️ Hãy tích chọn kênh ở trên",
                    "scheduled_time": "Chờ chọn kênh"
                })
            self.render_preview_table()
            self.lbl_schedule_title.setText(f"📁 ĐÃ NẠP {len(self.selected_videos)} VIDEO (⚠️ HÃY TÍCH CHỌN ÍT NHẤT 1 KÊNH Ở TRÊN ĐỂ HẸN GIỜ)")
            if hasattr(self, "lbl_queue_stats"):
                self.lbl_queue_stats.setText(f"⚠️ Đã nạp thành công {len(self.selected_videos)} video vào hệ thống. Vui lòng tích chọn kênh TikTok ở trên.")
            return

        mode = self.cmb_channel_mode.currentData()  # "round_robin" or "all_channels"
        schedule_type = self.cmb_schedule_type.currentData()
        start_qdate = self.date_start.date()
        start_qtime = self.time_start.time()
        start_dt = datetime(
            start_qdate.year(), start_qdate.month(), start_qdate.day(),
            start_qtime.hour(), start_qtime.minute(), 0
        )
        interval_mins = max(1, self.spn_interval_minutes.value())
        limit_vids = self.spn_limit_videos.value()
        hashtags_str = self.txt_hashtags.text().strip()
        self.preview_schedule_data = []

        if schedule_type == "continuous_day":
            # ĐĂNG LIÊN TỤC TRONG 1 NGÀY: Lấy đúng số lượng video đã chọn hôm nay
            vids_to_post = self.selected_videos[:limit_vids]

            if mode == "all_channels":
                for ch in target_channels:
                    for index, video_path in enumerate(vids_to_post):
                        post_time = start_dt + timedelta(minutes=index * interval_mins)
                        video_name = os.path.splitext(os.path.basename(video_path))[0]
                        full_caption = f"{video_name} {hashtags_str}".strip()

                        self.preview_schedule_data.append({
                            "video_path": video_path,
                            "video_title": video_name,
                            "caption": full_caption,
                            "hashtags": hashtags_str,
                            "channel_id": ch["id"],
                            "channel_name": ch["name"],
                            "scheduled_time": post_time.strftime("%Y-%m-%d %H:%M:%S")
                        })
            else:
                for index, video_path in enumerate(vids_to_post):
                    post_time = start_dt + timedelta(minutes=index * interval_mins)
                    assigned_channel = target_channels[index % len(target_channels)]
                    video_name = os.path.splitext(os.path.basename(video_path))[0]
                    full_caption = f"{video_name} {hashtags_str}".strip()

                    self.preview_schedule_data.append({
                        "video_path": video_path,
                        "video_title": video_name,
                        "caption": full_caption,
                        "hashtags": hashtags_str,
                        "channel_id": assigned_channel["id"],
                        "channel_name": assigned_channel["name"],
                        "scheduled_time": post_time.strftime("%Y-%m-%d %H:%M:%S")
                    })

            self.lbl_schedule_title.setText(
                f"⚡ ĐÃ CHỌN ĐĂNG LIÊN TỤC {len(vids_to_post)} VIDEO HÔM NAY ({len(self.preview_schedule_data)} lượt đăng - CÁCH NHAU {interval_mins} PHÚT - BẮT ĐẦU: {start_dt.strftime('%H:%M %d/%m/%Y')})"
            )
            if hasattr(self, "lbl_queue_stats"):
                ch_names_str = ", ".join([f"@{c.get('name', '').lstrip('@')}" for c in target_channels])
                self.lbl_queue_stats.setText(f"🎯 Kênh nhận đăng ({len(target_channels)}): {ch_names_str} | Cách nhau {interval_mins} phút")

        elif schedule_type == "daily_batch":
            # ĐĂNG THEO NGÀY: GIỜ BẮT ĐẦU VÀ CÁC MỐC GIỜ ĐĂNG CÁC NGÀY SAU ĐỀU NHƯ NHAU!
            vids_per_day = max(1, limit_vids)
            total_days = (len(self.selected_videos) + vids_per_day - 1) // vids_per_day
            sh = start_qtime.hour()
            sm = start_qtime.minute()

            if mode == "all_channels":
                for ch in target_channels:
                    for index, video_path in enumerate(self.selected_videos):
                        day_offset = index // vids_per_day
                        slot_in_day = index % vids_per_day
                        post_date = start_dt.date() + timedelta(days=day_offset)
                        base_start = datetime(post_date.year, post_date.month, post_date.day, sh, sm, 0)
                        scheduled_datetime = base_start + timedelta(minutes=slot_in_day * interval_mins)

                        video_name = os.path.splitext(os.path.basename(video_path))[0]
                        full_caption = f"{video_name} {hashtags_str}".strip()

                        self.preview_schedule_data.append({
                            "video_path": video_path,
                            "video_title": video_name,
                            "caption": full_caption,
                            "hashtags": hashtags_str,
                            "channel_id": ch["id"],
                            "channel_name": ch["name"],
                            "scheduled_time": scheduled_datetime.strftime("%Y-%m-%d %H:%M:%S")
                        })
            else:
                for index, video_path in enumerate(self.selected_videos):
                    day_offset = index // vids_per_day
                    slot_in_day = index % vids_per_day
                    post_date = start_dt.date() + timedelta(days=day_offset)
                    base_start = datetime(post_date.year, post_date.month, post_date.day, sh, sm, 0)
                    scheduled_datetime = base_start + timedelta(minutes=slot_in_day * interval_mins)

                    assigned_channel = target_channels[index % len(target_channels)]
                    video_name = os.path.splitext(os.path.basename(video_path))[0]
                    full_caption = f"{video_name} {hashtags_str}".strip()

                    self.preview_schedule_data.append({
                        "video_path": video_path,
                        "video_title": video_name,
                        "caption": full_caption,
                        "hashtags": hashtags_str,
                        "channel_id": assigned_channel["id"],
                        "channel_name": assigned_channel["name"],
                        "scheduled_time": scheduled_datetime.strftime("%Y-%m-%d %H:%M:%S")
                    })

            self.lbl_schedule_title.setText(
                f"📅 ĐÃ CHỌN ĐĂNG {len(self.selected_videos)} VIDEO (MỖI NGÀY {vids_per_day} VIDEO VÀO CÙNG GIỜ BẮT ĐẦU {sh:02d}:{sm:02d} - TRONG {total_days} NGÀY)"
            )
            if hasattr(self, "lbl_queue_stats"):
                ch_names_str = ", ".join([f"@{c.get('name', '').lstrip('@')}" for c in target_channels])
                self.lbl_queue_stats.setText(f"🎯 Kênh nhận đăng ({len(target_channels)}): {ch_names_str} | Tổng {len(self.preview_schedule_data)} lượt hẹn lịch")

        else:  # all_continuous
            # ĐĂNG TOÀN BỘ VIDEO LIÊN TỤC (Cách nhau X phút)
            if mode == "all_channels":
                for ch in target_channels:
                    for index, video_path in enumerate(self.selected_videos):
                        post_time = start_dt + timedelta(minutes=index * interval_mins)
                        video_name = os.path.splitext(os.path.basename(video_path))[0]
                        full_caption = f"{video_name} {hashtags_str}".strip()

                        self.preview_schedule_data.append({
                            "video_path": video_path,
                            "video_title": video_name,
                            "caption": full_caption,
                            "hashtags": hashtags_str,
                            "channel_id": ch["id"],
                            "channel_name": ch["name"],
                            "scheduled_time": post_time.strftime("%Y-%m-%d %H:%M:%S")
                        })
            else:
                for index, video_path in enumerate(self.selected_videos):
                    post_time = start_dt + timedelta(minutes=index * interval_mins)
                    assigned_channel = target_channels[index % len(target_channels)]
                    video_name = os.path.splitext(os.path.basename(video_path))[0]
                    full_caption = f"{video_name} {hashtags_str}".strip()

                    self.preview_schedule_data.append({
                        "video_path": video_path,
                        "video_title": video_name,
                        "caption": full_caption,
                        "hashtags": hashtags_str,
                        "channel_id": assigned_channel["id"],
                        "channel_name": assigned_channel["name"],
                        "scheduled_time": post_time.strftime("%Y-%m-%d %H:%M:%S")
                    })

            self.lbl_schedule_title.setText(f"📅 KẾ HOẠCH HẸN GIỜ ({len(self.preview_schedule_data)} video)")
            if hasattr(self, "lbl_queue_stats"):
                ch_names_str = ", ".join([f"@{c.get('name', '').lstrip('@')}" for c in target_channels])
                self.lbl_queue_stats.setText(f"🚀 Đăng {len(self.preview_schedule_data)} lượt liên tục (cách nhau {interval_mins} phút/video - Kênh: {ch_names_str})")

        self.render_preview_table()

    def render_preview_table(self):
        """Hiển thị danh sách xem trước toàn bộ các video sẽ được đăng theo lịch"""
        self.table_preview.clearContents()
        self.table_preview.setRowCount(len(self.preview_schedule_data))
        for row, item in enumerate(self.preview_schedule_data):
            # Cột 0: STT
            stt_item = QTableWidgetItem(str(row + 1))
            stt_item.setTextAlignment(Qt.AlignCenter)
            self.table_preview.setItem(row, 0, stt_item)

            # Cột 1: Tên Video Nguồn
            self.table_preview.setItem(row, 1, QTableWidgetItem(item.get("video_title", "")))

            # Cột 2: Caption Đăng
            self.table_preview.setItem(row, 2, QTableWidgetItem(item.get("caption", "")))

            # Cột 3: Kênh TikTok Nhận Đăng
            ch_raw = str(item.get("channel_name", "") or "").strip()
            if ch_raw.startswith("⚠️"):
                ch_display = ch_raw
            else:
                ch_clean = ch_raw.lstrip("@")
                ch_display = f"🎬 @{ch_clean}" if ch_clean else "-"
            ch_item = QTableWidgetItem(ch_display)
            ch_item.setTextAlignment(Qt.AlignCenter)
            if ch_raw.startswith("⚠️"):
                ch_item.setForeground(Qt.yellow)
            self.table_preview.setItem(row, 3, ch_item)

            # Cột 4: Thời Gian Đăng (Ngày & Giờ)
            time_item = QTableWidgetItem(f"🕒 {item.get('scheduled_time', '')}")
            time_item.setTextAlignment(Qt.AlignCenter)
            time_item.setForeground(Qt.cyan)
            self.table_preview.setItem(row, 4, time_item)

    # ==================== KÍCH HOẠT ====================
    def save_and_activate_schedule(self):
        from core.license_manager import license_mgr
        is_lic, lic_msg, lic_info = license_mgr.check_current_license()
        if not is_lic:
            QMessageBox.warning(
                self,
                "Bản Quyền Hết Hạn",
                "⚠️ Bản quyền phần mềm của bạn đã hết hạn hoặc bị thu hồi!\n\n"
                "Không thể lên lịch hẹn đăng video. Vui lòng liên hệ Admin để gia hạn bản quyền!"
            )
            from ui.components.license_dialog import LicenseDialog
            dlg = LicenseDialog(parent=self, is_mandatory=True)
            dlg.exec()
            return

        if not self.preview_schedule_data:
            QMessageBox.warning(self, "Chưa có lịch", "Vui lòng kéo thả video vào trước khi bắt đầu!")
            return

        total_posts = len(self.preview_schedule_data)
        reply = QMessageBox.question(
            self, "Bắt đầu đăng theo lịch",
            f"Bạn có chắc muốn kích hoạt lịch hẹn giờ cho <b>{total_posts}</b> lượt đăng này?",
            QMessageBox.Yes | QMessageBox.No
        )
        if reply != QMessageBox.Yes:
            return

        # Bulk Insert nhanh vào database (Tự động chuyển video vào kho của Tool)
        for item in self.preview_schedule_data:
            vault_path = video_vault.import_video_to_vault(item["video_path"], title=item["video_title"])
            file_size = os.path.getsize(vault_path) if os.path.exists(vault_path) else 0
            vid_id = db.add_video(
                title=item["video_title"],
                file_path=vault_path,
                file_size=file_size,
                channel_id=item["channel_id"]
            )
            db.add_schedule(
                channel_id=item["channel_id"],
                video_id=vid_id,
                scheduled_time=item["scheduled_time"],
                caption=item["caption"],
                hashtags=item["hashtags"]
            )

        scheduler_service.start()
        QMessageBox.information(
            self, "Đã kích hoạt",
            f"Đã lưu thành công {total_posts} lịch đăng vào hệ thống tự động!"
        )
        self.request_page.emit(3)
