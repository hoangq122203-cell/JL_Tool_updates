import sys
import os
import time
import threading
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QTableWidget, QTableWidgetItem, QHeaderView, QFrame, QComboBox,
    QMessageBox, QFileDialog, QCheckBox
)
from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QColor, QFont
from database.db_manager import db
from core.scheduler_service import scheduler_service
from core.tiktok_uploader import uploader
from core.video_resolver import resolve_video_path
from core.video_vault import video_vault

class SchedulePage(QWidget):
    def __init__(self):
        super().__init__()
        self.row_check_items = []
        self._btn_delete_active = None
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(28, 20, 28, 20)
        layout.setSpacing(16)

        # Header Title
        header_layout = QHBoxLayout()
        title_box = QVBoxLayout()
        lbl_title = QLabel("Quản Lý Lịch Trình Đăng Video Hàng Ngày")
        lbl_title.setProperty("class", "page-title")
        lbl_subtitle = QLabel("Theo dõi tiến trình đăng tự động, danh sách video đang chờ theo ngày và kết quả thực thi")
        lbl_subtitle.setStyleSheet("color: #25F4EE; font-size: 13px; font-weight: 500;")
        title_box.addWidget(lbl_title)
        title_box.addWidget(lbl_subtitle)
        header_layout.addLayout(title_box)

        header_layout.addStretch()

        # Nút Hẹn Lịch Đăng Mới
        self.btn_add_schedule = QPushButton("➕ Hẹn Lịch Đăng Mới")
        self.btn_add_schedule.setProperty("class", "btn-primary")
        self.btn_add_schedule.setStyleSheet("background-color: #2563EB; color: #FFFFFF; font-weight: 700; padding: 7px 16px; border-radius: 6px;")
        self.btn_add_schedule.setCursor(Qt.PointingHandCursor)
        self.btn_add_schedule.clicked.connect(self.open_add_schedule_dialog)
        header_layout.addWidget(self.btn_add_schedule)

        # NÚT ĐĂNG HÀNG LOẠT TẤT CẢ CÁC KÊNH (BATCH POST ALL CHANNELS)
        self.btn_batch_post = QPushButton("🚀 Đăng Hàng Loạt Tất Cả Kênh")
        self.btn_batch_post.setStyleSheet("""
            QPushButton {
                background-color: #059669;
                color: #FFFFFF;
                border: 1px solid #10B981;
                border-radius: 6px;
                padding: 7px 16px;
                font-weight: 800;
                font-size: 13px;
            }
            QPushButton:hover {
                background-color: #047857;
            }
        """)
        self.btn_batch_post.setCursor(Qt.PointingHandCursor)
        self.btn_batch_post.setToolTip("Kích hoạt đăng ngay lập tức toàn bộ video của tất cả các kênh trong lịch hẹn")
        self.btn_batch_post.clicked.connect(self.batch_post_all_channels)
        header_layout.addWidget(self.btn_batch_post)

        # Nút trạng thái dịch vụ hẹn giờ ngầm
        self.btn_toggle_service = QPushButton("🟢 Dịch vụ hẹn giờ: ĐANG CHẠY")
        self.btn_toggle_service.setProperty("class", "btn-secondary")
        self.btn_toggle_service.clicked.connect(self.toggle_scheduler_service)
        header_layout.addWidget(self.btn_toggle_service)

        self.btn_refresh = QPushButton("🔄 Làm mới")
        self.btn_refresh.setProperty("class", "btn-secondary")
        self.btn_refresh.clicked.connect(self.load_schedules)
        header_layout.addWidget(self.btn_refresh)

        self.btn_retry_failed = QPushButton("⚡ Thử lại các video lỗi")
        self.btn_retry_failed.setStyleSheet("""
            QPushButton {
                background-color: #D97706;
                color: #FFFFFF;
                border: 1px solid #F59E0B;
                border-radius: 6px;
                padding: 6px 12px;
                font-weight: 700;
                font-size: 12px;
            }
            QPushButton:hover {
                background-color: #B45309;
            }
        """)
        self.btn_retry_failed.setCursor(Qt.PointingHandCursor)
        self.btn_retry_failed.setToolTip("Khôi phục tất cả lịch đăng bị lỗi sang trạng thái Chờ đăng để tự động đăng lại")
        self.btn_retry_failed.clicked.connect(self.retry_all_failed)
        header_layout.addWidget(self.btn_retry_failed)

        self.btn_clean_duplicates = QPushButton("🧹 Quét & Xóa Trùng Lặp")
        self.btn_clean_duplicates.setStyleSheet("""
            QPushButton {
                background-color: #0F2942;
                color: #38BDF8;
                border: 1px solid #0284C7;
                border-radius: 6px;
                padding: 6px 12px;
                font-weight: 700;
                font-size: 12px;
            }
            QPushButton:hover {
                background-color: #0284C7;
                color: #FFFFFF;
            }
        """)
        self.btn_clean_duplicates.setCursor(Qt.PointingHandCursor)
        self.btn_clean_duplicates.setToolTip("Tự động quét kho lịch và xóa sạch 100% video bị cắt trùng lặp hoặc đăng lặp lại")
        self.btn_clean_duplicates.clicked.connect(self.clean_duplicates_manually)
        header_layout.addWidget(self.btn_clean_duplicates)

        self.btn_resync_schedules = QPushButton("⚡ Đồng Bộ Lại Lịch Chuẩn Giờ")
        self.btn_resync_schedules.setStyleSheet("""
            QPushButton {
                background-color: #065F46;
                color: #34D399;
                border: 1px solid #10B981;
                border-radius: 6px;
                padding: 6px 12px;
                font-weight: 700;
                font-size: 12px;
            }
            QPushButton:hover {
                background-color: #059669;
                color: #FFFFFF;
            }
        """)
        self.btn_resync_schedules.setCursor(Qt.PointingHandCursor)
        self.btn_resync_schedules.setToolTip("Tự động đồng bộ và tính toán lại lịch hẹn của tất cả kênh theo đúng cấu hình đã lưu, không bị lệch")
        self.btn_resync_schedules.clicked.connect(self.resync_all_schedules)
        header_layout.addWidget(self.btn_resync_schedules)

        self.btn_clear_all = QPushButton("🗑️ Xóa hết hàng đợi")
        self.btn_clear_all.setProperty("class", "btn-danger")
        self.btn_clear_all.clicked.connect(self.clear_all_schedules)
        header_layout.addWidget(self.btn_clear_all)

        layout.addLayout(header_layout)

        # Thanh công cụ lọc trạng thái & Thao tác chọn nhiều
        filter_bar = QFrame()
        filter_bar.setProperty("class", "content-panel")
        filter_layout = QHBoxLayout(filter_bar)
        filter_layout.setContentsMargins(14, 10, 14, 10)

        lbl_filter = QLabel("Lọc trạng thái:")
        lbl_filter.setStyleSheet("color: #FFFFFF; font-weight: 600;")
        filter_layout.addWidget(lbl_filter)

        self.cmb_status = QComboBox()
        self.cmb_status.addItem("Tất cả trạng thái", "all")
        self.cmb_status.addItem("Chờ đăng (Pending)", "pending")
        self.cmb_status.addItem("☁️ Đã lưu Đám Mây - Tắt máy tự đăng", "cloud_scheduled")
        self.cmb_status.addItem("Đang xử lý (Processing)", "processing")
        self.cmb_status.addItem("Đã thành công (Success)", "success")
        self.cmb_status.addItem("Thất bại / Lỗi (Failed)", "failed")
        self.cmb_status.currentIndexChanged.connect(self.load_schedules)
        filter_layout.addWidget(self.cmb_status)

        filter_layout.addSpacing(20)

        # Tích chọn tất cả & Nút Xóa video đã chọn
        self.chk_select_all = QCheckBox("Chọn tất cả")
        self.chk_select_all.setCursor(Qt.PointingHandCursor)
        self.chk_select_all.setStyleSheet("""
            QCheckBox {
                color: #F8FAFC;
                font-weight: 700;
                font-size: 13px;
                spacing: 8px;
            }
            QCheckBox::indicator {
                width: 18px;
                height: 18px;
                border: 1px solid #64748B;
                border-radius: 4px;
                background-color: #1E293B;
            }
            QCheckBox::indicator:hover {
                border-color: #38BDF8;
            }
            QCheckBox::indicator:checked {
                background-color: #0284C7;
                border-color: #38BDF8;
            }
        """)
        self.chk_select_all.stateChanged.connect(self.toggle_select_all)
        filter_layout.addWidget(self.chk_select_all)

        filter_layout.addSpacing(10)

        self.btn_delete_selected = QPushButton("🗑️ Xóa video đã chọn")
        self.btn_delete_selected.setCursor(Qt.PointingHandCursor)
        self.btn_delete_selected.setStyleSheet("""
            QPushButton {
                background-color: #374151;
                color: #9CA3AF;
                border: 1px solid #4B5563;
                border-radius: 6px;
                padding: 6px 14px;
                font-weight: 700;
                font-size: 12px;
            }
        """)
        self.btn_delete_selected.setEnabled(False)
        self.btn_delete_selected.clicked.connect(self.delete_selected_schedules)
        filter_layout.addWidget(self.btn_delete_selected)

        filter_layout.addStretch()

        self.lbl_queue_count = QLabel("Hàng đợi: 0 lịch đăng")
        self.lbl_queue_count.setStyleSheet("color: #8E8EA0; font-weight: 600;")
        filter_layout.addWidget(self.lbl_queue_count)

        layout.addWidget(filter_bar)

        # Bảng lịch đăng chi tiết (8 cột có cột Chọn)
        self.table = QTableWidget()
        self.table.setColumnCount(8)
        self.table.setHorizontalHeaderLabels([
            "Chọn", "STT", "Kênh Đăng", "Tên Video Nguồn", "Caption Đăng", "Thời Gian Hẹn Giờ (Giờ VN)", "Trạng Thái", "Hành Động"
        ])

        header = self.table.horizontalHeader()
        header.setSectionResizeMode(0, QHeaderView.Fixed)
        self.table.setColumnWidth(0, 50)

        header.setSectionResizeMode(1, QHeaderView.Fixed)
        self.table.setColumnWidth(1, 50)

        header.setSectionResizeMode(2, QHeaderView.Interactive)
        self.table.setColumnWidth(2, 185)

        header.setSectionResizeMode(3, QHeaderView.Interactive)
        self.table.setColumnWidth(3, 270)

        header.setSectionResizeMode(4, QHeaderView.Interactive)
        self.table.setColumnWidth(4, 270)

        header.setSectionResizeMode(5, QHeaderView.Fixed)
        self.table.setColumnWidth(5, 155)

        header.setSectionResizeMode(6, QHeaderView.Fixed)
        self.table.setColumnWidth(6, 170)

        header.setSectionResizeMode(7, QHeaderView.Fixed)
        self.table.setColumnWidth(7, 240)

        self.table.verticalHeader().setDefaultSectionSize(48)
        self.table.verticalHeader().setVisible(False)
        self.table.setSelectionBehavior(QTableWidget.SelectRows)
        self.table.setEditTriggers(QTableWidget.NoEditTriggers)
        self.table.setStyleSheet("""
            QWidget#cell_box { background: transparent; border: none; }
            QTableWidget::indicator {
                width: 18px; height: 18px; border: 1px solid #64748B;
                border-radius: 4px; background-color: #1E293B;
            }
            QTableWidget::indicator:hover { border-color: #38BDF8; }
            QTableWidget::indicator:checked { background-color: #0284C7; border-color: #38BDF8; }
            QPushButton#sched_post {
                background-color: #1E3A8A; color: #93C5FD; border: 1px solid #2563EB;
                border-radius: 5px; padding: 3px 8px; font-size: 11px; font-weight: 700;
            }
            QPushButton#sched_post:hover { background-color: #2563EB; color: #FFFFFF; }
            QPushButton#sched_pick {
                background-color: #064E3B; color: #6EE7B7; border: 1px solid #059669;
                border-radius: 5px; padding: 3px 8px; font-size: 11px; font-weight: 700;
            }
            QPushButton#sched_pick:hover { background-color: #059669; color: #FFFFFF; }
            QPushButton#sched_retry {
                background-color: #78350F; color: #FCD34D; border: 1px solid #D97706;
                border-radius: 5px; padding: 3px 8px; font-size: 11px; font-weight: 700;
            }
            QPushButton#sched_retry:hover { background-color: #B45309; color: #FFFFFF; }
            QPushButton#sched_del {
                background-color: #2D1A1E; color: #F87171; border: 1px solid #4F2228;
                border-radius: 5px; padding: 3px 8px; font-size: 11px; font-weight: 700;
            }
            QPushButton#sched_del:hover { background-color: #DC2626; color: #FFFFFF; }
        """)
        self.table.itemChanged.connect(self._on_table_item_changed)
        layout.addWidget(self.table)

        # Thanh phân trang gọn nhẹ (giới hạn 100 dòng/trang tránh dựng hàng trăm QWidget gây giật lag)
        self._page_size = 100
        self._current_page = 0
        self._total_pages = 1
        pag_bar = QHBoxLayout()
        pag_bar.setContentsMargins(0, 2, 0, 0)
        pag_bar.addStretch()
        self.btn_prev_page = QPushButton("◀ Trang trước")
        self.btn_prev_page.setFixedHeight(28)
        self.btn_prev_page.setCursor(Qt.PointingHandCursor)
        self.btn_prev_page.clicked.connect(lambda: self._go_page(-1))
        self.lbl_page_info = QLabel("Trang 1 / 1")
        self.lbl_page_info.setStyleSheet("color: #94A3B8; font-weight: 600; padding: 0 10px;")
        self.btn_next_page = QPushButton("Trang sau ▶")
        self.btn_next_page.setFixedHeight(28)
        self.btn_next_page.setCursor(Qt.PointingHandCursor)
        self.btn_next_page.clicked.connect(lambda: self._go_page(1))
        pag_bar.addWidget(self.btn_prev_page)
        pag_bar.addWidget(self.lbl_page_info)
        pag_bar.addWidget(self.btn_next_page)
        pag_bar.addStretch()
        layout.addLayout(pag_bar)

        # Tự động nạp dữ liệu và kiểm tra dịch vụ ngầm
        self.load_schedules()
        if not scheduler_service.is_running:
            scheduler_service.start()
        self.update_service_btn_text()

        # Timer tự động làm mới bảng (chỉ làm mới thông minh khi trang đang hiển thị và có dữ liệu thay đổi)
        self._last_schedule_digest = None
        self.refresh_timer = QTimer(self)
        self.refresh_timer.timeout.connect(self.on_auto_refresh)
        self.refresh_timer.start(30000)

    def on_auto_refresh(self):
        if not self.isVisible():
            return
        # TỐI ƯU SIÊU MƯỢT: Kiểm tra nhanh (<1ms) xem danh sách lịch có thay đổi không
        # Tránh vẽ lại bảng liên tục gây giật lag hoặc mất vị trí cuộn chuột của người dùng
        try:
            st_filter = self.cmb_status.currentData()
            digest_sql = """
                SELECT COUNT(*), COALESCE(MAX(id), 0), COALESCE(MAX(last_attempt), ''),
                       COALESCE(MAX(created_at), ''),
                       COALESCE(SUM(CASE
                           WHEN status = 'pending' THEN 1
                           WHEN status = 'processing' THEN 1000
                           WHEN status = 'cloud_scheduled' THEN 100000
                           ELSE 10000000 END), 0)
                FROM schedules
            """
            with db._get_connection() as conn:
                cur = conn.cursor()
                if st_filter:
                    cur.execute(f"{digest_sql} WHERE status = ?", (st_filter,))
                else:
                    cur.execute(digest_sql)
                row = cur.fetchone()
                digest = "_".join(str(x) for x in row)
                if digest == getattr(self, "_last_schedule_digest", None):
                    return
                self._last_schedule_digest = digest
        except Exception:
            pass
        self.load_schedules()

    def toggle_scheduler_service(self):
        if scheduler_service.is_running:
            scheduler_service.stop()
        else:
            scheduler_service.start()
        self.update_service_btn_text()

    def update_service_btn_text(self):
        if scheduler_service.is_running:
            self.btn_toggle_service.setText("🟢 Dịch vụ hẹn giờ: ĐANG BẬT")
            self.btn_toggle_service.setStyleSheet("color: #22C55E;")
        else:
            self.btn_toggle_service.setText("⚪ Dịch vụ hẹn giờ: ĐÃ TẮT")
            self.btn_toggle_service.setStyleSheet("color: #8E8EA0;")

    def _on_table_item_changed(self, item):
        if item is not None and item.column() == 0:
            self.update_delete_button_state()

    def toggle_select_all(self, state):
        is_checked = (state == Qt.Checked.value or state == Qt.Checked or state == 2 or state is True)
        target_state = Qt.Checked if is_checked else Qt.Unchecked
        self.table.blockSignals(True)
        try:
            for item in self.row_check_items:
                item.setCheckState(target_state)
        finally:
            self.table.blockSignals(False)
        self.update_delete_button_state()

    def update_delete_button_state(self):
        count = sum(1 for item in self.row_check_items if item.checkState() == Qt.Checked)
        has_selection = count > 0
        if has_selection:
            self.btn_delete_selected.setText(f"🗑️ Xóa video đã chọn ({count})")
            self.btn_delete_selected.setEnabled(True)
        else:
            self.btn_delete_selected.setText("🗑️ Xóa video đã chọn")
            self.btn_delete_selected.setEnabled(False)

        if self._btn_delete_active != has_selection:
            self._btn_delete_active = has_selection
            if has_selection:
                self.btn_delete_selected.setStyleSheet("""
                    QPushButton {
                        background-color: #DC2626;
                        color: #FFFFFF;
                        border: 1px solid #EF4444;
                        border-radius: 6px;
                        padding: 6px 14px;
                        font-weight: 700;
                        font-size: 12px;
                    }
                    QPushButton:hover {
                        background-color: #B91C1C;
                    }
                """)
            else:
                self.btn_delete_selected.setStyleSheet("""
                    QPushButton {
                        background-color: #374151;
                        color: #9CA3AF;
                        border: 1px solid #4B5563;
                        border-radius: 6px;
                        padding: 6px 14px;
                        font-weight: 700;
                        font-size: 12px;
                    }
                """)

        all_checked = bool(self.row_check_items) and count == len(self.row_check_items)
        self.chk_select_all.blockSignals(True)
        self.chk_select_all.setChecked(all_checked)
        self.chk_select_all.blockSignals(False)

    def delete_selected_schedules(self):
        selected_ids = [
            item.data(Qt.UserRole)
            for item in self.row_check_items
            if item.checkState() == Qt.Checked and item.data(Qt.UserRole) is not None
        ]
        if not selected_ids:
            QMessageBox.information(self, "Thông báo", "Vui lòng tích chọn ít nhất 1 video để xóa.")
            return

        reply = QMessageBox.question(
            self,
            "Xác nhận xóa hàng loạt",
            f"🗑️ Bạn có chắc chắn muốn xóa <b>{len(selected_ids)}</b> video đã chọn khỏi lịch hẹn?",
            QMessageBox.Yes | QMessageBox.No
        )
        if reply == QMessageBox.Yes:
            for sid in selected_ids:
                try:
                    db.delete_schedule(sid)
                except Exception:
                    pass
            self.load_schedules()
            QMessageBox.information(self, "Đã xóa", f"✅ Đã xóa thành công {len(selected_ids)} video đã chọn!")

    def resync_all_schedules(self):
        """Tự động đồng bộ và tính toán lại toàn bộ lịch hẹn của tất cả các kênh về đúng cài đặt đã lưu, không bị lệch"""
        total = db.reschedule_all_channels_pending_schedules()
        self.load_schedules()
        if total > 0:
            QMessageBox.information(
                self,
                "Đồng Bộ Thành Công",
                f"✅ Đã đồng bộ lại lịch hẹn cho <b>{total}</b> video chưa đăng theo đúng chuẩn cài đặt của từng kênh!\n\n"
                f"• Video 1 luôn bắt đầu đúng Slot 0.\n"
                f"• Giãn cách chuẩn xác từng phút (00 giây, không lệch jitter)."
            )
        else:
            QMessageBox.information(self, "Thông báo", "Toàn bộ lịch hẹn hiện tại đã ở trạng thái chuẩn xác nhất!")

    def clean_duplicates_manually(self):
        cleaned = db.clean_duplicate_pending_schedules()
        self.load_schedules()
        if cleaned > 0:
            QMessageBox.information(
                self,
                "Đã Dọn Dẹp Trùng Lặp",
                f"✅ <b>Đã dọn dẹp thành công!</b><br><br>"
                f"• Đã tự động loại bỏ <b>{cleaned} video</b> bị cắt trùng lặp khỏi kho lịch.<br>"
                "• Đảm bảo mỗi video chỉ được đăng đúng 1 lần theo thứ tự tập, không bao giờ đăng lặp lại."
            )
        else:
            QMessageBox.information(
                self,
                "Kho Video Chuẩn Xác",
                "✅ <b>Kho video hoàn toàn chuẩn xác 100%!</b><br><br>Không phát hiện video nào bị cắt trùng lặp."
            )

    def _go_page(self, delta: int):
        new_p = max(0, min(getattr(self, "_total_pages", 1) - 1, getattr(self, "_current_page", 0) + delta))
        if new_p != getattr(self, "_current_page", 0):
            self._current_page = new_p
            self.load_schedules()

    def load_schedules(self):
        # Tự động quét và loại bỏ video trùng lặp khỏi kho (đã tối ưu O(1) < 5ms)
        db.clean_duplicate_pending_schedules()
        st_filter = self.cmb_status.currentData()
        all_schedules = db.get_all_schedules(st_filter)

        total_count = len(all_schedules)
        page_size = getattr(self, "_page_size", 100)
        self._total_pages = max(1, (total_count + page_size - 1) // page_size)
        if getattr(self, "_current_page", 0) >= self._total_pages:
            self._current_page = self._total_pages - 1
        start_idx = self._current_page * page_size
        schedules = all_schedules[start_idx:start_idx + page_size]

        self.lbl_queue_count.setText(f"Số lượng lịch: {total_count} video")
        if hasattr(self, "lbl_page_info"):
            self.lbl_page_info.setText(f"Trang {self._current_page + 1} / {self._total_pages} (hiển thị {len(schedules)}/{total_count})")
            self.btn_prev_page.setEnabled(self._current_page > 0)
            self.btn_next_page.setEnabled(self._current_page + 1 < self._total_pages)
        self.row_check_items = []
        self.chk_select_all.blockSignals(True)
        self.chk_select_all.setChecked(False)
        self.chk_select_all.blockSignals(False)
        self.update_delete_button_state()

        from core.vpn_regions import get_region_profile, convert_local_to_target_time
        default_reg = db.get_setting("global_vpn_country_name", "") or db.get_setting("global_vpn_region", "philippines")
        global_reg_code = db.get_setting("global_vpn_region", "philippines")
        region_prof_cache = {}
        font_stt = QFont("Segoe UI", 10)
        font_stt.setBold(True)

        self.table.setUpdatesEnabled(False)
        self.table.blockSignals(True)
        try:
            self.table.clearContents()
            self.table.setRowCount(len(schedules))

            for row, s in enumerate(schedules):
                # Col 0: Tích chọn từng video bằng QTableWidgetItem checkable (tránh tạo QWidget+QLayout từng dòng)
                chk_item = QTableWidgetItem()
                chk_item.setFlags(Qt.ItemIsUserCheckable | Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                chk_item.setCheckState(Qt.Unchecked)
                chk_item.setData(Qt.UserRole, s["id"])
                chk_item.setTextAlignment(Qt.AlignCenter)
                self.table.setItem(row, 0, chk_item)
                self.row_check_items.append(chk_item)

                # Col 1: STT
                stt_num = start_idx + row + 1
                stt_item = QTableWidgetItem(str(stt_num))
                stt_item.setTextAlignment(Qt.AlignCenter)
                stt_item.setToolTip(f"STT: {stt_num} (ID Lịch Hẹn: {s['id']})")
                stt_item.setData(Qt.UserRole, s["id"])
                stt_item.setForeground(QColor("#94A3B8"))
                stt_item.setFont(font_stt)
                self.table.setItem(row, 1, stt_item)

                # Col 2: Kênh
                c_raw = str(s.get("channel_name", "") or "").strip()
                c_clean = c_raw.lstrip("@")
                c_display = f"🎬 @{c_clean}" if c_clean else "-"
                c_item = QTableWidgetItem(c_display)
                c_item.setToolTip(f"Kênh TikTok: {c_display}")
                self.table.setItem(row, 2, c_item)

                st = s.get("status", "pending")
                v_path = s.get("video_path", "")
                # Chỉ kiểm tra os.path.isfile khi thực sự cần hiển thị trạng thái failed (giảm hàng trăm syscall disk I/O)
                has_file = bool(v_path and os.path.isfile(v_path)) if st == "failed" else bool(v_path)

                # Col 3: Video Title
                v_title = s.get("video_title", "")
                item_title = QTableWidgetItem(v_title)
                item_title.setToolTip(f"🎬 Tên Video: {v_title}\n📁 Tệp: {os.path.basename(v_path)}")
                self.table.setItem(row, 3, item_title)

                # Col 4: Caption
                cap = s.get("caption", "")
                item_cap = QTableWidgetItem(cap)
                item_cap.setToolTip(f"📝 Caption: {cap}")
                self.table.setItem(row, 4, item_cap)

                # Col 5: Thời gian hẹn (cache region profile)
                sched_str = s.get("scheduled_time", "")
                t_item = QTableWidgetItem(sched_str)
                t_item.setForeground(Qt.cyan)
                if sched_str:
                    try:
                        reg = s.get("vpn_region") or s.get("target_country") or global_reg_code
                        prof = region_prof_cache.get(reg)
                        if prof is None:
                            prof = get_region_profile(reg)
                            region_prof_cache[reg] = prof
                        dt_loc = datetime.strptime(sched_str, "%Y-%m-%d %H:%M:%S")
                        dt_tgt = convert_local_to_target_time(dt_loc, prof["timezone_id"])
                        cnt_name = s.get("target_country") or prof.get("country", "Fake IP")
                        t_item.setToolTip(
                            f"🖥️ Giờ máy tính VN: {sched_str}\n"
                            f"🌍 Giờ tại nước fake IP ({cnt_name}): {dt_tgt.strftime('%H:%M ngày %d/%m/%Y')} ({dt_tgt.strftime('%Z')})"
                        )
                    except Exception:
                        pass
                self.table.setItem(row, 5, t_item)

                # Col 6: Trạng thái
                if st == "pending":
                    st_item = QTableWidgetItem("⏳ Chờ đến giờ")
                    st_item.setForeground(Qt.yellow)
                    st_item.setToolTip("Video đang xếp hàng và sẽ được tự động đăng đúng giờ hẹn")
                elif st == "cloud_scheduled":
                    st_item = QTableWidgetItem("☁️ Đã lưu Đám Mây (Tắt máy tự đăng)")
                    st_item.setForeground(QColor("#38BDF8"))
                    st_item.setToolTip(
                        "☁️ Video này đã được Tool nạp sẵn lên Máy Chủ Đám Mây của TikTok Studio!\n"
                        "👉 Bạn có thể TẮT NGUỒN MÁY TÍNH HOÀN TOÀN (Shut down), máy chủ TikTok vẫn tự động đăng đúng giờ hẹn 100%!"
                    )
                elif st == "processing":
                    st_item = QTableWidgetItem("⚡ Đang đăng...")
                    st_item.setForeground(Qt.cyan)
                    st_item.setToolTip("Hệ thống đang mở trình duyệt và tự động đăng tải video")
                elif st == "success":
                    st_item = QTableWidgetItem("✅ Đã hoàn tất")
                    st_item.setForeground(Qt.green)
                    st_item.setToolTip("Video đã đăng thành công lên kênh TikTok")
                else:
                    if not has_file:
                        st_item = QTableWidgetItem("❌ Mất file video")
                        st_item.setForeground(QColor("#FB7185"))
                        st_item.setToolTip(
                            f"⚠️ Không tìm thấy file video trên máy tính!\n"
                            f"Đường dẫn cũ: {v_path}\n"
                            f"Bấm nút [📁 Chọn file] để chọn video thay thế hoặc nút [✕ Xóa] để hủy lịch."
                        )
                    else:
                        retry_cnt = s.get("retry_count", 0)
                        max_ret = int(db.get_setting("auto_retry_max_count", "3") or "3")
                        err_msg = s.get("error_message", "Chưa rõ nguyên nhân") or "Chưa rõ nguyên nhân"
                        err_low = err_msg.lower()
                        is_auth_err = (
                            "something went wrong" not in err_low
                            and any(k in err_low for k in ["chưa đăng nhập", "đăng nhập lại", "sessionid", "bị khóa", "suspended", "hết phiên đăng nhập"])
                        )
                        if is_auth_err:
                            st_item = QTableWidgetItem("🔐 Cần đăng nhập lại")
                            st_item.setForeground(QColor("#FBBF24"))
                            st_item.setToolTip(f"{err_msg}\n👉 Mở Chrome kênh này đăng nhập lại rồi bấm [Thử ngay].")
                        elif retry_cnt >= max_ret:
                            st_item = QTableWidgetItem("❌ Lỗi (Đã dừng thử lại)")
                            st_item.setForeground(Qt.red)
                            st_item.setToolTip(f"{err_msg}\n(Đã thử lại {retry_cnt}/{max_ret} lần. Hãy kiểm tra kênh/Proxy rồi bấm [Thử ngay])")
                        else:
                            st_item = QTableWidgetItem(f"❌ Lỗi (Chờ thử lại {retry_cnt}/{max_ret})" if retry_cnt > 0 else "❌ Thất bại")
                            st_item.setForeground(Qt.red)
                            st_item.setToolTip(f"Lỗi: {err_msg}\n(Hệ thống sẽ tự động thử lại theo chu kỳ)")

                st_item.setTextAlignment(Qt.AlignCenter)
                self.table.setItem(row, 6, st_item)

                # Col 7: Nút Thao tác
                act_w = QWidget()
                act_w.setObjectName("cell_box")
                act_l = QHBoxLayout(act_w)
                act_l.setContentsMargins(4, 4, 4, 4)
                act_l.setSpacing(6)
                act_l.setAlignment(Qt.AlignCenter)

                if st == "pending":
                    btn_post_now = QPushButton("▶ Đăng ngay")
                    btn_post_now.setObjectName("sched_post")
                    btn_post_now.setFixedHeight(28)
                    btn_post_now.setCursor(Qt.PointingHandCursor)
                    btn_post_now.clicked.connect(lambda checked=False, sc=s: self.post_now(sc))
                    act_l.addWidget(btn_post_now)

                elif st == "failed":
                    if not has_file:
                        btn_pick = QPushButton("📁 Chọn file")
                        btn_pick.setObjectName("sched_pick")
                        btn_pick.setFixedHeight(28)
                        btn_pick.setCursor(Qt.PointingHandCursor)
                        btn_pick.setToolTip("Chọn lại file video mới trên máy tính cho lịch hẹn này")
                        btn_pick.clicked.connect(lambda checked=False, sid=s["id"], tit=v_title: self.select_new_video_file(sid, tit))
                        act_l.addWidget(btn_pick)

                    btn_retry = QPushButton("🔄 Thử ngay")
                    btn_retry.setObjectName("sched_retry")
                    btn_retry.setFixedHeight(28)
                    btn_retry.setCursor(Qt.PointingHandCursor)
                    btn_retry.setToolTip("Kích hoạt đăng lại video này ngay lập tức")
                    btn_retry.clicked.connect(lambda checked=False, sid=s["id"], sc=s: self.retry_single_schedule(sid, sc))
                    act_l.addWidget(btn_retry)

                btn_del = QPushButton("✕ Xóa")
                btn_del.setObjectName("sched_del")
                btn_del.setFixedHeight(28)
                btn_del.setToolTip("Xóa lịch đăng này khỏi hàng đợi")
                btn_del.setCursor(Qt.PointingHandCursor)
                btn_del.clicked.connect(lambda checked=False, sid=s["id"]: self.delete_single_schedule(sid))
                act_l.addWidget(btn_del)

                self.table.setCellWidget(row, 7, act_w)
        finally:
            self.table.blockSignals(False)
            self.table.setUpdatesEnabled(True)

    def select_new_video_file(self, schedule_id: int, current_title: str):
        default_dir = os.path.join(os.path.expanduser("~/Desktop"), "hitomi_downloaded_youtube")
        if not os.path.exists(default_dir):
            default_dir = os.path.expanduser("~/Desktop")

        file_path, _ = QFileDialog.getOpenFileName(
            self,
            f"Chọn tệp video mới cho: {current_title}",
            default_dir,
            "Video Files (*.mp4 *.mov *.mkv *.webm *.avi);;All Files (*.*)"
        )
        if file_path:
            norm_path = os.path.normpath(file_path)
            ch_id = None
            ch_name = ""
            try:
                with db._get_connection() as conn:
                    r = conn.execute(
                        "SELECT s.channel_id, c.name FROM schedules s LEFT JOIN channels c ON s.channel_id = c.id WHERE s.id = ?",
                        (schedule_id,)
                    ).fetchone()
                    if r:
                        ch_id = r["channel_id"]
                        ch_name = r["name"] or ""
            except Exception:
                pass
            # TỰ ĐỘNG CHUYỂN VIDEO VÀO THƯ MỤC RIÊNG CỦA KÊNH TRONG KHO TOOL
            vault_path = video_vault.import_video_to_vault(
                norm_path,
                title=current_title,
                channel_id=ch_id,
                channel_name=ch_name
            )
            db.update_schedule_video_path(schedule_id, vault_path)
            self.load_schedules()
            if not scheduler_service.is_running:
                scheduler_service.start()
            QMessageBox.information(
                self, "Đã cập nhật video",
                f"✅ Đã lưu video vào kho an toàn của Tool thành công:<br><b>{os.path.basename(vault_path)}</b><br><br>"
                "• Lịch đăng đã chuyển sang trạng thái <b>Chờ đến giờ</b>.<br>"
                "• Bạn có thể tự do xóa file ngoài máy tính mà không lo ảnh hưởng đến lịch đăng!"
            )

    def retry_single_schedule(self, schedule_id: int, schedule_item: dict):
        # Kiểm tra file video trước
        v_path = schedule_item.get("video_path", "")
        if not v_path or not os.path.isfile(v_path):
            resolved = resolve_video_path(v_path, schedule_item.get("caption", ""))
            if resolved:
                db.update_schedule_video_path(schedule_id, resolved)
            else:
                reply = QMessageBox.question(
                    self, "Không tìm thấy file video",
                    f"⚠️ Không tìm thấy file video trên máy tính!\n\n"
                    f"Tên: {schedule_item.get('video_title')}\n\n"
                    f"Bạn có muốn chọn file video mới thay thế ngay không?",
                    QMessageBox.Yes | QMessageBox.No
                )
                if reply == QMessageBox.Yes:
                    self.select_new_video_file(schedule_id, schedule_item.get("video_title", ""))
                return

        db.retry_single_schedule(schedule_id)
        if not scheduler_service.is_running:
            scheduler_service.start()
        self.load_schedules()
        QMessageBox.information(self, "Đang xử lý", "🚀 Đã kích hoạt thử lại! Hệ thống đang tiến hành đăng video này.")

    def open_add_schedule_dialog(self):
        from ui.components.schedule_dialog import ScheduleDialog
        dlg = ScheduleDialog(self)
        if dlg.exec():
            self.load_schedules()

    def post_now(self, item: dict):
        from core.license_manager import license_mgr
        is_lic, _, _ = license_mgr.check_current_license()
        if not is_lic:
            QMessageBox.warning(self, "Bản Quyền Hết Hạn", "⚠️ Bản quyền phần mềm đã hết hạn hoặc bị thu hồi! Không thể đăng video. Vui lòng gia hạn để tiếp tục.")
            from ui.components.license_dialog import LicenseDialog
            dlg = LicenseDialog(parent=self, is_mandatory=True)
            dlg.exec()
            return

        reply = QMessageBox.question(
            self, "Đăng ngay",
            f"Bạn có muốn thực hiện đăng video '{item.get('video_title')}' ngay lập tức?",
            QMessageBox.Yes | QMessageBox.No
        )
        if reply == QMessageBox.Yes:
            import threading
            def worker():
                channel_data = db.get_channel(item["channel_id"])
                if channel_data:
                    db.update_schedule_status(item["id"], "processing")
                    max_attempts = int(db.get_setting("max_immediate_retries", "3"))
                    retry_delay = int(db.get_setting("retry_delay_seconds", "8"))
                    attempt = 0
                    ok = False
                    err = ""
                    while attempt < max_attempts:
                        attempt += 1
                        if attempt > 1:
                            time.sleep(retry_delay)
                        ok, err = uploader.upload_video(
                            channel_data=channel_data,
                            video_path=item["video_path"],
                            caption=item.get("caption", ""),
                            hashtags=item.get("hashtags", "")
                        )
                        if ok:
                            break

                    if ok:
                        db.update_schedule_status(item["id"], "success")
                        # Tự động dọn dẹp video đã đăng khỏi kho video của Tool
                        video_vault.cleanup_vault_video(item["video_path"], schedule_id=item["id"])
                        # Tự động dọn dẹp lịch thành công
                        db.delete_schedule(item["id"])
                    else:
                        db.update_schedule_status(item["id"], "failed", f"Lỗi: {err}", increment_retry=True)
                    if db.get_setting("auto_disconnect_vpn_after_post", "0") == "1":
                        try:
                            from core.network_manager import network_mgr
                            network_mgr.pia_disconnect()
                        except Exception:
                            pass
                    QTimer.singleShot(0, self.load_schedules)

            threading.Thread(target=worker, daemon=True).start()
            QMessageBox.information(self, "Đang xử lý", "Đã gửi lệnh đăng video ngay lập tức!")

    def batch_post_all_channels(self):
        """Kích hoạt đăng hàng loạt ngay lập tức cho tất cả các kênh đã cài lịch hẹn"""
        schedules = db.get_all_schedules("pending")
        if not schedules:
            # Thử kiểm tra có video nào ở failed không
            failed_schedules = db.get_all_schedules("failed")
            if failed_schedules:
                self.retry_all_failed()
                return
            QMessageBox.information(self, "Thông báo", "Hiện không có lịch hẹn video nào đang chờ đăng.")
            return

        unique_channels = len(set(s.get("channel_id") for s in schedules))
        total_vids = len(schedules)

        reply = QMessageBox.question(
            self,
            "Xác nhận Đăng Hàng Loạt",
            f"🚀 <b>Bạn có muốn kích hoạt ĐĂNG HÀNG LOẠT NGAY LẬP TỨC?</b><br><br>"
            f"• <b>Tổng số video:</b> {total_vids} video<br>"
            f"• <b>Số lượng kênh:</b> {unique_channels} kênh TikTok<br><br>"
            "👉 <b>Cơ chế hoạt động:</b><br>"
            "1. Hệ thống sẽ tự động duyệt qua tất cả các kênh theo vòng tròn công bằng.<br>"
            "2. Tự động áp dụng toàn bộ cơ chế chống lỗi, dọn dẹp profile, nạp video và bấm nút Đăng.<br>"
            "3. Video nào đăng thành công sẽ tự động gửi thông báo Windows và dọn dẹp khỏi danh sách.",
            QMessageBox.Yes | QMessageBox.No
        )

        if reply == QMessageBox.Yes:
            # Chuyển toàn bộ lịch về giờ hiện tại để đăng ngay
            updated_count = db.set_all_pending_schedules_due_now(include_future=True)
            self.load_schedules()

            # Khởi động dịch vụ ngầm nếu đang tắt
            if not scheduler_service.is_running:
                scheduler_service.start()
            self.update_service_btn_text()

            QMessageBox.information(
                self,
                "Đã Kích Hoạt Đăng Hàng Loạt",
                f"🎉 <b>Đã kích hoạt đăng hàng loạt thành công!</b><br><br>"
                f"• Đã nạp <b>{updated_count}</b> video của <b>{unique_channels}</b> kênh vào luồng đăng ngầm.<br>"
                "• Bạn có thể thu nhỏ hoặc ẩn phần mềm xuống khay hệ thống, Tool sẽ tự động hoàn tất toàn bộ video!"
            )

    def retry_all_failed(self):
        # 1. Hàng loạt chuyển tất cả video failed sang pending ngay lập tức
        count = db.retry_all_failed_schedules(reset_time_to_now=True)
        self.load_schedules()

        if count > 0:
            if not scheduler_service.is_running:
                scheduler_service.start()

            # Đếm số lượng video bị mất file
            schedules = db.get_all_schedules("pending")
            missing_count = sum(1 for s in schedules if not s.get("video_path") or not os.path.isfile(s.get("video_path")))

            if missing_count > 0:
                QMessageBox.warning(
                    self, "Đã kích hoạt đăng lại hàng loạt",
                    f"🚀 Đã chuyển <b>{count}</b> video bị lỗi sang trạng thái <b>Chờ đăng</b>!<br><br>"
                    f"⚠️ <b>Lưu ý quan trọng:</b> Có <b>{missing_count}</b> video hiện không tìm thấy file trên ổ cứng (được đánh dấu <b>❌ Mất file video</b>).<br>"
                    "Bạn có thể bấm nút <b>[📁 Chọn file]</b> trên từng dòng để chọn video thay thế hoặc nút <b>[✕ Xóa]</b>."
                )
            else:
                QMessageBox.information(
                    self, "Đã kích hoạt đăng lại hàng loạt",
                    f"🎉 Đã chuyển <b>{count}</b> video bị lỗi sang trạng thái <b>Chờ đăng</b>!<br>"
                    "Hệ thống sẽ tự động thử lại liên tục cho đến khi <b>đăng thành công 100%</b> mới dừng!"
                )
        else:
            QMessageBox.information(self, "Thông báo", "Hiện không có video nào ở trạng thái lỗi cần thử lại.")

    def delete_single_schedule(self, schedule_id: int):
        db.delete_schedule(schedule_id)
        self.load_schedules()

    def clear_all_schedules(self):
        reply = QMessageBox.question(
            self, "Xác nhận", "Bạn có chắc muốn xóa TOÀN BỘ danh sách lịch hẹn giờ đăng video?",
            QMessageBox.Yes | QMessageBox.No
        )
        if reply == QMessageBox.Yes:
            db.clear_all_schedules()
            self.load_schedules()
            QMessageBox.information(self, "Đã xóa", "Toàn bộ hàng đợi đã được làm sạch.")
