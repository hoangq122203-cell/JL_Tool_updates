from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QTableWidget, QTableWidgetItem, QHeaderView, QFrame, QComboBox,
    QLineEdit, QMessageBox
)
from PySide6.QtCore import Qt
from PySide6.QtGui import QColor, QFont
from database.db_manager import db

class HistoryPage(QWidget):
    def __init__(self):
        super().__init__()
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 24, 24, 24)
        layout.setSpacing(18)

        # Header Title
        header_layout = QHBoxLayout()
        title_box = QVBoxLayout()
        lbl_title = QLabel("Lịch Sử Đăng Video")
        lbl_title.setProperty("class", "page-title")
        lbl_subtitle = QLabel("Theo dõi kết quả đăng tải, báo cáo lỗi chi tiết và liên kết video TikTok")
        lbl_subtitle.setProperty("class", "page-subtitle")
        title_box.addWidget(lbl_title)
        title_box.addWidget(lbl_subtitle)
        header_layout.addLayout(title_box)

        header_layout.addStretch()

        self.btn_refresh = QPushButton("🔄 Làm mới")
        self.btn_refresh.setProperty("class", "btn-secondary")
        self.btn_refresh.clicked.connect(self.load_history)
        header_layout.addWidget(self.btn_refresh)

        self.btn_clear = QPushButton("🗑️ Xóa toàn bộ lịch sử")
        self.btn_clear.setProperty("class", "btn-danger")
        self.btn_clear.clicked.connect(self.clear_history)
        header_layout.addWidget(self.btn_clear)

        layout.addLayout(header_layout)

        # Bộ lọc
        filter_bar = QFrame()
        filter_bar.setProperty("class", "content-panel")
        filter_layout = QHBoxLayout(filter_bar)
        filter_layout.setContentsMargins(14, 10, 14, 10)

        filter_layout.addWidget(QLabel("Lọc kết quả:"))
        self.cmb_filter_status = QComboBox()
        self.cmb_filter_status.addItem("Tất cả trạng thái", "all")
        self.cmb_filter_status.addItem("Thành công (Success)", "success")
        self.cmb_filter_status.addItem("Thất bại (Failed)", "failed")
        self.cmb_filter_status.currentIndexChanged.connect(self.load_history)
        filter_layout.addWidget(self.cmb_filter_status)

        filter_layout.addStretch()
        self.lbl_total_history = QLabel("Tổng số bản ghi: 0")
        self.lbl_total_history.setStyleSheet("color: #8E8E9F;")
        filter_layout.addWidget(self.lbl_total_history)

        layout.addWidget(filter_bar)

        # Bảng lịch sử
        self.table = QTableWidget()
        self.table.setColumnCount(6)
        self.table.setHorizontalHeaderLabels([
            "STT", "Kênh đăng", "Tên Video", "Thời Gian Đăng (Giờ VN)", "Trạng thái", "Liên kết / Chi tiết lỗi"
        ])

        header = self.table.horizontalHeader()
        header.setSectionResizeMode(0, QHeaderView.Fixed)
        self.table.setColumnWidth(0, 55)

        header.setSectionResizeMode(1, QHeaderView.Interactive)
        self.table.setColumnWidth(1, 195)

        header.setSectionResizeMode(2, QHeaderView.Stretch)

        header.setSectionResizeMode(3, QHeaderView.Fixed)
        self.table.setColumnWidth(3, 160)

        header.setSectionResizeMode(4, QHeaderView.Fixed)
        self.table.setColumnWidth(4, 150)

        header.setSectionResizeMode(5, QHeaderView.Stretch)

        self.table.verticalHeader().setDefaultSectionSize(48)
        self.table.verticalHeader().setVisible(False)
        self.table.setSelectionBehavior(QTableWidget.SelectRows)
        self.table.setEditTriggers(QTableWidget.NoEditTriggers)
        layout.addWidget(self.table)

        self.load_history()

    def load_history(self):
        status_filter = self.cmb_filter_status.currentData()
        with db._get_connection() as conn:
            cursor = conn.cursor()
            if status_filter == "all":
                total_cnt = cursor.execute("SELECT COUNT(*) FROM history").fetchone()[0]
                cursor.execute("SELECT * FROM history ORDER BY id DESC LIMIT 250")
            else:
                total_cnt = cursor.execute("SELECT COUNT(*) FROM history WHERE status = ?", (status_filter,)).fetchone()[0]
                cursor.execute("SELECT * FROM history WHERE status = ? ORDER BY id DESC LIMIT 250", (status_filter,))
            records = [dict(r) for r in cursor.fetchall()]

        if total_cnt > len(records):
            self.lbl_total_history.setText(f"Tổng số bản ghi: {total_cnt} (hiển thị {len(records)} mới nhất)")
        else:
            self.lbl_total_history.setText(f"Tổng số bản ghi: {total_cnt}")

        font_stt = QFont("Segoe UI", 10)
        font_stt.setBold(True)
        self.table.setUpdatesEnabled(False)
        self.table.blockSignals(True)
        try:
            self.table.clearContents()
            self.table.setRowCount(len(records))

            for row, rec in enumerate(records):
                stt_num = row + 1
                stt_item = QTableWidgetItem(str(stt_num))
                stt_item.setTextAlignment(Qt.AlignCenter)
                stt_item.setToolTip(f"STT: {stt_num} (ID Lịch Sử: {rec.get('id', '')})")
                stt_item.setData(Qt.UserRole, rec.get("id"))
                stt_item.setForeground(QColor("#94A3B8"))
                stt_item.setFont(font_stt)
                self.table.setItem(row, 0, stt_item)
                ch_raw = str(rec.get("channel_name", "") or "-").strip()
                ch_clean = ch_raw.lstrip("@")
                ch_display = f"🎬 @{ch_clean}" if ch_clean and ch_clean != "-" else "-"
                ch_item = QTableWidgetItem(ch_display)
                ch_item.setToolTip(f"Kênh TikTok: {ch_display}")
                self.table.setItem(row, 1, ch_item)
                self.table.setItem(row, 2, QTableWidgetItem(rec.get("video_title", "") or "-"))
                self.table.setItem(row, 3, QTableWidgetItem(rec.get("posted_at", "") or "-"))

                status = rec.get("status", "")
                st_item = QTableWidgetItem("✅ Thành công" if status == "success" else "❌ Thất bại")
                st_item.setForeground(Qt.green if status == "success" else Qt.red)
                self.table.setItem(row, 4, st_item)

                detail = rec.get("post_url") or rec.get("error_message") or "-"
                self.table.setItem(row, 5, QTableWidgetItem(detail))
        finally:
            self.table.blockSignals(False)
            self.table.setUpdatesEnabled(True)

    def clear_history(self):
        reply = QMessageBox.question(
            self, "Xác nhận", "Bạn có chắc chắn muốn xóa toàn bộ lịch sử đăng video không?",
            QMessageBox.Yes | QMessageBox.No
        )
        if reply == QMessageBox.Yes:
            with db._get_connection() as conn:
                conn.execute("DELETE FROM history")
                conn.commit()
            self.load_history()
            QMessageBox.information(self, "Đã xóa", "Toàn bộ lịch sử đã được làm sạch.")

