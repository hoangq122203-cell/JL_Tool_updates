import os
import time
import threading
from typing import Dict, Any, List, Optional
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QLineEdit, QTableWidget, QTableWidgetItem, QHeaderView,
    QMessageBox, QFrame, QCheckBox, QComboBox
)
from PySide6.QtCore import Qt, Signal, QTimer
from PySide6.QtGui import QColor, QFont
from database.db_manager import db
from core.chrome_manager import chrome_mgr
from core.network_manager import network_mgr
from ui.components.channel_dialog import ChannelDialog
from ui.components.vpn_account_dialog import VpnAccountDialog

class ChannelsPage(QWidget):
    channel_updated = Signal()
    stats_synced_signal = Signal(int, int, int)

    def __init__(self):
        super().__init__()
        self.channels_data = []
        self.current_rendered_channels = []
        self.row_checkboxes = []
        self._pending_reload = False
        self._progress_last_sig = {}
        self._pending_progress = {}
        self._progress_timer = QTimer(self)
        self._progress_timer.setSingleShot(True)
        self._progress_timer.setInterval(300)
        self._progress_timer.timeout.connect(self._flush_series_progress_updates)
        self._queue_reload_timer = QTimer(self)
        self._queue_reload_timer.setSingleShot(True)
        self._queue_reload_timer.setInterval(600)
        self._queue_reload_timer.timeout.connect(self._flush_queued_reload)
        self._is_async_reloading = False
        self.init_ui()
        # Đăng ký nhận thông báo đồng bộ số liệu tự động theo thời gian thực (30 phút/lần, trễ 120s sau mở app để tránh tranh chấp CPU lúc đầu)
        from core.stats_sync_service import stats_sync_service
        self.stats_synced_signal.connect(self._on_stat_synced_live)
        stats_sync_service.register_callback(lambda cid, f, v: self.stats_synced_signal.emit(cid, f, v))
        stats_sync_service.start_background_sync(delay_start=120.0, interval_seconds=1800)

        # Đăng ký nhận thông báo tiến trình Hàng đợi Cắt & Rải lịch ngầm (gom nhịp tránh đơ giao diện)
        from core.series_queue_manager import series_queue_mgr
        series_queue_mgr.queue_updated.connect(self._request_channels_reload)
        series_queue_mgr.task_progress.connect(self._on_series_progress_update)

    def showEvent(self, event):
        super().showEvent(event)
        if getattr(self, "_pending_reload", False):
            self._pending_reload = False
            self.load_channels()

    def _request_channels_reload(self):
        """Gom các tín hiệu queue_updated liên tiếp và hoãn vẽ lại bảng nếu tab đang ẩn."""
        self._refresh_series_live_banner()
        if not self.isVisible():
            self._pending_reload = True
            return
        self._queue_reload_timer.start()

    def _flush_queued_reload(self):
        if not self.isVisible():
            self._pending_reload = True
            return
        if getattr(self, "_is_async_reloading", False):
            return
        self._pending_reload = False
        self._is_async_reloading = True

        def _bg_fetch():
            try:
                ch_list = db.get_all_channels()
                st_map = db.get_channels_video_schedule_status()
            except Exception:
                self._is_async_reloading = False
                return

            def _apply_ui():
                self._is_async_reloading = False
                if not self.isVisible():
                    self._pending_reload = True
                    return
                self.channels_data = ch_list
                self.apply_filters(status_map=st_map)
                self._refresh_series_live_banner()
                self.channel_updated.emit()

            QTimer.singleShot(0, _apply_ui)

        threading.Thread(target=_bg_fetch, daemon=True).start()

    def init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 20, 24, 20)
        layout.setSpacing(16)

        # Header Title & Top Buttons
        header_layout = QHBoxLayout()
        title_box = QVBoxLayout()
        lbl_title = QLabel("Quản Lý Kênh TikTok & Tùy Chọn IP VPN Theo Từng Kênh")
        lbl_title.setProperty("class", "page-title")
        lbl_subtitle = QLabel("Đăng nhập 1 tài khoản VPN cho toàn tool: Tích chọn kênh nào muốn đổi IP hoặc giữ nguyên IP gốc")
        lbl_subtitle.setStyleSheet("color: #25F4EE; font-size: 13px; font-weight: 600;")
        title_box.addWidget(lbl_title)
        title_box.addWidget(lbl_subtitle)
        header_layout.addLayout(title_box)

        header_layout.addStretch()

        # Nút Mở Hộp Thoại Quản Lý VPN Trung Tâm
        self.btn_open_vpn_mgr = QPushButton("🛡️ TÀI KHOẢN VPN & CHỌN NƯỚC")
        self.btn_open_vpn_mgr.setProperty("class", "btn-secondary")
        self.btn_open_vpn_mgr.setStyleSheet("color: #25F4EE; border: 1px solid #25F4EE; font-weight: 700; padding: 7px 14px;")
        self.btn_open_vpn_mgr.setCursor(Qt.PointingHandCursor)
        self.btn_open_vpn_mgr.clicked.connect(self.open_vpn_account_dialog)
        header_layout.addWidget(self.btn_open_vpn_mgr)

        # Nút Gán Proxy Tĩnh Hàng Loạt trên Header (To rõ, nổi bật)
        self.btn_batch_proxy = QPushButton("🛡️ GÁN PROXY TĨNH")
        self.btn_batch_proxy.setCursor(Qt.PointingHandCursor)
        self.btn_batch_proxy.setStyleSheet("background-color: #0284C7; color: #FFFFFF; font-weight: 800; font-size: 13px; padding: 7px 16px; border-radius: 6px; border: 1.5px solid #38BDF8;")
        self.btn_batch_proxy.setToolTip("Cấu hình & Gán Proxy tĩnh (5 Kênh / 1 Proxy trên 1 lần đăng, xoay tua tự động)")
        self.btn_batch_proxy.clicked.connect(self.open_batch_proxy_dialog)
        header_layout.addWidget(self.btn_batch_proxy)

        # Nút Đăng nhập hàng loạt (Gradient tím hồng)
        self.btn_batch_login = QPushButton("🚀 ĐĂNG NHẬP HÀNG LOẠT")
        self.btn_batch_login.setProperty("class", "btn-batch")
        self.btn_batch_login.setCursor(Qt.PointingHandCursor)
        self.btn_batch_login.clicked.connect(self.batch_launch_profiles)
        header_layout.addWidget(self.btn_batch_login)

        # Nút Thêm kênh mới
        self.btn_add_channel = QPushButton("➕ Thêm Kênh Mới")
        self.btn_add_channel.setProperty("class", "btn-primary")
        self.btn_add_channel.clicked.connect(self.open_add_channel_dialog)
        header_layout.addWidget(self.btn_add_channel)

        layout.addLayout(header_layout)

        # Thanh công cụ: Checkbox chọn tất cả, Thao tác bật/tắt VPN hàng loạt, Lọc & Tìm kiếm
        # Tất cả các ô trên thanh công cụ được thiết kế đồng bộ theo phong cách button viền xám nền xanh thẫm
        tool_bar = QFrame()
        tool_bar.setProperty("class", "content-panel")
        tool_layout = QHBoxLayout(tool_bar)
        tool_layout.setContentsMargins(14, 10, 14, 10)
        tool_layout.setSpacing(12)

        self.chk_select_all = QCheckBox("Chọn tất cả")
        self.chk_select_all.setCursor(Qt.PointingHandCursor)
        self.chk_select_all.setStyleSheet("""
            QCheckBox {
                background-color: #1C2337;
                color: #FFFFFF;
                border: 1px solid #2B3654;
                border-radius: 6px;
                padding: 6px 14px;
                font-weight: 600;
                font-size: 12px;
            }
            QCheckBox:hover {
                background-color: #242E48;
                border-color: #38476E;
            }
            QCheckBox::indicator {
                width: 16px;
                height: 16px;
                border-radius: 4px;
                border: 1.5px solid #475569;
                background-color: #0F172A;
            }
            QCheckBox::indicator:hover {
                border: 1.5px solid #38BDF8;
                background-color: #1E293B;
            }
            QCheckBox::indicator:checked {
                background-color: #2563EB;
                border: 1.5px solid #60A5FA;
                image: url("assets/check_white.png");
            }
        """)
        self.chk_select_all.stateChanged.connect(self.toggle_select_all)
        tool_layout.addWidget(self.chk_select_all)

        # 2 nút Bật/Tắt VPN cho các kênh đã chọn
        btn_enable_vpn_batch = QPushButton("⚡ Bật VPN")
        btn_enable_vpn_batch.setCursor(Qt.PointingHandCursor)
        btn_enable_vpn_batch.setToolTip("Bật VPN cho tất cả các kênh được tích chọn")
        btn_enable_vpn_batch.setStyleSheet("""
            QPushButton {
                background-color: #1C2337;
                color: #FFFFFF;
                border: 1px solid #2B3654;
                border-radius: 6px;
                padding: 6px 14px;
                font-weight: 600;
                font-size: 12px;
            }
            QPushButton:hover {
                background-color: #0D9488;
                border-color: #14B8A6;
            }
        """)
        btn_enable_vpn_batch.clicked.connect(lambda: self.set_batch_vpn_status(True))
        tool_layout.addWidget(btn_enable_vpn_batch)

        btn_disable_vpn_batch = QPushButton("🌐 Tắt VPN (Dùng IP Gốc)")
        btn_disable_vpn_batch.setCursor(Qt.PointingHandCursor)
        btn_disable_vpn_batch.setToolTip("Tắt VPN, chuyển về IP gốc cho các kênh được chọn")
        btn_disable_vpn_batch.setStyleSheet("""
            QPushButton {
                background-color: #1C2337;
                color: #FFFFFF;
                border: 1px solid #2B3654;
                border-radius: 6px;
                padding: 6px 14px;
                font-weight: 600;
                font-size: 12px;
            }
            QPushButton:hover {
                background-color: #DC2626;
                border-color: #EF4444;
            }
        """)
        btn_disable_vpn_batch.clicked.connect(lambda: self.set_batch_vpn_status(False))
        tool_layout.addWidget(btn_disable_vpn_batch)

        # Nút Gán Proxy Tĩnh trực tiếp trên thanh công cụ (Đặt cạnh Bật/Tắt VPN)
        self.btn_proxy_toolbar = QPushButton("🛡️ GÁN PROXY TĨNH")
        self.btn_proxy_toolbar.setCursor(Qt.PointingHandCursor)
        self.btn_proxy_toolbar.setToolTip("Cấu hình & Gán Proxy tĩnh (5 Kênh / 1 Proxy trên 1 lần đăng, tự động xoay tua)")
        self.btn_proxy_toolbar.setStyleSheet("""
            QPushButton {
                background-color: #1E293B;
                color: #38BDF8;
                border: 1.5px solid #0284C7;
                border-radius: 6px;
                padding: 6px 14px;
                font-weight: 700;
                font-size: 12px;
            }
            QPushButton:hover {
                background-color: #0284C7;
                color: #FFFFFF;
                border-color: #38BDF8;
            }
        """)
        self.btn_proxy_toolbar.clicked.connect(self.open_batch_proxy_dialog)
        tool_layout.addWidget(self.btn_proxy_toolbar)

        # Nút Tự Động Series YouTube (1 Kênh - 1 Nguồn - Rải Lịch)
        self.btn_auto_series = QPushButton("🎬 TỰ ĐỘNG SERIES YOUTUBE")
        self.btn_auto_series.setCursor(Qt.PointingHandCursor)
        self.btn_auto_series.setToolTip("Tự động lấy video phổ biến nhất từ YouTube, cắt 9:16 giữ chân và rải lịch độc quyền theo ngày cho 1 kênh")
        self.btn_auto_series.setStyleSheet("""
            QPushButton {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #8B5CF6, stop:1 #EC4899);
                color: #FFFFFF;
                border: 1.5px solid #C084FC;
                border-radius: 6px;
                padding: 6px 14px;
                font-weight: 700;
                font-size: 12px;
            }
            QPushButton:hover {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #7C3AED, stop:1 #DB2777);
                border-color: #F472B6;
            }
        """)
        self.btn_auto_series.clicked.connect(lambda: self.open_auto_series_dialog())
        tool_layout.addWidget(self.btn_auto_series)

        # Nút Sửa Đổi Tên Kênh cho các kênh được tích chọn
        btn_rename_batch = QPushButton("✏️ Đổi Tên Kênh")
        btn_rename_batch.setCursor(Qt.PointingHandCursor)
        btn_rename_batch.setToolTip("Tích chọn các kênh cần đổi tên rồi bấm vào đây để sửa đổi tên kênh")
        btn_rename_batch.setStyleSheet("""
            QPushButton {
                background-color: #1C2337;
                color: #FFFFFF;
                border: 1px solid #2B3654;
                border-radius: 6px;
                padding: 6px 14px;
                font-weight: 600;
                font-size: 12px;
            }
            QPushButton:hover {
                background-color: #2563EB;
                border-color: #3B82F6;
            }
        """)
        btn_rename_batch.clicked.connect(self.rename_selected_channels)
        tool_layout.addWidget(btn_rename_batch)

        # Nút Tự động đồng bộ Chỉ số Followers (Flow) & Views trực tiếp từ TikTok
        self.btn_stats_batch = QPushButton("🔄 TỰ ĐỘNG ĐỒNG BỘ FLOW & VIEW")
        self.btn_stats_batch.setCursor(Qt.PointingHandCursor)
        self.btn_stats_batch.setToolTip("Tool tự động quét và cập nhật trực tiếp số liệu Follower và Lượt Xem chuẩn xác từ TikTok cho toàn bộ kênh")
        self.btn_stats_batch.setStyleSheet("""
            QPushButton {
                background-color: #0F2942;
                color: #38BDF8;
                border: 1.5px solid #0284C7;
                border-radius: 6px;
                padding: 6px 14px;
                font-weight: 700;
                font-size: 12px;
            }
            QPushButton:hover {
                background-color: #0284C7;
                color: #FFFFFF;
                border-color: #38BDF8;
            }
        """)
        self.btn_stats_batch.clicked.connect(self.trigger_full_auto_sync)
        tool_layout.addWidget(self.btn_stats_batch)

        # Ô Lọc kênh thiết kế giống hệt nút Bật Fake và Tắt VPN
        self.cmb_filter_net = QComboBox()
        self.cmb_filter_net.setMinimumWidth(190)
        self.cmb_filter_net.setCursor(Qt.PointingHandCursor)
        self.cmb_filter_net.addItem("🔍 Lọc: Tất cả kênh", "all")
        self.cmb_filter_net.addItem("🟢 Lọc: Kênh còn video", "active")
        self.cmb_filter_net.addItem("🟠 Lọc: Kênh sắp hết video", "ending_soon")
        self.cmb_filter_net.addItem("🔴 Lọc: Kênh hết video", "empty")
        self.cmb_filter_net.addItem("🛡️ Lọc: Đang bật VPN", "vpn")
        self.cmb_filter_net.addItem("🌐 Lọc: Đang dùng IP Gốc", "direct")
        self.cmb_filter_net.setStyleSheet("""
            QComboBox {
                background-color: #1C2337;
                color: #FFFFFF;
                border: 1px solid #2B3654;
                border-radius: 6px;
                padding: 6px 14px;
                font-weight: 500;
                font-size: 12px;
            }
            QComboBox:hover {
                background-color: #242E48;
                border-color: #38476E;
            }
            QComboBox::drop-down {
                border: none;
                width: 22px;
            }
            QComboBox QAbstractItemView {
                background-color: #1C2337;
                border: 1px solid #2B3654;
                selection-background-color: #2563EB;
                selection-color: #FFFFFF;
                color: #FFFFFF;
                padding: 4px;
            }
        """)
        self.cmb_filter_net.currentIndexChanged.connect(self.apply_filters)
        tool_layout.addWidget(self.cmb_filter_net)

        self.txt_search = QLineEdit()
        self.txt_search.setPlaceholderText("🔎 Tìm theo tên kênh hoặc username...")
        self.txt_search.setClearButtonEnabled(True)
        self.txt_search.setStyleSheet("""
            QLineEdit {
                background-color: #1C2337;
                color: #FFFFFF;
                border: 1px solid #2B3654;
                border-radius: 6px;
                padding: 6px 14px;
                font-size: 12px;
            }
            QLineEdit:focus {
                border: 1px solid #38BDF8;
                background-color: #242E48;
            }
        """)
        self._search_timer = QTimer(self)
        self._search_timer.setSingleShot(True)
        self._search_timer.setInterval(150)
        self._search_timer.timeout.connect(self.apply_filters)
        self.txt_search.textChanged.connect(lambda: self._search_timer.start())
        tool_layout.addWidget(self.txt_search, 1)

        layout.addWidget(tool_bar)

        # Thanh thông báo tiến trình tải/cắt video tự động ngầm (hiển thị ngay trên đầu bảng khi có kênh đang chạy)
        self.lbl_series_live_banner = QLabel("")
        self.lbl_series_live_banner.setVisible(False)
        self.lbl_series_live_banner.setStyleSheet("""
            QLabel {
                background-color: #0B2A4A;
                color: #38BDF8;
                border: 1px solid #0284C7;
                border-radius: 6px;
                padding: 7px 14px;
                font-size: 12px;
                font-weight: 700;
            }
        """)
        layout.addWidget(self.lbl_series_live_banner)

        # Bảng danh sách kênh TikTok chuyên nghiệp
        self.table = QTableWidget()
        self.table.setColumnCount(12)
        self.table.setHorizontalHeaderLabels([
            "STT", "Kênh TikTok", "Nguồn YouTube", "Lịch Đăng", "VPN", "Kết Nối / IP",
            "Đăng Nhập", "Follow", "View", "Đã Đăng", "Chrome", "Thao Tác"
        ])

        header = self.table.horizontalHeader()
        header.setSectionResizeMode(0, QHeaderView.Fixed)
        self.table.setColumnWidth(0, 46)

        header.setSectionResizeMode(1, QHeaderView.Interactive)
        self.table.setColumnWidth(1, 210)

        header.setSectionResizeMode(2, QHeaderView.Interactive)
        self.table.setColumnWidth(2, 190)

        header.setSectionResizeMode(3, QHeaderView.Interactive)
        self.table.setColumnWidth(3, 195)

        header.setSectionResizeMode(4, QHeaderView.Interactive)
        self.table.setColumnWidth(4, 145)

        header.setSectionResizeMode(5, QHeaderView.Stretch)

        header.setSectionResizeMode(6, QHeaderView.Fixed)
        self.table.setColumnWidth(6, 110)

        header.setSectionResizeMode(7, QHeaderView.Fixed)
        self.table.setColumnWidth(7, 95)

        header.setSectionResizeMode(8, QHeaderView.Fixed)
        self.table.setColumnWidth(8, 95)

        header.setSectionResizeMode(9, QHeaderView.Fixed)
        self.table.setColumnWidth(9, 75)

        header.setSectionResizeMode(10, QHeaderView.Fixed)
        self.table.setColumnWidth(10, 100)

        header.setSectionResizeMode(11, QHeaderView.Fixed)
        self.table.setColumnWidth(11, 145)

        self.table.verticalHeader().setDefaultSectionSize(52)
        self.table.verticalHeader().setVisible(False)
        self.table.setSelectionBehavior(QTableWidget.SelectRows)
        self.table.setSelectionMode(QTableWidget.ExtendedSelection)
        self.table.setEditTriggers(QTableWidget.NoEditTriggers)
        self.table.setWordWrap(False)
        self.table.setTextElideMode(Qt.ElideRight)
        self.table.setStyleSheet("""
            QWidget#cell_box { background: transparent; border: none; }
            QPushButton#yt_btn {
                background-color: #0C2B35; color: #38BDF8; border: 1px solid #0891B2;
                border-radius: 6px; font-weight: 700; font-size: 11px; padding: 4px 6px; text-align: center;
            }
            QPushButton#yt_btn:hover { background-color: #0891B2; color: #FFFFFF; border-color: #38BDF8; }
            QPushButton#yt_del {
                background-color: #7F1D1D; color: #FCA5A5; border: 1px solid #DC2626;
                border-radius: 4px; font-size: 10px; font-weight: 700;
            }
            QPushButton#yt_del:hover { background-color: #DC2626; color: #FFFFFF; }
            QPushButton#yt_add {
                background-color: #1E293B; color: #94A3B8; border: 1px dashed #475569;
                border-radius: 6px; font-weight: 600; font-size: 11px; padding: 4px 8px;
            }
            QPushButton#yt_add:hover { background-color: #334155; color: #FFFFFF; border-color: #94A3B8; }
            QLabel#lbl_prio {
                background-color: #0F2942; color: #38BDF8; border: 1px solid #0284C7;
                border-radius: 5px; font-weight: 800; font-size: 11px; padding: 3px 8px;
            }
            QCheckBox#chk_vpn { font-weight: 700; color: #38BDF8; spacing: 8px; }
            QLabel#lbl_unlogged { color: #94A3B8; font-size: 11px; }
            QPushButton#btn_mark_login {
                background-color: #16A34A; color: #FFFFFF; font-weight: 700;
                font-size: 10px; padding: 3px 6px; border-radius: 4px;
            }
            QPushButton#flow_active {
                background-color: #0F2942; color: #38BDF8; border: 1px solid #0284C7;
                border-radius: 5px; font-weight: 700; font-size: 11px; padding: 4px 8px;
            }
            QPushButton#flow_empty {
                background-color: #1E293B; color: #94A3B8; border: 1px solid #334155;
                border-radius: 5px; font-weight: 700; font-size: 11px; padding: 4px 8px;
            }
            QPushButton#flow_active:hover, QPushButton#flow_empty:hover {
                background-color: #0284C7; color: #FFFFFF; border-color: #38BDF8;
            }
            QPushButton#view_active {
                background-color: #3B1425; color: #F472B6; border: 1px solid #DB2777;
                border-radius: 5px; font-weight: 700; font-size: 11px; padding: 4px 8px;
            }
            QPushButton#view_empty {
                background-color: #1E293B; color: #94A3B8; border: 1px solid #334155;
                border-radius: 5px; font-weight: 700; font-size: 11px; padding: 4px 8px;
            }
            QPushButton#view_active:hover, QPushButton#view_empty:hover {
                background-color: #DB2777; color: #FFFFFF; border-color: #F472B6;
            }
            QPushButton#btn_chrome {
                background-color: #1E293B; color: #38BDF8; border: 1px solid #334155;
                border-radius: 5px; font-weight: 700; font-size: 11px; padding: 4px 8px;
            }
            QPushButton#btn_chrome:hover { background-color: #2563EB; color: #FFFFFF; border-color: #60A5FA; }
            QPushButton#btn_audit {
                background-color: #0C2B35; border: 1px solid #0891B2; border-radius: 6px; font-size: 14px;
            }
            QPushButton#btn_audit:hover { background-color: #0E7490; border-color: #22D3EE; }
            QPushButton#btn_sched {
                background-color: #1E293B; border: 1px solid #334155; border-radius: 6px; font-size: 13px;
            }
            QPushButton#btn_sched:hover { background-color: #2563EB; border-color: #60A5FA; }
            QPushButton#btn_edit {
                background-color: #1E293B; border: 1px solid #334155; border-radius: 6px; font-size: 13px;
            }
            QPushButton#btn_edit:hover { background-color: #475569; border-color: #94A3B8; }
            QPushButton#btn_del {
                background-color: #2A1215; border: 1px solid #7F1D1D; border-radius: 6px; font-size: 13px;
            }
            QPushButton#btn_del:hover { background-color: #DC2626; border-color: #EF4444; }
        """)
        self.table.itemSelectionChanged.connect(self.on_selection_changed)
        self.table.cellDoubleClicked.connect(self.on_cell_double_clicked)

        # Đã bỏ sự kiện click/double click vào dòng để mở Chrome (chỉ mở Chrome khi ấn nút chuyên biệt)

        layout.addWidget(self.table)
        self.load_channels()

    def load_channels(self):
        if not self.isVisible() and self.channels_data:
            self._pending_reload = True
            self._refresh_series_live_banner()
            self.channel_updated.emit()
            return
        self._pending_reload = False
        self.channels_data = db.get_all_channels()
        self.apply_filters()
        self._refresh_series_live_banner()
        self.channel_updated.emit()

    def _refresh_series_live_banner(self):
        """Cập nhật thanh thông báo trực tiếp ngay phía trên bảng khi có kênh đang tự động cắt video."""
        try:
            from core.series_queue_manager import series_queue_mgr
            summary = series_queue_mgr.get_active_summary()
            if summary:
                self.lbl_series_live_banner.setText(summary)
                self.lbl_series_live_banner.setVisible(True)
            else:
                self.lbl_series_live_banner.clear()
                self.lbl_series_live_banner.setVisible(False)
        except Exception:
            pass

    def apply_filters(self, status_map=None):
        query = self.txt_search.text().strip().lower()
        net_filter = self.cmb_filter_net.currentData()

        # Lấy trạng thái lịch đăng video chuẩn xác của từng kênh
        if status_map is None:
            status_map = db.get_channels_video_schedule_status()

        filtered = []
        for ch in self.channels_data:
            if query and (
                query not in ch.get("name", "").lower()
                and query not in ch.get("username", "").lower()
                and query not in str(ch.get("youtube_channel_name", "")).lower()
            ):
                continue
            use_vpn = ch.get("use_vpn", 1)
            cid = ch["id"]
            st_info = status_map.get(cid, {})
            st_type = st_info.get("status_type", "empty")

            if net_filter == "vpn" and use_vpn == 0:
                continue
            elif net_filter == "direct" and use_vpn == 1:
                continue
            elif net_filter == "active" and st_type != "active":
                continue
            elif net_filter == "ending_soon" and st_type not in ("ending_today", "ending_tomorrow"):
                continue
            elif net_filter == "empty" and st_type != "empty":
                continue

            filtered.append(ch)

        self.current_rendered_channels = filtered
        self.render_table(filtered, status_map)

    def render_table(self, channels, status_map=None):
        if status_map is None:
            status_map = db.get_channels_video_schedule_status()

        # QUAN TRỌNG: Tạm tắt repaint khi dựng bảng + clearSpans() trước khi render lại
        self.table.setUpdatesEnabled(False)
        self.table.blockSignals(True)
        try:
            self._render_table_inner(channels, status_map)
        finally:
            self.table.blockSignals(False)
            self.table.setUpdatesEnabled(True)

    def _render_table_inner(self, channels, status_map):
        self.table.clearSpans()
        self.table.clearContents()
        total_channels = len(channels)
        self.table.setRowCount(total_channels)
        self.row_checkboxes.clear()

        if total_channels == 0:
            if getattr(self, "channels_data", None):
                self.table.setRowCount(1)
                q_text = self.txt_search.text().strip()
                empty_msg = f"🔍 Không có kênh nào khớp với '{q_text}' (Bấm vào đây hoặc nút [✕] để hiện lại tất cả kênh)" if q_text else "🔍 Không có kênh nào phù hợp với bộ lọc hiện tại. Bấm vào đây để xem tất cả."
                empty_item = QTableWidgetItem(empty_msg)
                empty_item.setTextAlignment(Qt.AlignCenter)
                empty_item.setForeground(QColor("#38BDF8"))
                font_empty = QFont("Segoe UI", 11)
                font_empty.setBold(True)
                empty_item.setFont(font_empty)
                self.table.setItem(0, 1, empty_item)
                self.table.setSpan(0, 1, 1, 7)
            return

        # Nạp các giá trị chung 1 lần ngoài vòng lặp (tránh truy vấn DB/JSON O(N^2))
        saved_country = db.get_setting("global_vpn_country_name", "Philippines")
        cached_fake_ip = db.get_setting("cached_fake_ip", "")
        c_clean = saved_country
        for p in ["🇻🇳", "🇯🇵", "🇰🇷", "🇸🇬", "🇹🇼", "🇭🇰", "🇹🇭", "🇲🇾", "🇮🇩", "🇵🇭", "🇮🇳", "🇦🇺", "🇺🇸", "🇨🇦", "🇬🇧", "🇩🇪", "🇫🇷", "🇳🇱"]:
            c_clean = c_clean.replace(p, "").strip()
        if "(" in c_clean:
            c_clean = c_clean.split("(")[0].strip()

        from core.rotating_proxy_manager import rotating_proxy_mgr
        from core.series_queue_manager import series_queue_mgr
        rot_cfg = rotating_proxy_mgr.get_config()
        rot_enabled = rot_cfg["enabled"] and len(rot_cfg["proxies"]) > 0
        target_index_map = None
        if rot_enabled:
            target_cids = rot_cfg.get("target_channel_ids") or [int(c["id"]) for c in channels]
            sorted_targets = sorted(target_cids)
            target_index_map = {cid_val: i for i, cid_val in enumerate(sorted_targets)}

        try:
            if rot_enabled:
                self.btn_batch_proxy.setText("🛡️ GÁN PROXY TĨNH (ĐANG BẬT XOAY TUA)")
                self.btn_batch_proxy.setStyleSheet("background-color: #10B981; color: #FFFFFF; font-weight: 800; padding: 7px 14px; border-radius: 6px; border: 1.5px solid #34D399;")
                if hasattr(self, 'btn_proxy_toolbar'):
                    self.btn_proxy_toolbar.setText("🛡️ PROXY (ĐANG XOAY TUA)")
                    self.btn_proxy_toolbar.setStyleSheet("background-color: #065F46; color: #34D399; border: 1.5px solid #10B981; border-radius: 6px; padding: 6px 14px; font-weight: 700; font-size: 12px;")
            else:
                self.btn_batch_proxy.setText("🛡️ GÁN PROXY TĨNH")
                self.btn_batch_proxy.setStyleSheet("background-color: #0284C7; color: #FFFFFF; font-weight: 800; padding: 7px 16px; border-radius: 6px; border: 1.5px solid #38BDF8;")
                if hasattr(self, 'btn_proxy_toolbar'):
                    self.btn_proxy_toolbar.setText("🛡️ GÁN PROXY TĨNH")
                    self.btn_proxy_toolbar.setStyleSheet("background-color: #1E293B; color: #38BDF8; border: 1.5px solid #0284C7; border-radius: 6px; padding: 6px 14px; font-weight: 700; font-size: 12px;")
        except Exception:
            pass

        font_bold_10 = QFont("Segoe UI", 10)
        font_bold_10.setBold(True)
        font_bold_9 = QFont("Segoe UI", 9)
        font_bold_9.setBold(True)

        for row, ch in enumerate(channels):
            # Cột 0: STT - Đánh số từ cao xuống thấp (ví dụ: 18, 17, 16... 1)
            stt_num = total_channels - row
            item_stt = QTableWidgetItem(str(stt_num))
            item_stt.setTextAlignment(Qt.AlignCenter)
            item_stt.setToolTip(f"STT: {stt_num} (ID Kênh: {ch.get('id', '')})")
            item_stt.setData(Qt.UserRole, ch.get("id"))
            item_stt.setForeground(QColor("#94A3B8"))
            item_stt.setFont(font_bold_10)
            self.table.setItem(row, 0, item_stt)

            # Cột 1: Tên kênh TikTok (làm sạch xuống dòng / ký tự ẩn để không bị lỗi hiển thị '🎬 ...')
            raw_name = str(ch.get("name") or "").replace("\u200b", "").replace("\ufeff", "")
            name = " ".join(raw_name.split()) or "Kênh"
            raw_user = " ".join(str(ch.get("username") or "").replace("\u200b", "").replace("\ufeff", "").split())
            handle = raw_user if raw_user else f"@{name}"
            if not handle.startswith("@"):
                handle = f"@{handle}"

            clean_name = name.lstrip("@").strip()
            clean_handle = handle.lstrip("@").strip()
            if not clean_name and clean_handle:
                clean_name = clean_handle
                name = clean_handle
            if clean_name.lower() == clean_handle.lower():
                display_name = f"🎬 @{clean_name}"
            else:
                display_name = f"🎬 {name} ({handle})"

            item_name = QTableWidgetItem(display_name)
            item_name.setToolTip(f"Kênh TikTok: {display_name} (ID: {ch.get('id', '')})")
            item_name.setForeground(Qt.white)
            item_name.setFont(font_bold_10)
            self.table.setItem(row, 1, item_name)

            # Cột 2: Nguồn YouTube (không gọi network đồng bộ trong luồng giao diện)
            yt_source = str(ch.get("youtube_channel_name") or "").strip()
            yt_url = str(ch.get("youtube_source_url") or "").strip()

            yt_box = QWidget()
            yt_box.setObjectName("cell_box")
            yt_layout = QHBoxLayout(yt_box)
            yt_layout.setContentsMargins(4, 2, 4, 2)
            yt_layout.setSpacing(4)
            yt_layout.setAlignment(Qt.AlignCenter)

            if yt_source or yt_url:
                raw_name = yt_source or "YouTube"
                display_yt = raw_name if raw_name.startswith("@") else f"@{raw_name}"
                btn_yt = QPushButton(f"📺 {display_yt}")
                btn_yt.setObjectName("yt_btn")
                btn_yt.setCursor(Qt.PointingHandCursor)
                btn_yt.setToolTip(f"Nguồn YouTube độc quyền: {display_yt}\nLink: {yt_url}\n👉 Bấm vào đây để đổi nguồn hoặc cấu hình cho kênh này")
                btn_yt.clicked.connect(lambda checked=False, cid=ch["id"]: self.open_auto_series_dialog(cid))
                yt_layout.addWidget(btn_yt, 1)

                btn_del_yt = QPushButton("❌")
                btn_del_yt.setObjectName("yt_del")
                btn_del_yt.setFixedSize(22, 22)
                btn_del_yt.setCursor(Qt.PointingHandCursor)
                btn_del_yt.setToolTip(f"Xóa nguồn YouTube và tắt tự động lấy video cho kênh @{ch.get('name', '')}")
                btn_del_yt.clicked.connect(lambda checked=False, cid=ch["id"], cname=ch.get("name", ""): self.quick_clear_youtube_source(cid, cname))
                yt_layout.addWidget(btn_del_yt)
            else:
                btn_yt = QPushButton("➕ Gán nguồn")
                btn_yt.setObjectName("yt_add")
                btn_yt.setCursor(Qt.PointingHandCursor)
                btn_yt.setToolTip("Kênh này chưa gán nguồn YouTube. Bấm vào đây để gán nguồn tự động nạp video!")
                btn_yt.clicked.connect(lambda checked=False, cid=ch["id"]: self.open_auto_series_dialog(cid))
                yt_layout.addWidget(btn_yt, 1)

            self.table.setCellWidget(row, 2, yt_box)

            # Cột 3: TÌNH TRẠNG LỊCH ĐĂNG VIDEO
            cid = ch["id"]
            q_st = series_queue_mgr.get_channel_status(cid)

            if q_st:
                if q_st.get("status") == "processing":
                    prog = q_st.get("progress", 0)
                    st_info = {
                        "status_type": "processing",
                        "count": 0,
                        "label": f"⚡ Đang cắt ({prog}%)",
                        "tooltip": f"Kênh đang được Tool tải & cắt video tự động ngầm:\n{q_st.get('step', '')}\n👉 Cắt tuần tự từng kênh 1 an toàn 100%!",
                        "color": "#38BDF8",
                        "bg_color": "#0B2A4A",
                        "border_color": "#0284C7"
                    }
                else:
                    pos = q_st.get("position", 1)
                    st_info = {
                        "status_type": "queued",
                        "count": 0,
                        "label": f"⏳ Chờ cắt (#{pos})",
                        "tooltip": f"Kênh đang trong hàng đợi tự động cắt video (Vị trí #{pos}).\nTool sẽ cắt xong kênh trước rồi tự động đến kênh này!",
                        "color": "#FCD34D",
                        "bg_color": "#3B2507",
                        "border_color": "#D97706"
                    }
            else:
                st_info = status_map.get(cid, {
                    "status_type": "empty",
                    "count": 0,
                    "label": "🔴 Hết video",
                    "tooltip": "Kênh chưa có video nào trong lịch hẹn đăng",
                    "color": "#EF4444",
                    "bg_color": "#2D1519",
                    "border_color": "#7F1D1D"
                })

            badge_box = QWidget()
            badge_box.setObjectName("cell_box")
            badge_l = QHBoxLayout(badge_box)
            badge_l.setContentsMargins(4, 2, 4, 2)
            badge_l.setAlignment(Qt.AlignCenter)

            lbl_sched = QLabel(st_info["label"])
            lbl_sched.setAlignment(Qt.AlignCenter)
            lbl_sched.setToolTip(st_info.get("tooltip", ""))
            lbl_sched.setStyleSheet(
                f"QLabel {{ background-color: {st_info.get('bg_color', '#1C2337')}; "
                f"color: {st_info.get('color', '#FFFFFF')}; "
                f"border: 1px solid {st_info.get('border_color', '#2B3654')}; "
                f"border-radius: 6px; font-weight: 700; font-size: 11px; padding: 4px 10px; }}"
            )
            badge_l.addWidget(lbl_sched)
            self.table.setCellWidget(row, 3, badge_box)

            net_info = rotating_proxy_mgr.resolve_channel_network(ch, cached_cfg=rot_cfg, target_index_map=target_index_map)
            is_proxy_channel = (net_info["mode"] == "proxy")

            # Cột 4: TÍCH CHỌN BẬT VPN HOẶC TRẠNG THÁI ƯU TIÊN PROXY
            vpn_cell_w = QWidget()
            vpn_cell_w.setObjectName("cell_box")
            vpn_cell_l = QHBoxLayout(vpn_cell_w)
            vpn_cell_l.setContentsMargins(6, 2, 6, 2)
            vpn_cell_l.setAlignment(Qt.AlignCenter)

            if is_proxy_channel:
                lbl_prio = QLabel("🛡️ Ưu tiên Proxy")
                lbl_prio.setObjectName("lbl_prio")
                lbl_prio.setToolTip("Kênh này đã được tích chọn gắn Proxy Tĩnh.\nProxy được ưu tiên tuyệt đối, không bị chèn IP của VPN PIA!")
                vpn_cell_l.addWidget(lbl_prio)
            else:
                chk_vpn = QCheckBox("VPN PIA")
                chk_vpn.setObjectName("chk_vpn")
                chk_vpn.setChecked(True)
                chk_vpn.setCursor(Qt.PointingHandCursor)
                chk_vpn.stateChanged.connect(lambda state, cid=ch["id"]: self.on_channel_vpn_toggled(state, cid))
                vpn_cell_l.addWidget(chk_vpn)

            self.table.setCellWidget(row, 4, vpn_cell_w)

            # Cột 5: Kết Nối / Quốc Gia
            if is_proxy_channel:
                item_badge = QTableWidgetItem(net_info["badge_text"])
                item_badge.setForeground(QColor(net_info.get("badge_color", "#38BDF8")))
                item_badge.setToolTip(net_info.get("tooltip", "Kênh chạy qua Proxy Tĩnh (Ưu tiên số 1, tách biệt hoàn toàn khỏi VPN PIA)"))
            else:
                if cached_fake_ip and cached_fake_ip not in ["Chưa fake", "Đang quét..."]:
                    badge_text = f"🛡️ VPN PIA: {c_clean} ({cached_fake_ip})"
                else:
                    badge_text = f"🛡️ VPN PIA: {c_clean}"
                item_badge = QTableWidgetItem(badge_text)
                item_badge.setForeground(QColor("#34D399"))
                disp_ip = cached_fake_ip if (cached_fake_ip and cached_fake_ip not in ["Chưa fake", "Đang quét..."]) else "Tự động kết nối khi chạy"
                item_badge.setToolTip(f"Kênh không gắn Proxy ➔ Mặc định chạy qua VPN của PIA ({saved_country})\nĐịa chỉ IP VPN: {disp_ip}")

            item_badge.setTextAlignment(Qt.AlignCenter)
            item_badge.setFont(font_bold_10)
            self.table.setItem(row, 5, item_badge)

            # Cột 6: Trạng thái Login
            is_logged = bool(ch["is_logged_in"])
            if is_logged:
                item_status = QTableWidgetItem("🟢 ĐÃ ĐĂNG NHẬP")
                item_status.setTextAlignment(Qt.AlignCenter)
                item_status.setForeground(QColor("#22C55E"))
                item_status.setFont(font_bold_9)
                self.table.setItem(row, 6, item_status)
            else:
                status_box = QWidget()
                status_box.setObjectName("cell_box")
                status_layout = QHBoxLayout(status_box)
                status_layout.setContentsMargins(4, 2, 4, 2)
                status_layout.setSpacing(6)
                status_layout.setAlignment(Qt.AlignCenter)

                lbl_status = QLabel("⚪ Chưa Login")
                lbl_status.setObjectName("lbl_unlogged")
                btn_mark_login = QPushButton("✅ Hoàn tất")
                btn_mark_login.setObjectName("btn_mark_login")
                btn_mark_login.setToolTip("Bấm vào đây để xác nhận kênh này đã đăng nhập xong trên web")
                btn_mark_login.setCursor(Qt.PointingHandCursor)
                btn_mark_login.clicked.connect(lambda checked=False, cid=ch["id"], cname=ch["name"]: self.quick_confirm_login(cid, cname))
                status_layout.addWidget(lbl_status)
                status_layout.addWidget(btn_mark_login)
                self.table.setCellWidget(row, 6, status_box)

            # Cột 7: Followers
            flow_cnt = int(ch.get("followers_count") or 0)
            flow_box = QWidget()
            flow_box.setObjectName("cell_box")
            flow_layout = QHBoxLayout(flow_box)
            flow_layout.setContentsMargins(4, 2, 4, 2)
            flow_layout.setAlignment(Qt.AlignCenter)

            flow_text = f"👥 {self.format_metric(flow_cnt)}" if flow_cnt > 0 else "⚪ 0 Follow"
            btn_flow = QPushButton(flow_text)
            btn_flow.setObjectName("flow_active" if flow_cnt > 0 else "flow_empty")
            btn_flow.setCursor(Qt.PointingHandCursor)
            btn_flow.setToolTip(f"👥 Người theo dõi: {flow_cnt:,} Follower\n🟢 Tự động đồng bộ chuẩn xác từ TikTok\n👉 Bấm để quét cập nhật ngay lập tức")
            btn_flow.setFixedHeight(30)
            btn_flow.clicked.connect(lambda checked=False, ch_obj=ch: self.auto_sync_single_channel(ch_obj))
            flow_layout.addWidget(btn_flow)
            self.table.setCellWidget(row, 7, flow_box)

            # Cột 8: Lượt Thích / View
            views_cnt = int(ch.get("views_count") or ch.get("likes_count") or 0)
            view_box = QWidget()
            view_box.setObjectName("cell_box")
            view_layout = QHBoxLayout(view_box)
            view_layout.setContentsMargins(4, 2, 4, 2)
            view_layout.setAlignment(Qt.AlignCenter)

            view_text = f"❤️ {self.format_metric(views_cnt)}" if views_cnt > 0 else "⚪ 0 Thích"
            btn_view = QPushButton(view_text)
            btn_view.setObjectName("view_active" if views_cnt > 0 else "view_empty")
            btn_view.setCursor(Qt.PointingHandCursor)
            btn_view.setToolTip(f"❤️ Lượt thích / Tương tác: {views_cnt:,} Thích\n👥 Follower: {flow_cnt:,} Follow\n🟢 Số liệu khớp 100% theo thời gian thực từ TikTok\n👉 Bấm để quét cập nhật ngay lập tức")
            btn_view.setFixedHeight(30)
            btn_view.clicked.connect(lambda checked=False, ch_obj=ch: self.auto_sync_single_channel(ch_obj))
            view_layout.addWidget(btn_view)
            self.table.setCellWidget(row, 8, view_box)

            # Cột 9: Đã đăng
            item_count = QTableWidgetItem(str(ch["posted_count"]))
            item_count.setTextAlignment(Qt.AlignCenter)
            self.table.setItem(row, 9, item_count)

            # Cột 10: Nút Mở Chrome
            login_box = QWidget()
            login_box.setObjectName("cell_box")
            login_layout = QHBoxLayout(login_box)
            login_layout.setContentsMargins(4, 2, 4, 2)
            login_layout.setAlignment(Qt.AlignCenter)

            btn_chrome_login = QPushButton("🌐 Mở Chrome")
            btn_chrome_login.setObjectName("btn_chrome")
            btn_chrome_login.setToolTip("Mở trình duyệt Google Chrome với Profile riêng của kênh này")
            btn_chrome_login.setFixedHeight(30)
            btn_chrome_login.setCursor(Qt.PointingHandCursor)
            btn_chrome_login.clicked.connect(lambda checked=False, c=ch: self.launch_web_login(c))
            login_layout.addWidget(btn_chrome_login)
            self.table.setCellWidget(row, 10, login_box)

            # Cột 11: Hành động
            action_widget = QWidget()
            action_widget.setObjectName("cell_box")
            action_layout = QHBoxLayout(action_widget)
            action_layout.setContentsMargins(6, 2, 6, 2)
            action_layout.setSpacing(6)
            action_layout.setAlignment(Qt.AlignCenter)

            btn_audit = QPushButton("🩺")
            btn_audit.setObjectName("btn_audit")
            btn_audit.setToolTip("🩺 Khám Sức Khỏe Kênh AI (Phát hiện Shadowban & Đề xuất cắn view)")
            btn_audit.setFixedSize(32, 32)
            btn_audit.setCursor(Qt.PointingHandCursor)
            btn_audit.clicked.connect(lambda checked=False, c=ch: self.open_channel_audit(c))
            action_layout.addWidget(btn_audit)

            btn_sched = QPushButton("📅")
            btn_sched.setObjectName("btn_sched")
            btn_sched.setToolTip("📅 Lên lịch đăng video cho kênh này (Chọn ngày & giờ)")
            btn_sched.setFixedSize(32, 32)
            btn_sched.setCursor(Qt.PointingHandCursor)
            btn_sched.clicked.connect(lambda checked=False, cid=ch["id"]: self.open_schedule_for_channel(cid))
            action_layout.addWidget(btn_sched)

            btn_edit = QPushButton("✏️")
            btn_edit.setObjectName("btn_edit")
            btn_edit.setToolTip("✏️ Chỉnh sửa thông tin kênh & Proxy")
            btn_edit.setFixedSize(32, 32)
            btn_edit.setCursor(Qt.PointingHandCursor)
            btn_edit.clicked.connect(lambda checked=False, c=ch: self.open_edit_channel_dialog(c))
            action_layout.addWidget(btn_edit)

            btn_delete = QPushButton("🗑️")
            btn_delete.setObjectName("btn_del")
            btn_delete.setToolTip("🗑️ Xóa kênh khỏi hệ thống")
            btn_delete.setFixedSize(32, 32)
            btn_delete.setCursor(Qt.PointingHandCursor)
            btn_delete.clicked.connect(lambda checked=False, cid=ch["id"], cname=ch["name"]: self.delete_channel(cid, cname))
            action_layout.addWidget(btn_delete)

            self.table.setCellWidget(row, 11, action_widget)

    # ==================== SỰ KIỆN TÍCH CHỌN VPN CHO TỪNG KÊNH ====================
    def on_channel_vpn_toggled(self, state, channel_id: int):
        use_vpn = (state == Qt.Checked.value or state == True)
        db.set_channel_vpn_status(channel_id, use_vpn)
        self.load_channels()

    def set_batch_vpn_status(self, use_vpn: bool):
        selected = self.get_selected_channels()
        if not selected:
            QMessageBox.warning(self, "Chưa chọn kênh", "Vui lòng bấm chọn các dòng kênh trong bảng (hoặc tích 'Chọn tất cả') để đổi trạng thái VPN!")
            return

        cids = [c["id"] for c in selected]
        db.set_multiple_channels_vpn(cids, use_vpn)
        self.load_channels()
        action_text = "BẬT VPN" if use_vpn else "TẮT VPN (DÙNG IP GỐC)"
        QMessageBox.information(self, "Đã cập nhật", f"Đã {action_text} cho {len(cids)} kênh đã chọn.")

    def open_batch_proxy_dialog(self):
        selected_channels = self.get_selected_channels()
        selected_ids = [ch["id"] for ch in selected_channels]
        from ui.components.proxy_batch_dialog import BatchProxyDialog
        dlg = BatchProxyDialog(self, selected_channel_ids=selected_ids)
        dlg.proxies_assigned.connect(self.load_channels)
        dlg.exec()

    def open_vpn_account_dialog(self):
        dlg = VpnAccountDialog(self)
        if dlg.exec():
            self.load_channels()

    def open_auto_series_dialog(self, channel_id: Optional[int] = None):
        if channel_id is None:
            selected = self.get_selected_channels()
            if selected:
                channel_id = selected[0]["id"]
        from ui.components.auto_series_dialog import AutoSeriesDialog
        dlg = AutoSeriesDialog(preselected_channel_id=channel_id, parent=self)
        dlg.exec()
        self.load_channels()

    def quick_clear_youtube_source(self, channel_id: int, channel_name: str = ""):
        ch = db.get_channel(channel_id)
        cname = channel_name or (ch.get("name", f"Kênh #{channel_id}") if ch else f"Kênh #{channel_id}")
        reply = QMessageBox.question(
            self,
            "Xác nhận tắt nguồn",
            f"Bạn có chắc chắn muốn XÓA NGUỒN YouTube và TẮT TỰ ĐỘNG LẤY VIDEO cho kênh '@{cname}' không?\n\n"
            "Sau khi tắt, Tool sẽ ngừng hoàn toàn việc tự động tải và cắt video từ YouTube cho kênh này.",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No
        )
        if reply == QMessageBox.Yes:
            db.clear_channel_youtube_source(channel_id)
            try:
                from core.series_queue_manager import series_queue_mgr
                series_queue_mgr.cancel_channel(channel_id)
            except Exception:
                pass
            self.load_channels()
            QMessageBox.information(self, "Đã tắt nguồn", f"Đã xóa nguồn YouTube và tắt tự động nạp video cho kênh '@{cname}' thành công!")

    def on_selection_changed(self):
        selected_rows = len(set(index.row() for index in self.table.selectedIndexes()))
        total_rows = self.table.rowCount()
        self.chk_select_all.blockSignals(True)
        if total_rows > 0 and selected_rows == total_rows:
            self.chk_select_all.setCheckState(Qt.Checked)
        elif selected_rows > 0:
            self.chk_select_all.setCheckState(Qt.PartiallyChecked)
        else:
            self.chk_select_all.setCheckState(Qt.Unchecked)
        self.chk_select_all.blockSignals(False)

    def toggle_select_all(self, state):
        is_checked = (state == Qt.Checked.value or state == True)
        if is_checked:
            self.table.selectAll()
        else:
            self.table.clearSelection()

    def get_selected_channels(self):
        selected = []
        selected_rows = sorted(set(index.row() for index in self.table.selectedIndexes()))
        for r in selected_rows:
            if 0 <= r < len(self.current_rendered_channels):
                selected.append(self.current_rendered_channels[r])
        return selected

    def on_table_cell_clicked(self, row: int, col: int):
        # Bấm vào bảng khi không có kênh thì tự động xóa tìm kiếm và hiện lại toàn bộ kênh
        if not self.current_rendered_channels and getattr(self, "channels_data", None):
            self.txt_search.clear()
            self.cmb_filter_net.setCurrentIndex(0)

    def on_table_cell_double_clicked(self, row: int, col: int):
        # Không tự động mở Chrome khi double click vào ô kênh nữa
        pass

    def launch_web_login(self, channel: dict):
        success, msg = chrome_mgr.launch_chrome_for_login(channel, "https://www.tiktok.com/")
        if not success:
            QMessageBox.critical(self, "Lỗi khởi chạy", msg)
            return

        from core.notifier import notifier
        notifier.notify(
            "🌐 Đang Mở Chrome Đăng Nhập",
            f"Đã mở Google Chrome cho kênh '{channel.get('name', '')}'.\nHệ thống sẽ TỰ ĐỘNG nhận diện và đồng bộ ngay khi bạn đăng nhập xong trên Web!",
            is_success=True
        )

    def quick_confirm_login(self, channel_id: int, channel_name: str):
        db.update_channel_login_status(channel_id, True)
        self.load_channels()
        self.channel_updated.emit()
        from core.notifier import notifier
        notifier.notify_login_success(channel_name)
        QMessageBox.information(
            self, "Hoàn tất đăng nhập",
            f"🎉 Đã lưu thành công trạng thái <b>ĐÃ ĐĂNG NHẬP</b> cho kênh: <b>{channel_name}</b>!<br>"
            "Kênh đã sẵn sàng để đăng video tự động."
        )

    def open_channel_audit(self, channel_data: Dict[str, Any]):
        from ui.components.channel_audit_dialog import ChannelAuditDialog
        dlg = ChannelAuditDialog(channel_data, parent=self)
        dlg.exec()

    def open_schedule_for_channel(self, channel_id: int):
        from ui.components.schedule_dialog import ScheduleDialog
        dlg = ScheduleDialog(self, preselected_channel_id=channel_id)
        if dlg.exec():
            self.load_channels()

    def batch_launch_profiles(self):
        selected = self.get_selected_channels()
        if not selected:
            QMessageBox.warning(self, "Chưa chọn kênh", "Vui lòng tích chọn ít nhất một kênh TikTok để mở!")
            return

        reply = QMessageBox.question(
            self, "Mở hàng loạt kênh",
            f"Bạn có muốn mở ngay đồng thời <b>{len(selected)}</b> Profile Chrome cho các kênh đã chọn?",
            QMessageBox.Yes | QMessageBox.No
        )
        if reply == QMessageBox.Yes:
            chrome_mgr.launch_batch_profiles(selected, delay_seconds=2.0)

    def open_add_channel_dialog(self):
        dlg = ChannelDialog(self)
        if dlg.exec():
            self.load_channels()

    def open_edit_channel_dialog(self, channel: dict):
        dlg = ChannelDialog(self, channel_data=channel)
        if dlg.exec():
            self.load_channels()

    def rename_selected_channels(self):
        selected = self.get_selected_channels()
        if not selected:
            QMessageBox.warning(
                self, "Chưa chọn kênh",
                "Vui lòng bấm chọn các dòng kênh trong bảng (hoặc tích 'Chọn tất cả') bạn muốn đổi tên, sau đó bấm lại nút '✏️ Đổi Tên Kênh'!"
            )
            return

        from ui.components.rename_dialog import QuickRenameDialog
        dlg = QuickRenameDialog(self, channels=selected)
        if dlg.exec():
            self.load_channels()

    def delete_channel(self, channel_id: int, channel_name: str):
        reply = QMessageBox.question(
            self, "Xác nhận xóa",
            f"Bạn có chắc muốn xóa kênh '<b>{channel_name}</b>' cùng toàn bộ dữ liệu lưu trữ?",
            QMessageBox.Yes | QMessageBox.No
        )
        if reply == QMessageBox.Yes:
            try:
                ch = db.get_channel(channel_id)
                if ch and ch.get("profile_dir"):
                    p_dir = ch["profile_dir"]
                    if os.path.exists(p_dir):
                        import shutil
                        shutil.rmtree(p_dir, ignore_errors=True)
                db.delete_channel(channel_id)
                self.load_channels()
                self.channel_updated.emit()
                QMessageBox.information(self, "Đã xóa", f"✅ Đã xóa thành công kênh '{channel_name}' và giải phóng dung lượng đĩa.")
            except Exception as e:
                QMessageBox.critical(self, "Lỗi khi xóa kênh", f"Không thể xóa kênh: {str(e)}")

    @staticmethod
    def format_metric(num: int) -> str:
        if not num or num <= 0:
            return "0"
        if num >= 1_000_000:
            return f"{num / 1_000_000:.1f}M"
        elif num >= 10_000:
            return f"{num / 1_000:.1f}K"
        elif num >= 1_000:
            return f"{num / 1_000:.1f}K"
        return f"{num:,}"

    def _on_stat_synced_live(self, cid: int, followers: int, views: int):
        """Cập nhật trực tiếp số Follow & View vào hàng của kênh tương ứng trên bảng theo thời gian thực"""
        for row in range(self.table.rowCount()):
            if row < len(self.current_rendered_channels):
                ch = self.current_rendered_channels[row]
                if ch.get("id") == cid:
                    ch["followers_count"] = followers
                    ch["views_count"] = views
                    # Cập nhật ô Follower (Cột 7)
                    cell_flow = self.table.cellWidget(row, 7)
                    if cell_flow:
                        btn = cell_flow.findChild(QPushButton)
                        if btn:
                            flow_text = f"👥 {self.format_metric(followers)}" if followers > 0 else "⚪ 0 Follow"
                            if btn.text() != flow_text:
                                btn.setText(flow_text)
                            btn.setToolTip(f"👥 Người theo dõi: {followers:,} Follower\n🟢 Tự động đồng bộ chuẩn xác từ TikTok\n👉 Bấm để quét cập nhật ngay lập tức")
                            is_flow_active = followers > 0
                            if btn.property("_stat_active") != is_flow_active:
                                btn.setProperty("_stat_active", is_flow_active)
                                btn.setStyleSheet(f"""
                                    QPushButton {{
                                        background-color: {"#0F2942" if is_flow_active else "#1E293B"};
                                        color: {"#38BDF8" if is_flow_active else "#94A3B8"};
                                        border: 1px solid {"#0284C7" if is_flow_active else "#334155"};
                                        border-radius: 5px;
                                        font-weight: 700;
                                        font-size: 11px;
                                        padding: 4px 8px;
                                    }}
                                    QPushButton:hover {{
                                        background-color: #0284C7;
                                        color: #FFFFFF;
                                        border-color: #38BDF8;
                                    }}
                                """)
                    # Cập nhật ô Lượt Thích / View (Cột 8)
                    cell_view = self.table.cellWidget(row, 8)
                    if cell_view:
                        btn_v = cell_view.findChild(QPushButton)
                        if btn_v:
                            view_text = f"❤️ {self.format_metric(views)}" if views > 0 else "⚪ 0 Thích"
                            if btn_v.text() != view_text:
                                btn_v.setText(view_text)
                            btn_v.setToolTip(f"❤️ Lượt thích / Tương tác: {views:,} Thích ({self.format_metric(views)})\n👥 Follower: {followers:,} Follow\n🟢 Số liệu khớp 100% theo thời gian thực từ TikTok\n👉 Bấm để quét cập nhật ngay lập tức")
                            is_view_active = views > 0
                            if btn_v.property("_stat_active") != is_view_active:
                                btn_v.setProperty("_stat_active", is_view_active)
                                btn_v.setStyleSheet(f"""
                                    QPushButton {{
                                        background-color: {"#3B1425" if is_view_active else "#1E293B"};
                                        color: {"#F472B6" if is_view_active else "#94A3B8"};
                                        border: 1px solid {"#DB2777" if is_view_active else "#334155"};
                                        border-radius: 5px;
                                        font-weight: 700;
                                        font-size: 11px;
                                        padding: 4px 8px;
                                    }}
                                    QPushButton:hover {{
                                        background-color: #DB2777;
                                        color: #FFFFFF;
                                        border-color: #F472B6;
                                    }}
                                """)
                    break

    def _on_series_progress_update(self, cid: int, progress: int, msg: str):
        """Gom nhịp cập nhật tiến trình cắt video (Cột 3) và banner mỗi 300ms để tránh giật lag UI."""
        sig = (progress, msg)
        if getattr(self, "_progress_last_sig", None) is not None and self._progress_last_sig.get(cid) == sig:
            return
        self._progress_last_sig[cid] = sig
        self._pending_progress[cid] = (progress, msg)
        if not self._progress_timer.isActive():
            self._progress_timer.start()

    def _flush_series_progress_updates(self):
        """Áp dụng các cập nhật tiến trình đã gom lên banner và bảng kênh."""
        batch = dict(getattr(self, "_pending_progress", {}))
        self._pending_progress.clear()
        self._refresh_series_live_banner()
        if not self.isVisible() or not batch:
            return
        from core.series_queue_manager import series_queue_mgr
        for cid, (progress, msg) in batch.items():
            q_st = series_queue_mgr.get_channel_status(cid)
            is_queued = bool(q_st and q_st.get("status") == "queued")
            pos = q_st.get("position", 1) if q_st else 1

            for row in range(self.table.rowCount()):
                if row < len(self.current_rendered_channels):
                    ch = self.current_rendered_channels[row]
                    if ch.get("id") == cid:
                        badge_box = self.table.cellWidget(row, 3)
                        if badge_box:
                            lbl = badge_box.findChild(QLabel)
                            if lbl:
                                if is_queued:
                                    lbl.setText(f"⏳ Chờ cắt (#{pos})")
                                    lbl.setToolTip(f"Kênh đang trong hàng đợi tự động cắt video (Vị trí #{pos}).\nTool sẽ cắt xong kênh trước rồi tự động đến kênh này!")
                                    if lbl.property("_badge_state") != "queued":
                                        lbl.setProperty("_badge_state", "queued")
                                        lbl.setStyleSheet("""
                                            QLabel {
                                                background-color: #3B2507;
                                                color: #FCD34D;
                                                border: 1px solid #D97706;
                                                border-radius: 6px;
                                                font-weight: 700;
                                                font-size: 11px;
                                                padding: 4px 10px;
                                            }
                                        """)
                                else:
                                    lbl.setText(f"⚡ Đang cắt ({progress}%)")
                                    lbl.setToolTip(f"Kênh đang được Tool tải & cắt video tự động ngầm:\n{msg}\n👉 Cắt tuần tự từng kênh 1 an toàn 100%!")
                                    if lbl.property("_badge_state") != "processing":
                                        lbl.setProperty("_badge_state", "processing")
                                        lbl.setStyleSheet("""
                                            QLabel {
                                                background-color: #0B2A4A;
                                                color: #38BDF8;
                                                border: 1px solid #0284C7;
                                                border-radius: 6px;
                                                font-weight: 700;
                                                font-size: 11px;
                                                padding: 4px 10px;
                                            }
                                        """)
                        break

    def auto_sync_single_channel(self, channel_data: Dict[str, Any]):
        """Tự động quét và cập nhật trực tiếp từ TikTok khi bấm vào badge của kênh"""
        cname = channel_data.get("name", "")
        clean_user = (channel_data.get("username") or f"@{cname}").lstrip("@").strip()
        from core.notifier import notifier
        notifier.notify(
            "🔄 Đang Đồng Bộ TikTok",
            f"Đang tự động quét số liệu mới nhất từ TikTok cho kênh '@{clean_user}'...",
            is_success=True
        )
        def worker():
            from core.stats_sync_service import stats_sync_service
            res = stats_sync_service.sync_channel(channel_data)
            f_val = res.get("followers", 0)
            v_val = res.get("views", 0)
            notifier.notify(
                "✅ Đã Cập Nhật TikTok",
                f"Kênh '@{clean_user}': {f_val:,} Follower | {v_val:,} Views chuẩn xác!",
                is_success=True
            )
        threading.Thread(target=worker, daemon=True).start()

    def trigger_full_auto_sync(self):
        """Kích hoạt quét đồng bộ tự động toàn bộ kênh từ TikTok"""
        self.btn_stats_batch.setText("⏳ ĐANG ĐỒNG BỘ TIKTOK...")
        self.btn_stats_batch.setEnabled(False)
        from core.notifier import notifier
        notifier.notify(
            "🔄 Bắt Đầu Tự Động Đồng Bộ",
            "Hệ thống đang quét ngầm số liệu Follower và Lượt Xem trực tiếp từ TikTok cho tất cả các kênh...",
            is_success=True
        )
        def worker():
            from core.stats_sync_service import stats_sync_service
            stats_sync_service.sync_all_channels()
            QTimer.singleShot(500, lambda: self.btn_stats_batch.setText("🔄 TỰ ĐỘNG ĐỒNG BỘ FLOW & VIEW"))
            QTimer.singleShot(500, lambda: self.btn_stats_batch.setEnabled(True))
            notifier.notify(
                "✅ Hoàn Tất Đồng Bộ",
                "Đã tự động cập nhật số liệu Follower và View chính xác cho tất cả kênh!",
                is_success=True
            )
        threading.Thread(target=worker, daemon=True).start()

    def quick_edit_followers(self, channel_id: int, channel_name: str, current_followers: int, current_views: int):
        from PySide6.QtWidgets import QInputDialog
        val, ok = QInputDialog.getInt(
            self,
            "👥 Cập Nhật Người Theo Dõi (Flow)",
            f"Nhập số lượng người theo dõi (Followers) chuẩn cho kênh <b>@{channel_name}</b>:",
            value=int(current_followers or 0),
            minValue=0,
            maxValue=100000000,
            step=100
        )
        if ok:
            db.update_channel_stats(channel_id, followers_count=val, views_count=current_views)
            self.load_channels()
            from core.notifier import notifier
            notifier.notify(
                "✅ Đã Cập Nhật Followers",
                f"Đã lưu thành công: {val:,} Follower cho kênh '@{channel_name}'!",
                is_success=True
            )

    def quick_edit_views(self, channel_id: int, channel_name: str, current_followers: int, current_views: int):
        from PySide6.QtWidgets import QInputDialog
        val, ok = QInputDialog.getInt(
            self,
            "👁️ Cập Nhật Lượt Xem Video (View)",
            f"Nhập tổng lượt xem video (Views) chuẩn cho kênh <b>@{channel_name}</b>:",
            value=int(current_views or 0),
            minValue=0,
            maxValue=2000000000,
            step=500
        )
        if ok:
            db.update_channel_stats(channel_id, followers_count=current_followers, views_count=val)
            self.load_channels()
            from core.notifier import notifier
            notifier.notify(
                "✅ Đã Cập Nhật Lượt Xem",
                f"Đã lưu thành công: {val:,} Views cho kênh '@{channel_name}'!",
                is_success=True
            )

    def on_cell_double_clicked(self, row: int, column: int):
        if row < 0 or row >= len(self.current_rendered_channels):
            return
        ch = self.current_rendered_channels[row]
        if column in (7, 8):
            self.auto_sync_single_channel(ch)

    def open_batch_stats_dialog(self):
        selected_channels = self.get_selected_channels()
        selected_ids = [ch["id"] for ch in selected_channels]
        from ui.components.batch_stats_dialog import BatchStatsDialog
        dlg = BatchStatsDialog(self, selected_channel_ids=selected_ids)
        dlg.stats_updated.connect(self.load_channels)
        dlg.exec()
