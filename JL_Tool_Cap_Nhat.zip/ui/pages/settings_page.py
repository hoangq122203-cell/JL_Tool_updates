import os
from pathlib import Path
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QLineEdit, QFileDialog, QSpinBox, QFrame, QMessageBox,
    QGroupBox, QFormLayout, QCheckBox, QScrollArea
)
from PySide6.QtCore import Qt
import config
from database.db_manager import db
from core.chrome_manager import chrome_mgr
from core.network_manager import network_mgr

GB_STYLE = (
    "QGroupBox { "
    "   font-weight: 700; "
    "   font-size: 13px; "
    "   color: #38BDF8; "
    "   border: 1px solid #262D40; "
    "   border-radius: 8px; "
    "   margin-top: 14px; "
    "   padding: 18px 14px 14px 14px; "
    "   background-color: #111422; "
    "} "
    "QGroupBox::title { "
    "   subcontrol-origin: margin; "
    "   left: 14px; "
    "   padding: 0 8px; "
    "   color: #38BDF8; "
    "   font-weight: 700; "
    "   font-size: 13px; "
    "   background-color: #111422; "
    "}"
)

class SettingsPage(QWidget):
    def __init__(self):
        super().__init__()
        self.init_ui()

    def init_ui(self):
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.NoFrame)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        scroll.setStyleSheet("QScrollArea { background: transparent; border: none; }")

        content_widget = QWidget()
        content_widget.setObjectName("settings_content")
        content_widget.setStyleSheet("QWidget#settings_content { background: transparent; }")

        layout = QVBoxLayout(content_widget)
        layout.setContentsMargins(24, 20, 24, 20)
        layout.setSpacing(16)

        # Header Title
        title_box = QVBoxLayout()
        lbl_title = QLabel("Cài Đặt Hệ Thống & Cấu Hình Mạng")
        lbl_title.setProperty("class", "page-title")
        lbl_subtitle = QLabel("Thiết lập đường dẫn Google Chrome, thư mục hồ sơ Profile, CLI của PIA VPN & HMA VPN")
        lbl_subtitle.setProperty("class", "page-subtitle")
        title_box.addWidget(lbl_title)
        title_box.addWidget(lbl_subtitle)
        layout.addLayout(title_box)

        # 0. NHÓM TỰ ĐỘNG CẬP NHẬT PHẦN MỀM (ĐẶT LÊN ĐẦU ĐỂ KHÁCH DỄ THẤY NGAY)
        grp_update = QGroupBox("🔄 Tự Động Cập Nhật Phần Mềm Từ Xa (Auto-Update)")
        grp_update.setStyleSheet(GB_STYLE)
        update_layout = QVBoxLayout(grp_update)
        update_layout.setSpacing(10)

        row_up_top = QHBoxLayout()
        lbl_v_cur = QLabel(f"Phiên bản đang dùng: <b style='color:#38BDF8;'>v{config.APP_VERSION}</b>")
        lbl_v_cur.setStyleSheet("color: #FFFFFF; font-size: 13px;")
        row_up_top.addWidget(lbl_v_cur)

        self.lbl_up_status = QLabel("🟢 Hệ thống tự động kiểm tra mỗi khi khởi động")
        self.lbl_up_status.setStyleSheet("color: #34D399; font-size: 12px; font-weight: 600;")
        row_up_top.addWidget(self.lbl_up_status)
        row_up_top.addStretch()

        self.btn_check_update_now = QPushButton("🔄 Cập Nhật Phiên Bản Mới")
        self.btn_check_update_now.setCursor(Qt.PointingHandCursor)
        self.btn_check_update_now.setFixedHeight(32)
        self.btn_check_update_now.setStyleSheet("""
            QPushButton {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #0284C7, stop:1 #2563EB);
                color: #FFFFFF;
                border: 1px solid #38BDF8;
                border-radius: 6px;
                padding: 0 16px;
                font-weight: 700;
                font-size: 11px;
            }
            QPushButton:hover {
                background: #0369A1;
            }
        """)
        self.btn_check_update_now.clicked.connect(self.manual_check_update)
        row_up_top.addWidget(self.btn_check_update_now)
        update_layout.addLayout(row_up_top)

        # Đường dẫn cập nhật
        row_up_url = QHBoxLayout()
        lbl_url_t = QLabel("Máy chủ cập nhật:")
        lbl_url_t.setFixedWidth(120)
        self.txt_update_url = QLineEdit()
        self.txt_update_url.setPlaceholderText("https://raw.githubusercontent.com/.../version.json")
        row_up_url.addWidget(lbl_url_t)
        row_up_url.addWidget(self.txt_update_url, 1)
        update_layout.addLayout(row_up_url)

        lbl_up_tip = QLabel("💡 <i>Khi bạn phát hành bản sửa lỗi mới, toàn bộ máy khách hàng mở tool sẽ tự động nạp bản cập nhật trong 3 giây. Dữ liệu tài khoản & bản quyền của khách luôn được bảo vệ nguyên vẹn 100%.</i>")
        lbl_up_tip.setStyleSheet("color: #94A3B8; font-size: 11px;")
        lbl_up_tip.setWordWrap(True)
        update_layout.addWidget(lbl_up_tip)

        # Nút Mở Bộ Phát Hành (Dành riêng cho Admin)
        from pathlib import Path
        pub_file = Path(__file__).resolve().parent.parent.parent / "Phat_Hanh_Ban_Moi.py"
        if pub_file.is_file():
            row_admin_pub = QHBoxLayout()
            self.btn_open_publisher = QPushButton("🚀 MỞ BỘ PHÁT HÀNH BẢN CẬP NHẬT MỚI (DÀNH CHO ADMIN)")
            self.btn_open_publisher.setCursor(Qt.PointingHandCursor)
            self.btn_open_publisher.setFixedHeight(34)
            self.btn_open_publisher.setStyleSheet("""
                QPushButton {
                    background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #8B5CF6, stop:1 #EC4899);
                    color: #FFFFFF;
                    border: 1px solid #C084FC;
                    border-radius: 6px;
                    font-weight: 800;
                    font-size: 11px;
                    padding: 0 16px;
                }
                QPushButton:hover {
                    background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #7C3AED, stop:1 #DB2777);
                }
            """)
            self.btn_open_publisher.clicked.connect(self.open_release_publisher)
            row_admin_pub.addWidget(self.btn_open_publisher)
            row_admin_pub.addStretch()
            update_layout.addLayout(row_admin_pub)

        layout.addWidget(grp_update)

        # 1. Cấu hình Trình duyệt Chrome & Profile
        grp_chrome = QGroupBox("1. Cấu hình Google Chrome và Thư mục Hồ sơ (Profile)")
        grp_chrome.setStyleSheet(GB_STYLE)
        chrome_layout = QFormLayout(grp_chrome)
        chrome_layout.setSpacing(12)

        row_c = QHBoxLayout()
        self.txt_chrome_path = QLineEdit()
        self.btn_browse_chrome = QPushButton("Duyệt...")
        self.btn_browse_chrome.setProperty("class", "btn-secondary")
        self.btn_browse_chrome.clicked.connect(self.browse_chrome)
        self.btn_auto_chrome = QPushButton("Tự dò tìm")
        self.btn_auto_chrome.setProperty("class", "btn-secondary")
        self.btn_auto_chrome.clicked.connect(self.auto_detect_chrome)
        row_c.addWidget(self.txt_chrome_path)
        row_c.addWidget(self.btn_browse_chrome)
        row_c.addWidget(self.btn_auto_chrome)
        chrome_layout.addRow("Google Chrome Executable:", row_c)

        row_p = QHBoxLayout()
        self.txt_profiles_dir = QLineEdit()
        self.btn_browse_profiles = QPushButton("Duyệt...")
        self.btn_browse_profiles.setProperty("class", "btn-secondary")
        self.btn_browse_profiles.clicked.connect(self.browse_profiles_dir)
        self.btn_open_profiles = QPushButton("Mở thư mục")
        self.btn_open_profiles.setProperty("class", "btn-secondary")
        self.btn_open_profiles.clicked.connect(self.open_profiles_dir)
        row_p.addWidget(self.txt_profiles_dir)
        row_p.addWidget(self.btn_browse_profiles)
        row_p.addWidget(self.btn_open_profiles)
        chrome_layout.addRow("Thư mục lưu Profiles:", row_p)

        layout.addWidget(grp_chrome)

        # 2. Cấu hình PIA VPN & HMA VPN CLI
        grp_vpn = QGroupBox("2. Cấu hình Tích hợp VPN (Private Internet Access và HideMyAss)")
        grp_vpn.setStyleSheet(GB_STYLE)
        vpn_layout = QFormLayout(grp_vpn)
        vpn_layout.setSpacing(12)

        # PIA
        row_pia = QHBoxLayout()
        self.txt_pia_path = QLineEdit()
        self.btn_browse_pia = QPushButton("Duyệt...")
        self.btn_browse_pia.setProperty("class", "btn-secondary")
        self.btn_browse_pia.clicked.connect(self.browse_pia)
        self.btn_auto_pia = QPushButton("Tự dò tìm")
        self.btn_auto_pia.setProperty("class", "btn-secondary")
        self.btn_auto_pia.clicked.connect(self.auto_detect_pia)
        row_pia.addWidget(self.txt_pia_path)
        row_pia.addWidget(self.btn_browse_pia)
        row_pia.addWidget(self.btn_auto_pia)
        vpn_layout.addRow("Đường dẫn PIA (piactl.exe):", row_pia)

        # HMA
        row_hma = QHBoxLayout()
        self.txt_hma_path = QLineEdit()
        self.btn_browse_hma = QPushButton("Duyệt...")
        self.btn_browse_hma.setProperty("class", "btn-secondary")
        self.btn_browse_hma.clicked.connect(self.browse_hma)
        self.btn_auto_hma = QPushButton("Tự dò tìm")
        self.btn_auto_hma.setProperty("class", "btn-secondary")
        self.btn_auto_hma.clicked.connect(self.auto_detect_hma)
        row_hma.addWidget(self.txt_hma_path)
        row_hma.addWidget(self.btn_browse_hma)
        row_hma.addWidget(self.btn_auto_hma)
        vpn_layout.addRow("Đường dẫn HMA (HMA.exe):", row_hma)

        self.chk_auto_disconnect_vpn = QCheckBox("Tự động ngắt VPN sau khi đăng xong để giữ nguyên tốc độ mạng gốc của máy tính")
        self.chk_auto_disconnect_vpn.setStyleSheet("color: #38BDF8; font-weight: 700; font-size: 13px;")
        vpn_layout.addRow("Tối ưu mạng máy tính:", self.chk_auto_disconnect_vpn)

        lbl_vpn_tip = QLabel(
            "💡 Khuyên dùng: Giúp máy tính luôn duy trì tốc độ Download/Upload tối đa của nhà mạng (FPT/VNPT) khi Tool chạy ngầm. "
            "VPN chỉ tự động bật trong 30-40 giây lúc xuất bản video rồi tự ngắt ngay lập tức."
        )
        lbl_vpn_tip.setStyleSheet("color: #94A3B8; font-size: 11px;")
        lbl_vpn_tip.setWordWrap(True)
        vpn_layout.addRow("", lbl_vpn_tip)

        layout.addWidget(grp_vpn)

        # 3. Tùy chọn Tác vụ hàng loạt & Tự động thử lại khi lỗi
        grp_tasks = QGroupBox("3. Thiết lập Vận Hành, Hiệu Năng & Tự Động Thử Lại (Auto-Retry)")
        grp_tasks.setStyleSheet(GB_STYLE)
        task_layout = QFormLayout(grp_tasks)
        task_layout.setSpacing(12)

        self.spn_concurrent = QSpinBox()
        self.spn_concurrent.setRange(1, 30)
        self.spn_concurrent.setValue(2)
        self.spn_concurrent.setFixedWidth(100)
        task_layout.addRow("Số luồng tác vụ song song tối đa:", self.spn_concurrent)

        self.spn_delay = QSpinBox()
        self.spn_delay.setRange(1, 10)
        self.spn_delay.setValue(2)
        self.spn_delay.setSuffix(" giây")
        self.spn_delay.setFixedWidth(100)
        task_layout.addRow("Khoảng cách mở giữa các cửa sổ Profile:", self.spn_delay)

        self.chk_auto_retry = QCheckBox("Bật tính năng tự động đăng tải lại khi video gặp lỗi")
        self.chk_auto_retry.setStyleSheet("color: #38BDF8; font-weight: 600;")
        self.chk_auto_retry.setChecked(True)
        task_layout.addRow("Tự động đăng lại (Auto-Retry):", self.chk_auto_retry)

        self.chk_delete_after_post = QCheckBox("Tự động xóa file video trên máy tính sau khi đăng thành công (Giải phóng ổ cứng)")
        self.chk_delete_after_post.setStyleSheet("color: #10B981; font-weight: 600;")
        self.chk_delete_after_post.setChecked(True)
        task_layout.addRow("Dọn dẹp video thành công:", self.chk_delete_after_post)

        # CẤU HÌNH BẢO VỆ KÊNH & KHẮC PHỤC 0 VIEW (ANTI-SHADOWBAN)
        self.chk_anti_shadowban = QCheckBox("Tự động lách bản quyền & đổi vân tay video bằng AI/FFmpeg (Chống 0 view)")
        self.chk_anti_shadowban.setStyleSheet("color: #F59E0B; font-weight: 700;")
        self.chk_anti_shadowban.setChecked(True)
        task_layout.addRow("Lách bản quyền video:", self.chk_anti_shadowban)

        self.chk_warmup = QCheckBox("Tự động lướt xem feed TikTok 15-30s làm ấm tài khoản trước khi đăng (Tăng Trust Score)")
        self.chk_warmup.setStyleSheet("color: #FCD34D; font-weight: 600;")
        self.chk_warmup.setChecked(True)
        task_layout.addRow("Làm ấm kênh (Warm-up):", self.chk_warmup)

        self.chk_auto_hashtag = QCheckBox("Tự động thêm bộ Hashtag xu hướng (#fyp #trending #viral) nếu để trống")
        self.chk_auto_hashtag.setStyleSheet("color: #38BDF8; font-weight: 600;")
        self.chk_auto_hashtag.setChecked(True)
        task_layout.addRow("Tự động thêm Hashtag:", self.chk_auto_hashtag)

        self.spn_max_retries = QSpinBox()
        self.spn_max_retries.setRange(1, 10)
        self.spn_max_retries.setValue(3)
        self.spn_max_retries.setSuffix(" lần")
        self.spn_max_retries.setFixedWidth(100)
        task_layout.addRow("Số lần tự động thử lại tối đa:", self.spn_max_retries)

        self.spn_retry_delay = QSpinBox()
        self.spn_retry_delay.setRange(3, 60)
        self.spn_retry_delay.setValue(10)
        self.spn_retry_delay.setSuffix(" giây")
        self.spn_retry_delay.setFixedWidth(100)
        task_layout.addRow("Thời gian chờ giữa các lần thử lại:", self.spn_retry_delay)

        layout.addWidget(grp_tasks)

        # 4. Cấu hình Thông Báo Telegram (Gửi tin nhắn khi đăng video thành công)
        grp_telegram = QGroupBox("4. Cấu hình Thông Báo Telegram (Gửi tin nhắn khi đăng video thành công)")
        grp_telegram.setStyleSheet(GB_STYLE)
        tg_layout = QFormLayout(grp_telegram)
        tg_layout.setSpacing(12)

        self.chk_telegram_enabled = QCheckBox("Bật thông báo về Telegram khi video đăng tải thành công")
        self.chk_telegram_enabled.setStyleSheet("color: #38BDF8; font-weight: 700; font-size: 13px;")
        tg_layout.addRow("Báo qua Telegram:", self.chk_telegram_enabled)

        self.chk_desktop_notify = QCheckBox("Hiện thông báo nổi & phát chuông trên máy tính khi đăng video thành công")
        self.chk_desktop_notify.setStyleSheet("color: #94A3B8; font-size: 13px;")
        tg_layout.addRow("Báo trên máy tính:", self.chk_desktop_notify)

        self.txt_telegram_token = QLineEdit()
        self.txt_telegram_token.setPlaceholderText("VD: 7123456789:AAHabcdefgh-xyz1234567890 (Lấy từ @BotFather)")
        self.txt_telegram_token.setEchoMode(QLineEdit.PasswordEchoOnEdit)
        tg_layout.addRow("Telegram Bot Token:", self.txt_telegram_token)

        row_chat = QHBoxLayout()
        self.txt_telegram_chat_id = QLineEdit()
        self.txt_telegram_chat_id.setPlaceholderText("VD: 123456789 (ID cá nhân) hoặc -100123456789 (ID Nhóm/Kênh)")
        row_chat.addWidget(self.txt_telegram_chat_id)

        self.btn_test_telegram = QPushButton("📲 Gửi Thử Tin Nhắn")
        self.btn_test_telegram.setCursor(Qt.PointingHandCursor)
        self.btn_test_telegram.setStyleSheet("""
            QPushButton {
                background-color: #0369A1;
                color: #FFFFFF;
                border: 1px solid #0284C7;
                border-radius: 6px;
                padding: 6px 14px;
                font-weight: 700;
                font-size: 12px;
            }
            QPushButton:hover {
                background-color: #0284C7;
            }
        """)
        self.btn_test_telegram.clicked.connect(self.test_telegram_connection)
        row_chat.addWidget(self.btn_test_telegram)
        tg_layout.addRow("Telegram Chat ID:", row_chat)

        guide_frame = QFrame()
        guide_frame.setStyleSheet("""
            QFrame {
                background-color: #13141F;
                border: 1px solid #1E293B;
                border-left: 4px solid #38BDF8;
                border-radius: 8px;
                padding: 10px;
                margin-top: 4px;
            }
        """)
        guide_inner = QVBoxLayout(guide_frame)
        guide_inner.setContentsMargins(10, 8, 10, 8)
        guide_inner.setSpacing(6)

        lbl_guide_title = QLabel("📖 HƯỚNG DẪN KẾT NỐI BOT TELEGRAM (CỰC KỲ ĐƠN GIẢN TRONG 3 BƯỚC):")
        lbl_guide_title.setStyleSheet("color: #38BDF8; font-weight: 700; font-size: 12px;")
        guide_inner.addWidget(lbl_guide_title)

        lbl_tg_guide = QLabel(
            "<b>• Bước 1 - Tạo Bot & Lấy Token:</b> Mở ứng dụng Telegram, tìm <b>@BotFather</b> ➔ Gõ <code>/newbot</code>, đặt tên Bot ➔ BotFather sẽ gửi cho bạn một đoạn mã <b>HTTP API Token</b> (VD: <code>7123456789:AAH...</code>). Dán mã đó vào ô <b>Telegram Bot Token</b> ở trên.<br>"
            "<b>• Bước 2 - Kích hoạt Bot:</b> Bấm vào link bot vừa tạo (hoặc tìm kiếm tên bot trên Telegram) rồi bấm <b>START</b> (bắt buộc để bot có quyền gửi tin cho bạn).<br>"
            "<b>• Bước 3 - Lấy Chat ID:</b> Tìm kiếm bot <b>@userinfobot</b> (hoặc <b>@getmyid_bot</b>) trên Telegram ➔ Bấm START ➔ Copy dãy số <b>Id</b> (VD: <code>123456789</code>) và dán vào ô <b>Telegram Chat ID</b> ở trên.<br>"
            "<i>💡 Mẹo: Nếu muốn gửi tin nhắn vào nhóm/kênh Telegram, chỉ cần thêm bot vào nhóm đó và nhập Chat ID của nhóm (thường bắt đầu bằng dấu trừ <code>-100...</code>).</i><br>"
            "<b>• Bước 4 - Kiểm tra:</b> Bấm nút <b>📲 Gửi Thử Tin Nhắn</b> bên trên. Khi bot gửi tin nhắn thành công, bạn tích chọn <b>Bật thông báo</b> và bấm <b>💾 LƯU CẤU HÌNH</b> là xong!"
        )
        lbl_tg_guide.setStyleSheet("color: #CBD5E1; font-size: 11px; line-height: 1.5;")
        lbl_tg_guide.setWordWrap(True)
        guide_inner.addWidget(lbl_tg_guide)

        tg_layout.addRow("", guide_frame)

        layout.addWidget(grp_telegram)

        # 5. Tối ưu hóa & Dọn dẹp dung lượng lưu trữ
        grp_storage = QGroupBox("5. Quản lý Dung Lượng & Dọn Dẹp Bộ Nhớ")
        grp_storage.setStyleSheet(GB_STYLE)
        storage_layout = QVBoxLayout(grp_storage)
        storage_layout.setContentsMargins(16, 16, 16, 16)
        storage_layout.setSpacing(10)

        row_info = QHBoxLayout()
        self.lbl_storage_info = QLabel("Đang tính toán dung lượng...")
        self.lbl_storage_info.setStyleSheet("color: #38BDF8; font-weight: 700; font-size: 13px;")
        row_info.addWidget(self.lbl_storage_info)
        row_info.addStretch()

        self.btn_clean_storage = QPushButton("🧹 DỌN DẸP RÁC & TỐI ƯU DUNG LƯỢNG NGAY")
        self.btn_clean_storage.setCursor(Qt.PointingHandCursor)
        self.btn_clean_storage.setStyleSheet("""
            QPushButton {
                background-color: #1E3A8A;
                color: #60A5FA;
                border: 1px solid #2563EB;
                border-radius: 6px;
                padding: 7px 16px;
                font-weight: 700;
                font-size: 11px;
            }
            QPushButton:hover {
                background-color: #2563EB;
                color: #FFFFFF;
            }
        """)
        self.btn_clean_storage.clicked.connect(self.clean_and_optimize_storage)
        row_info.addWidget(self.btn_clean_storage)
        storage_layout.addLayout(row_info)

        lbl_explain = QLabel(
            "💡 Tự động dọn dẹp các mảnh video tạm (IndexedDB Blobs), bộ nhớ đệm Chromium và thư mục hồ sơ cũ. "
            "Giảm hơn 95% dung lượng thư mục mà vẫn BẢO TOÀN 100% tài khoản và đăng nhập TikTok của bạn."
        )
        lbl_explain.setStyleSheet("color: #94A3B8; font-size: 11px;")
        lbl_explain.setWordWrap(True)
        storage_layout.addWidget(lbl_explain)

        layout.addWidget(grp_storage)

        # Nút Lưu
        save_row = QHBoxLayout()
        save_row.addStretch()
        self.btn_save = QPushButton("💾 LƯU CẤU HÌNH TOÀN BỘ HỆ THỐNG")
        self.btn_save.setProperty("class", "btn-primary")
        self.btn_save.setFixedHeight(40)
        self.btn_save.clicked.connect(self.save_settings)
        save_row.addWidget(self.btn_save)
        layout.addLayout(save_row)

        layout.addStretch()
        scroll.setWidget(content_widget)
        main_layout.addWidget(scroll)
        self.load_settings()

    def load_settings(self):
        chrome_path = db.get_setting("chrome_path", config.DEFAULT_CHROME_PATH)
        profiles_dir = db.get_setting("profiles_dir", str(config.PROFILES_DIR))
        pia_path = db.get_setting("pia_path", "")
        hma_path = db.get_setting("hma_path", "")
        concurrent = int(db.get_setting("max_concurrent_tasks", "2"))
        delay = int(db.get_setting("batch_delay", "2"))
        auto_retry = db.get_setting("auto_retry_failed", "1") == "1"
        del_after_post = db.get_setting("delete_video_after_post", "1") == "1"
        anti_shadowban = db.get_setting("anti_shadowban_enabled", "1") == "1"
        warmup = db.get_setting("warmup_before_post", "1") == "1"
        auto_hashtag = db.get_setting("auto_hashtag_enabled", "1") == "1"
        max_retries = int(db.get_setting("max_immediate_retries", "3"))
        retry_delay = int(db.get_setting("retry_delay_seconds", "10"))

        self.txt_chrome_path.setText(chrome_path)
        self.txt_profiles_dir.setText(profiles_dir)
        self.txt_pia_path.setText(pia_path)
        self.txt_hma_path.setText(hma_path)
        self.spn_concurrent.setValue(concurrent)
        self.spn_delay.setValue(delay)
        self.chk_auto_retry.setChecked(auto_retry)
        self.chk_delete_after_post.setChecked(del_after_post)
        self.chk_anti_shadowban.setChecked(anti_shadowban)
        self.chk_warmup.setChecked(warmup)
        self.chk_auto_hashtag.setChecked(auto_hashtag)
        self.spn_max_retries.setValue(max_retries)
        self.spn_retry_delay.setValue(retry_delay)

        auto_disc_vpn = db.get_setting("auto_disconnect_vpn_after_post", "0") == "1"
        self.chk_auto_disconnect_vpn.setChecked(auto_disc_vpn)

        tg_enabled = db.get_setting("telegram_notify_enabled", "0") == "1"
        tg_token = db.get_setting("telegram_bot_token", "")
        tg_chat_id = db.get_setting("telegram_chat_id", "")
        self.chk_telegram_enabled.setChecked(tg_enabled)

        desktop_notif = db.get_setting("desktop_notify_success", "0") == "1"
        self.chk_desktop_notify.setChecked(desktop_notif)
        self.txt_telegram_token.setText(tg_token)
        self.txt_telegram_chat_id.setText(tg_chat_id)

        update_u = db.get_setting("custom_update_url", getattr(config, "UPDATE_API_URL", ""))
        if not update_u or "quanhoang3700/JL_Tool_Updates" in update_u:
            update_u = getattr(config, "UPDATE_API_URL", "")
        self.txt_update_url.setText(update_u)

        self.update_storage_info()

    def update_storage_info(self):
        try:
            total_sz = 0
            base = str(config.BASE_DIR)
            for r, d, files in os.walk(base):
                for f in files:
                    try:
                        total_sz += os.path.getsize(os.path.join(r, f))
                    except Exception:
                        pass
            mb = total_sz / (1024 * 1024)
            self.lbl_storage_info.setText(f"Dung lượng Tool hiện tại: {mb:.1f} MB (Tối ưu xuất sắc)")
        except Exception:
            self.lbl_storage_info.setText("Dung lượng Tool: Đã tối ưu")

    def clean_and_optimize_storage(self):
        reply = QMessageBox.question(
            self, "Xác nhận dọn dẹp",
            "Hệ thống sẽ dọn sạch bộ nhớ đệm tạm (Cache, Video Blobs, rác thừa) để giải phóng tối đa bộ nhớ.\n\n"
            "Tài khoản TikTok và trạng thái Đã đăng nhập của bạn được GIỮ NGUYÊN 100%.\n\n"
            "Bạn có muốn tiếp tục?",
            QMessageBox.Yes | QMessageBox.No
        )
        if reply != QMessageBox.Yes:
            return

        import shutil
        freed = 0
        base_dir = str(config.BASE_DIR)
        data_dir = str(config.DATA_DIR)
        profiles_dir = str(config.PROFILES_DIR)

        # 1. Lấy danh sách profile đang dùng trong database
        channels = db.get_all_channels()
        active_names = set(os.path.basename(ch.get("profile_dir", "")) for ch in channels if ch.get("profile_dir"))

        # 2. Xóa các profile mồ côi (kênh đã xóa trong quá khứ)
        if os.path.exists(profiles_dir):
            for item in os.listdir(profiles_dir):
                full_p = os.path.join(profiles_dir, item)
                if os.path.isdir(full_p) and item not in active_names:
                    sz = sum(os.path.getsize(os.path.join(r, f)) for r, d, files in os.walk(full_p) for f in files)
                    freed += sz
                    shutil.rmtree(full_p, ignore_errors=True)

        # 3. Dọn cache và video blobs trong các profile đang dùng
        cache_subs = [
            os.path.join("Default", "Cache"),
            os.path.join("Default", "Code Cache"),
            os.path.join("Default", "GPUCache"),
            os.path.join("Default", "DawnCache"),
            os.path.join("Default", "Media Cache"),
            "BrowserMetrics",
            "optimization_guide_model_store",
            "component_crx_cache",
            "Crashpad",
            "GrShaderCache"
        ]

        for item in active_names:
            p_path = os.path.join(profiles_dir, item)
            if not os.path.exists(p_path):
                continue
            for sub in cache_subs:
                sub_p = os.path.join(p_path, sub)
                if os.path.exists(sub_p):
                    sz = sum(os.path.getsize(os.path.join(r, f)) for r, d, files in os.walk(sub_p) for f in files)
                    freed += sz
                    shutil.rmtree(sub_p, ignore_errors=True)

            idb_dir = os.path.join(p_path, "Default", "IndexedDB")
            if os.path.exists(idb_dir):
                for sub in os.listdir(idb_dir):
                    if sub.endswith(".blob"):
                        bp = os.path.join(idb_dir, sub)
                        sz = sum(os.path.getsize(os.path.join(r, f)) for r, d, files in os.walk(bp) for f in files)
                        freed += sz
                        shutil.rmtree(bp, ignore_errors=True)

        # 4. Xóa ảnh screenshot test
        for f in os.listdir(data_dir):
            if f.endswith(".png") and f not in ["icon.png", "logo.png"]:
                fp = os.path.join(data_dir, f)
                if os.path.isfile(fp):
                    freed += os.path.getsize(fp)
                    try:
                        os.remove(fp)
                    except Exception:
                        pass

        # 5. SQLite VACUUM
        try:
            with db._get_connection() as conn:
                conn.execute("VACUUM")
        except Exception:
            pass

        self.update_storage_info()
        mb_freed = freed / (1024 * 1024)
        QMessageBox.information(
            self, "Dọn dẹp hoàn tất",
            f"🎉 Đã dọn dẹp và tối ưu hóa thành công!\n\n"
            f"- Đã giải phóng: {mb_freed:.1f} MB bộ nhớ đệm rác.\n"
            f"- Toàn bộ tài khoản và đăng nhập TikTok vẫn được bảo toàn nguyên vẹn."
        )

    def browse_chrome(self):
        f, _ = QFileDialog.getOpenFileName(self, "Chọn chrome.exe", "", "Executable Files (*.exe)")
        if f:
            self.txt_chrome_path.setText(f)

    def auto_detect_chrome(self):
        path = config.find_chrome_path()
        if path:
            self.txt_chrome_path.setText(path)
            QMessageBox.information(self, "Tìm thấy", f"Đã tìm thấy Google Chrome:\n{path}")
        else:
            QMessageBox.warning(self, "Không tìm thấy", "Không tự động tìm thấy Chrome trên các thư mục mặc định.")

    def browse_profiles_dir(self):
        d = QFileDialog.getExistingDirectory(self, "Chọn thư mục lưu Profiles")
        if d:
            self.txt_profiles_dir.setText(d)

    def open_profiles_dir(self):
        d = self.txt_profiles_dir.text()
        if os.path.exists(d):
            os.startfile(d)
        else:
            QMessageBox.warning(self, "Thư mục không tồn tại", f"Thư mục '{d}' chưa được tạo.")

    def browse_pia(self):
        f, _ = QFileDialog.getOpenFileName(self, "Chọn piactl.exe của PIA VPN", "", "Executable Files (*.exe)")
        if f:
            self.txt_pia_path.setText(f)

    def auto_detect_pia(self):
        p = network_mgr.get_pia_path()
        if p:
            self.txt_pia_path.setText(p)
            QMessageBox.information(self, "Tìm thấy", f"Đã tìm thấy PIA VPN:\n{p}")
        else:
            QMessageBox.warning(self, "Không tìm thấy", "Chưa tìm thấy piactl.exe trên máy. Vui lòng bấm Duyệt để chọn vị trí cài đặt PIA.")

    def browse_hma(self):
        f, _ = QFileDialog.getOpenFileName(self, "Chọn HMA.exe của HMA VPN", "", "Executable Files (*.exe)")
        if f:
            self.txt_hma_path.setText(f)

    def auto_detect_hma(self):
        p = network_mgr.get_hma_path()
        if p:
            self.txt_hma_path.setText(p)
            QMessageBox.information(self, "Tìm thấy", f"Đã tìm thấy HMA VPN:\n{p}")
        else:
            QMessageBox.warning(self, "Không tìm thấy", "Chưa tìm thấy HMA.exe trên máy. Vui lòng bấm Duyệt để chọn vị trí cài đặt HMA.")

    def test_telegram_connection(self):
        token = self.txt_telegram_token.text().strip()
        chat_id = self.txt_telegram_chat_id.text().strip()
        if not token or not chat_id:
            QMessageBox.warning(self, "Chưa điền thông tin", "Vui lòng nhập đầy đủ Bot Token và Chat ID trước khi gửi thử nghiệm!")
            return

        from core.notifier import send_telegram_message
        test_msg = (
            "🧪 <b>JL TOOL - KIỂM TRA THÔNG BÁO TELEGRAM</b>\n\n"
            "✅ Kết nối thành công 100%!\n"
            "Từ bây giờ, mỗi khi có video đăng tải thành công lên TikTok, JL Tool sẽ tự động gửi thông báo chi tiết về đây cho bạn."
        )
        self.btn_test_telegram.setEnabled(False)
        self.btn_test_telegram.setText("⏳ Đang gửi...")
        from PySide6.QtWidgets import QApplication
        QApplication.processEvents()

        ok, res = send_telegram_message(test_msg, bot_token=token, chat_id=chat_id)
        self.btn_test_telegram.setEnabled(True)
        self.btn_test_telegram.setText("📲 Gửi Thử Tin Nhắn")

        if ok:
            from core.notifier import clean_telegram_inputs
            clean_tok, clean_cid = clean_telegram_inputs(token, chat_id)
            self.txt_telegram_token.setText(clean_tok)
            self.txt_telegram_chat_id.setText(clean_cid)
            db.set_setting("telegram_bot_token", clean_tok)
            db.set_setting("telegram_chat_id", clean_cid)
            db.set_setting("telegram_notify_enabled", "1")
            self.chk_telegram_enabled.setChecked(True)
            QMessageBox.information(
                self, "Kết nối thành công",
                "🎉 Đã gửi tin nhắn thử nghiệm thành công tới Telegram của bạn!\n\n"
                "Cấu hình đã được tự động lưu và kích hoạt tính năng thông báo."
            )
        else:
            QMessageBox.critical(
                self, "Kết Nối Thất Bại",
                f"{res}"
            )

    def save_settings(self):
        chrome_path = self.txt_chrome_path.text().strip()
        profiles_dir = self.txt_profiles_dir.text().strip()
        pia_path = self.txt_pia_path.text().strip()
        hma_path = self.txt_hma_path.text().strip()
        concurrent = str(self.spn_concurrent.value())
        delay = str(self.spn_delay.value())

        if chrome_path and not os.path.isfile(chrome_path):
            QMessageBox.warning(self, "Cảnh báo", "Đường dẫn chrome.exe không hợp lệ hoặc file không tồn tại!")
            return

        db.set_setting("chrome_path", chrome_path)
        db.set_setting("profiles_dir", profiles_dir)
        db.set_setting("pia_path", pia_path)
        db.set_setting("hma_path", hma_path)
        db.set_setting("max_concurrent_tasks", concurrent)
        db.set_setting("batch_delay", delay)
        db.set_setting("auto_retry_failed", "1" if self.chk_auto_retry.isChecked() else "0")
        db.set_setting("delete_video_after_post", "1" if self.chk_delete_after_post.isChecked() else "0")
        db.set_setting("anti_shadowban_enabled", "1" if self.chk_anti_shadowban.isChecked() else "0")
        db.set_setting("warmup_before_post", "1" if self.chk_warmup.isChecked() else "0")
        db.set_setting("auto_hashtag_enabled", "1" if self.chk_auto_hashtag.isChecked() else "0")
        db.set_setting("auto_disconnect_vpn_after_post", "1" if self.chk_auto_disconnect_vpn.isChecked() else "0")
        db.set_setting("max_immediate_retries", str(self.spn_max_retries.value()))
        db.set_setting("max_retries", str(self.spn_max_retries.value()))
        db.set_setting("retry_delay_seconds", str(self.spn_retry_delay.value()))
        from core.notifier import clean_telegram_inputs
        tok, cid = clean_telegram_inputs(self.txt_telegram_token.text(), self.txt_telegram_chat_id.text())
        self.txt_telegram_token.setText(tok)
        self.txt_telegram_chat_id.setText(cid)
        db.set_setting("desktop_notify_success", "1" if self.chk_desktop_notify.isChecked() else "0")
        db.set_setting("telegram_notify_enabled", "1" if self.chk_telegram_enabled.isChecked() else "0")
        db.set_setting("telegram_bot_token", tok)
        db.set_setting("telegram_chat_id", cid)
        db.set_setting("custom_update_url", self.txt_update_url.text().strip())

        QMessageBox.information(self, "Thành công", "Đã lưu toàn bộ cấu hình hệ thống & thông báo Telegram!")

    def open_release_publisher(self):
        from Phat_Hanh_Ban_Moi import ReleasePublisherApp
        self._pub_win = ReleasePublisherApp()
        self._pub_win.show()
        self._pub_win.showNormal()
        self._pub_win.raise_()
        self._pub_win.activateWindow()

    def manual_check_update(self):
        self.btn_check_update_now.setEnabled(False)
        self.btn_check_update_now.setText("⏳ Đang kiểm tra...")
        self.lbl_up_status.setText("Đang kết nối tới máy chủ cập nhật...")
        self.lbl_up_status.setStyleSheet("color: #38BDF8; font-size: 12px;")

        from core.auto_updater import auto_updater
        custom_u = self.txt_update_url.text().strip()
        if custom_u:
            auto_updater.check_url = custom_u

        def do_check():
            has_u, data, msg = auto_updater.check_for_updates(timeout=3.5)
            self.btn_check_update_now.setEnabled(True)
            self.btn_check_update_now.setText("🔄 Cập Nhật Phiên Bản Mới")

            if has_u:
                ver = data.get("version", "")
                cl = data.get("changelog", "")
                self.lbl_up_status.setText(f"🔥 Đã có bản mới v{ver}!")
                self.lbl_up_status.setStyleSheet("color: #FACC15; font-size: 12px; font-weight: bold;")
                reply = QMessageBox.question(
                    self, "Phát Hiện Bản Cập Nhật Mới",
                    f"🎉 ĐÃ CÓ PHIÊN BẢN MỚI v{ver}!\n\n"
                    f"📝 Nội dung: {cl}\n\n"
                    f"Bạn có muốn tiến hành tải và tự động cập nhật ngay bây giờ không?",
                    QMessageBox.Yes | QMessageBox.No
                )
                if reply == QMessageBox.Yes:
                    d_url = data.get("download_url", "")
                    if d_url:
                        main_w = self.window()
                        if hasattr(main_w, "start_apply_update"):
                            main_w._pending_download_url = d_url
                            main_w._pending_version = ver
                            main_w.start_apply_update()
            else:
                self.lbl_up_status.setText("🟢 Đang là phiên bản mới nhất")
                self.lbl_up_status.setStyleSheet("color: #34D399; font-size: 12px; font-weight: 600;")
                QMessageBox.information(self, "Kiểm Tra Cập Nhật", msg)

        QTimer.singleShot(100, do_check)
