import os
from pathlib import Path
from typing import List, Dict, Any
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QTableWidget, QTableWidgetItem, QHeaderView, QFrame,
    QFileDialog, QMessageBox, QCheckBox, QListWidget, QListWidgetItem,
    QSplitter
)
from PySide6.QtCore import Qt, Signal
from database.db_manager import db

class VideosPage(QWidget):
    # Signal gửi danh sách video đã chọn sang trang Đăng video & Lên lịch
    request_upload_with_videos = Signal(list)

    def __init__(self):
        super().__init__()
        self.videos_data: List[Dict[str, Any]] = []
        self.row_checkboxes = []
        self.selected_video_paths: List[str] = []
        self.setAcceptDrops(True)
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(28, 20, 28, 20)
        layout.setSpacing(16)

        # Header Title
        header_layout = QHBoxLayout()
        title_box = QVBoxLayout()
        lbl_title = QLabel("Quản Lý Kho Video Nguồn & Phân Loại")
        lbl_title.setProperty("class", "page-title")
        lbl_subtitle = QLabel("Thư viện lưu trữ video MP4, MOV - Tích chọn video để chuyển thẳng vào bộ lên lịch đăng bài")
        lbl_subtitle.setStyleSheet("color: #25F4EE; font-size: 13px; font-weight: 500;")
        title_box.addWidget(lbl_title)
        title_box.addWidget(lbl_subtitle)
        header_layout.addLayout(title_box)

        header_layout.addStretch()

        self.btn_add_files = QPushButton("➕ Thêm Video Vào Kho...")
        self.btn_add_files.setProperty("class", "btn-primary")
        self.btn_add_files.clicked.connect(self.add_video_files)
        header_layout.addWidget(self.btn_add_files)

        self.btn_add_folder = QPushButton("📁 Quét Cả Thư Mục...")
        self.btn_add_folder.setProperty("class", "btn-secondary")
        self.btn_add_folder.clicked.connect(self.scan_folder)
        header_layout.addWidget(self.btn_add_folder)

        layout.addLayout(header_layout)

        # Thanh công cụ: Checkbox chọn tất cả & Thông số
        tool_bar = QFrame()
        tool_bar.setProperty("class", "content-panel")
        tool_layout = QHBoxLayout(tool_bar)
        tool_layout.setContentsMargins(14, 10, 14, 10)
        tool_layout.setSpacing(14)

        self.chk_select_all = QCheckBox("Chọn tất cả video trong kho")
        self.chk_select_all.stateChanged.connect(self.toggle_select_all)
        tool_layout.addWidget(self.chk_select_all)

        tool_layout.addStretch()

        self.lbl_total_info = QLabel("Tổng số: 0 video trong kho")
        self.lbl_total_info.setStyleSheet("color: #8E8EA0; font-weight: 600;")
        tool_layout.addWidget(self.lbl_total_info)

        layout.addWidget(tool_bar)

        # Splitter chia 2 khu vực: Trái (Bảng kho video) - Phải (Panel Các Video Đã Chọn)
        splitter = QSplitter(Qt.Horizontal)
        splitter.setStyleSheet("""
            QSplitter::handle {
                background-color: #242533;
                width: 2px;
            }
        """)

        # ==================== KHU VỰC TRÁI: BẢNG KHO VIDEO ====================
        left_widget = QWidget()
        left_layout = QVBoxLayout(left_widget)
        left_layout.setContentsMargins(0, 0, 8, 0)
        left_layout.setSpacing(10)

        self.table = QTableWidget()
        self.table.setColumnCount(6)
        self.table.setHorizontalHeaderLabels([
            "✔", "Tên Video Nguồn", "Dung Lượng", "Đường Dẫn Tệp", "Trạng Thái", "Xóa"
        ])
        
        header = self.table.horizontalHeader()
        header.setSectionResizeMode(0, QHeaderView.Fixed)
        self.table.setColumnWidth(0, 36)

        header.setSectionResizeMode(1, QHeaderView.Stretch)

        header.setSectionResizeMode(2, QHeaderView.Fixed)
        self.table.setColumnWidth(2, 90)

        header.setSectionResizeMode(3, QHeaderView.Fixed)
        self.table.setColumnWidth(3, 170)

        header.setSectionResizeMode(4, QHeaderView.Fixed)
        self.table.setColumnWidth(4, 125)

        header.setSectionResizeMode(5, QHeaderView.Fixed)
        self.table.setColumnWidth(5, 85)

        self.table.verticalHeader().setDefaultSectionSize(44)
        self.table.verticalHeader().setVisible(False)
        self.table.setSelectionBehavior(QTableWidget.SelectRows)
        self.table.setEditTriggers(QTableWidget.NoEditTriggers)
        left_layout.addWidget(self.table)
        splitter.addWidget(left_widget)
        splitter.setSizes([720, 260])

        # ==================== KHU VỰC PHẢI: PANEL CÁC VIDEO ĐÃ CHỌN ====================
        right_panel = QFrame()
        right_panel.setStyleSheet("""
            QFrame {
                background-color: #141520;
                border: 1px solid #282A3E;
                border-radius: 12px;
                padding: 12px;
            }
        """)
        right_layout = QVBoxLayout(right_panel)
        right_layout.setContentsMargins(12, 12, 12, 12)
        right_layout.setSpacing(12)

        # Tiêu đề Panel
        selected_title_box = QVBoxLayout()
        selected_title_box.setSpacing(2)
        lbl_selected_header = QLabel("📌 CÁC VIDEO ĐÃ CHỌN")
        lbl_selected_header.setStyleSheet("font-weight: 800; color: #FFFFFF; font-size: 13px; letter-spacing: 0.5px;")
        
        self.lbl_selected_count = QLabel("Đang chọn: 0 video (0.0 MB)")
        self.lbl_selected_count.setStyleSheet("color: #25F4EE; font-size: 12px; font-weight: 600;")
        
        selected_title_box.addWidget(lbl_selected_header)
        selected_title_box.addWidget(self.lbl_selected_count)
        right_layout.addLayout(selected_title_box)

        # Danh sách các video đã chọn
        self.list_selected_videos = QListWidget()
        self.list_selected_videos.setStyleSheet("""
            QListWidget {
                background-color: #0E0F17;
                border: 1px solid #232432;
                border-radius: 8px;
                padding: 6px;
                color: #FFFFFF;
            }
            QListWidget::item {
                padding: 6px 8px;
                border-bottom: 1px solid #1A1B26;
            }
        """)
        right_layout.addWidget(self.list_selected_videos)

        # Nút chuyển video đã chọn vào Lịch đăng
        self.btn_send_to_upload = QPushButton("🚀 ĐƯA VÀO LỊCH ĐĂNG NGAY")
        self.btn_send_to_upload.setProperty("class", "btn-batch")
        self.btn_send_to_upload.setFixedHeight(40)
        self.btn_send_to_upload.setCursor(Qt.PointingHandCursor)
        self.btn_send_to_upload.clicked.connect(self.send_selected_to_upload)
        right_layout.addWidget(self.btn_send_to_upload)

        # Nút phụ: Xóa các video đã chọn khỏi kho & Bỏ chọn
        btn_action_box = QHBoxLayout()
        self.btn_uncheck_all = QPushButton("Bỏ chọn")
        self.btn_uncheck_all.setProperty("class", "btn-secondary")
        self.btn_uncheck_all.clicked.connect(self.uncheck_all)

        self.btn_delete_selected = QPushButton("🗑️ Xóa khỏi kho")
        self.btn_delete_selected.setProperty("class", "btn-danger")
        self.btn_delete_selected.clicked.connect(self.delete_selected_videos)

        btn_action_box.addWidget(self.btn_uncheck_all)
        btn_action_box.addWidget(self.btn_delete_selected)
        right_layout.addLayout(btn_action_box)

        splitter.addWidget(right_panel)
        splitter.setStretchFactor(0, 6) # Bảng kho video chiếm 60%
        splitter.setStretchFactor(1, 4) # Panel đã chọn chiếm 40%

        layout.addWidget(splitter)
        self.load_videos()

    # ==================== KÉO THẢ VIDEO VÀO KHO ====================
    def dragEnterEvent(self, event):
        if event.mimeData().hasUrls():
            event.acceptProposedAction()

    def dropEvent(self, event):
        paths = []
        for url in event.mimeData().urls():
            p = url.toLocalFile()
            if os.path.isfile(p) and p.lower().endswith(('.mp4', '.mov', '.mkv')):
                paths.append(p)
            elif os.path.isdir(p):
                for root, _, files in os.walk(p):
                    for f in files:
                        if f.lower().endswith(('.mp4', '.mov', '.mkv')):
                            paths.append(os.path.join(root, f))
        if paths:
            self.process_added_videos(paths)

    def add_video_files(self):
        files, _ = QFileDialog.getOpenFileNames(
            self, "Chọn danh sách file Video", "", "Video Files (*.mp4 *.mov *.mkv);;All Files (*)"
        )
        if files:
            self.process_added_videos(files)

    def scan_folder(self):
        folder = QFileDialog.getExistingDirectory(self, "Chọn thư mục chứa Video")
        if folder:
            paths = []
            for root, _, files in os.walk(folder):
                for f in files:
                    if f.lower().endswith(('.mp4', '.mov', '.mkv')):
                        paths.append(os.path.join(root, f))
            if paths:
                self.process_added_videos(paths)
            else:
                QMessageBox.information(self, "Thông báo", "Không tìm thấy file video MP4/MOV nào.")

    def process_added_videos(self, paths: List[str]):
        count = 0
        from core.video_vault import video_vault
        for path in paths:
            file_name = os.path.basename(path)
            vault_path = video_vault.import_video_to_vault(path, file_name)
            file_size = os.path.getsize(vault_path) if os.path.exists(vault_path) else 0
            with db._get_connection() as conn:
                conn.execute("""
                    INSERT INTO videos (title, file_path, file_size)
                    VALUES (?, ?, ?)
                """, (file_name, vault_path, file_size))
                conn.commit()
                count += 1
        self.load_videos()
        QMessageBox.information(self, "Thành công", f"Đã thêm thành công {count} video vào kho an toàn của Tool!")

    # ==================== NẠP & HIỂN THỊ ====================
    def load_videos(self):
        with db._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM videos ORDER BY id DESC")
            self.videos_data = [dict(r) for r in cursor.fetchall()]

        self.lbl_total_info.setText(f"Tổng số: {len(self.videos_data)} video trong kho")
        self.render_table()
        self.update_selected_panel()

    def render_table(self):
        self.table.setRowCount(len(self.videos_data))
        self.row_checkboxes.clear()

        for row, v in enumerate(self.videos_data):
            # Cột 0: Checkbox
            chk = QCheckBox()
            chk.setStyleSheet("margin-left: 8px;")
            p = v.get("file_path", "")
            if p in self.selected_video_paths:
                chk.setChecked(True)
            chk.stateChanged.connect(lambda state, video=v: self.on_checkbox_changed(state, video))

            chk_w = QWidget()
            chk_l = QHBoxLayout(chk_w)
            chk_l.setContentsMargins(0, 0, 0, 0)
            chk_l.setAlignment(Qt.AlignCenter)
            chk_l.addWidget(chk)
            self.table.setCellWidget(row, 0, chk_w)
            self.row_checkboxes.append((chk, v))

            # Cột 1: Tên video
            self.table.setItem(row, 1, QTableWidgetItem(f"🎬 {v.get('title', '')}"))

            # Cột 2: Dung lượng
            size_mb = (v.get("file_size", 0) or 0) / (1024 * 1024)
            self.table.setItem(row, 2, QTableWidgetItem(f"{size_mb:.1f} MB"))

            # Cột 3: Đường dẫn
            self.table.setItem(row, 3, QTableWidgetItem(v.get("file_path", "")))

            # Cột 4: Trạng thái
            is_posted = bool(v.get("is_posted", 0))
            st_item = QTableWidgetItem("✅ Đã đăng" if is_posted else "⏳ Chưa đăng")
            st_item.setForeground(Qt.green if is_posted else Qt.gray)
            st_item.setTextAlignment(Qt.AlignCenter)
            self.table.setItem(row, 4, st_item)

            # Cột 5: Nút xóa đơn lẻ
            del_w = QWidget()
            del_l = QHBoxLayout(del_w)
            del_l.setContentsMargins(2, 2, 2, 2)
            del_l.setAlignment(Qt.AlignCenter)
            btn_delete = QPushButton("🗑️ Xóa")
            btn_delete.setFixedHeight(28)
            btn_delete.setCursor(Qt.PointingHandCursor)
            btn_delete.setStyleSheet("""
                QPushButton {
                    background-color: #2D1A1E;
                    color: #F87171;
                    border: 1px solid #4F2228;
                    border-radius: 4px;
                    padding: 2px 8px;
                    font-size: 11px;
                }
                QPushButton:hover {
                    background-color: #DC2626;
                    color: #FFFFFF;
                }
            """)
            btn_delete.clicked.connect(lambda checked=False, vid=v["id"]: self.delete_single_video(vid))
            del_l.addWidget(btn_delete)
            self.table.setCellWidget(row, 5, del_w)

    def on_checkbox_changed(self, state, video: dict):
        path = video.get("file_path", "")
        if (state == Qt.Checked.value or state == True):
            if path and path not in self.selected_video_paths:
                self.selected_video_paths.append(path)
        else:
            if path in self.selected_video_paths:
                self.selected_video_paths.remove(path)

        self.update_selected_panel()

    def toggle_select_all(self, state):
        is_checked = (state == Qt.Checked.value or state == True)
        self.selected_video_paths.clear()
        if is_checked:
            for _, v in self.row_checkboxes:
                p = v.get("file_path", "")
                if p:
                    self.selected_video_paths.append(p)

        for chk, _ in self.row_checkboxes:
            chk.blockSignals(True)
            chk.setChecked(is_checked)
            chk.blockSignals(False)

        self.update_selected_panel()

    def uncheck_all(self):
        self.chk_select_all.setChecked(False)
        self.toggle_select_all(False)

    def update_selected_panel(self):
        self.list_selected_videos.clear()
        total_size_bytes = 0

        for path in self.selected_video_paths:
            name = os.path.basename(path)
            size_mb = 0
            if os.path.exists(path):
                s = os.path.getsize(path)
                total_size_bytes += s
                size_mb = s / (1024 * 1024)

            item = QListWidgetItem(f"📹 {name} ({size_mb:.1f} MB)")
            item.setToolTip(path)
            self.list_selected_videos.addItem(item)

        total_mb = total_size_bytes / (1024 * 1024)
        self.lbl_selected_count.setText(f"Đang chọn: {len(self.selected_video_paths)} video ({total_mb:.1f} MB)")

    # ==================== HÀNH ĐỘNG ====================
    def send_selected_to_upload(self):
        """Chuyển danh sách video đã chọn sang trang Đăng video để lên lịch tự động ngay"""
        if not self.selected_video_paths:
            QMessageBox.warning(self, "Chưa chọn video", "Vui lòng tích chọn ít nhất 1 video trong kho!")
            return

        # Emit signal sang MainWindow
        self.request_upload_with_videos.emit(list(self.selected_video_paths))

    def delete_selected_videos(self):
        if not self.selected_video_paths:
            QMessageBox.warning(self, "Chưa chọn video", "Vui lòng tích chọn các video bạn muốn xóa!")
            return

        reply = QMessageBox.question(
            self, "Xác nhận xóa",
            f"Bạn có chắc muốn xóa <b>{len(self.selected_video_paths)}</b> video đã chọn khỏi cơ sở dữ liệu?",
            QMessageBox.Yes | QMessageBox.No
        )
        if reply == QMessageBox.Yes:
            with db._get_connection() as conn:
                for path in self.selected_video_paths:
                    conn.execute("DELETE FROM videos WHERE file_path = ?", (path,))
                conn.commit()

            self.selected_video_paths.clear()
            self.load_videos()
            QMessageBox.information(self, "Đã xóa", "Đã xóa các video đã chọn khỏi kho dữ liệu.")

    def delete_single_video(self, video_id: int):
        with db._get_connection() as conn:
            conn.execute("DELETE FROM videos WHERE id = ?", (video_id,))
            conn.commit()
        self.load_videos()
