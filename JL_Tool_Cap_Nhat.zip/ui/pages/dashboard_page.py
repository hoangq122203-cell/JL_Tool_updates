import datetime
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QFrame, QTableWidget, QTableWidgetItem, QHeaderView,
    QScrollArea, QMessageBox
)
from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QColor, QFont
from ui.components.stat_card import StatCard
from database.db_manager import db
from core.chrome_manager import chrome_mgr

class DashboardPage(QWidget):
    request_page = Signal(int)

    def __init__(self):
        super().__init__()
        self.init_ui()

    def init_ui(self):
        outer_layout = QVBoxLayout(self)
        outer_layout.setContentsMargins(0, 0, 0, 0)
        outer_layout.setSpacing(0)

        scroll_area = QScrollArea()
        scroll_area.setWidgetResizable(True)
        scroll_area.setStyleSheet("QScrollArea { border: none; background-color: #0C0E17; }")

        container = QWidget()
        container.setStyleSheet("background-color: #0C0E17;")
        layout = QVBoxLayout(container)
        layout.setContentsMargins(28, 22, 28, 28)
        layout.setSpacing(18)

        # ==================== 1. HEADER TỔNG QUAN CHUẨN MẪU & NÚT CÔNG NĂNG NHANH ====================
        top_header_row = QHBoxLayout()
        top_header_row.setSpacing(16)

        header_box = QVBoxLayout()
        header_box.setSpacing(4)

        lbl_main_title = QLabel("Tổng quan")
        lbl_main_title.setStyleSheet("font-size: 22px; font-weight: 700; color: #FFFFFF; letter-spacing: 0.3px;")
        header_box.addWidget(lbl_main_title)

        now_time = datetime.datetime.now().strftime("%H:%M:%S")
        self.lbl_subtitle = QLabel(
            f"Toàn cảnh vận hành — số liệu đăng bài, cảnh báo cần chú ý, và chi tiết theo từng project. — Cập nhật lúc {now_time}"
        )
        self.lbl_subtitle.setStyleSheet("font-size: 12px; color: #8C9BB0; font-weight: 400;")
        header_box.addWidget(self.lbl_subtitle)

        top_header_row.addLayout(header_box)
        top_header_row.addStretch()

        # Nút thao tác nhanh công năng gốc
        action_btn_box = QHBoxLayout()
        action_btn_box.setSpacing(10)

        self.btn_add_channel = QPushButton("➕ Thêm Kênh")
        self.btn_add_channel.setProperty("class", "btn-primary")
        self.btn_add_channel.setFixedHeight(34)
        self.btn_add_channel.setCursor(Qt.PointingHandCursor)
        self.btn_add_channel.clicked.connect(lambda: self.request_page.emit(1))
        action_btn_box.addWidget(self.btn_add_channel)

        self.btn_quick_upload = QPushButton("📅 Lịch Hẹn Đăng")
        self.btn_quick_upload.setProperty("class", "btn-secondary")
        self.btn_quick_upload.setFixedHeight(34)
        self.btn_quick_upload.setCursor(Qt.PointingHandCursor)
        self.btn_quick_upload.setToolTip("Xem và quản lý lịch hẹn đăng video")
        self.btn_quick_upload.clicked.connect(lambda: self.request_page.emit(2))
        action_btn_box.addWidget(self.btn_quick_upload)

        self.btn_refresh = QPushButton("🔄 Làm Mới")
        self.btn_refresh.setProperty("class", "btn-secondary")
        self.btn_refresh.setFixedHeight(34)
        self.btn_refresh.setCursor(Qt.PointingHandCursor)
        self.btn_refresh.clicked.connect(self.load_data)
        action_btn_box.addWidget(self.btn_refresh)

        top_header_row.addLayout(action_btn_box)
        layout.addLayout(top_header_row)

        # ==================== 2. HÀNG 4 THẺ THỐNG KÊ (STAT CARDS) ====================
        cards_layout = QHBoxLayout()
        cards_layout.setSpacing(14)

        self.card_posted_24h = StatCard(
            title="ĐÃ ĐĂNG 24H",
            value="0",
            description="clip đăng TikTok thành công"
        )
        self.card_total_posted = StatCard(
            title="TỔNG ĐÃ ĐĂNG",
            value="0",
            description="từ trước đến nay"
        )
        self.card_active_accounts = StatCard(
            title="TÀI KHOẢN HOẠT ĐỘNG",
            value="0/0",
            description="đang bật | 0 chưa gắn project"
        )
        self.card_channels_follow = StatCard(
            title="KÊNH THEO DÕI",
            value="0",
            description="lịch đăng đang chờ"
        )

        cards_layout.addWidget(self.card_posted_24h)
        cards_layout.addWidget(self.card_total_posted)
        cards_layout.addWidget(self.card_active_accounts)
        cards_layout.addWidget(self.card_channels_follow)

        layout.addLayout(cards_layout)

        # ==================== 3. KHUNG CẦN CHÚ Ý (ATTENTION BOX) ====================
        notice_card = QFrame()
        notice_card.setStyleSheet("""
            QFrame {
                background-color: #141A2D;
                border: 1px solid #222B42;
                border-radius: 8px;
            }
        """)
        notice_layout = QVBoxLayout(notice_card)
        notice_layout.setContentsMargins(18, 14, 18, 16)
        notice_layout.setSpacing(10)

        # Tiêu đề "Cần chú ý"
        lbl_notice_title = QLabel("Cần chú ý")
        lbl_notice_title.setStyleSheet("font-size: 13px; font-weight: 700; color: #FFFFFF; border: none; background: transparent;")
        notice_layout.addWidget(lbl_notice_title)

        # Vạch kẻ phân cách mỏng
        line_sep = QFrame()
        line_sep.setFixedHeight(1)
        line_sep.setStyleSheet("background-color: #202940; border: none;")
        notice_layout.addWidget(line_sep)

        # Khu vực cảnh báo bên trong
        notice_content = QHBoxLayout()
        notice_content.setContentsMargins(10, 16, 10, 18)

        self.lbl_alert_detail = QLabel("Hệ thống hoạt động bình thường, không có cảnh báo nào.")
        self.lbl_alert_detail.setStyleSheet("color: #8C9BB0; font-size: 12px; font-weight: 500; border: none; background: transparent;")
        notice_content.addWidget(self.lbl_alert_detail)

        notice_content.addStretch()

        self.lbl_no_alert = QLabel("Không có cảnh báo nào")
        self.lbl_no_alert.setStyleSheet("color: #7E8D9F; font-size: 12px; font-weight: 500; border: none; background: transparent;")
        notice_content.addWidget(self.lbl_no_alert)

        notice_layout.addLayout(notice_content)
        layout.addWidget(notice_card)

        # ==================== 4. KHUNG TỔNG QUAN TIKTOK ACCOUNTS ====================
        accounts_card = QFrame()
        accounts_card.setStyleSheet("""
            QFrame {
                background-color: #141A2D;
                border: 1px solid #222B42;
                border-radius: 8px;
            }
        """)
        acc_layout = QVBoxLayout(accounts_card)
        acc_layout.setContentsMargins(18, 14, 18, 16)
        acc_layout.setSpacing(12)

        # Tiêu đề "Tổng quan TikTok accounts"
        acc_top_row = QHBoxLayout()
        acc_top_row.setContentsMargins(0, 0, 0, 0)

        lbl_acc_title = QLabel("Tổng quan TikTok accounts")
        lbl_acc_title.setStyleSheet("font-size: 14px; font-weight: 700; color: #FFFFFF; border: none; background: transparent;")
        acc_top_row.addWidget(lbl_acc_title)
        acc_top_row.addStretch()

        btn_manage = QPushButton("Quản lý toàn bộ kênh & Proxy ➔")
        btn_manage.setProperty("class", "btn-secondary")
        btn_manage.setCursor(Qt.PointingHandCursor)
        btn_manage.clicked.connect(lambda: self.request_page.emit(1))
        acc_top_row.addWidget(btn_manage)

        acc_layout.addLayout(acc_top_row)

        # Bảng danh sách kênh tài khoản
        self.table_accounts = QTableWidget()
        self.table_accounts.setColumnCount(8)
        self.table_accounts.setHorizontalHeaderLabels([
            "STT", "Kênh TikTok", "Follow", "View", "Kết Nối / IP", "Chrome", "Đã Đăng", "Thao Tác"
        ])

        header = self.table_accounts.horizontalHeader()
        header.setSectionResizeMode(0, QHeaderView.Fixed)
        self.table_accounts.setColumnWidth(0, 50)

        header.setSectionResizeMode(1, QHeaderView.Interactive)
        self.table_accounts.setColumnWidth(1, 160)

        header.setSectionResizeMode(2, QHeaderView.Fixed)
        self.table_accounts.setColumnWidth(2, 130)

        header.setSectionResizeMode(3, QHeaderView.Fixed)
        self.table_accounts.setColumnWidth(3, 130)

        header.setSectionResizeMode(4, QHeaderView.Stretch)

        header.setSectionResizeMode(5, QHeaderView.Fixed)
        self.table_accounts.setColumnWidth(5, 140)

        header.setSectionResizeMode(6, QHeaderView.Fixed)
        self.table_accounts.setColumnWidth(6, 80)

        header.setSectionResizeMode(7, QHeaderView.Fixed)
        self.table_accounts.setColumnWidth(7, 120)

        self.table_accounts.verticalHeader().setDefaultSectionSize(52)
        self.table_accounts.verticalHeader().setVisible(False)
        self.table_accounts.setMinimumHeight(180)
        acc_layout.addWidget(self.table_accounts)

        layout.addWidget(accounts_card)

        # ==================== 5. BẢNG NHẬT KÝ ĐĂNG VIDEO GẦN NHẤT ====================
        history_card = QFrame()
        history_card.setStyleSheet("""
            QFrame {
                background-color: #141A2D;
                border: 1px solid #222B42;
                border-radius: 8px;
            }
        """)
        hist_layout = QVBoxLayout(history_card)
        hist_layout.setContentsMargins(18, 14, 18, 16)
        hist_layout.setSpacing(12)

        hist_top_row = QHBoxLayout()
        lbl_hist_title = QLabel("Nhật ký đăng tải gần nhất")
        lbl_hist_title.setStyleSheet("font-size: 14px; font-weight: 700; color: #FFFFFF; border: none; background: transparent;")
        hist_top_row.addWidget(lbl_hist_title)
        hist_top_row.addStretch()

        btn_view_history = QPushButton("Xem toàn bộ lịch sử ➔")
        btn_view_history.setProperty("class", "btn-secondary")
        btn_view_history.setCursor(Qt.PointingHandCursor)
        btn_view_history.clicked.connect(lambda: self.request_page.emit(4))
        hist_top_row.addWidget(btn_view_history)

        hist_layout.addLayout(hist_top_row)

        self.table_recent = QTableWidget()
        self.table_recent.setColumnCount(5)
        self.table_recent.setHorizontalHeaderLabels([
            "Kênh TikTok", "Tên Video", "Thời Gian (Giờ VN)", "Trạng Thái", "Chi Tiết / Liên Kết"
        ])
        h_header = self.table_recent.horizontalHeader()
        h_header.setSectionResizeMode(0, QHeaderView.ResizeToContents)
        h_header.setSectionResizeMode(1, QHeaderView.Stretch)
        h_header.setSectionResizeMode(2, QHeaderView.ResizeToContents)
        h_header.setSectionResizeMode(3, QHeaderView.ResizeToContents)
        h_header.setSectionResizeMode(4, QHeaderView.Stretch)

        self.table_recent.setSelectionBehavior(QTableWidget.SelectRows)
        self.table_recent.setEditTriggers(QTableWidget.NoEditTriggers)
        self.table_recent.setMinimumHeight(180)
        self.table_recent.verticalHeader().setVisible(False)
        hist_layout.addWidget(self.table_recent)

        layout.addWidget(history_card)

        # Thêm container vào scroll area
        scroll_area.setWidget(container)
        outer_layout.addWidget(scroll_area)

        self.load_data()

    def load_data(self):
        """Nạp dữ liệu từ database và cập nhật giao diện Dashboard"""
        stats = db.get_dashboard_stats()
        channels = db.get_all_channels()

        tot = len(channels)
        logged = sum(1 for ch in channels if ch.get("is_logged_in"))

        now_time = datetime.datetime.now().strftime("%H:%M:%S")
        self.lbl_subtitle.setText(
            f"Toàn cảnh vận hành — số liệu đăng bài, cảnh báo cần chú ý, và chi tiết theo từng project. — Cập nhật lúc {now_time}"
        )

        # Cập nhật 4 thẻ chỉ số
        self.card_posted_24h.update_value(
            str(stats.get("today_posted", 0)),
            "clip đăng TikTok thành công"
        )
        self.card_total_posted.update_value(
            str(stats.get("total_posted", 0)),
            "từ trước đến nay"
        )
        self.card_active_accounts.update_value(
            f"{logged}/{tot}" if tot > 0 else "0/0",
            f"đang bật | {tot} kênh trong hệ thống"
        )
        self.card_channels_follow.update_value(
            str(stats.get("pending_videos", 0)),
            "lịch đăng đang chờ"
        )

        # Cập nhật cảnh báo nếu có kênh chưa login
        unlogged = tot - logged
        if unlogged > 0:
            self.lbl_alert_detail.setText(f"⚠️ Phát hiện {unlogged} tài khoản TikTok chưa đăng nhập phiên Chrome.")
            self.lbl_no_alert.setText(f"Cần xử lý {unlogged} kênh")
            self.lbl_no_alert.setStyleSheet("color: #F59E0B; font-size: 12px; font-weight: 700; border: none; background: transparent;")
        else:
            self.lbl_alert_detail.setText("Tất cả tài khoản và kết nối mạng đều sẵn sàng.")
            self.lbl_no_alert.setText("Không có cảnh báo nào")
            self.lbl_no_alert.setStyleSheet("color: #7E8D9F; font-size: 12px; font-weight: 500; border: none; background: transparent;")

        # Nạp bảng tài khoản TikTok
        saved_vpn_country = db.get_setting("global_vpn_country_name", "VPN")
        self.table_accounts.clearContents()
        self.table_accounts.setRowCount(len(channels))
        for row, ch in enumerate(channels):
            is_logged = bool(ch.get("is_logged_in"))

            # Cột 0: STT (Đánh số từ 1 trở đi)
            item_stt = QTableWidgetItem(str(row + 1))
            item_stt.setTextAlignment(Qt.AlignCenter)
            item_stt.setForeground(QColor("#94A3B8"))
            font_stt = QFont("Segoe UI", 10)
            font_stt.setBold(True)
            item_stt.setFont(font_stt)
            self.table_accounts.setItem(row, 0, item_stt)

            # Cột 1: Tên kênh TikTok đồng nhất sau chữ @ (ví dụ 🎬 @5)
            name = str(ch.get("name", "Kênh")).strip()
            raw_user = str(ch.get("username", "") or "").strip()
            handle = raw_user if raw_user else f"@{name}"
            if not handle.startswith("@"):
                handle = f"@{handle}"

            clean_name = name.lstrip("@")
            clean_handle = handle.lstrip("@")
            if clean_name.lower() == clean_handle.lower():
                display_name = f"🎬 @{clean_name}"
            else:
                display_name = f"🎬 {name}  ({handle})"

            item_name = QTableWidgetItem(display_name)
            item_name.setForeground(Qt.white)
            self.table_accounts.setItem(row, 1, item_name)

            # Cột 2: Mạng Proxy/VPN (ĐỒNG NHẤT VỚI FAKE IP CỦA TOOL, RÕ RÀNG KHÔNG VỆT ĐEN)
            use_vpn = bool(ch.get("use_vpn", 1))
            net_type = ch.get("network_type", "vpn")
            cached_fake_ip = db.get_setting("cached_fake_ip", "")
            cached_real_ip = db.get_setting("cached_real_machine_ip", "")

            font_badge = QFont("Segoe UI", 10)
            font_badge.setBold(True)

            if net_type == "proxy" and ch.get("proxy_string"):
                item_badge = QTableWidgetItem("🛡️ PROXY RIÊNG")
                item_badge.setForeground(QColor("#60A5FA"))
                item_badge.setToolTip("Kênh chạy qua Proxy riêng được cấu hình")
            elif use_vpn:
                c_clean = saved_vpn_country
                for p in ["🇻🇳", "🇯🇵", "🇰🇷", "🇸🇬", "🇹🇼", "🇭🇰", "🇹🇭", "🇲🇾", "🇮🇩", "🇵🇭", "🇮🇳", "🇦🇺", "🇺🇸", "🇨🇦", "🇬🇧", "🇩🇪", "🇫🇷", "🇳🇱"]:
                    c_clean = c_clean.replace(p, "").strip()
                if "(" in c_clean:
                    c_clean = c_clean.split("(")[0].strip()

                has_valid_ip = bool(
                    cached_fake_ip and 
                    "fake" not in cached_fake_ip.lower() and 
                    "quét" not in cached_fake_ip.lower() and 
                    "chưa" not in cached_fake_ip.lower()
                )
                if has_valid_ip:
                    badge_text = f"🛡️ IP: {c_clean} ({cached_fake_ip})"
                else:
                    badge_text = f"🛡️ IP: {c_clean}"
                item_badge = QTableWidgetItem(badge_text)
                item_badge.setForeground(QColor("#38BDF8"))
                disp_ip = cached_fake_ip if has_valid_ip else "Chưa kết nối"
                item_badge.setToolTip(f"Kênh đang chạy qua VPN vùng {saved_vpn_country}\nĐịa chỉ IP: {disp_ip}")
            else:
                if cached_real_ip:
                    badge_text = f"🌐 IP GỐC: {cached_real_ip}"
                else:
                    badge_text = "🌐 IP GỐC MÁY"
                item_badge = QTableWidgetItem(badge_text)
                item_badge.setForeground(QColor("#34D399"))
                item_badge.setToolTip("Kênh chạy bằng địa chỉ IP thật của máy tính")

            item_badge.setTextAlignment(Qt.AlignCenter)
            item_badge.setFont(font_badge)

            # Cột 2: Followers (Flow)
            flow_cnt = int(ch.get("followers_count") or 0)
            flow_str = f"👥 {flow_cnt:,}" if flow_cnt < 10000 else f"👥 {flow_cnt/1000:.1f}K"
            flow_item = QTableWidgetItem(flow_str if flow_cnt > 0 else "⚪ 0")
            flow_item.setTextAlignment(Qt.AlignCenter)
            flow_item.setForeground(QColor("#38BDF8") if flow_cnt > 0 else QColor("#94A3B8"))
            flow_item.setToolTip(f"👥 Người theo dõi: {flow_cnt:,} Follower")
            self.table_accounts.setItem(row, 2, flow_item)

            # Cột 3: Lượt Thích / View - Khớp 100% với số hiển thị trên TikTok
            views_cnt = int(ch.get("views_count") or ch.get("likes_count") or 0)
            view_str = f"❤️ {views_cnt:,}" if views_cnt < 10000 else f"❤️ {views_cnt/1000:.1f}K"
            view_item = QTableWidgetItem(view_str if views_cnt > 0 else "⚪ 0")
            view_item.setTextAlignment(Qt.AlignCenter)
            view_item.setForeground(QColor("#F472B6") if views_cnt > 0 else QColor("#94A3B8"))
            view_item.setToolTip(f"❤️ Lượt thích / Tương tác: {views_cnt:,} Thích")
            self.table_accounts.setItem(row, 3, view_item)

            # Cột 4: Kết Nối (Proxy / VPN)
            self.table_accounts.setItem(row, 4, item_badge)

            # Cột 5: Trạng thái Login
            st_text = "🟢 Đã đăng nhập" if is_logged else "⚪ Chưa đăng nhập"
            st_item = QTableWidgetItem(st_text)
            st_item.setTextAlignment(Qt.AlignCenter)
            st_item.setForeground(Qt.green if is_logged else Qt.gray)
            self.table_accounts.setItem(row, 5, st_item)

            # Cột 6: Đã đăng
            item_count = QTableWidgetItem(str(ch.get("posted_count", 0)))
            item_count.setTextAlignment(Qt.AlignCenter)
            self.table_accounts.setItem(row, 6, item_count)

            # Cột 7: Nút thao tác mở web/login
            action_widget = QWidget()
            action_widget.setStyleSheet("background: transparent; border: none;")
            action_layout = QHBoxLayout(action_widget)
            action_layout.setContentsMargins(4, 2, 4, 2)
            action_layout.setSpacing(6)
            action_layout.setAlignment(Qt.AlignCenter)

            btn_open = QPushButton("🌐 Mở Chrome")
            btn_open.setProperty("class", "btn-secondary")
            btn_open.setCursor(Qt.PointingHandCursor)
            btn_open.setToolTip("Mở Google Chrome với Profile riêng của kênh này")
            btn_open.clicked.connect(lambda _, c=ch: self.open_web_login(c))
            action_layout.addWidget(btn_open)

            self.table_accounts.setCellWidget(row, 7, action_widget)

        # Nạp bảng lịch sử đăng gần đây
        history = db.get_recent_history(limit=8)
        self.table_recent.clearContents()
        self.table_recent.setRowCount(len(history))
        for row, item in enumerate(history):
            c_raw = str(item.get('channel_name', '') or '-').strip()
            c_clean = c_raw.lstrip("@")
            c_display = f"🎬 @{c_clean}" if c_clean and c_clean != "-" else "-"
            self.table_recent.setItem(row, 0, QTableWidgetItem(c_display))
            self.table_recent.setItem(row, 1, QTableWidgetItem(item.get("video_title", "") or "-"))
            self.table_recent.setItem(row, 2, QTableWidgetItem(item.get("posted_at", "") or "-"))

            status = item.get("status", "")
            if status == "success":
                st_item = QTableWidgetItem("✅ Thành công")
                st_item.setForeground(Qt.green)
            else:
                st_item = QTableWidgetItem("❌ Thất bại")
                st_item.setForeground(Qt.red)
            st_item.setTextAlignment(Qt.AlignCenter)
            self.table_recent.setItem(row, 3, st_item)

            detail = item.get("post_url") or item.get("error_message") or "-"
            self.table_recent.setItem(row, 4, QTableWidgetItem(detail))

    def open_web_login(self, channel_data: dict):
        success, msg = chrome_mgr.launch_chrome_for_login(channel_data, "https://www.tiktok.com/")
        if not success:
            QMessageBox.critical(self, "Lỗi mở Chrome", msg)
            return
        from core.notifier import notifier
        notifier.notify(
            "🌐 Đang Mở Chrome Đăng Nhập",
            f"Đã mở Google Chrome cho kênh '{channel_data.get('name', '')}'.\nHệ thống sẽ TỰ ĐỘNG nhận diện và đồng bộ ngay khi bạn đăng nhập xong trên Web!",
            is_success=True
        )
        self.load_data()
