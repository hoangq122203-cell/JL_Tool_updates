# Giao diện chuẩn xác theo thiết kế Dark Slate Navy hiện đại:
# Nền đen xanh thẫm (#0C0E17), Sidebar (#10131F), Thẻ thẻ chỉ số (#141A2D)

DARK_THEME_QSS = """
/* ==================== GLOBAL STYLES ==================== */
QWidget {
    background-color: #0C0E17;
    color: #F1F5F9;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI Variable Text", "Segoe UI", system-ui, Roboto, "Helvetica Neue", Arial, sans-serif;
    font-size: 13px;
    selection-background-color: #2563EB;
    selection-color: #FFFFFF;
}

QMainWindow {
    background-color: #0C0E17;
}

/* ==================== GLOBAL TOOLTIP (CHỈ CHUỘT CHỮ TRẮNG RÕ RÀNG 100%) ==================== */
QToolTip {
    background-color: #1E293B;
    color: #FFFFFF;
    border: 1.5px solid #38BDF8;
    border-radius: 6px;
    padding: 6px 10px;
    font-size: 12px;
    font-weight: 600;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
}

/* ==================== SIDEBAR STYLES ==================== */
#sidebar {
    background-color: #10131F;
    border-right: 1px solid #1B2234;
    min-width: 250px;
    max-width: 250px;
}

#logoTitle {
    color: #FFFFFF;
    font-size: 14px;
    font-weight: 700;
    letter-spacing: 0.5px;
    padding-left: 4px;
}

#logoSubTitle {
    color: #64748B;
    font-size: 10px;
    padding-left: 4px;
}

QPushButton.nav-btn {
    background-color: transparent;
    color: #8C9BB0;
    border: none;
    border-radius: 6px;
    padding: 8px 12px;
    text-align: left;
    font-size: 13px;
    font-weight: 500;
}

QPushButton.nav-btn:hover {
    background-color: #171D2D;
    color: #FFFFFF;
}

QPushButton.nav-btn:checked {
    background-color: #232A3D;
    color: #FFFFFF;
    font-weight: 600;
}

/* ==================== CARDS & CONTAINERS ==================== */
QFrame.stat-card {
    background-color: #141A2D;
    border: 1px solid #222B42;
    border-radius: 8px;
    padding: 14px 16px;
}

QFrame.stat-card:hover {
    border: 1px solid #2D3A58;
    background-color: #161D32;
}

QLabel.stat-title {
    color: #8C9BB0;
    font-size: 11px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

QLabel.stat-value {
    color: #FFFFFF;
    font-size: 26px;
    font-weight: 800;
    margin-top: 2px;
}

QLabel.stat-desc {
    color: #64748B;
    font-size: 11px;
    margin-top: 2px;
}

QFrame.content-panel {
    background-color: #141A2D;
    border: 1px solid #222B42;
    border-radius: 8px;
    padding: 18px;
}

/* ==================== BUTTONS ==================== */
QPushButton.btn-primary {
    background-color: #2563EB;
    color: #FFFFFF;
    border: none;
    border-radius: 6px;
    padding: 8px 16px;
    font-weight: 600;
    font-size: 13px;
}

QPushButton.btn-primary:hover {
    background-color: #1D4ED8;
}

QPushButton.btn-primary:pressed {
    background-color: #1E40AF;
}

QPushButton.btn-secondary {
    background-color: #1C2337;
    color: #E2E8F0;
    border: 1px solid #2B3654;
    border-radius: 6px;
    padding: 7px 14px;
    font-weight: 500;
    font-size: 12px;
}

QPushButton.btn-secondary:hover {
    background-color: #242E48;
    border-color: #38476E;
    color: #FFFFFF;
}

QPushButton.btn-weblogin {
    background-color: #162438;
    color: #38BDF8;
    border: 1px solid #0284C7;
    border-radius: 6px;
    padding: 5px 10px;
    font-weight: 600;
    font-size: 12px;
}

QPushButton.btn-weblogin:hover {
    background-color: #0284C7;
    color: #FFFFFF;
}

QPushButton.btn-danger {
    background-color: #2E181D;
    color: #F87171;
    border: 1px solid #5C2229;
    border-radius: 6px;
    padding: 6px 12px;
    font-weight: 500;
}

QPushButton.btn-danger:hover {
    background-color: #EF4444;
    color: #FFFFFF;
}

/* ==================== INPUTS & CONTROLS ==================== */
QLineEdit, QTextEdit, QPlainTextEdit, QComboBox, QSpinBox, QDateEdit, QTimeEdit {
    background-color: #0A0B10;
    border: 1px solid #1E2433;
    border-radius: 6px;
    padding: 7px 10px;
    color: #FFFFFF;
    font-size: 13px;
    selection-background-color: #2563EB;
}

QLineEdit:focus, QTextEdit:focus, QPlainTextEdit:focus, QComboBox:focus {
    border: 1px solid #38BDF8;
    background-color: #0E121B;
}

QComboBox {
    background-color: #0A0B10;
    color: #FFFFFF;
    font-size: 13px;
    font-weight: 500;
}

QComboBox::drop-down {
    border: none;
    width: 24px;
}

QComboBox QAbstractItemView {
    background-color: #0A0B10;
    border: 1px solid #222B42;
    selection-background-color: #2563EB;
    selection-color: #FFFFFF;
    color: #FFFFFF;
    padding: 6px;
    font-size: 13px;
}

/* ==================== TABLES ==================== */
QTableWidget, QTableView {
    background-color: #101424;
    border: 1px solid #202940;
    border-radius: 6px;
    gridline-color: #182033;
    color: #F8FAFC;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI Variable Text", "Segoe UI", system-ui, Roboto, "Helvetica Neue", Arial, sans-serif;
    outline: none;
}

/* Loại bỏ hoàn toàn mọi vệt nền đen/khung đen dưới chữ và nhãn trong ô bảng */
QTableWidget QWidget, QTableView QWidget {
    background-color: transparent;
    background: transparent;
    border: none;
}

QTableWidget QFrame, QTableView QFrame {
    background-color: transparent;
    background: transparent;
    border: none;
}

QTableWidget::item {
    padding: 8px 10px;
    border-bottom: 1px solid #182033;
    color: #E2E8F0;
    font-size: 12px;
}

QTableWidget::item:selected {
    background-color: #1E273E;
    color: #FFFFFF;
}

QTableWidget::item:hover {
    background-color: #161D30;
}

QHeaderView::section {
    background-color: #141A2D;
    color: #94A3B8;
    padding: 8px 10px;
    border: none;
    border-bottom: 1px solid #222B42;
    font-weight: 700;
    font-size: 11px;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI Variable Text", "Segoe UI", system-ui, Roboto, "Helvetica Neue", Arial, sans-serif;
}

/* ==================== CHECKBOXES ==================== */
QCheckBox {
    color: #FFFFFF;
    font-size: 13px;
    spacing: 8px;
    background: transparent;
}

QCheckBox::indicator {
    width: 18px;
    height: 18px;
    border-radius: 4px;
    border: 1.5px solid #475569;
    background-color: #0F172A;
}

QCheckBox::indicator:hover {
    border: 1.5px solid #38BDF8;
    background-color: #1E293B;
}

QCheckBox::indicator:checked {
    background-color: #2563EB;
    border: 1.5px solid #60A5FA;
    image: url("assets/check_white.png");
}

QCheckBox::indicator:checked:hover {
    background-color: #1D4ED8;
    border: 1.5px solid #93C5FD;
    image: url("assets/check_white.png");
}

/* ==================== SCROLLBARS ==================== */
QScrollBar:vertical {
    border: none;
    background-color: #0C0E17;
    width: 8px;
    border-radius: 4px;
}

QScrollBar::handle:vertical {
    background-color: #222B42;
    min-height: 24px;
    border-radius: 4px;
}

QScrollBar::handle:vertical:hover {
    background-color: #2D3A58;
}

QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {
    height: 0px;
}

QScrollBar:horizontal {
    border: none;
    background-color: #0C0E17;
    height: 8px;
    border-radius: 4px;
}

QScrollBar::handle:horizontal {
    background-color: #222B42;
    min-width: 24px;
    border-radius: 4px;
}

QScrollBar::handle:horizontal:hover {
    background-color: #2D3A58;
}

QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal {
    width: 0px;
}

/* ==================== BADGES & TAGS ==================== */
QLabel.badge-vpn, QLabel[class="badge-vpn"] {
    background-color: #1E3A8A;
    color: #38BDF8;
    border: 1px solid #2563EB;
    border-radius: 5px;
    padding: 3px 8px;
    font-size: 11px;
    font-weight: 700;
    min-height: 22px;
}

QLabel.badge-proxy, QLabel[class="badge-proxy"] {
    background-color: #1E284A;
    color: #60A5FA;
    border: 1px solid #1D4ED8;
    border-radius: 5px;
    padding: 3px 8px;
    font-size: 11px;
    font-weight: 700;
    min-height: 22px;
}

QLabel.badge-direct, QLabel[class="badge-direct"] {
    background-color: #064E3B;
    color: #34D399;
    border: 1px solid #059669;
    border-radius: 5px;
    padding: 3px 8px;
    font-size: 11px;
    font-weight: 700;
    min-height: 22px;
}

/* ==================== CALENDAR & DATE TIME ==================== */
QCalendarWidget QWidget {
    background-color: #0E121E;
    color: #FFFFFF;
}

QCalendarWidget QAbstractItemView {
    background-color: #0A0B10;
    color: #FFFFFF;
    selection-background-color: #2563EB;
    selection-color: #FFFFFF;
    font-size: 12px;
}

QCalendarWidget QToolButton {
    background-color: #1C2337;
    color: #FFFFFF;
    border: 1px solid #2B3654;
    border-radius: 4px;
    padding: 4px;
    font-weight: 600;
}

/* ==================== GLOBAL TOOLTIP OVERRIDE (CHỮ TRẮNG 100%) ==================== */
QToolTip, QTableWidget QToolTip, QTableView QToolTip, QHeaderView QToolTip, QLabel QToolTip, QPushButton QToolTip {
    background-color: #1E293B;
    color: #FFFFFF;
    border: 1.5px solid #38BDF8;
    border-radius: 6px;
    padding: 6px 10px;
    font-size: 12px;
    font-weight: 600;
}
"""
