@echo off
setlocal enabledelayedexpansion
chcp 65001 >nul
title Cap Nhat JL Tool - 1-Click Update

cd /d "%~dp0"

echo ======================================================================
echo           TRINH CAP NHAT TU DONG JL TOOL (1-CLICK UPDATE)
echo ======================================================================
echo.

if not exist "%~dp0requirements.txt" goto NOT_EXTRACTED

echo [*] Dang kiem tra va dong JL Tool neu dang mo...
taskkill /f /im pythonw.exe >nul 2>&1
taskkill /f /im "JL Tool.exe" >nul 2>&1
timeout /t 1 /nobreak >nul 2>&1

:: Tim thu muc cai dat chinh cua khach hang tu APPDATA
set "INSTALL_DIR="
if exist "%APPDATA%\JL_Tool\install_dir.txt" (
    set /p INSTALL_DIR=<"%APPDATA%\JL_Tool\install_dir.txt"
)

:: Neu khong co trong APPDATA hoac da o dung thu muc
if "%INSTALL_DIR%"=="" set "INSTALL_DIR=%~dp0"
if not exist "%INSTALL_DIR%\main.py" set "INSTALL_DIR=%~dp0"

:: Neu khach giai nen ra thu muc khac, tu dong chep de vao thu muc goc
if /i not "%~dp0"=="%INSTALL_DIR%\" (
    if /i not "%~dp0"=="%INSTALL_DIR%" (
        echo [*] Dang tu dong dong bo ma nguon moi vao: %INSTALL_DIR%
        xcopy /s /y /i /q "%~dp0core" "%INSTALL_DIR%\core\" >nul 2>&1
        xcopy /s /y /i /q "%~dp0ui" "%INSTALL_DIR%\ui\" >nul 2>&1
        xcopy /s /y /i /q "%~dp0database" "%INSTALL_DIR%\database\" >nul 2>&1
        if exist "%~dp0assets" xcopy /s /y /i /q "%~dp0assets" "%INSTALL_DIR%\assets\" >nul 2>&1
        copy /y "%~dp0main.py" "%INSTALL_DIR%\" >nul 2>&1
        copy /y "%~dp0config.py" "%INSTALL_DIR%\" >nul 2>&1
        copy /y "%~dp0requirements.txt" "%INSTALL_DIR%\" >nul 2>&1
        if exist "%~dp0JL Tool.exe" copy /y "%~dp0JL Tool.exe" "%INSTALL_DIR%\" >nul 2>&1
        if exist "%~dp0Chay_JL_Tool.bat" copy /y "%~dp0Chay_JL_Tool.bat" "%INSTALL_DIR%\" >nul 2>&1
    )
)

echo [*] Dang kiem tra va cap nhat thu vien moi (yt-dlp, FFmpeg engine)...
set "PY_EXE="
if exist "%LOCALAPPDATA%\Programs\Python\Python311\python.exe" (
    set "PY_EXE=%LOCALAPPDATA%\Programs\Python\Python311\python.exe"
) else if exist "%LOCALAPPDATA%\Programs\Python\Python312\python.exe" (
    set "PY_EXE=%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
) else if exist "%LOCALAPPDATA%\Programs\Python\Python310\python.exe" (
    set "PY_EXE=%LOCALAPPDATA%\Programs\Python\Python310\python.exe"
) else (
    set "PY_EXE=python.exe"
)

"%PY_EXE%" -m pip install yt-dlp imageio-ffmpeg --quiet --no-warn-script-location >nul 2>&1

echo.
echo ======================================================================
echo [OK] DA CAP NHAT PHAN MEM JL TOOL HOAN TAT 100%!
echo.
echo * DU LIEU CUA BAN:
echo   - Toan bo Danh sach kenh TikTok da them van GIU NGUYEN 100%.
echo   - Toan bo Tai khoan da dang nhap van GIU NGUYEN 100%.
echo   - Toan bo Lich hen va Ban quyen may tinh van GIU NGUYEN 100%.
echo ======================================================================
echo.
echo Ban co the mo lai JL Tool ngoai man hinh Desktop de su dung ngay!
echo.
pause
exit /b 0

:NOT_EXTRACTED
echo ======================================================================
echo [!] BAN DANG BAM TRUC TIEP TRONG FILE NEN CHUA GIAI NEN!
echo.
echo Cach xu ly nhanh:
echo   1. Bam chuot phai vao file JL_Tool_Cap_Nhat.zip, chon Extract All...
echo   2. Mo thu muc vua giai nen va chay file Cap_Nhat_JL_Tool.bat!
echo ======================================================================
echo.
pause
exit /b 1
